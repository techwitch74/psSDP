<# Script name: Get-psSDP.ps1
 last edit by: waltere 2020-10-26
::
Copyright ^(C^) Microsoft. All rights reserved.
THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE 
USE OR OTHER DEALINGS IN THE SOFTWARE.
::
Purpose: Powershell Script to collect SDP (Support Diagnostic Platform) report
Help:  get-help .\Get-psSDP.ps1 -detailed
#> 

<#
.SYNOPSIS
The script generates Support Diagnostic Platform files to run in PowerShell window on your system.
One package to collect SDPs for different speciality reports (SDPtech), also able to collect Mini (*_msinfo.*, hotfixes.*, _sym.*, *_pstat.txt) or Nano (network) report.

.DESCRIPTION
The script generates Support Diagnostic files when running in an elevated PowerShell window on your system.
It will collect the same file set as done in classic CSS SDP troubleshooters.
To start data collection, open an elevated PowerShell CMD
Usage:
 .\Get-psSDP.ps1 [Apps|Cluster|S2D|SCCM|CTS|DA|Dom|DPM|HyperV|Net|Perf|Print|RDS|Setup|SQLbase|SQLconn|SQLmsdtc|SQLsetup|VSS|Mini|Nano|RFL|Repro|All]

If you get an error that running scripts is disabled, run 
	Set-ExecutionPolicy Bypass -force -Scope Process
and verify with 'Get-ExecutionPolicy -List' that no ExecutionPolicy with higher precedence is blocking execution of this script.
Then run ".\Get-psSDP.ps1 <speciality-of-SDP>" again.

Alternate method#1: to sign .ps1 scripts: run in elevated CMD 
  tss_PS1sign.cmd Get-psSDP
Alternate method#2: run in elevated Powershell: 
 Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass

.PARAMETER savePath
 This switch determines the path for output files
 
.PARAMETER UseExitCode
 This switch will cause the script to close after the error is logged if an error occurs.
 It is used to pass the error number back to the task scheduler or CMD script.

.PARAMETER noNetAdapters
 This switch will skip NetAdapters data collection in network section of SDPs

.PARAMETER runFull
 This switch will run full data collection in SETUP edition of SDPs

.PARAMETER localNodeOnly
 This switch will collect Cluster SDP on local node only
.PARAMETER skipBPA
 This switch will skip all Best Practice Analyzer (BPA) TroubleShooter
.PARAMETER skipHang
 This switch will skip steps in datacollection, that potentially could cause a hang situation during datacollection
 .PARAMETER skipHVreplica
 This switch will skip HyperV Replica script
 .PARAMETER skipCsvSMB
 This switch will skip Cluster tests "Testing accessing shares via SMB..."
.PARAMETER skipNetview
 This switch will skip Get-Netview output
.PARAMETER skipSddcDiag
 This switch will skip PrivateCloud.DiagnosticInfo output
.PARAMETER skipTS
 This switch will skip all TroubleShooter (TS and RC) scripts in TS_AutoAddCommands*.ps1 scripts
.PARAMETER skipTScluster
 This switch will skip Cluster TroubleShooter (TS and RC) scripts in TS_AutoAddCommands*.ps1 scripts
.PARAMETER skipXray
 This switch will skip xray troubleshooter, as it is perhaps already performed in TSS
 
.PARAMETER Transcript
 use -Transcript:$true to start PS Transcription, sometimes you may see error 'Transcription cannot be started.'
 
.PARAMETER sVersion
 use -sVersion to show script version
 
 .PARAMETER RoleType
 use -RoleType Client or -RoleType Server to distinguis between roles when using DA SDP
 
.EXAMPLE
 .\Get-psSDP.ps1 Net -savePath C:\temp
 for collecting SDP NETworking Diagnostic data, saving data to folder C:\temp
 
.EXAMPLE
 .\Get-psSDP.ps1 Mini
 for SDP Basic minimal data collection, saving data to current folder
 
.EXAMPLE
  .\Get-psSDP.ps1 Net -NoCab
  for SDP Net without zipping results
 
.LINK
email: waltere@microsoft.com
https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/psSDP
#>

[CmdletBinding()]
PARAM (
	[ValidateSet("Apps","Net","DA","Dom","DPM","CTS","Print","HyperV","Setup","Perf","Cluster","S2D","SCCM","RDS","Remote","SQLbase","SQLconn","SQLmsdtc","SQLsetup","VSS","mini","nano","Repro","RFL","All")]
	[Parameter(Mandatory=$False,Position=0,HelpMessage='Choose one technology from: Apps|Cluster|S2D|SCCM|CTS|DA|Dom|DPM|HyperV|Net|Perf|Print|RDS|Setup|SQLbase|SQLconn|SQLmsdtc|SQLsetup|VSS|Mini|Nano|Remote|Repro|RFL|All')]
	[string]$SDPtech = "Net"
	,
	[string]$savePath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[switch]$NoCab,					# skip zipping results
	[switch]$ZipIt,					#
	[switch]$noNetAdapters = $false,# skip NetAdapters data collection in network section of SDPs
	[switch]$skipBPA = $false,		# skip all Best Practice Analyzer (BPA) TroubleShooter
	[switch]$skipNetview = $false,	# skip Get-Netview output
	[switch]$skipSddcDiag = $false,	# skip PrivateCloud.DiagnosticInfo output _SddcDiag*
	[switch]$skipTS = $false,		# skip all TroubleShooter TS and RC scripts in TS_AutoAddCommands*.ps1
	[switch]$skipTScluster = $false,# skip all TroubleShooter TS and RC scripts in TS_AutoAddCommands*.ps1	
	[switch]$localNodeOnly = $true,	# use -localNodeOnly:$false to try collecting SDP info on all cluster nodes 
	[switch]$skipHang = $false,		# skip steps that potentially could cause a hang situation
	[switch]$skipHVreplica = $false,# skip HyperV Replica
	[switch]$skipCsvSMB = $false,	# skip Cluster tests "Testing accessing shares via SMB..."
	[switch]$skipXray = $false,		# skip xray troubleshooter
	[switch]$Transcript = $false,	# use -Transcript:$true to start PS Transcription 
	[switch]$runFull = $false,		# use -runFull:$true to run full Data collectors for Setup-Report
	[switch]$UseExitCode = $true,	# This will cause the script to close after the error is logged if an error occurs.
	[switch]$sVersion = $false,		# This will show current psSDP script version
	[ValidateSet("Client","Server")]
	[Parameter(Mandatory=$False,HelpMessage='Choose for role from: Client|Server')]
	[string]$RoleType = "Client"
	,
	[ValidateSet("on","off")]
	[Parameter(Mandatory=$False,HelpMessage='Debug facility: on|off')]
	[string]$Debug_script = "off"
	)

BEGIN {
  # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
  $startErrorActionPreference = $errorActionPreference
	$StartExecPolicy = Get-ExecutionPolicy -Scope Process
  $errorActionPreference = 'Continue' #'Stop'
  # This gets the current path and name of the script.
  $invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
  $scriptPath = Split-Path $invocation.MyCommand.Path
	$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
  $scriptName = $invocation.MyCommand.Name
	$computername 	= $env:computername
	$Script:PSver = $PSVersionTable.PSVersion.Major
	$CurrentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent()) 
  $isElev = ($CurrentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator))
	if (-not $isElev) { Write-Host -ForegroundColor Yellow "For complete SDP results it is recommended to start this script with elevated priv - Run as Administrator `n
			 === Please respond with 'y' to proceed, or 'n' key to exit.  ===`n" 
		do {
			$UserDone = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
			if ($UserDone.Character -ieq 'n') {exit}
		} until ($UserDone.Character -ieq 'y')

	}
	$ProcArch=$ENV:PROCESSOR_ARCHITECTURE
	if ("$ProcArch" -eq "AMD64") { Set-Variable -scope Global -name ProcessorArch -Value x64 }
	
	# Remember original ExecutionPolicy in Registry and temp changing policy based ExecutionPolicy
	$StartPSExePolicyReg= (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -ErrorAction SilentlyContinue).ExecutionPolicy
	if ($StartPSExePolicyReg) {Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass -ErrorAction SilentlyContinue}


	#region ### customization section of script, logging configuration -----------------------#
	$global:ToolsPath 	= "$ScriptParentPath\psSDP\Diag\global"
	$global:VerDate = "2021.04.12.0"
	$global:Publish_Date = "12-Apr-2021"
	# [string]$xrayActiveComponents = "DHCPsrv,802Dot1x,WLAN,Firewall"
	$ProcessWaitMin=10	# wait max minutes to complete MSinfo32
	#endregion ### customization section -----------------------------------------------------#
	
	if ($noNetAdapters) {Set-Variable -scope Global -name noNetAdapters -Value $true} else {if ($Global:noNetAdapters) {Clear-Variable -scope Global -name noNetAdapters}}
	if ($runFull) {Set-Variable -scope Global -name runFull -Value $true} else {if ($Global:runFull) {Clear-Variable -scope Global -name runFull}}
	if ($skipTS) {Set-Variable -scope Global -name skipTS -Value $true} else {if ($Global:skipTS) {Clear-Variable -scope Global -name skipTS}}
	if ($skipTScluster) {Set-Variable -scope Global -name skipTScluster -Value $true} else {if ($Global:skipTScluster) {Clear-Variable -scope Global -name skipTScluster}}
	if ($localNodeOnly) {Set-Variable -scope Global -name localNodeOnly -Value $true} else {if ($Global:localNodeOnly) {Clear-Variable -scope Global -name localNodeOnly}}
	if ($skipBPA) {Set-Variable -scope Global -name skipBPA -Value $true} else {if ($Global:skipBPA) {Clear-Variable -scope Global -name skipBPA}}
	if ($skipHang) {Set-Variable -scope Global -name skipHang -Value $true} else {if ($Global:skipHang) {Clear-Variable -scope Global -name skipHang}}
	if ($skipHVreplica) {Set-Variable -scope Global -name skipHVreplica -Value $true} else {if ($Global:skipHVreplica) {Clear-Variable -scope Global -name skipHVreplica}}
	if ($skipCsvSMB) {Set-Variable -scope Global -name skipCsvSMB -Value $true} else {if ($Global:skipCsvSMB) {Clear-Variable -scope Global -name skipCsvSMB}}
	if ($skipNetview) {Set-Variable -scope Global -name skipNetview -Value $true} else {if ($Global:skipNetview) {Clear-Variable -scope Global -name skipNetview}}
	if ($skipSddcDiag) {Set-Variable -scope Global -name skipSddcDiag -Value $true} else {if ($Global:skipSddcDiag) {Clear-Variable -scope Global -name skipSddcDiag}}
	if ($skipXray) {Set-Variable -scope Global -name skipXray -Value $true} else {if ($Global:skipXray) {Clear-Variable -scope Global -name skipXray}}

	#if ($RoleType) {Set-Variable -scope Global -name RoleType -Value $true} else {if ($Global:RoleType) {Clear-Variable -scope Global -name RoleType}}

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

	# Unblock all *.ps* and *.exe files in ToolsPath and below
	Get-ChildItem -Recurse $global:ToolsPath\*.ps*,$global:ToolsPath\*.exe | Unblock-File -Confirm:$false
	Get-ChildItem  $scriptPath\$ProcessorArch\*.* | Unblock-File -Confirm:$false
	Get-ChildItem  $scriptPath\xray\*.ps* | Unblock-File -Confirm:$false
	
	#region ::::: Helper Functions ::::
	function Get-TimeStamp { # SYNOPSIS:  Returns a timestamp string
		return "$(Get-Date -format "yyyyMMdd_HHmmss")"
	}
	function Get-TimeStampUTC { # SYNOPSIS:  Returns a UUTC timestamp string
		return (Get-Date).ToUniversalTime().ToString("yyMMdd-HHmmss")
	} 
	function Create-ZipFromDirectory { # SYNOPSIS:  Creates a ZIP file from a given directory
		<#
		.DESCRIPTION
		Creates a ZIP file from a given directory.

		.PARAMETER SourceDirectory
		The folder with the files you intend to zip.
		
		.PARAMETER ZipFileName
		The zip file that you intend to create
		
		.PARAMETER IncludeParentDirectory
		Setting this option will include the parent directory.
		
		.PARAMETER Overwrite
		Setting this option will overwrite the zip file if already exits.
		
		.EXAMPLE
		Create-ZipFromDirectory -Source $SourceDirectory -ZipFileName $ZipFileName -IncludeParentDirectory -Overwrite

		.EXAMPLE
		Create-ZipFromDirectory -S $SourceDirectory -O $ZipFileName -Rooted -Force
		#>

		PARAM
		(
			[Alias('S')]
			[Parameter(Position = 1, Mandatory = $true)]
			[ValidateScript({Test-Path -Path $_})]
			[string]$SourceDirectory,
		 
			[Alias('O')]
			[parameter(Position = 2, Mandatory = $false)]
			[string]$ZipFileName,

			[Alias('Rooted')]
			[Parameter(Mandatory = $false)]
			[switch]$IncludeParentDirectory,

			[Alias('Force')]
			[Parameter(Mandatory = $false)]
			[switch]$Overwrite
		)
		PROCESS
		{
			$ZipFileName = (("{0}.zip" -f $ZipFileName), $ZipFileName)[$ZipFileName.EndsWith('.zip', [System.StringComparison]::OrdinalIgnoreCase)]

			if(![System.IO.Path]::IsPathRooted($ZipFileName))
			{
				$ZipFileName = ("{0}\{1}" -f (Get-Location), $ZipFileName)
			}
						
			if($Overwrite)
			{
			  if(Test-Path($ZipFileName)){ Remove-Item $ZipFileName -Force -ErrorAction SilentlyContinue }
			}
			
			$source = Get-Item $SourceDirectory

			if ($source.PSIsContainer)
			{
				if($null -eq $newZipperAvailable)
				{
					try
					{
						$ErrorActionPreference = 'Stop'
						Add-Type -AssemblyName System.IO.Compression.FileSystem
						$newZipperAvailable = $true
					}
					catch
					{
						$newZipperAvailable = $false
					}
				}

				if($newZipperAvailable -eq $true) # More efficent and works silently.
				{
					[System.IO.Compression.ZipFile]::CreateFromDirectory($source.FullName, $ZipFileName, [System.IO.Compression.CompressionLevel]::Optimal, $IncludeParentDirectory)
				}
				else # Will show progress dialog.
				{

					# Preparing zip if not available.
					if(-not(Test-Path($ZipFileName)))
					{
						Set-Content $ZipFileName (“PK” + [char]5 + [char]6 + (“$([char]0)” * 18))
						(Get-ChildItem $ZipFileName).IsReadOnly = $false
					}

					if(-not $IncludeParentDirectory)
					{
						$source = Get-ChildItem $SourceDirectory
					}
				
					$zipPackage = (New-Object -ComObject Shell.Application).NameSpace($ZipFileName)
			
					[System.Int32]$NoProgressDialog = 16 #Tried but not effective.
					foreach($file in $source)
					{ 
						$zipPackage.CopyHere($file.FullName, $NoProgressDialog)
						do
						{
							Start-Sleep -Milliseconds 256
						}
						while ($zipPackage.Items().count -eq 0) # Waiting for an operation to complete.
					}
				}
				return $true
			}
			else
			{
				Write-Error 'The directory name is invalid.'
				return $false
			}
		}
	}
	function Write-Log { # SYNOPSIS:  Writes script information to a log file and to the screen when -Verbose is set
		PARAM (
			[Parameter(Mandatory=$true,Position=0)]
			[String]$logEntry,
			[switch]$tee = $false,
			[string]$foreColor = $null)

		$foreColors = "Black","Blue","Cyan","DarkBlue","DarkCyan","DarkGray","DarkGreen","DarkMagenta","DarkRed","DarkYellow","Gray","Green","Magenta","Red","White","Yellow"
		# check the log file, create if missing
		$isPath = Test-Path "$script:LogName"
		if (!$isPath) {
			"$(Get-TimeStamp): Local log file path: $("$script:LogName")"	| Out-File $script:LogName -Force
			"Start time (UTC):    $((Get-Date).ToUniversalTime())" 			| Out-File $script:LogName -Append
			"Start time (Local):  $((Get-Date).ToLocalTime()) $(if ((Get-Date).IsDaylightSavingTime()) {([System.TimeZone]::CurrentTimeZone).DaylightName} else {([System.TimeZone]::CurrentTimeZone).StandardName})`n" | Out-File $script:LogName -Append
			Write-Verbose " Local log file path: $("$script:LogName")"
		}

		$callStack = Get-PSCallStack
		if ($callStack.Count -gt 1) {
			$caller = $callStack[1].FunctionName + " " + (Split-Path -Path $callStack[1].ScriptName -Leaf).ToString() + ":" +  $callStack[1].ScriptLineNumber
		}
		$timestamp = (Get-Date -Format "yyyy/MM/dd HH:mm:ss.fffffff").ToString()
		# write into log
		"$timestamp [$caller]: $logEntry" | Out-File "$script:LogName" -Append
		# write logEntry verbosely to screen
		Write-Verbose $logEntry
		if ($tee)
		{
			# make sure the foreground color is valid
			if ($foreColors -contains $foreColor -and $foreColor) { Write-Host -ForegroundColor $foreColor $logEntry
			} else { Write-Host $logEntry }        
		}
	} # end function Write-Log
	function Add-Path { # SYNOPSIS: Adds a Directory to the Current Path
	 <#
		.SYNOPSIS
		 Adds a Directory to the Current Path | Join-Path ?
		.DESCRIPTION
		 Add a directory to the current path. This is useful for temporary changes to the path or, when run from your 
		 profile, for adjusting the path within your powershell prompt.
		.EXAMPLE
		 Add-Path -Directory "C:\Program Files\Notepad++"
		.PARAMETER Directory
		 The name of the directory to add to the current path.
	 #>

	 PARAM (
		[Parameter(
		 Mandatory=$True,
		 ValueFromPipeline=$True,
		 ValueFromPipelineByPropertyName=$True,
		 HelpMessage='What directory would you like to add?')]
		[Alias('dir')]
		[string[]]$Directory
	 )
	 PROCESS {
		$Path = $env:PATH.Split(';')
		foreach ($dir in $Directory) {
		 if ($Path -contains $dir) {
			Write-Log "$dir is already present in PATH"
		 } else {
			if (-not (Test-Path $dir)) {
			 Write-Log "$dir does not exist in the filesystem"
			} else {
			 $Path += $dir
			}
		 }
		}
		$env:PATH = [String]::Join(';', $Path)
	 }
	} #end function Add-Path
	function inform_onError { # SYNOPSIS: Inform user on error
		Write-Log -foreColor Gray -tee "`n [psSDP-Info] in case you see any red error messages regarding signing, [method#1] open an Admin Powershell CMD and run this command first:"
		Write-Log -foreColor White -tee "	 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force"
		Write-Log -foreColor Gray -tee   "     [Alternate method#2]: To self sign .ps1 scripts: run in elevated CMD"
		Write-Log -foreColor White -tee "         tss_PS1sign.cmd Get-psSDP"
		Write-Log -foreColor Gray -tee   "     [Alternate method#3a]: If scripts are blocked by MachinePolicy, run in elevated Powershell: "
		Write-Log -foreColor White -tee "	 Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass"
		Write-Log -foreColor White -tee "	 Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name EnableScripts  -Value 1 -Type DWord"
		Write-Log -foreColor Gray -tee   "     [Alternate method#3b]: If scripts are blocked by UserPolicy, run in elevated Powershell: "
		Write-Log -foreColor White -tee "	 Set-ItemProperty -Path HKLM:\Software\Microsoft\PowerShell\1\ShellIds\Microsoft.PowerShell -Name ExecutionPolicy -Value ByPass"
		Write-Log -foreColor White -tee "	 Set-ItemProperty -Path HKLM:\Software\Microsoft\PowerShell\1\ShellIds\Microsoft.PowerShell -Name EnableScripts  -Value 1 -Type DWord `n"
	} #end inform_onError
	function Move-stdout { # SYNOPSIS: move stdout.log into working folder
		if (Test-Path $ScriptParentPath\stdout*.log) 	{Move-Item $ScriptParentPath\stdout*.log $global:savePathTmp -Force}
		if (Test-Path $savePath\*SDPExecution.log) 		{Move-Item $ScriptParentPath\stdout*.log $global:savePathTmp -Force}
		if (Test-Path $savePath\*_LogFile_sdp.txt) 		{Move-Item $ScriptParentPath\*_LogFile_sdp.txt 	$global:savePathTmp -Force}
		if (Test-Path $savePath\stdout*.log) 			{Move-Item $savePath\stdout*.log 		$global:savePathTmp -Force}
		if (Test-Path $savePath\xray_*.*) 				{Move-Item $savePath\xray_*.* 			$global:savePathTmp -Force}
	}
	function Log-PSExecPolicy { # SYNOPSIS: log current Powershell ExecutionPolicy 
	" Current ExecutionPolicy: $(Get-ExecutionPolicy)" | Out-File "$script:LogName" -Append
	Get-ExecutionPolicy -List | Out-File "$script:LogName" -Append
	Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -EA SilentlyContinue | Out-File "$script:LogName" -Append
	Get-ItemProperty -Path HKLM:\Software\Microsoft\PowerShell\1\ShellIds\Microsoft.PowerShell -EA SilentlyContinue | Out-File "$script:LogName" -Append
	}
	function Run-xray { # SYNOPSIS: run xray troubleshooter for components
	PARAM (
			[String]$Component,
			[String]$Area,
			[String]$DataPath
		)
	"... running  xray troubleshooter for Area: $Area  - DataPath: $DataPath "| Out-File "$script:LogName" -Append
	Push-Location $ScriptParentPath\xray
		& "$ScriptParentPath\xray\xray.ps1" -DataPath $savePath -Area $Area -WaitBeforeClose
	Pop-Location
	}
	#endregion ::::: Helper Functions ::::
} #end BEGIN

PROCESS {
	<#
	Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred." | Write-host
		 "[info]: Exception.Message $ExceptionMessage." | Write-host
		 $Error.Clear()
		 continue
	}
	#>
	try {
		# Show only sVersion, then exit
		if ($sVersion) {Write-Host -ForegroundColor Cyan "psSDP Script Version: $global:VerDate"; exit 0}
		
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::
		$Global:SDPtech 		= $SDPtech
		$Global:RoleType 		= $RoleType
		$global:savePath		= $savePath
		$global:savePathTmp 	= "$savePath`\Results_$SDPtech`_$(Get-TimeStampUTC)"
		$TranscriptLog			= "$global:savePathTmp`\_psSDP_$SDPtech`_Transcript_$ComputerName`_$(Get-TimeStampUTC)`.Log"
		$script:LogName			= $global:savePathTmp + "\_psSDP-DiagLog_" + $(Get-TimeStampUTC) + ".txt"
		if (-NOT (Test-Path $global:savePathTmp)) {[void](new-item -path $global:savePathTmp -type directory)}
		Write-Log "Bound Param: " 
		$PSBoundParameters |ft 											| Out-File $script:LogName -Append
		Write-Log "ScriptParentPath: $ScriptParentPath"
		Write-Log "ToolsPath:        $global:ToolsPath"
		Write-Log "savePath:         $savePath"
		Write-Log "savePathTmp:      $global:savePathTmp"
		Log-PSExecPolicy
		##Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force -Whatif | Out-File "$script:LogName" -Append
		if (($Script:PSver -gt 2) -and ($Transcript -eq $true)) { Start-Transcript -Path $TranscriptLog }
		 else {Write-Log "... will not start Transcript log. -Transcript:$False or old PS version $Script:PSver"}
		Write-Host "$(Get-Date -Format 'HH:mm:ss') starting psSDP v$VerDate Data Collection Report for Windows Technology: '$SDPtech'" -ForegroundColor White -BackgroundColor DarkGreen
		Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "** -runFull: $Global:runFull -SkipTS: $Global:skipTS -SkipBPA: $Global:skipBPA  -skipNetView: $Global:skipNetview -skipSddcDiag: $Global:skipSddcDiag -noNetAdapters: $Global:noNetAdapters -skipHVreplica: $Global:skipHVreplica  -skipCsvSMB: $Global:skipCsvSMB -skipHang: $Global:skipHang -skipXray: $Global:skipXray"
		Write-Host "`n"
		if ($SDPtech -match "DA|Dom|DPM|Repro|SQLbase") {Write-Log -foreColor Yellow -tee "Note: You may be asked for additional input for '$SDPtech' report... "
											[System.Media.SystemSounds]::Hand.Play() } # Play sound to get some attention 

		### Debug output is stored in $env:TEMP\longGUID.txt i.e. d61ae9b514e84e5984cd8992acd1dd4b.txt
			switch($Debug_script)
				{
				"off"			{$Global:Debug=$false}
				"on"			{$Global:Debug=$true}
				} 

		$CurrentPath= get-location	# will jump back at end of script
		if (-NOT (Test-Path $global:savePathTmp\output)) {[void](new-item -path $global:savePathTmp\output -type directory)}	# for Filter UpdateDiagReport
		if (-NOT (Test-Path $global:savePathTmp\result)) {[void](new-item -path $global:savePathTmp\result -type directory)}	# in utils_CTS.ps1

		if (Test-Path $global:savePathTmp) {
			Add-Path -Directory "$global:ToolsPath", "$scriptPath\$ProcessorArch"
			Write-Log "___Path: $env:PATH"
			Push-Location -path $global:savePathTmp #$global:ToolsPath
			
			###  _Copy utils...
			if (-NOT ($SDPtech -match "mini|nano|RFL")) {
				Write-Log -foreColor White -tee "$(Get-Date -UFormat "%R:%S") _Copy utils..."
				Write-Log "_Copy-Item *.exe *.ico *.js *.mui *.vbs *.sql *.cs *.ps* *.xml *.xsl* Files to $($global:savePathTmp)\* -Force"
				[string[]]$Files = @("exe", "ico", "js", "mui", "vbs", "sql", "cs", "ps*", "xml", "xsl*")
				foreach ($File in $Files)
					{ 
					if ( Get-ChildItem -path "$global:ToolsPath`\*.$File" -ErrorAction SilentlyContinue ) {[void](Copy-Item "$global:ToolsPath`\*.$File" $global:savePathTmp -Force) }
					}
			}
			if ($SDPtech -match "mini|nano|RFL") {
				#	\Run_Discovery.ps1 and \ConfigXPLSchema.xml are needed in Discovery
				Write-Log "Copy-Item $global:ToolsPath`\Run_Discovery.ps1 $global:savePathTmp`\Run_Discovery.ps1 -Force"
				Copy-Item $global:ToolsPath`\Run_Discovery.ps1 $global:savePathTmp`\Run_Discovery.ps1 -Force
				Copy-Item $global:ToolsPath`\ConfigXPLSchema.xml $global:savePathTmp`\ConfigXPLSchema.xml -Force
				Copy-Item $global:ToolsPath`\GetEvents.VBS $global:savePathTmp`\GetEvents.VBS -Force
				if (Test-Path $global:ToolsPath`\results_$SDPtech`.xml) 			{Copy-Item $global:ToolsPath`\results_$SDPtech`.xml $global:savePathTmp`\results.xml -Force}
				}
			#_#Copy-Item ($global:ToolsPath + "\GetDiagInputResponse.xml") $global:savePathTmp\output -Force #was needed in DOM report - Answerfile Sec-Event
			# Create and copy Images
			if (-NOT (Test-Path $global:savePathTmp\Images)) {new-item -path $global:savePathTmp\Images -type directory |out-null}
			$imageFiles =$global:ToolsPath + "\images\*.png"
			Copy-Item $imageFiles ($global:savePathTmp + "\Images\") -Force
			Write-Log -foreColor White -tee "$(Get-Date -UFormat "%R:%S") _Copy utils... done"
			
			### Load Common Library
			Write-Log "_Load Common Library: $global:ToolsPath\utils_Cts.ps1"
			. "$global:ToolsPath\utils_Cts.ps1"
			. "$global:ToolsPath\Utils_Discovery.ps1"
			. "$global:ToolsPath\utils_Remote.ps1"	# Filter Update-Diagreport, Function Write-DiagProgress
			if ($SDPtech -match "CTS|All") {. "$global:ToolsPath\utils_DSD.ps1"
										. "$global:ToolsPath\utils_Exchange_all_exchange_versions_using_powershell_should_not_be_called_while_loading_powershell.ps1"
										. "$global:ToolsPath\utils_Exchange_all_exchange_versions_withoutpowershellaccess.ps1"
										. "$global:ToolsPath\utils_load20072010powershell.ps1"
										. "$global:ToolsPath\utils_loadex2013powershell.ps1" }

			$startTime_info32 = Get-Date
			Write-Log -foreColor White -tee "`n... starting script: TS_Main_$SDPtech`.ps1 (... please be patient until all modules finished ...)"
			### collect Mini (*_msinfo.*, hotfixes.*, _sym.*, *_pstat.txt) or Nano (network) report:
			if ($SDPtech -match "mini|nano|RFL") {
				$PSscript_Names = Get-Content "$global:ToolsPath\_Script_names_$($SDPtech).txt"
				foreach ($line in $PSscript_Names){
					if (-not $line.StartsWith('#')) {
						Write-Log -foreColor White -tee "$(Get-Date -UFormat "%R:%S") _running_ $line"
						& "$($global:ToolsPath)\$($line)"
						}
				}
			}
			
			else { ### collect various speciality reports (SDPtech):
				if (Test-Path $global:ToolsPath`\TS_AutoAddCommands_$SDPtech`.ps1)	{Copy-Item $global:ToolsPath`\TS_AutoAddCommands_$SDPtech`.ps1 $global:savePathTmp`\TS_AutoAddCommands.ps1 -Force}
				if (Test-Path $global:ToolsPath`\DiagPackage_$SDPtech`.diagpkg) 	{Copy-Item $global:ToolsPath`\DiagPackage_$SDPtech`.diagpkg $global:savePathTmp`\DiagPackage.diagpkg -Force}
				if (Test-Path $global:ToolsPath`\DiagPackage_$SDPtech`.dll) 		{Copy-Item $global:ToolsPath`\DiagPackage_$SDPtech`.dll $global:savePathTmp`\DiagPackage.dll -Force}
				if (Test-Path $global:ToolsPath`\results_$SDPtech`.xml) 			{Copy-Item $global:ToolsPath`\results_$SDPtech`.xml $global:savePathTmp`\results.xml -Force}
				# now run main SDP report
				& ".\TS_Main_$SDPtech.ps1"
				if ($Global:skipXray -ne $true) {
					#_# now run xray Troubleshooters for known trending issues
					#_# $TechAreas = @("ADS", "DND", "NET", "PRF", "SHA", "UEX") / * = All
						if ($Script:PSver -gt 1) { Write-Log "Run-xray -Area * -DataPath $global:savePathTmp"
													Run-xray -Area * -DataPath $global:savePathTmp}
						else {Write-Log "Skip xray, PS version: $Script:PSver "}
				} else {Write-Log "Skipping xray, PS version: $Script:PSver , skipXray: $Global:skipXray"}
				Write-Host "$(Get-Date -Format 'HH:mm:ss') *** end psSDP Report for Windows Technology: '$SDPtech'" -ForegroundColor White -BackgroundColor DarkGreen
			}
			#Start-Sleep -Seconds 120
			## remove Util files
			Write-Log "$(Get-Date -UFormat "%R:%S") _Remove utils..."  
			[string[]]$Files = @("*.exe", "*.dll", "*.ico", "*.js", "*.mui", "*.vbs", "*.sql", "*.cs", "*.ps*", "*.diagpkg", "*.xsl*", "*.xml")
			foreach ($File in $Files)
			{ 
				if ( Get-ChildItem -path "$global:savePathTmp\$File" -ErrorAction SilentlyContinue ) {[void](Remove-Item "$global:savePathTmp\$File" -Exclude $Env:computername`*.xml,results.xml,MachineInfo.xml -Force) }
			}
			# Remove empty Folders
			if (Test-Path .\EventLogs) {Remove-Item .\EventLogs -Recurse -Force}
			if (Test-Path .\Perfmon) {Remove-Item .\Perfmon -Recurse -Force}
			if (Test-Path .\RasTracingDir) {Remove-Item .\RasTracingDir -Recurse -Force}
			# Rename *.XML items
			if (Test-Path $global:savePathTmp`\$ENV:Computername`_EventLogAlerts.XML) 		{Rename-Item $global:savePathTmp`\$ENV:Computername`_EventLogAlerts.XML $global:savePathTmp`\$ENV:Computername`_EventLogAlerts.htm -Force}
			# Copy BPA html files
			if (Test-Path $ENV:USERPROFILE`\$ENV:Computername`*BPAInfo.HTM) {Copy-Item $ENV:USERPROFILE\$ENV:Computername*BPAInfo.HTM $global:savePathTmp\ -Force}
			if (Test-Path $scriptPath`\$ENV:Computername`*BPAInfo.*) 		{Move-Item $scriptPath\$ENV:Computername*BPAInfo.* $global:savePathTmp\ -Force}
			if (Test-Path $global:savePath`\BPAresults.*) 					{Move-Item $global:savePath`\BPAresults.* $global:savePathTmp\ -Force}
		
			# if started and still running: wait for msinfo32 to complete - moved to end before compress;  wait also on checkSym*.exe
			if (Get-Process msinfo32 -EA SilentlyContinue) {$nid = (Get-Process msinfo32).id } 
			if (Get-Process CheckSym* -EA SilentlyContinue) {$nidChkSym = (Get-Process CheckSym*).id }  
			if (($nid) -or ($nidChkSym)) {
				Write-Log -foreColor White -tee "$(Get-Date -UFormat "%R:%S") ...waiting max $ProcessWaitMin minutes on MsInfo32 PID $nid and/or CheckSym* PID $nidChkSym processes to complete"; 
						Wait-Process -Name msinfo32 -Timeout ($ProcessWaitMin * 60) -EA SilentlyContinue;
						Wait-Process -Name CheckSym* -Timeout ($ProcessWaitMin * 60) -EA SilentlyContinue
			}

			
			### begin compress -inner-
			if ($ZipIt.IsPresent) {
				$OutputFileZip = "psSDP_i_$SDPtech`_$ComputerName`_$(Get-TimeStampUTC)`.zip"
				Write-Log -foreColor White -tee "$(Get-Date -UFormat "%R:%S") ... zipping $OutputFileZip"
				$zipComp = CompressCollectFiles -Recursive -NumberofDays 1 -filesToCollect $global:savePathTmp -DestinationFileName $OutputFileZip -renameOutput $false -fileDescription "psSDP Logs" -sectionDescription "psSDP data collection" 
				if ($zipComp) {	Write-Log "_zipped $OutputFileZip" }
			}

			Move-stdout

			if (($Script:PSver -gt 2) -and ($Transcript -eq $true)) { try { Stop-Transcript | out-null} catch {} }
			 else {Write-Log -foreColor White "... Transcript log was not started. -Transcript:$False or old PS version $Script:PSver"}
			
			### begin compress files (zip cab)
			if ($NoCab.IsPresent -ne $true) {
				#$TimeStampUTC = Get-Date -Format "yyMMdd-HHmmss"
				$OutputFileZip = "$savePath`\tss_$(Get-TimeStampUTC)`_$ENV:ComputerName`_psSDP_$SDPtech`.zip"
				try {
					### Zip file if PowerShell v3 or higher is installed
					if ($Script:PSver -gt 2) { Write-Log -foreColor White -tee "$(Get-Date -UFormat "%R:%S") ... now zipping '$SDPtech' data folder $global:savePathTmp" 
												Write-Log "Resulting cabinet/zip: $OutputFileZip"
												$zipped = Create-ZipFromDirectory -SourceDirectory $global:savePathTmp -ZipFileName $OutputFileZip -overwrite }
					else {Write-Log -foreColor Yellow -tee "`n*** Please zip all results files in $global:savePathTmp and upload to workspace"}
					}
				catch {$zipped=$null;Write-Log -foreColor Red -tee "`n*** Failure during compression. Exception Message:`n $($_.Exception.Message)"}
			} #end compress
			else {Write-Log -foreColor Yellow -tee "`n*** Please zip all results files in $global:savePathTmp and upload to workspace"}

			#set-location -path $CurrentPath
			Pop-Location
			if ($zipped) {
				Write-Log "_Remove-Item $global:savePathTmp -Force -Recurse"
				Start-Sleep -Seconds 2
				Remove-Item $global:savePathTmp -Force -Recurse -EA SilentlyContinue
				Write-Host -ForegroundColor Green " [psSDP-Info] done. Resulting cabinet/zip: $OutputFileZip"
				}
		}
		#endregion: MAIN :::::
	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName v$VerDate caught an exception on $($ENV:COMPUTERNAME):`n`n"
		$errorMessage += "Exception Type:    $($_.Exception.GetType().FullName)`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		#echo $_.Exception|format-list -force
		$errMsg = $_.Exception|format-list -force; $line = $_.InvocationInfo.ScriptLineNumber; Write-Log "$errorMessage"; $line; Write-Log -foreColor Red -tee "[ERROR] v$VerDate Please report above error message in $scriptName line: $line - Elevated: $isElev"
		Move-stdout
		Start-Sleep -Seconds 2
		Write-Debug $errorMessage
		$ErrorThrown = $true
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
  } #end Catch PROCESS
	Finally {
		if (Test-Path $global:savePathTmp) {
			$TmpCnt = (get-childitem $global:savePathTmp).count 
			if ($TmpCnt -eq 0) {Remove-Item $global:savePathTmp -ErrorAction SilentlyContinue}
		}
		if($ErrorThrown) { inform_onError }
		# Reset original ExecutionPolicy
		Set-ExecutionPolicy -Scope Process -ExecutionPolicy $StartExecPolicy -Force -ErrorAction SilentlyContinue
		# Reset original ExecutionPolicy in Registry
		if ($StartPSExePolicyReg) {Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value $StartPSExePolicyReg}
		if ($Script:PSver -gt 2) { Unblock-File -Path $ScriptParentPath\Get-psSDP.ps1 -ErrorAction SilentlyContinue 
									try { Stop-Transcript | out-null} catch {} # Stop-Transcript in case of any error
		}
	} #end Finally PROCESS
} #end PROCESS


END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	#$LogLevel = 0
	if($ErrorThrown) {Throw $error[0].Exception.Message}

	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done on this PC $env:COMPUTERNAME; script $scriptName '$SDPtech' v$VerDate took $Duration"
	[System.Media.SystemSounds]::Hand.Play() # Play sound to signal end of SDP data collection
	
  # This resets the ErrorActionPreference to the value at script start.
  $errorActionPreference = $startErrorActionPreference
} #end END

#region: comments
<# Info:
Files collected within SDP report:
- "Net","DA","Dom","DPM","CTS","Print","HyperV","Perf","Setup","Cluster","Mini","Nano","RFL","All"

 2027424	[SDP 3][d92078bc-87a3-492b-978e-1f91d4eaaed9] Windows Printing
 http://support.microsoft.com/kb/2027424/EN-US
 2224427	[SDP 2][9B947211-ED5B-4BAE-85A5-823B8718DB59] Setup - Windows XP, Server 2003, Windows Vista, and Windows Server 2008 MSDT manifest
 http://support.microsoft.com/kb/2224427/EN-US
 2415016	[SDP 3][62ec9a58-1f9e-4550-b65c-87827221dd05] FailoverCluster Multinode troubleshooter for Windows Server
 http://support.microsoft.com/kb/2415016/EN-US


VERSION and AUTHORs:
    Ver 1.00 - 12.03.2017
	Walter Eder	- waltere@microsoft.com

HISTORY
**psSDP Revision History** - see online https://github.com/CSS-Windows/WindowsDiag/blob/master/ALL/psSDP/revision-history.txt
Version number=Change Date | Notes
2021.04.12.0 add SCCM
2021.03.30.0 add RDS
2021.03.17.0 add Get-WindowsUpdateLog to skipHang
2021.02.02.0 upd GetNetview; Hyper-V Shielded VM EventLogs
2021.01.26.0 skipHang for DC_W32Time.ps1
2021.01.13.0 skipHang for TS_DumpCollector
2020.12.16.0 upd xray 201217
2020.12.16.0 fixed AutorunsC, replaced .exe with older version
2020.12.09.0 added DPM
2020.11.03.0 upd DNSsrv
2020.11.02.0 upd xray
2020.10.26.0 added CscDbDump for NET
2020.10.16.0 include reg.Hives
2020.08.20.0 fixed CORE running without 'Get-ClusterNode'
2020.08.15.0 upd Get_SmbShare, UTC time
2020.06.14.0 upd xray, added ReFs event log collection to Setup, Hyper-V, Cluster and S2D SDP logs
2020.06.01.0 remove XP/W2k3
2020.05.31.0 upd xray
2020.05.07.0 run xray, if PSver > 4.0 run xray, if PSver > 1
2020.05.07.0 run xray, if PSver > 4
2020.04.24.0 upd xray, SQL
2020.04.22.1 upd xray; added Schannel to DS_regEntries
2020.04.19.1 activated xray; SDDC
2020.04.13.2 upd of many troubleshooter to run on Win10; add SkipXray
	
ToDo: handle utils_Remote.ps1:Function Get-DiagInput :: in DC_CollectSecurityEventLog.ps1 (done), DC_DfsrInfo.ps1, DC_HyperVReplica.ps1, DC_ServerCoreR2Setup.ps1, TS_RemoteSetup.ps1, TS_SelectClusterNodes.ps1 
	- only run once CTS report, else errors: New-Variable : Cannot overwrite variable SQL:PSSDIAGXML because it is read-only or constant.
	- findstr /i /c:"get-diaginput" *.*
	- consider adding for DOM: ADdiag - see https://techcommunity.microsoft.com/t5/ask-the-directory-services-team/son-of-spa-ad-data-collector-sets-in-win2008-and-beyond/ba-p/397893
#>
#endregion: comments

