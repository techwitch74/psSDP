<# Script name: Get-psSDP.ps1
 last edit by: waltere 2019-03-20
::
Copyright ^(C^) Microsoft. All rights reserved.
THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. 
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR 
OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE 
USE OR OTHER DEALINGS IN THE SOFTWARE.
::
Purpose: Powershell Script to collect SDP (Support Diagnostic Platform) report
Help:    get-help .\Get-psSDP.ps1 -detailed
#> 

<#
.SYNOPSIS
The script generates Support Diagnostic Platform files to run in PowerShell window on your system.
One package to collect SDPs for different speciality reports (SDPtech), also able to collect Mini (*_msinfo.*, hotfixes.*, _sym.*, *_pstat.txt) or Nano (network) report.

.DESCRIPTION
The script generates Support Diagnostic files when running in an elevated PowerShell window on your system.
It will collect the same file set as done in classic CSS SDP troubleshooters.
To start data collection, open an elevated PowerShell CMD
Usage:
 .\Get-psSDP.ps1 [Cluster|CTS|Dom|HyperV|Net|Perf|Print|Setup|SQLbase|Mini|Nano|All]

If you get an error that running scripts is disabled, run 
	Set-ExecutionPolicy Bypass -force -Scope Process
and verify with 'Get-ExecutionPolicy -List' that no ExecutionPolicy with higher precedence is blocking execution of this script.
Then run ".\Get-psSDP.ps1 <speciality-of-SDP>" again.

Alternate method#1: to sign .ps1 scripts: run in elevated CMD 
   tss_PS1sign.cmd Get-psSDP
Alternate method#2: run in elevated Powershell: 
  Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass

.PARAMETER UseExitCode
  This switch will cause the script to close after the error is logged if an error occurs.
  It is used to pass the error number back to the task scheduler or CMD script.

.PARAMETER noNetAdapters
  This switch will skip NetAdapters data collection in network section of SDPs

.PARAMETER skipTS
  This switch will skip all TroubleShooter (TS and RC) scripts in TS_AutoAddCommands*.ps1 scripts
.PARAMETER skipTScluster
  This switch will skip Cluster TroubleShooter (TS and RC) scripts in TS_AutoAddCommands*.ps1 scripts
    
.PARAMETER skipBPA
  This switch will skip all Best Practice Analyzer (BPA) TroubleShooter

.PARAMETER Transcript
  use -Transcript:$false to avoid PS Transcription, i.e. if you see error 'Transcription cannot be started.'
  
.EXAMPLE
  .\Get-psSDP.ps1 Net -savePath C:\temp
  for collecting SDP NETworking Diagnostic data, saving data to folder C:\temp
  
.EXAMPLE
  .\Get-psSDP.ps1 Mini
  for SDP Basic minimal data collection, saving data to current folder
  
.EXAMPLE
   .\Get-psSDP.ps1 Net -NoCab
   for SDP Net without zipping results
  
.LINK
email: waltere@microsoft.com
https://github.com/CSS-Windows/WindowsDiag/tree/master/ALL/psSDP
#>

[CmdletBinding()]
PARAM (
	[ValidateSet("Net","Dom","CTS","Print","HyperV","Setup","Perf","Cluster","Remote","SQLbase","mini","nano","Repro","RFL","All")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose one technology from: Cluster|CTS|Dom|HyperV|Net|Perf|Print|Setup|SQLbase|Mini|Nano|Remote|RFL|All')]
	[string]$SDPtech
	,
	[string]$savePath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[switch]$NoCab,					# skip zipping results
	[switch]$ZipIt,					#
	[switch]$noNAPServer = $false, 	# skip NAPServer data collection in network section of SDPs
	[switch]$noNAPClient = $false,	# skip NAPClient data collection in network section of SDPs
	[switch]$noNetAdapters = $false,# skip NetAdapters data collection in network section of SDPs
	[switch]$skipBPA = $false,		# skip all Best Practice Analyzer (BPA) TroubleShooter
	[switch]$skipTS = $false,		# skip all TroubleShooter TS and RC scripts in TS_AutoAddCommands*.ps1
	[switch]$skipTScluster = $false,	# skip all TroubleShooter TS and RC scripts in TS_AutoAddCommands*.ps1	
	[switch]$Transcript = $true,	# use -Transcript:$false to avoid PS Transcription 
	[switch]$UseExitCode = $true	# This will cause the script to close after the error is logged if an error occurs.
	,
	[ValidateSet("on","off")]
	[Parameter(Mandatory=$False,HelpMessage='Debug facility: on|off')]
	[string]$Debug_script = "off"
	)

BEGIN {
    # This saves the starting ErrorActionPreference and then sets it to 'Stop'.
    $startErrorActionPreference = $errorActionPreference
	$StartExecPolicy = Get-ExecutionPolicy -Scope Process
    $errorActionPreference = 'Continue' #'Stop'
    # This gets the current path and name of the script.
    $invocation = (Get-Variable MyInvocation).Value
	$invocationLine= $($MyInvocation.Line)
    $scriptPath = Split-Path $invocation.MyCommand.Path
	$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
    $scriptName = $invocation.MyCommand.Name
	$computername 	= $env:computername
	$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
	$Script:PSver = $PSVersionTable.PSVersion.Major
	$CurrentUser = New-Object Security.Principal.WindowsPrincipal $([Security.Principal.WindowsIdentity]::GetCurrent()) 
	$isElev = ($CurrentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator))
	$ProcArch=$ENV:PROCESSOR_ARCHITECTURE
	if ("$ProcArch" -eq "AMD64") { Set-Variable -scope Global -name ProcessorArch -Value x64 }
    #Write-Host "Running `"$scriptPath\$scriptName`"..." -BackgroundColor Black -ForegroundColor Green
	
	# Remember original ExecutionPolicy in Registry and temp changing policy based ExecutionPolicy
	$StartPSExePolicyReg= (Get-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -ErrorAction SilentlyContinue).ExecutionPolicy
	if ($StartPSExePolicyReg) {Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass -ErrorAction SilentlyContinue} else { }


	#region: ###### customization section of script, logging configuration ########################
	$global:ToolsPath 	= "$ScriptParentPath\psSDP\Diag\global"
	$VerMa="1"
	$VerMi="10.08"
	$MsInfo32waitMin=4	# wait x minutes to complete MSinfo32
	#endregion: ###### customization section 
	
	if ($noNAPClient) {Set-Variable -scope Global -name no_NAPClient -Value $true} else { if ($Global:no_NAPClient) {Clear-Variable -scope Global -name no_NAPClient}}
	if ($noNAPServer) {Set-Variable -scope Global -name no_NAPServer -Value $true} else {if ($Global:no_NAPServer) {Clear-Variable -scope Global -name no_NAPServer}}
	if ($noNetAdapters) {Set-Variable -scope Global -name no_NetAdapters -Value $true} else {if ($Global:no_NetAdapters) {Clear-Variable -scope Global -name no_NetAdapters}}
	if ($skipTS) {Set-Variable -scope Global -name skipTS -Value $true} else {if ($Global:skipTS) {Clear-Variable -scope Global -name skipTS}}
	if ($skipTScluster) {Set-Variable -scope Global -name skipTScluster -Value $true} else {if ($Global:skipTScluster) {Clear-Variable -scope Global -name skipTScluster}}
	if ($skipBPA) {Set-Variable -scope Global -name skipBPA -Value $true} else {if ($Global:skipBPA) {Clear-Variable -scope Global -name skipBPA}}

	If ($PSBoundParameters['Debug']) { $DebugPreference='Continue'}

	#$global:ToolsPath = $global:ToolsPath

	
	#region: Script Functions
	#region ::::: Helper Functions ::::
	function Get-TimeStamp {
	 # SYNOPSIS:   Returns a timestamp string
	 return "$(Get-Date -format "yyyyMMdd_HHmmss_ffff")"
	} # end Get-TimeStamp

	Function Zip-Files(
			[Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$false)]
			[string] $zipfilename,
			[Parameter(Position=1, Mandatory=$true, ValueFromPipeline=$false)]
			[string] $sourcedir,
			[Parameter(Position=2, Mandatory=$false, ValueFromPipeline=$false)]
			[bool] $overwrite)
		{
			if ($Script:PSver -le 2) 
				{ Write-Output "Compression not supported for this PS version: $Script:PSver"
				return $false
				}
			else {
				Add-Type -Assembly System.IO.Compression.FileSystem
				$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
				if ($overwrite -eq $true ) { if (Test-Path $zipfilename) { Remove-Item $zipfilename } }
				[System.IO.Compression.ZipFile]::CreateFromDirectory($sourcedir, $zipfilename, $compressionLevel, $false)
				return $true
			}
		}

	function Create-ZipFromDirectory {
		<#
		.DESCRIPTION
		Creates a ZIP file from a given directory.

		.PARAMETER SourceDirectory
		The folder with the files you intend to zip.
		
		.PARAMETER ZipFileName
		The zip file that you intend to create
		
		.PARAMETER IncludeParentDirectory
		Setting this option will include the parent directory.
		
		.PARAMETER Overwrite
		Setting this option will overwrite the zip file if already exits.
		
		.EXAMPLE
		Create-ZipFromDirectory -Source $ResultRootDirectory -ZipFileName $CompressedResultFileName -IncludeParentDirectory -Overwrite

		.EXAMPLE
		Create-ZipFromDirectory -S $ResultRootDirectory -O $CompressedResultFileName -Rooted -Force
		#>

		PARAM
		(
			[Alias('S')]
			[Parameter(Position = 1, Mandatory = $true)]
			[ValidateScript({Test-Path -Path $_})]
			[string]$SourceDirectory,
		 
			[Alias('O')]
			[parameter(Position = 2, Mandatory = $false)]
			[string]$ZipFileName,

			[Alias('Rooted')]
			[Parameter(Mandatory = $false)]
			[switch]$IncludeParentDirectory,

			[Alias('Force')]
			[Parameter(Mandatory = $false)]
			[switch]$Overwrite
		)
		PROCESS
		{
			$ZipFileName = (("{0}.zip" -f $ZipFileName), $ZipFileName)[$ZipFileName.EndsWith('.zip', [System.StringComparison]::OrdinalIgnoreCase)]

			if(![System.IO.Path]::IsPathRooted($ZipFileName))
			{
				$ZipFileName = ("{0}\{1}" -f (Get-Location), $ZipFileName)
			}
						
			if($Overwrite)
			{
			   if(Test-Path($ZipFileName)){ Remove-Item $ZipFileName -Force -ErrorAction SilentlyContinue }
			}
			
			$source = Get-Item $SourceDirectory

			if ($source.PSIsContainer)
			{
				if($newZipperAvailable -eq $null)
				{
					try
					{
						$ErrorActionPreference = 'Stop'
						Add-Type -AssemblyName System.IO.Compression.FileSystem
						$newZipperAvailable = $true
					}
					catch
					{
						$newZipperAvailable = $false
					}
				}

				if($newZipperAvailable -eq $true) # More efficent and works silently.
				{
					[System.IO.Compression.ZipFile]::CreateFromDirectory($source.FullName, $ZipFileName, [System.IO.Compression.CompressionLevel]::Optimal, $IncludeParentDirectory)
				}
				else # Will show progress dialog.
				{

					# Preparing zip if not available.
					if(-not(Test-Path($ZipFileName)))
					{
						Set-Content $ZipFileName (“PK” + [char]5 + [char]6 + (“$([char]0)” * 18))
						(dir $ZipFileName).IsReadOnly = $false
					}

					if(-not $IncludeParentDirectory)
					{
						$source = Get-ChildItem $SourceDirectory
					}
				
					$zipPackage = (New-Object -ComObject Shell.Application).NameSpace($ZipFileName)
			
					[System.Int32]$NoProgressDialog = 16 #Tried but not effective.
					foreach($file in $source)
					{ 
						$zipPackage.CopyHere($file.FullName, $NoProgressDialog)
						do
						{
							Start-Sleep -Milliseconds 256
						}
						while ($zipPackage.Items().count -eq 0) # Waiting for an operation to complete.
					}
				}
				return $true
			}
			else
			{
				Write-Error 'The directory name is invalid.'
				return $false
			}
		}
	}
	function Add-Path {
	  <#
		.SYNOPSIS
		  Adds a Directory to the Current Path
		.DESCRIPTION
		  Add a directory to the current path.  This is useful for temporary changes to the path or, when run from your 
		  profile, for adjusting the path within your powershell prompt.
		.EXAMPLE
		  Add-Path -Directory "C:\Program Files\Notepad++"
		.PARAMETER Directory
		  The name of the directory to add to the current path.
	  #>

	  [CmdletBinding()]
	  param (
		[Parameter(
		  Mandatory=$True,
		  ValueFromPipeline=$True,
		  ValueFromPipelineByPropertyName=$True,
		  HelpMessage='What directory would you like to add?')]
		[Alias('dir')]
		[string[]]$Directory
	  )

	  PROCESS {
		$Path = $env:PATH.Split(';')

		foreach ($dir in $Directory) {
		  if ($Path -contains $dir) {
			Write-Verbose "$dir is already present in PATH"
		  } else {
			if (-not (Test-Path $dir)) {
			  Write-Verbose "$dir does not exist in the filesystem"
			} else {
			  $Path += $dir
			}
		  }
		}

		$env:PATH = [String]::Join(';', $Path)
	  }
	}
	<#
	$value = Get-ItemProperty -Path HKCU:\Environment -Name Path
	$newpath = $value.Path += ";C:\src\bin\"
	Set-ItemProperty -Path HKCU:\Environment -Name Path -Value $newpath
	#>
	
	#endregion ::::: Helper Functions ::::
	#endregion: Script Functions
} #end BEGIN

PROCESS {
	Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | Write-host
		 "[info]: Exception.Message $ExceptionMessage."  | Write-host
		 $Error.Clear()
		 continue
	}
	try {
		$ScriptBeginTimeStamp = Get-Date
		#region: MAIN :::::
		$Global:SDPtech = $SDPtech
		$global:savePathTmp 	= "$savePath`\Results_$SDPtech`_$(Get-Timestamp)"
		#$global:savePathTmp = $global:savePathTmp 
		$TranscriptLog	= "$global:savePathTmp`\_psSDP_$SDPtech`_Transcript_$ComputerName`_$CheckDate`.Log"
		write-verbose "ScriptParentPath $ScriptParentPath"
		write-verbose "ToolsPath        $global:ToolsPath"
		write-verbose "savePath         $savePath"
		write-verbose "savePathTmp      $global:savePathTmp"
		Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
		if (($Script:PSver -gt 2) -and ($Transcript)) { Start-Transcript -Path $TranscriptLog }
		else {Write-Host  "... will not start Transcript log. -Transcript:$False or old PS version $Script:PSver"}
		Write-Host "$(Get-Date -Format 'HH:mm:ss') starting psSDP v$VerMa.$VerMi Data Collection Report for Windows Technology: '$SDPtech'" -ForegroundColor White -BackgroundColor DarkGreen
		if ($SDPtech -match "Dom|Cluster") {Write-Host "Note: You may be asked for additional input for '$SDPtech' report... " -ForegroundColor Yellow
											[System.Media.SystemSounds]::Hand.Play() } # Play sound to get some attention 

		### Debug output is stored in $env:TEMP\longGUID.txt i.e. d61ae9b514e84e5984cd8992acd1dd4b.txt
			switch($Debug_script)
				{
				"off"			{$Debug=$false}
				"on"			{$Debug=$true}
				} 

		$CurrentPath= get-location	# will jump back at end of script
		if (-NOT (Test-Path $global:savePathTmp)) {[void](new-item -path $global:savePathTmp -type directory)}
		if (-NOT (Test-Path $global:savePathTmp\output)) {[void](new-item -path $global:savePathTmp\output -type directory)}	# for Filter UpdateDiagReport
		if (-NOT (Test-Path $global:savePathTmp\result)) {[void](new-item -path $global:savePathTmp\result -type directory)}	# in utils_CTS.ps1

		if (Test-Path $global:savePathTmp) {
			Add-Path -Directory "$global:ToolsPath", "$scriptPath\$ProcessorArch"
			Write-host "___Path: $env:PATH"
			set-location -path $global:savePathTmp
			
			if (-NOT ($SDPtech -match "mini|nano|RFL")) {
				Write-host "$(Get-Date -UFormat "%R:%S") _Copy utils..."
				Write-Verbose "_Copy-Item *.exe *.dll *.vbs *.sql *.cs *.ps* *.xml *.xsl Files to $($global:savePathTmp)\* -Force"
				#[string[]]$Files = @("exe", "dll", "ico", "js", "mui", "vbs", "sql", "cs", "ps*", "xml", "xsl")
				[string[]]$Files = @("ico", "js", "mui", "vbs", "sql", "cs", "ps*", "xml", "xsl")
				foreach ($File in $Files)
					{ 
					if ( Get-ChildItem -path "$global:ToolsPath`\*.$File" -ErrorAction SilentlyContinue ) {[void](Copy-Item "$global:ToolsPath`\*.$File" $global:savePathTmp -Force) }
					}
			}
			if ($SDPtech -match "mini|nano|RFL") {
				#	\Run_Discovery.ps1 and \ConfigXPLSchema.xml are needed in Discovery
				Write-Verbose "Copy-Item $global:ToolsPath`\Run_Discovery.ps1 $global:savePathTmp`\Run_Discovery.ps1 -Force"
				Copy-Item $global:ToolsPath`\Run_Discovery.ps1 $global:savePathTmp`\Run_Discovery.ps1 -Force
				Copy-Item $global:ToolsPath`\ConfigXPLSchema.xml $global:savePathTmp`\ConfigXPLSchema.xml -Force
				Copy-Item $global:ToolsPath`\GetEvents.VBS $global:savePathTmp`\GetEvents.VBS -Force
				}
			#_#Copy-Item ($global:ToolsPath + "\GetDiagInputResponse.xml") $global:savePathTmp\output -Force #was needed in DOM report - Answerfile Sec-Event
			# Create and copy Images
			if (-NOT (Test-Path $global:savePathTmp\Images)) {new-item -path $global:savePathTmp\Images -type directory |out-null}
			$imageFiles =$global:ToolsPath + "\images\*.png"
			Copy-Item $imageFiles ($global:savePathTmp + "\Images\")  -Force
			Write-host "$(Get-Date -UFormat "%R:%S") _Copy utils... done"
			#}
			
			### Load Common Library
			Write-Verbose "_Load Common Library: $global:ToolsPath\utils_Cts.ps1"
			. "$global:ToolsPath\utils_Cts.ps1"
			. "$global:ToolsPath\Utils_Discovery.ps1"
			. "$global:ToolsPath\utils_Remote.ps1"	# Filter Update-Diagreport, Function Write-DiagProgress
			if ($SDPtech -match "CTS|All") {. "$global:ToolsPath\utils_DSD.ps1"
										. "$global:ToolsPath\utils_Exchange_all_exchange_versions_using_powershell_should_not_be_called_while_loading_powershell.ps1"
										. "$global:ToolsPath\utils_Exchange_all_exchange_versions_withoutpowershellaccess.ps1"
										. "$global:ToolsPath\utils_load20072010powershell.ps1"
										. "$global:ToolsPath\utils_loadex2013powershell.ps1" }

			$startTime_info32 = Get-Date
			Write-Host "... starting script: TS_Main_$SDPtech`.ps1 (... please be patient until all modules finished ...)"
			### collect Mini (*_msinfo.*, hotfixes.*, _sym.*, *_pstat.txt) or Nano (network) report:
			if ($SDPtech -match "mini|nano|RFL") {
				$PSscript_Names = Get-Content "$global:ToolsPath\_Script_names_$($SDPtech).txt"
				foreach ($line in $PSscript_Names){
					if (-not $line.StartsWith('#')) {
						"$(Get-Date -UFormat "%R:%S") _running_ $line"
						& "$($global:ToolsPath)\$($line)"
						}
				}
			}
			##### collect various speciality reports (SDPtech):
			else {
				if (Test-Path $global:ToolsPath`\TS_AutoAddCommands_$SDPtech`.ps1) {Copy-Item $global:ToolsPath`\TS_AutoAddCommands_$SDPtech`.ps1 $global:savePathTmp`\TS_AutoAddCommands.ps1 -Force}
				if (Test-Path $global:ToolsPath`\DiagPackage_$SDPtech`.diagpkg) 	{Copy-Item $global:ToolsPath`\DiagPackage_$SDPtech`.diagpkg $global:savePathTmp`\DiagPackage.diagpkg -Force}
				if (Test-Path $global:ToolsPath`\DiagPackage_$SDPtech`.dll) 		{Copy-Item $global:ToolsPath`\DiagPackage_$SDPtech`.dll $global:savePathTmp`\DiagPackage.dll -Force}
				if (Test-Path $global:ToolsPath`\results_$SDPtech`.xml) 			{Copy-Item $global:ToolsPath`\results_$SDPtech`.xml $global:savePathTmp`\results.xml -Force}
				& ".\TS_Main_$SDPtech.ps1"
				Write-Host "$(Get-Date -Format 'HH:mm:ss') *** end psSDP Report for Windows Technology: '$SDPtech'" -ForegroundColor White -BackgroundColor DarkGreen
			}

			#if (-NOT ($SDPtech -match "mini|nano|RFL")) {
				## remove Util files
				Write-Verbose "$(Get-Date -UFormat "%R:%S") _Remove utils..." #   
				[string[]]$Files = @("*.exe", "*.dll", "*.ico", "*.js", "*.mui", "*.vbs", "*.sql", "*.cs", "*.ps*", "*.diagpkg", "*.xsl", "results_*.xml", "WUErrors.xml", "SystemPerformance.xml", "PSSDiag.XML", "GetDiagInputResponse.xml", "EventLogAdvisorAlerts.XML", "ConfigXPLSchema.xml")
				foreach ($File in $Files)
				{ 
					if ( Get-ChildItem -path "$global:savePathTmp\$File" -ErrorAction SilentlyContinue ) {[void](Remove-Item "$global:savePathTmp\$File" -Force) }
				}
				# Remove empty Folders
				if (Test-Path .\EventLogs) {Remove-Item .\EventLogs -Recurse -Force}
				if (Test-Path .\Perfmon) {Remove-Item .\Perfmon -Recurse -Force}
				if (Test-Path .\RasTracingDir) {Remove-Item .\RasTracingDir -Recurse -Force}
				# Rename *.XML items
				if (Test-Path $global:savePathTmp`\$ENV:Computername`_EventLogAlerts.XML) 		{Rename-Item $global:savePathTmp`\$ENV:Computername`_EventLogAlerts.XML $global:savePathTmp`\$ENV:Computername`_EventLogAlerts.htm -Force}
				# Copy BPA html files
				if (Test-Path $ENV:USERPROFILE`\$ENV:Computername`*BPAInfo.HTM) 		{Copy-Item $ENV:USERPROFILE\$ENV:Computername*BPAInfo.HTM $global:savePathTmp\ -Force}
			#}
			
			# wait for msinfo32 to complete - moved to end before compress
			if (Get-Process msinfo32 -EA SilentlyContinue) {Write-Host "$(Get-Date -UFormat "%R:%S") ...waiting max $MsInfo32waitMin minutes on MsInfo32 to complete"}
				do
				{
					$isDone = Get-Process msinfo32 -EA SilentlyContinue
					Start-Sleep -Seconds 2
				} until ($isDone -eq $null -or (Get-Date) -gt $startTime_info32.AddMinutes($MsInfo32waitMin))

			if (Test-Path $ScriptParentPath\stdout*.log) {Move-Item $ScriptParentPath\stdout*.log $global:savePathTmp -Force}

			$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
			
			### begin compress -inner-
			if ($ZipIt.IsPresent) {
				$OutputFileZip = "psSDP_i_$SDPtech`_$ComputerName`_$CheckDate`.zip"
				Write-Host "$(Get-Date -UFormat "%R:%S") ... zipping $OutputFileZip"
				$zipComp = CompressCollectFiles -Recursive -NumberofDays 1 -filesToCollect $global:savePathTmp -DestinationFileName $OutputFileZip -renameOutput $false -fileDescription "psSDP Logs" -sectionDescription "psSDP data collection" 
				if ($zipComp) {	Write-Verbose "_zipped $OutputFileZip" }
			}

			if (($Script:PSver -gt 2) -and ($Transcript)) { try { Stop-Transcript | out-null} catch {} }
			else {Write-Host  "... Transcript log was not started. -Transcript:$False or old PS version $Script:PSver"}
			
			### begin compress files (zip cab)
			if ($NoCab.IsPresent -ne $true) {
				$OutputFileZip = "$savePath`\psSDP_$SDPtech`_$ComputerName`_$CheckDate`.zip"
				### Zip file if PowerShell v3 or higher is installed
				if ($Script:PSver -gt 2) { Write-Host "$(Get-Date -UFormat "%R:%S") ... now zipping '$SDPtech' data folder $global:savePathTmp" 
											#$zipped = Zip-Files -zipfilename $OutputFileZip -sourcedir $global:savePathTmp -Verbose -overwrite $true 
											$zipped = Create-ZipFromDirectory -SourceDirectory $global:savePathTmp -ZipFileName $OutputFileZip -overwrite }
				else {Write-Host "`n*** Please zip all results files in $global:savePathTmp and upload to workspace" -ForegroundColor yellow}
			} #end zip
			else {Write-Host "`n*** Please zip all results files in $global:savePathTmp and upload to workspace" -ForegroundColor yellow}

			set-location -path $CurrentPath
			if ($zipped) {
				Write-Verbose "_Remove-Item $global:savePathTmp -Force -Recurse"
				Remove-Item $global:savePathTmp -Force -Recurse
				Write-Host " [psSDP-Info] done. Resulting cabinet: $OutputFileZip" -ForegroundColor green
				}
		}
		#endregion: MAIN :::::
	} # end try PROCESS
	catch {
		$errorMessage = "$scriptName caught an exception on $($ENV:COMPUTERNAME):`n`n"
		$errorMessage += "Exception Type: $($_.Exception.GetType().FullName)`n`n"
		$errorMessage += "Exception Message: $($_.Exception.Message)"

		Write-Error $errorMessage -ErrorAction Continue
		<# Log error
				Write-Verbose "Logging the script's error..."
		# Log error - EventLog
				#An event log source needs to be preconfigured to use this.
				Write-EventLog `
					-EventId $AlertNumber `
					-LogName $LogName `
					-Source $EventSource `
					-Message $errorMessage `
					-EntryType Error
		# Log error - Email
				# This will attempt to send an immediate alert about the error.
				# The EventLog also needs to log the error because this one may not be sent.
				#use Send-MailMessage
		#>
		#echo $_.Exception|format-list -force
		$errMsg = $_.Exception|format-list -force; $line = $_.InvocationInfo.ScriptLineNumber; $errMsg; $line;  Write-host -ForegroundColor Red -BackgroundColor Black "Please report above error message in $scriptName line: $line - Elevated: $isElev"

		Start-Sleep -Seconds 2
		Write-Debug $errorMessage
		$ErrorThrown = $true
		if ( $UseExitCode ) {
			$error.clear()	# clear script errors
			exit 1
		} #end UseExitCode
    } #end Catch PROCESS
	Finally {
		# Reset original ExecutionPolicy
		Set-ExecutionPolicy -Scope Process -ExecutionPolicy $StartExecPolicy -Force -ErrorAction SilentlyContinue
		# Reset original ExecutionPolicy in Registry
		if ($StartPSExePolicyReg) {Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value $StartPSExePolicyReg}
		
		if ($Script:PSver -gt 2) { Unblock-File -Path $ScriptParentPath\Get-psSDP.ps1 -ErrorAction SilentlyContinue }
		Write-Host "`n [psSDP-Info] in case you see any red error messages regarding signing, open an Admin Powershell CMD and run this command first:
			 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force 
		 Alternate method#1: to sign .ps1 scripts: run in elevated CMD 'tss_PS1sign.cmd Get-psSDP' `n 
		 Alternate method#2: if scripts are blocked by Policy, run in elevated Powershell: 
			Set-ItemProperty -Path HKLM:\Software\Policies\Microsoft\Windows\PowerShell -Name ExecutionPolicy -Value ByPass `n" -ForegroundColor gray
	} #end Finally PROCESS
} #end PROCESS


END {
	$ScriptEndTimeStamp = Get-Date
	$Duration = $(New-TimeSpan -Start $ScriptBeginTimeStamp -End $ScriptEndTimeStamp)
	$LogLevel = 0
	#Write-Host "Script $scriptName v$VerMa.$VerMi execution finished. Duration: $Duration `n"
	if($ErrorThrown) {Throw $error[0].Exception.Message}

	Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done on this PC $env:COMPUTERNAME; script $scriptName '$SDPtech' version v$VerMa.$VerMi took $Duration`n"
	[System.Media.SystemSounds]::Hand.Play() # Play sound to signal end of SDP data collection
	
    # This resets the ErrorActionPreference to the value at script start.
    $errorActionPreference = $startErrorActionPreference
} #end END

#region: comments
<# Info:
Files collected within SDP report:
- "Net","Dom","CTS","Print","HyperV","Perf","Setup","Cluster","Mini","Nano","RFL","All"

 2027424	[SDP 3][d92078bc-87a3-492b-978e-1f91d4eaaed9] Windows Printing
  http://support.microsoft.com/kb/2027424/EN-US
 2224427	[SDP 2][9B947211-ED5B-4BAE-85A5-823B8718DB59] Setup - Windows XP, Server 2003, Windows Vista, and Windows Server 2008 MSDT manifest
  http://support.microsoft.com/kb/2224427/EN-US
 2415016	[SDP 3][62ec9a58-1f9e-4550-b65c-87827221dd05] FailoverCluster Multinode troubleshooter for Windows Server
  http://support.microsoft.com/kb/2415016/EN-US


VERSION and AUTHORs:
        Ver 1.00 - 12.03.2017
	Walter Eder	- waltere@microsoft.com

HISTORY
	2016-09-23  v1.00
	2017-03-11  v1.02 commented original SDP *.ps1 files with: #_#Write-DiagProgress -activity, + #_#Run-DiagExpression,+ #_#Run-DiagExpression --> undo, Filter/functions are in utils_Remote.ps1
	 ??some older DC_* files have incorrect REG parts, missing "," at end of line:
	  DC_DirectAccessClient-Component.ps1: 	corrected error in REG part of $CurrentVersionKeys = "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient",	< missing ","
	  DC_RegistrySetupPerf.ps1: 			corrected error in REG part of $StartupKeys = "HKCU\Software\Microsoft\Windows NT\CurrentVersion"" < missing ","
	  DC_RegistrySetupPerf.ps1 				corrected error in REG part of $PoliciesKeys
	2017-03-14  v1.03 created standalone offline package psSDP-offline.zip
	2017-03-18  v1.04 DC_W32Time.ps1 corrected error "Copy-Item : Cannot overwrite the item .\Results\computername_W32Time_Reg_Key.txt with itself." \utils_Remote.ps1:297
				Win10 Fixes in networking *.ps1: replace : $bn = $wmiOSVersion.BuildNumber - with: [int]$bn = [int]$wmiOSVersion.BuildNumber
				corrected in TS_AutoAddCommands_CTS.ps1: Run-DiagExpression .\DC_ExchangeServerEventLogs.ps1
	2017-03-20	v1.05 DC_IPsec-Component, DC_DirectAccessServer-Component.ps1 : not running "Get-NetIPsecDospSetting" on Win8+,Win10 client;
				DC_HyperVNetworking.ps1: not running "Get-NetNat*" not running "Get-NetIPsecDospSetting" on Win8+ client;
				DC_NetdomFSMO.ps1: Netdom.exe -- -or ($bn -ge 9200)) #_# netdom.exe not running on W8+
				TS_DFSRRootCausesCheck.ps1: -- $SysvolRG = get-itemproperty -path Registry::"HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -name SysVol -ErrorAction SilentlyContinue #_#
				DC_IPsec-Component.ps1, DC_HyperVNetworking.ps1 #_#
	2018-06-15	v1.06 DC_DirectAccessClient-Component.ps1 DirectAccessConnectivityAssistant < missing ","
				DC_ProxyConfiguration.ps1 - suppress output of HKU; DC_RAS-Component.ps1 suppress output of Compress RasTracingFiles
				removed HTM in DC_UpdateHistory.ps1 $OutputFormats= @("TXT", "CSV", "HTM")
	2018-12-09 Cluster report
	
	ToDo: handle utils_Remote.ps1:Function Get-DiagInput :: in DC_CollectSecurityEventLog.ps1 (done), DC_DfsrInfo.ps1, DC_HyperVReplica.ps1, DC_ServerCoreR2Setup.ps1, TS_RemoteSetup.ps1, TS_SelectClusterNodes.ps1 
		- only run once CTS report, else errors: New-Variable : Cannot overwrite variable SQL:PSSDIAGXML because it is read-only or constant.
	- findstr /i /c:"get-diaginput" *.*
#>
#endregion: comments


