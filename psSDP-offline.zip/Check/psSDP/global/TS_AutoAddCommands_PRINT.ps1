﻿	# Performance Monitor - System Performance Data Collector [AutoAdded]
	Run-DiagExpression .\TS_PerfmonSystemPerf.ps1 -NumberOfSeconds 60 -DataCollectorSetXMLName "SystemPerformance.xml"

	# BPA Performance [AutoAdded]
	Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/TerminalServices" -OutputFileName ($Computername + "_TS_BPAInfo.HTM") -ReportTitle "Terminal Services Best Practices Analyzer"

	# Information about Processes resource usage and top Kernel memory tags [AutoAdded]
	Run-DiagExpression .\TS_ProcessInfo.ps1

	# [Idea ID 2334] [Windows] W2K3 x86 SP2 server running out of paged pool due to D2d tag [AutoAdded]
	Run-DiagExpression .\TS_KnownKernelTags.ps1

	# Collect Print Registry Keys [AutoAdded]
	Run-DiagExpression .\DC_RegPrintKeys.ps1

	# [Idea ID 5603] [Windows] Unable to start a service due to corruption in the Event Log key [AutoAdded]
	Run-DiagExpression .\TS_EventLogServiceRegistryCheck.ps1

	# MSInfo [AutoAdded]
	Run-DiagExpression .\DC_MSInfo.ps1

	# Obtain pstat output [AutoAdded]
	Run-DiagExpression .\DC_PStat.ps1

	# Collect Machine Registry Information for Setup and Performance Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_RegistrySetupPerf.ps1

	# CheckSym [AutoAdded]
	Run-DiagExpression .\DC_ChkSym.ps1

	# List Schedule Tasks using schtasks.exe utility [AutoAdded]
	Run-DiagExpression .\DC_ScheduleTasks.ps1

	# Collects information about Driver Verifier (verifier.exe utility) [AutoAdded]
	Run-DiagExpression .\DC_Verifier.ps1

	# Collects Windows Server 2008/R2 Server Manager Information [AutoAdded]
	Run-DiagExpression .\DC_ServerManagerInfo.ps1

	# Update History [AutoAdded]
	Run-DiagExpression .\DC_UpdateHistory.ps1

	# Collects System and Application Event Logs  [AutoAdded]
	Run-DiagExpression .\DC_SystemAppEventLogs.ps1

	# Collect Basic Cluster System Information [AutoAdded]
	Run-DiagExpression .\TS_BasicClusterInfo.ps1

	# Collects Cluster Logs [AutoAdded]
	Run-DiagExpression .\DC_ClusterLogs.ps1

	# Export cluster resources properties to a file (2K8 R2 and newer) [AutoAdded]
	Run-DiagExpression .\DC_ClusterResourcesProperties.ps1

	# Collects Cluster Groups Resource Dependency Report (Win2K8R2) [AutoAdded]
	Run-DiagExpression .\DC_ClusterDependencyReport.ps1

	# Collects Cluster - related Event Logs for Cluster Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_ClusterEventLogs.ps1

	# GPResults.exe Output [AutoAdded]
	Run-DiagExpression .\DC_RSoP.ps1

	# User Rights (privileges) via the userrights.exe tool [AutoAdded]
	Run-DiagExpression .\DC_UserRights.ps1

	# WhoAmI [AutoAdded]
	Run-DiagExpression .\DC_Whoami.ps1

	# TCPIP Component [AutoAdded]
	Run-DiagExpression .\DC_TCPIP-Component.ps1

	# DHCP Client Component [AutoAdded]
	Run-DiagExpression .\DC_DhcpClient-Component.ps1

	# DNS Client Component [AutoAdded]
	Run-DiagExpression .\DC_DNSClient-Component.ps1

	# WINSClient [AutoAdded]
	Run-DiagExpression .\DC_WINSClient-Component.ps1

	# SMB Client Component [AutoAdded]
	Run-DiagExpression .\DC_SMBClient-Component.ps1

	# SMB Server Component [AutoAdded]
	Run-DiagExpression .\DC_SMBServer-Component.ps1

	# RPC [AutoAdded]
	Run-DiagExpression .\DC_RPC-Component.ps1

	# Firewall [AutoAdded]
	Run-DiagExpression .\DC_Firewall-Component.ps1

	# IPsec [AutoAdded]
	Run-DiagExpression .\DC_IPsec-Component.ps1

	# Hyper-V Networking Settings [AutoAdded]
	Run-DiagExpression .\DC_HyperVNetworking.ps1

	# Hyper-V Network Virtualization [AutoAdded]
	Run-DiagExpression .\DC_HyperVNetworkVirtualization.ps1

	# NetworkAdapters [AutoAdded]
	Run-DiagExpression .\DC_NetworkAdapters-Component.ps1

	# NetLBFO [AutoAdded]
	Run-DiagExpression .\DC_NetLBFO-Component.ps1

	# Perf/Printing Event Logs [AutoAdded]
	Run-DiagExpression .\DC_PerfPrintEventLogs.ps1

	# Detects and alerts evaluation media [AutoAdded]
	Run-DiagExpression .\TS_EvalMediaDetection.ps1

	# Debug/GFlags check [AutoAdded]
	Run-DiagExpression .\TS_DebugFlagsCheck.ps1

	# Check for ephemeral port usage [AutoAdded]
	Run-DiagExpression .\TS_PortUsage.ps1

	# FailoverCluster Cluster Name Object AD check [AutoAdded]
	Run-DiagExpression .\TS_ClusterCNOCheck.ps1

	# Information about Windows 2008 R2 Cluster Shared Volumes [AutoAdded]
	Run-DiagExpression .\DC_CSVInfo.ps1

	# [Idea ID 2169] [Windows] Xsigo network host driver can cause Cluster disconnects [AutoAdded]
	Run-DiagExpression .\TS_ClusterXsigoDriverNetworkCheck.ps1

	# [Idea ID 2251] [Windows] Cluster 2003 - Access denied errors during a join, heartbeat, and Cluster Admin open [AutoAdded]
	Run-DiagExpression .\TS_Cluster2K3NoLmHash.ps1

	# [Idea ID 2513] [Windows] IPv6 rules for Windows Firewall can cause loss of communications between cluster nodes [AutoAdded]
	Run-DiagExpression .\TS_ClusterIPv6FirewallCheck.ps1

	# [Idea ID 5258] [Windows] Identifying Cluster Hive orphaned resources located in the dependencies key [AutoAdded]
	Run-DiagExpression .\TS_Cluster_OrphanResource.ps1

	# [Idea ID 6519] [Windows] Invalid Class error on 2012 Clusters (SDP) [AutoAdded]
	Run-DiagExpression .\TS_ClusterCAUWMINamespaceCheck.ps1

	# [Idea ID 6500] [Windows] Invalid Namespace error on 2008 and 2012 Clusters [AutoAdded]
	Run-DiagExpression .\TS_ClusterMSClusterWMINamespaceCheck.ps1

	# Checking the presence of Citrix AppSense 8.1 [AutoAdded]
	Run-DiagExpression .\TS_CitrixAppSenseCheck.ps1

	# Check for large number of Inactive Terminal Server ports [AutoAdded]
	Run-DiagExpression .\TS_KB2655998_InactiveTSPorts.ps1

	# Checking if Registry Size Limit setting is present on the system [AutoAdded]
	Run-DiagExpression .\TS_RegistrySizeLimitCheck.ps1

	# [Idea ID 2446] [Windows] Determining the trimming threshold set by the Memory Manager [AutoAdded]
	Run-DiagExpression .\TS_2K3PoolUsageMaximum.ps1

	# Checks files in the LamnServer, if any at .PST files a file is created with listing all of the files in the directory [AutoAdded]
	Run-DiagExpression .\TS_NetFilePSTCheck.ps1

	# [Idea ID 986] [Windows] SBSL McAfee Endpoint Encryption for PCs may cause slow boot or delay between CTRL+ALT+DEL and Cred [AutoAdded]
	Run-DiagExpression .\TS_SBSL_MCAfee_EEPC_SlowBoot.ps1

	# [Idea ID 2285] [Windows] Windows Server 2003 TS Licensing server does not renew new versions of TS Per Device CALs [AutoAdded]
	Run-DiagExpression .\TS_RemoteDesktopLServerKB2512845.ps1

	# [Idea ID 3181] [Windows] Symantec Endpoint Protection's smc.exe causing handle leak [AutoAdded]
	Run-DiagExpression .\TS_SEPProcessHandleLeak.ps1

	# [Idea ID 2387] [Windows] Verify if RPC connection a configured to accept only Authenticated sessions [AutoAdded]
	Run-DiagExpression .\TS_RPCUnauthenticatedSessions.ps1

	# [Idea ID 1911] [Windows] NTFS metafile cache consumes most of RAM in Win2k8R2 Server [AutoAdded]
	Run-DiagExpression .\TS_NTFSMetafilePerfCheck.ps1

	# [Idea ID 2346] [Windows] high cpu only on one processor [AutoAdded]
	Run-DiagExpression .\TS_2K3ProcessorAffinityMaskCheck.ps1

	# [Idea ID 3989] [Windows] STACK MATCH - Win2008R2 - Machine hangs after shutdown, caused by ClearPageFileAtShutdown setting [AutoAdded]
	Run-DiagExpression .\TS_SBSLClearPageFileAtShutdown.ps1

	# [Idea ID 2753] [Windows] HP DL385 G5p machine cannot generate dump file [AutoAdded]
	Run-DiagExpression .\TS_ProLiantDL385NMICrashDump.ps1

	# [Idea ID 3253] [Windows] Windows Search service does not start immediately after the machine is booted [AutoAdded]
	Run-DiagExpression .\TS_WindowsSearchLenovoRapidBootCheck.ps1

	# [Idea ID 3317] [Windows] DisableEngine reg entry can cause app install or registration failure [AutoAdded]
	Run-DiagExpression .\TS_AppCompatDisabledCheck.ps1

	# [Idea ID 2357] [Windows] the usage of NPP is very large for XTE.exe [AutoAdded]
	Run-DiagExpression .\TS_XTENonPagedPoolCheck.ps1

	# [Idea ID 4368] [Windows] Windows Logon Slow and Explorer Slow [AutoAdded]
	Run-DiagExpression .\TS_2K3CLSIDUserACLCheck.ps1

	# [Idea ID 4649] [Windows] Incorrect values for HeapDecomitFreeBlockThreshold  causes high Private Bytes in multiple processes [AutoAdded]
	Run-DiagExpression .\TS_HeapDecommitFreeBlockThresholdCheck.ps1

	# [Idea ID 2056] [Windows] Consistent Explorer crash due to wsftpsi.dll [AutoAdded]
	Run-DiagExpression .\TS_WsftpsiExplorerCrashCheck.ps1

	# [Idea ID 3250] [Windows] Machine exhibits different symptoms due to Confliker attack [AutoAdded]
	Run-DiagExpression .\TS_Netapi32MS08-067Check.ps1

	# [Idea ID 5194] [Windows] Unable to install vcredist_x86.exe with message (Required file install.ini not found. Setup will now exit) [AutoAdded]
	Run-DiagExpression .\TS_RegistryEntryForAutorunsCheck.ps1

	# [Idea ID 5452] [Windows] The “Red Arrow” issue in Component Services caused by registry keys corruption [AutoAdded]
	Run-DiagExpression .\TS_RedArrowRegistryCheck.ps1

	# [Idea ID 4783] [Windows] eEye Digital Security causing physical memory depletion [AutoAdded]
	Run-DiagExpression .\TS_eEyeDigitalSecurityCheck.ps1

	# [Idea ID 5091] [Windows] Super Rule-To check if both 3GB and PAE switch is present in boot.ini for a 32bit OS (Pre - Win 2k8) [AutoAdded]
	Run-DiagExpression .\TS_SwithesInBootiniCheck.ps1

	# [Idea ID 6530] [Windows] Check for any configured RPC port range which may cause issues with DCOM or DTC components [AutoAdded]
	Run-DiagExpression .\TS_RPCPortRangeCheck.ps1

	# [Idea ID 7018] [Windows] Event Log Service won't start [AutoAdded]
	Run-DiagExpression .\TS_EventLogStoppedGPPCheck.ps1

	# Check if hotfix 2480954 installed [AutoAdded]
	Run-DiagExpression .\TS_KB2480954AndWinRMStateCheck.ps1

	# Collects Windows Remote Management Event log [AutoAdded]
	Run-DiagExpression .\DC_WinRMEventLogs.ps1

	# Collects WSMAN and WinRM binary details info [AutoAdded]
	Run-DiagExpression .\DC_WSMANWinRMInfo.ps1

	# [Idea ID 8012] [Windows] SDP-UDE check for reg key DisablePagingExecutive [AutoAdded]
	Run-DiagExpression .\TS_DisablePagingExecutiveCheck.ps1

	# [KSE Rule] [ Windows V3] Server Manager refresh issues and SDP changes reqd for MMC Snapin Issues in 2008, 2008 R2 [AutoAdded]
	Run-DiagExpression .\TS_ServerManagerRefreshKB2762229.ps1

	# [KSE Rule] [ Windows V3] Presence of lots of folders inside \spool\prtprocs\ causes failure to install print queues [AutoAdded]
	Run-DiagExpression .\TS_PrtprocsSubfolderBloat.ps1

	# [KSE Rule] [ Windows V3] Handle leak in Svchost.exe when a WMI query is triggered by using the Win32_PowerSettingCapabilities [AutoAdded]
	Run-DiagExpression .\TS_WMIHandleLeakKB2639077.ps1

	# Detect 4KB Drives (Disk Sector Size) [AutoAdded]
	Run-DiagExpression .\TS_DriveSectorSizeInfo.ps1

	# EMC Replistor Software installation detected but KB 975759 is not installed [AutoAdded]
	Run-DiagExpression .\TS_ReplistorCheck.ps1

	# Warning if Windows Server 2008 Service Pack 1, We end support Windows Server 2008 SP1 on July 12, advice customer to upgrade to SP2. [AutoAdded]
	Run-DiagExpression .\TS_ServicePackKB2590494Check.ps1

	# Checks 32 bit windows server 2003 / 2008 to see is DEP is disabled, if so it might not detect more than 4 GB of RAM. [AutoAdded]
	Run-DiagExpression .\TS_DEPDisabled4GBCheck.ps1

	# Check for Sophos BEFLT.SYS version 5.60.1.7 [AutoAdded]
	Run-DiagExpression .\TS_B2693877_Sophos_BEFLTCheck.ps1

	# [Idea ID 2695] [Windows] Check the Log On account for the Telnet service to verify it's not using the Local System account [AutoAdded]
	Run-DiagExpression .\TS_TelnetSystemAccount.ps1

	# [Idea ID 2842] [Windows] Alert Engineers if they are working on a Dell machine models R910, R810 and M910 [AutoAdded]
	Run-DiagExpression .\TS_DellPowerEdgeBiosCheck.ps1

	# [Idea ID 2389] [Windows] Hang caused by kernel memory depletion due 'SystemPages' reg key with wrong value [AutoAdded]
	Run-DiagExpression .\TS_MemoryManagerSystemPagesCheck.ps1

	# Detect Virtualization [AutoAdded]
	Run-DiagExpression .\TS_Virtualization.ps1

	# [Idea ID 7065] [Windows] Alert users about Windows XP EOS [AutoAdded]
	Run-DiagExpression .\TS_WindowsXPEOSCheck.ps1

	# [KSE Rule] [ Windows V3] HpCISSs2 version 62.26.0.64 causes 0xD1 or 0x9E [AutoAdded]
	Run-DiagExpression .\TS_HpCISSs2DriverIssueCheck.ps1

	# Checks if machine is server 2008 R2 sp0 or sp1, and event log 602 exists, and hotfix kb 2457866 is installed if true generate alert [AutoAdded]
	Run-DiagExpression .\TS_PrinterKB2457866Check.ps1

	# Checks if a Kyocera print driver is installed then checks if KB982728 is installed [AutoAdded]
	Run-DiagExpression .\TS_PrinterKB982728Check.ps1

	# Checks if Point and Print Restriction Policy and then look for specifc events on event logs [AutoAdded]
	Run-DiagExpression .\TS_PrinterKB2618460Check.ps1

	# Checks to see if HP Standard TCP/IP Port key is present on the system [AutoAdded]
	Run-DiagExpression .\TS_PrintingHPTCPMonCheck.ps1

	# Checking if 'Net Driver HPZ12' or 'Pml Driver HPZ12' is one of the installed services and startup type is something different than Disabled [AutoAdded]
	Run-DiagExpression .\TS_HPZ12ServiceCheck.ps1

	# Detect the OEM HP driver hpzui4wm.DLL [AutoAdded]
	Run-DiagExpression .\TS_PrintHpzui4wmCheck.ps1

	# Check for the presence of Zenographics Device Manager User Interface [AutoAdded]
	Run-DiagExpression .\TS_Check_ZenographicsUI.ps1

	# Check for upgrade from HP UPD 5.2 to 5.3 [AutoAdded]
	Run-DiagExpression .\TS_2628581_HPUPDUpgrade.ps1

	# [Idea ID 2226] [Windows] Old SHD and SPL files residual in the Spool directory cause issues [AutoAdded]
	Run-DiagExpression .\TS_PrintSpoolerOldSPLSHD.ps1

	# [Idea ID 1872] [Windows] Detecting bloated HKEY_USERS\.default\printers\Devmodes2 registry key on Terminal servers [AutoAdded]
	Run-DiagExpression .\TS_PrintDevModes2CountCheck.ps1

	# [Idea ID 3462] [Windows] Printing issue - multiple SETxnnn.tmp files [AutoAdded]
	Run-DiagExpression .\TS_PrintSetTMPSystem32Check.ps1

	# [Idea ID 4091] [Windows] frequent spooler crash due to zsdnt5ui.dll [AutoAdded]
	Run-DiagExpression .\TS_PrintZSDDMUICheck.ps1

	# [Idea ID 4168] [Windows] Check for existence of 2647753  for printing issues [AutoAdded]
	Run-DiagExpression .\TS_Win7PrintUpdateRollupCheck.ps1

	# [Idea ID 2374] [Windows] Spooler service hangs since CSR exhausts the 512 threads in thread pool [AutoAdded]
	Run-DiagExpression .\TS_PrintCSRBloatingCheck.ps1

	# [Idea ID 4805] [Windows] Printers show Offline on Windows 7 clients [AutoAdded]
	Run-DiagExpression .\TS_PrinterShowOffline.ps1

	# [Idea ID 5470] [Windows] GPP printer fails to add with error code 0x80070704 [AutoAdded]
	Run-DiagExpression .\TS_GPPDeployPrinterCheck.ps1

	# [Idea ID 6863] [Windows] GPP printer fails to be added since LocalEnumForms returns error 8007007a [AutoAdded]
	Run-DiagExpression .\TS_GPPMapPrinterKB2797136.ps1

	# [KSE Rule] [ Windows V3] HKCU\Software\Hewlett-Packard registry hive increases in size on Citrix servers [AutoAdded]
	Run-DiagExpression .\TS_HPPrinterDriverVersionCheck.ps1

	# Basic System Information [AutoAdded]
	Run-DiagExpression .\DC_BasicSystemInformation.ps1

	# List Schedule Tasks using schtasks.exe utility [AutoAdded]
	Run-DiagExpression .\TS_SpoolerDumpInfo.ps1


# SIG # Begin signature block
# MIIa4AYJKoZIhvcNAQcCoIIa0TCCGs0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUflm/tYoH2967C/VhMgcjLLGS
# zTugghV6MIIEuzCCA6OgAwIBAgITMwAAAFnWc81RjvAixQAAAAAAWTANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTQwNTIzMTcxMzE1
# WhcNMTUwODIzMTcxMzE1WjCBqzELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# DTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjpGNTI4LTM3
# NzctOEE3NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMZsTs9oU/3vgN7oi8Sx8H4H
# zh487AyMNYdM6VE6vLawlndC+v88z+Ha4on6bkIAmVsW3QlkOOJS+9+O+pOjPbuH
# j264h8nQYE/PnIKRbZEbchCz2EN8WUpgXcawVdAn2/L2vfIgxiIsnmuLLWzqeATJ
# S8FwCee2Ha+ajAY/eHD6du7SJBR2sq4gKIMcqfBIkj+ihfeDysVR0JUgA3nSV7wT
# tU64tGxWH1MeFbvPMD/9OwHNX3Jo98rzmWYzqF0ijx1uytpl0iscJKyffKkQioXi
# bS5cSv1JuXtAsVPG30e5syNOIkcc08G5SXZCcs6Qhg4k9cI8uQk2P6hTXFb+X2EC
# AwEAAaOCAQkwggEFMB0GA1UdDgQWBBRbKBqzzXUNYz39mfWbFQJIGsumrDAfBgNV
# HSMEGDAWgBQjNPjZUkZwCu1A+3b7syuwwzWzDzBUBgNVHR8ETTBLMEmgR6BFhkNo
# dHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNyb3Nv
# ZnRUaW1lU3RhbXBQQ0EuY3JsMFgGCCsGAQUFBwEBBEwwSjBIBggrBgEFBQcwAoY8
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3NvZnRUaW1l
# U3RhbXBQQ0EuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBBQUA
# A4IBAQB68A30RWw0lg538OLAQgVh94jTev2I1af193/yCPbV/cvKdHzbCanf1hUH
# mb/QPoeEYnvCBo7Ki2jiPd+eWsWMsqlc/lliJvXX+Xi2brQKkGVm6VEI8XzJo7cE
# N0bF54I+KFzvT3Gk57ElWuVDVDMIf6SwVS3RgnBIESANJoEO7wYldKuFw8OM4hRf
# 6AVUj7qGiaqWrpRiJfmvaYgKDLFRxAnvuIB8U5B5u+mP0EjwYsiZ8WU0O/fOtftm
# mLmiWZldPpWfFL81tPuYciQpDPO6BHqCOftGzfHgsha8fSD4nDkVJaEmLdaLgb3G
# vbCdVP5HC18tTir0h+q1D7W37ZIpMIIE7DCCA9SgAwIBAgITMwAAAMps1TISNcTh
# VQABAAAAyjANBgkqhkiG9w0BAQUFADB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTAeFw0xNDA0MjIxNzM5MDBaFw0xNTA3MjIxNzM5MDBaMIGDMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQD
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCWcV3tBkb6hMudW7dGx7DhtBE5A62xFXNgnOuntm4aPD//ZeM08aal
# IV5WmWxY5JKhClzC09xSLwxlmiBhQFMxnGyPIX26+f4TUFJglTpbuVildGFBqZTg
# rSZOTKGXcEknXnxnyk8ecYRGvB1LtuIPxcYnyQfmegqlFwAZTHBFOC2BtFCqxWfR
# +nm8xcyhcpv0JTSY+FTfEjk4Ei+ka6Wafsdi0dzP7T00+LnfNTC67HkyqeGprFVN
# TH9MVsMTC3bxB/nMR6z7iNVSpR4o+j0tz8+EmIZxZRHPhckJRIbhb+ex/KxARKWp
# iyM/gkmd1ZZZUBNZGHP/QwytK9R/MEBnAgMBAAGjggFgMIIBXDATBgNVHSUEDDAK
# BggrBgEFBQcDAzAdBgNVHQ4EFgQUH17iXVCNVoa+SjzPBOinh7XLv4MwUQYDVR0R
# BEowSKRGMEQxDTALBgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNTk1K2I0MjE4ZjEz
# LTZmY2EtNDkwZi05YzQ3LTNmYzU1N2RmYzQ0MDAfBgNVHSMEGDAWgBTLEejK0rQW
# WAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0FfMDgtMzEtMjAx
# MC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0zMS0yMDEwLmNy
# dDANBgkqhkiG9w0BAQUFAAOCAQEAd1zr15E9zb17g9mFqbBDnXN8F8kP7Tbbx7Us
# G177VAU6g3FAgQmit3EmXtZ9tmw7yapfXQMYKh0nfgfpxWUftc8Nt1THKDhaiOd7
# wRm2VjK64szLk9uvbg9dRPXUsO8b1U7Brw7vIJvy4f4nXejF/2H2GdIoCiKd381w
# gp4YctgjzHosQ+7/6sDg5h2qnpczAFJvB7jTiGzepAY1p8JThmURdwmPNVm52Iao
# AP74MX0s9IwFncDB1XdybOlNWSaD8cKyiFeTNQB8UCu8Wfz+HCk4gtPeUpdFKRhO
# lludul8bo/EnUOoHlehtNA04V9w3KDWVOjic1O1qhV0OIhFeezCCBbwwggOkoAMC
# AQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmSJomT8ixkARkW
# A2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9z
# b2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgzMTIyMTkzMloX
# DTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAgQpl2U2w+G9Zv
# zMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn08GisTUuNpb15
# S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqelcnNW8ReU5P01
# lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQwWfjSjWL9y8lf
# RjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vXT2Pn0i1i8UU9
# 56wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJXwPTAgMBAAGj
# ggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK0rQWWAHJNy4z
# Fha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEE
# AYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ5KQwUAYDVR0f
# BEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEBBEgwRjBEBggr
# BgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNy
# b3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5Pn8mRq/rb0Cx
# MrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9MuqKoVpzjcLu4
# tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOlVuC4iktX8pVC
# nPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7IG9KPcpUqcW2b
# Gvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/TartSCMm78pJUT
# 5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhcyTUWX92THUmO
# Lb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zKwexwo1eSV32U
# jaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K3RDeZPRvzkbU
# 0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO7bN2edgKNAlt
# HIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdibIa4NXJzwoq6G
# aIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HOiMm4GPoOco3B
# oz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZoNAAAAAAAHDAN
# BgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPy
# LGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAzMTMwMzA5WjB3
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhN
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7Rp9FMrXQwIBHr
# B9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y9GccLPx754gd
# 6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYuJ6yGT1VSDOQD
# LPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdmEScpZqiX5NMG
# gUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68eeEExd8yb3zuD
# k6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAPBgNVHRMBAf8E
# BTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzALBgNVHQ8EBAMC
# AYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyCYEBWJ5flJRP8
# KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAXBgoJkiaJk/Is
# ZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8ESTBHMEWgQ6BB
# hj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9taWNy
# b3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsGAQUFBzAChjho
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jvc29mdFJvb3RD
# ZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQUFAAOCAgEA
# EJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxtYrhXAstOIBNQ
# md16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1Pq5Lk541q1YDB
# 5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxnLcVRDupiXD8W
# mIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/xTUrXqO/67x9
# C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW6J1wlGysOUzU
# 9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146SodDW4TsVxIxIm
# dgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD6Svpu/RIzCzU
# 2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9iaF2YbRuoROm
# v6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpjtHhUBdRBLlCs
# lLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J4PcBZW+JC33I
# acjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTQMIIEzAIBATCBkDB5
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpN
# aWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAMps1TISNcThVQABAAAAyjAJ
# BgUrDgMCGgUAoIHpMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQB
# gjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBTH38gD6x0ro5vE
# AuLn+54nxpjUrTCBiAYKKwYBBAGCNwIBDDF6MHigXoBcAEQASQBBAEcAXwBDAFQA
# UwBQAHIAaQBuAHQAaQBuAGcAXwBnAGwAbwBiAGEAbABfAFQAUwBfAEEAdQB0AG8A
# QQBkAGQAQwBvAG0AbQBhAG4AZABzAC4AcABzADGhFoAUaHR0cDovL21pY3Jvc29m
# dC5jb20wDQYJKoZIhvcNAQEBBQAEggEAUXaDRRzdtyWk1g25p0/Guyg0sqOosf3a
# E2qcMoCb+yn61CIUIf1+zbnHFvencHNjHnbaPZz6GtvB7TZzt3R68Q0+CMAcWKUl
# UVSJb38+MhDk0cv9bBuXPTV2q7fjNVeDUtdDXALrFvG1rVgszvEdOBFeXLFyUR99
# cRul50u/XrSQuOiIwuxihksl/lOmsaXHO0mGwmaU4m0JIEVoBB81ql+1CexowGrP
# eypnetDfU3ngDWRHFkGNVrSgRmRhsHAbl4veZfUW7Gi1umdeSgIlxy36vjOpg1yn
# HjC2O/Ubx0RIFBNzQW15o0IXONCVwIQ8lkTW+CguP13EQ/mq3cF1TaGCAigwggIk
# BgkqhkiG9w0BCQYxggIVMIICEQIBATCBjjB3MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0ECEzMAAABZ1nPNUY7wIsUAAAAAAFkwCQYFKw4DAhoFAKBdMBgGCSqGSIb3DQEJ
# AzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTE0MDkwMzIwMjgxN1owIwYJ
# KoZIhvcNAQkEMRYEFCUTq4xCzum3XneQNhioVTs5EFwLMA0GCSqGSIb3DQEBBQUA
# BIIBAHhNAOIh10b9yI/DZRP6OajpYXKEAUDp7onDktQcx/suhh4AG2eLKppSx2x6
# Cuk1S187s74X6g9pQN2y6sTFWW1ySNgegbGvYZ10RUvHCTS+4OCWc8K2McM9/XE5
# JYU6gIxHabAgUy98Vnvqg3b5tIDEJpH72JDlJX70nt9cTzQvlojRNCth90AvHTvr
# Y3i8GZr/GfzkCMmlvKiRAlu4HTOalI6UoFTWXL53m7Gg/diDyNBL8Filq/VGSmn6
# 0rmf5DGnhyC2W5o353/smtpWGCMEPgtnY74AbqpCfozffYaTZha/AxAH1KdxlyTz
# pnlAQYwYjqV5bxehDKWbP/BHOY8=
# SIG # End signature block
