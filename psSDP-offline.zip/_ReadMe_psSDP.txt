psSDP Readme
============
to start SDPreport,
	- open elevated PowerShell window, and run commands
 PS > cd .\psSDP
 PS > .\Get-psSDP.ps1		(or .\Get-psSDP.ps1 NET)

for help, enter in PowerShell window:
 PS C:\psSDP> get-help .\Get-psSDP.ps1
 
see also Readme file in folder \psSDP\_psSDP_readme.txt 
