﻿
#************************************************
# DC_EnvVars.ps1
# Version 2.0
# Date: 10-09-2012
# Author: clandis, andret
# Description: Collects environment variables (output of SET command)
#************************************************

Import-LocalizedData -BindingVariable EnvVarsStrings

Write-DiagProgress -Activity $EnvVarsStrings.ID_EnvVarsOutput -Status $EnvVarsStrings.ID_EnvVarsObtaining

$OutputFile = $ComputerName + "_EnvironmentVariables.txt"

get-childitem env: | ft -wrap | out-file $OutputFile

$fileDescription = "Environment Variables"
$sectionDescription = "Environment Variables"

CollectFiles -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
