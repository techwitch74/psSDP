﻿#************************************************
# DC_WinStoreCollect.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects Windows Store information.
# Called from: TS_AutoAddCommands_Apps.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_WinStoreCollect.ps1"

"Starting WinStoreCollect.ps1 script" | WriteTo-StdOut
"============================================================" | WriteTo-StdOut
#_# Import-LocalizedData -BindingVariable ScriptStrings

# Registry keys
"Getting Windows Store Registry Keys." | WriteTo-StdOut

$Regkeys = "HKLM\Software\Policies\Microsoft\WindowsStore"
$OutputFile = $ComputerName + "_Regkeys_WindowsStorePolicies_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WindowsStore Policies Registry Key" -SectionDescription "Software Registry keys" 

$Regkeys = "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\WSService\Packages" 
$OutputFile = $ComputerName + "_Regkeys_WSServicePackages_HKLM.txt"
RegQuery -RegistryKeys $Regkeys -Recursive $true -OutputFile $OutputFile -fileDescription "WSService Packages Registry Key" -SectionDescription "Software Registry keys"


# Saved Directories
"Getting Copies of Windows Store files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_WindowsStorefiles_Title -Status $ScriptStrings.ID_WindowsStorefiles_Status
$sectionDescription = "Windows Store files"
if(test-path "$env:windir\ImmersiveControlPanel")
{
	$DesinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:windir\ImmersiveControlPanel" -Destination $DesinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DesinationTempFolder -DestinationFileName "ImmersiveControlPanel.zip" -fileDescription "Files under \Windows\ImmersiveControlPanel" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DesinationTempFolder -Force -Recurse
}
if(test-path "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log" -fileDescription "Winstore log" -sectionDescription $sectionDescription
}
if(test-path "$env:localappdata\Temp\WinStore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Temp\WinStore.log" -fileDescription "Broker log" -sectionDescription $sectionDescription
}



# Directory Listings
"Getting Directory Listing of Windows Store files" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_WindowsStoreDirectoryListings_Title -Status $ScriptStrings.ID_WindowsStoreDirectoryListings_Status
$sectionDescription = "Windows Store Directory Listings"
if(test-path "$env:localappdata\Microsoft\Windows Store\Checkpoints")
{
	dir -Recurse "$env:localappdata\Microsoft\Windows Store\Checkpoints" >> "DirList_CheckPointDir.txt"
	CollectFiles -filesToCollect "DirList_CheckPointDir.txt" -fileDescription "CheckPoint Directory Listings" -sectionDescription $sectionDescription
}
if(test-path "$env:windir\Winstore")
{
	dir -Recurse "$env:windir\Winstore"                                  >> "DirList_WinStoreDir.txt"
	CollectFiles -filesToCollect "DirList_WinStoreDir.txt" -fileDescription "WinStore Directory Listings" -sectionDescription $sectionDescription
}


# Event Logs
"Getting Windows Store Event Logs" | WriteTo-StdOut
$sectionDescription = "Event Logs"
$EventLogNames = "Microsoft-WS-Licensing/Admin"
Run-DiagExpression .\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription

# Running WSRun application:
$sectionDescription = "WinStore package and licensing information"
$OSProcessorArch = $Env:PROCESSOR_ARCHITECTURE
$ToolName = "wsrun" + $OSProcessorArch + ".exe"
$OutputFile = $ComputerName + "_WSRunResults.log"
$CommandLineToExecute = "cmd.exe /c $ToolName WSRunCommand.wsrun > $OutputFile"
"Executing $CommandLineToExecute to get WinStore package and licensing information" | WriteTo-StdOut
Write-DiagProgress -Activity $ScriptStrings.ID_WSRuntool_Title -Status $ScriptStrings.ID_WSRuntool_Status
RunCmD -commandToRun $CommandLineToExecute	-filesToCollect "WSRunResults.log" -fileDescription "WinStore package and licensing information" -sectionDescription $sectionDescription

Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_WinStoreCollect.ps1"