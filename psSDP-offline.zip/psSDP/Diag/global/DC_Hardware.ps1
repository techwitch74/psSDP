﻿###########################################################################
# DC_Hardware
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Collects Installed Hardware Data
###########################################################################

Import-LocalizedData -BindingVariable Hardware -FileName DC_Hardware -UICulture en-us
Write-DiagProgress -Activity $Hardware.ID_Hardware

$OutputFile = $ComputerName + "_Hardware.txt"
$SystemName = "System Name: " + $ComputerName + "`n"

logstart 

$SystemName | Out-File $OutputFile
$Header = "Memory:"
$Header | Out-File -Append $OutputFile

$Memory = Get-WmiObject -class Win32_computerSystem | ForEach-Object {[math]::truncate($_.TotalPhysicalMemory / 1MB)} 
$WriteMemory = "Total Physical Memory: " + $Memory + "MB `n"
$WriteMemory | Out-File -Append $OutputFile

$Processors = Get-WmiObject Win32_Processor
$ProcName = "Processors:`n" + $Blocks + "`n" + "Name: " + $processors.Name + "`n"
Add-Content $OutputFile $ProcName -Encoding unknown



Add-Content $OutputFile "Disks: " -Encoding Unknown
$Blocks | Out-File -Append $OutputFile

$Disks= Get-WmiObject Win32_LogicalDisk

foreach ( $Drive in $Disks ) 
{ 



if ($drive.DriveType -eq "3")
	{
	
	$Size = ForEach-Object {[math]::truncate($Drive.Size / 1GB)} 
	$Space = ForEach-Object {[math]::truncate($Drive.FreeSpace / 1GB)} 

	#{[math]::truncate($Drive.Size / 1GB)} | Out-File $OutputFile
	#$Size | Out-File -Append $OutputFile
	#$Sizes | Out-File -Append $OutputFile 
	
	$DriveName = "DeviceID: " + $drive.Name
	$DriveType = "Drive Type: " + $drive.DriveType
	$DiskSize = "Drive Size " + $Size
	$FreeSpace = "Free Space: " + $Space + "`n"
	 
	$DriveName | Out-File -Append $OutputFile
	$DriveType | Out-File -Append $OutputFile
	$DiskSize | Out-File -Append $OutputFile
	$FreeSpace | Out-File -Append $OutputFile
	
	}

}

CollectFiles -filesToCollect $OutputFile -fileDescription "Hardware" -sectionDescription "System Information"

logstop