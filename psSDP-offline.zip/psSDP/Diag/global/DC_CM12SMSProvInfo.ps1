# ***********************************************************************************************************
# Version 1.0
# Date: 01-24-2014
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description: Collects data from SMS Provider
# ***********************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

If (!$Is_SiteServer) {
	TraceOut "ConfigMgr Site Server not detected. This script gathers data only from a Site Server. Exiting."
	exit 0
}

If ($SiteType -eq 2) {
	TraceOut "Secondary Site Server detected. This script gathers data only from a Primary Site Server. Exiting."
	AddTo-CMServerSummary -Name "Boundaries" -Value "Not available on a Secondary Site" -NoToSummaryReport
	AddTo-CMServerSummary -Name "Cloud Services Info" -Value "Not available on a Secondary Site" -NoToSummaryReport
	AddTo-CMServerSummary -Name "Features Info" -Value "Not available on a Secondary Site" -NoToSummaryReport
	exit 0
}

function Get-BoundariesNotInAnyGroups ()
{
	param (
		$SMSProvServer,
		$SMSProvNamespace
	)

	process {
		$BoundaryNotInGroups = @()
		Get-CimInstance -Query "SELECT * FROM SMS_Boundary WHERE GroupCount = 0" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace | `
			foreach {
				$BoundaryType = switch($_.BoundaryType) {
					0 {"IP Subnet"}
					1 {"AD Site"}
					2 {"IPv6 Prefix"}
					3 {"IP Range"}
					default {"Unknown"}
				}

				$Boundary = @{'BoundaryID'=$_.BoundaryID;
						'BoundaryType'=$BoundaryType;
						'DisplayName'=$_.DisplayName;
						'Value'=$_.Value;
						'SiteSystems'=$_.SiteSystems}

				$BoundaryObject = New-Object PSObject -Property $Boundary
				$BoundaryNotInGroups += $BoundaryObject
			}

		# $BoundaryNotInGroups | Select BoundaryID, BoundaryType, DisplayName, Value, SiteSystems | Sort BoundaryType | Format-Table -AutoSize
		return $BoundaryNotInGroups
	}
}

function Get-Boundaries ()
{
	param (
		$SMSProvServer,
		$SMSProvNamespace
	)

	process {
		# Boundary Groups
		$BoundaryResults  = "#######################`r`n"
		$BoundaryResults += "# All Boundary Groups #`r`n"
		$BoundaryResults += "#######################`r`n"
		$BoundaryGroups = Get-CimInstance -Query "SELECT * FROM SMS_BoundaryGroup LEFT JOIN SMS_BoundaryGroupSiteSystems ON SMS_BoundaryGroupSiteSystems.GroupId = SMS_BoundaryGroup.GroupId" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace -ErrorAction SilentlyContinue -ErrorVariable WMIError
		If ($WMIError.Count -eq 0) {
			if ($BoundaryGroups -ne $null) {
				$BoundaryGroups = Get-BoundaryGroupsFromWmiResults -BoundaryGroupsFromWmi $BoundaryGroups
				$BoundaryResults += $BoundaryGroups | Sort GroupID | Format-Table -AutoSize | Out-String -Width 2048
			}
			else {
				$BoundaryResults += "    None.`r`n`r`n"
			}
		}
		else {
			$BoundaryResults += "    ERROR: $($WMIError[0].Exception.Message)`r`n`r`n"
			$WMIError.Clear()
		}

		# Boundaries with multiple Sites for Assignment
		$BoundaryResults += "###################################################`r`n"
		$BoundaryResults += "# Boundaries set for Assignment to multiple Sites #`r`n"
		$BoundaryResults += "###################################################`r`n"
		$BoundariesWithAssignments = Get-CimInstance -Query "SELECT * FROM SMS_Boundary WHERE GroupCount > 0" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace -ErrorAction SilentlyContinue -ErrorVariable WMIError
		If ($WMIError.Count -eq 0) {
			if ($BoundariesWithAssignments -ne $null) {
				$BoundaryMultipleAssignments = $BoundariesWithAssignments | ForEach {$asc = $_.DefaultSiteCode | Where-Object {$_}; if ($asc.Count -gt 1) {$_}}
				if ($BoundaryMultipleAssignments -ne $null) {
					$BoundaryMultipleAssignments = Get-BoundariesFromWmiResults -BoundariesFromWmi $BoundaryMultipleAssignments
					$BoundaryResults += $BoundaryMultipleAssignments
				}
				else {
					$BoundaryResults += "`r`n    None.`r`n`r`n"
				}
			}
			else {
				$BoundaryResults += "`r`n    None.`r`n`r`n"
			}
		}
		else {
			$BoundaryResults += "    ERROR: $($WMIError[0].Exception.Message)`r`n`r`n"
			$WMIError.Clear()
		}

		# Boundaries not in any groups
		$BoundaryResults += "#########################################`r`n"
		$BoundaryResults += "# Boundaries not in any Boundary Groups #`r`n"
		$BoundaryResults += "#########################################`r`n"
		$BoundaryNotInGroups = 	Get-CimInstance -Query "SELECT * FROM SMS_Boundary WHERE GroupCount = 0" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace -ErrorAction SilentlyContinue -ErrorVariable WMIError
		If ($WMIError.Count -eq 0) {
			if ($BoundaryNotInGroups-ne $null) {
				$BoundaryNotInGroups = Get-BoundariesFromWmiResults -BoundariesFromWmi $BoundaryNotInGroups
				$BoundaryResults += $BoundaryNotInGroups
			}
			else {
				$BoundaryResults += "`r`n    None.`r`n`r`n"
			}
		}
		else {
			$BoundaryResults += "`r`n    ERROR: $($WMIError[0].Exception.Message)`r`n`r`n"
			$WMIError.Clear()
		}

		# Members for each Boundary Group
		$BoundaryResults += "#############################`r`n"
		$BoundaryResults += "# Boundary Group Membership #`r`n"
		$BoundaryResults += "#############################`r`n`r`n"
		$Members = Get-CimInstance -Query "SELECT * FROM SMS_Boundary JOIN SMS_BoundaryGroupMembers ON SMS_BoundaryGroupMembers.BoundaryID = SMS_Boundary.BoundaryID" -ComputerName $SMSProvServer -Namespace $SMSProvNamespace -ErrorAction SilentlyContinue -ErrorVariable WMIError
		If ($WMIError.Count -eq 0) {
			if ($Members -ne $null) {
				#foreach ($Member in $($Members.SMS_BoundaryGroupMembers | Select GroupID -Unique)) { # Works with PowerShell 3.0
				foreach ($Member in $($Members | Select -ExpandProperty SMS_BoundaryGroupMembers | Select GroupID -Unique)) {  # Works with PowerShell 2.0
					$BoundaryResults += "Boundary Members for Boundary Group ID: $($Member.GroupId)`r`n"
					$BoundaryResults += "===================================================`r`n"
					$MembersWmi = $Members | Where-Object {$_.SMS_BoundaryGroupMembers.GroupID -eq $Member.GroupId} | Select -ExpandProperty SMS_Boundary
					$MemberBoundary = Get-BoundariesFromWmiResults -BoundariesFromWmi $MembersWmi
					$BoundaryResults += $MemberBoundary
				}
			}
			else {
				$BoundaryResults += "    Boundary Groups have no members.`r`n`r`n"
			}
		}
		else {
			$BoundaryResults += "    ERROR: $($WMIError[0].Exception.Message)`r`n`r`n"
			$WMIError.Clear()
		}

		return $BoundaryResults
	}
}

function Get-BoundaryGroupsFromWmiResults ()
{
	param (
		$BoundaryGroupsFromWmi
	)

	$BoundaryGroups = @()

	foreach($Group in ($BoundaryGroupsFromWmi | Select -ExpandProperty SMS_BoundaryGroup | Select GroupId -Unique)) {
		$BoundaryGroupWmi = $BoundaryGroupsFromWmi | Select -ExpandProperty SMS_BoundaryGroup | Where-Object {$_.GroupId -eq $Group.GroupId} | Select -Unique
		$SiteSystems = ""
		$SiteSystems = $BoundaryGroupsFromWmi | Select -ExpandProperty SMS_BoundaryGroupSiteSystems | Where-Object {$_.GroupId -eq $Group.GroupId} | Select -ExpandProperty ServerNalPath `
			| ForEach {$SiteSystem = $_; $SiteSystem.Split("\\")[2]}
		$BoundaryGroup = @{
			'GroupID'=$BoundaryGroupWmi.GroupID;
			'Name'=$BoundaryGroupWmi.Name;
			'AssignmentSiteCode'=$BoundaryGroupWmi.DefaultSiteCode
			'Shared'=$BoundaryGroupWmi.Shared;
			'MemberCount'=$BoundaryGroupWmi.MemberCount;
			'SiteSystemCount'=$BoundaryGroupWmi.SiteSystemCount;
			'SiteSystems'=$SiteSystems -join "; ";
			'Description'=$BoundaryGroupWmi.Description
		}

		$BoundaryGroupObject = New-Object PSObject -Property $BoundaryGroup
		$BoundaryGroups += $BoundaryGroupObject
	}

	return ($BoundaryGroups | Select GroupID, Name, AssignmentSiteCode, Shared, MemberCount, SiteSystemCount, SiteSystems, Description)
}

function Get-BoundariesFromWmiResults ()
{
	param (
		$BoundariesFromWmi
	)

	$Boundaries = @()

	foreach ($BoundaryWmi in $BoundariesFromWmi)
	{
		$BoundaryType = switch($BoundaryWmi.BoundaryType) {
			0 {"IP Subnet"}
			1 {"AD Site"}
			2 {"IPv6 Prefix"}
			3 {"IP Range"}
			default {"Unknown"}
		}

		if (($BoundaryWmi.DefaultSiteCode | ? {$_}).Count -gt 1) {
			$AssignmentSiteCode = $BoundaryWmi.DefaultSiteCode -join "; "
		}
		else {
			$AssignmentSiteCode = $BoundaryWmi.DefaultSiteCode -join ""
		}

		$Boundary = @{
			'BoundaryID'=$BoundaryWmi.BoundaryID;
			'DisplayName'=$BoundaryWmi.DisplayName;
			'BoundaryType'=$BoundaryType;
			'Value'=$BoundaryWmi.Value;
			'AssignmentSiteCode'=$AssignmentSiteCode;
			'SiteSystems'=$BoundaryWmi.SiteSystems -join "; "
		}

		$BoundaryObject = New-Object PSObject -Property $Boundary
		$Boundaries += $BoundaryObject
	}

	return ($Boundaries | Select BoundaryID, DisplayName, BoundaryType, Value, AssignmentSiteCode, SiteSystems | Sort BoundaryID | Format-Table -AutoSize | Out-String -Width 2048)
}

function Get-WmiOutput {
	Param(
		[Parameter(Mandatory=$false)]
	    [string]$ClassName,
		[Parameter(Mandatory=$false)]
	    [string]$Query,
		[Parameter(Mandatory=$false)]
	    [string]$DisplayName,
		[Parameter(Mandatory=$false)]
		[switch]$FormatList,
		[Parameter(Mandatory=$false)]
		[switch]$FormatTable
	)

	if ($DisplayName) {
		$DisplayText = $DisplayName
	}
	else {
		$DisplayText = $ClassName
	}

	$results =  "`r`n=================================`r`n"
	$results += " $DisplayText `r`n"
	$results += "=================================`r`n`r`n"

	if ($ClassName) {
		$Temp = Get-WmiData -ClassName $ClassName
	}

	if ($Query) {
		$Temp = Get-WmiData -Query $Query
	}

	if ($Temp) {
		if ($FormatList) {
			$results += ($Temp | Format-List | Out-String).Trim()
		}

		if ($FormatTable) {
			$results += ($Temp | Format-Table | Out-String -Width 500).Trim()
		}

		$results += "`r`n"
	}
	else {
		$results += "    No Instances.`r`n"
	}

	return $results
}

function Get-WmiData{
	Param(
	   [Parameter(Mandatory=$false)]
	   [string]$ClassName,
		[Parameter(Mandatory=$false)]
	   [string]$Query
	)

	if ($ClassName) {
		$Temp = Get-CimInstance -Computername $SMSProviderServer -Namespace $SMSProviderNamespace -Class $ClassName -ErrorVariable WMIError -ErrorAction SilentlyContinue
	}

	if ($Query) {
		$Temp = Get-CimInstance -Computername $SMSProviderServer -Namespace $SMSProviderNamespace -Query $Query -ErrorVariable WMIError -ErrorAction SilentlyContinue
	}

	if ($WMIError.Count -ne 0) {
		if ($WMIError[0].Exception.Message -eq "") {
			$results = $WMIError[0].Exception.ToString()
		}
		else {
			$results = $WMIError[0].Exception.Message
		}
		$WMIError.Clear()
		return $results
	}

	if (($Temp | Measure-Object).Count -gt 0) {
		$results = $Temp | Select * -ExcludeProperty __GENUS, __CLASS, __SUPERCLASS, __DYNASTY, __RELPATH, __PROPERTY_COUNT, __DERIVATION, __SERVER, __NAMESPACE, __PATH, PSComputerName, Scope, Path, Options, ClassPath, Properties, SystemProperties, Qualifiers, Site, Container
	}
	else {
		$results = $null
	}

	return $results
}

TraceOut "Started"

Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "Configuration Manager Server Information"

TraceOut "    SMS Provider: $SMSProviderServer"
TraceOut "    SMS Provider Namespace: $SMSProviderNamespace"

# ===========
# Boundaries
# ===========
TraceOut "    Getting Boundaries from SMS Provider"
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ServerInfo -Status $ScriptStrings.ID_SCCM_CMServerInfo_Boundary
$TempFileName = ($ComputerName + "_CMServer_Boundaries.TXT")
$OutputFile = join-path $pwd.path $TempFileName
$Temp = Get-Boundaries -SMSProvServer $SMSProviderServer -SMSProvNamespace $SMSProviderNamespace
$Temp | Out-File $OutputFile -Append
AddTo-CMServerSummary -Name "Boundaries" -Value "Review $TempFileName" -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Boundaries" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ============
# Cloud Roles
# ============
TraceOut "    Getting Cloud Services Data from SMS Provider"
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ServerInfo -Status $ScriptStrings.ID_SCCM_CMServerInfo_Cloud

$TempFileName = ($ComputerName + "_CMServer_CloudServices.TXT")
$OutputFile = join-path $pwd.path $TempFileName

Get-WmiOutput -ClassName SMS_Azure_CloudService -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_CloudSubscription -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_IntuneAccountInfo -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_CloudProxyConnector -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_CloudProxyRoleEndpoint -FormatTable | Out-File $OutputFile -Append -Width 500
Get-WmiOutput -ClassName SMS_CloudProxyEndpointDefinition -FormatTable | Out-File $OutputFile -Append -Width 500
Get-WmiOutput -ClassName SMS_CloudProxyExternalEndpoint -FormatTable | Out-File $OutputFile -Append -Width 500
Get-WmiOutput -ClassName SMS_AzureService -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_WSfBConfigurationData -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_OMSConfigurationData -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_OMSCollection -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_ReadinessDashboardConfigurationData -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_AfwAccountStatus -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -ClassName SMS_MDMAppleVppToken -FormatList | Out-File $OutputFile -Append

AddTo-CMServerSummary -Name "Cloud Services Info" -Value "Review $TempFileName" -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Cloud Services" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ============
# Features
# ============
TraceOut "    Getting Features List from SMS Provider"
$TempFileName = ($ComputerName + "_CMServer_Features.TXT")
$OutputFile = join-path $pwd.path $TempFileName

Get-WmiOutput -Query "SELECT FeatureGUID, FeatureType, Exposed, Status, Name FROM SMS_CM_UpdateFeatures" `
	-DisplayName "SMS_CM_UpdateFeatures" -FormatTable | Out-File $OutputFile -Append
AddTo-CMServerSummary -Name "Features Info" -Value "Review $TempFileName" -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Features Information" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

TraceOut "Completed"
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCPufvzL4TYOz/f
# +JBxQygIvQd7WpA2bn8wG8R4mag1g6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg3yT8Olux
# EXdd6CTxp4R6oWAKdy5gilPx22uH1z+Npt8wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAKVX1s5OHxUSIxWLE4AQv//5dIcm2N8Lq1mmi4vRTzDtC2V9mzHMLyBK
# kJnix2s7VfOkhxWutxfGY0V2ijDtZeXiE9x4vCXNm9RQyP/0LTAfs5gL23XpUuj9
# GC7erIgS8bmx2DXSpXT4VIVrwE4ZY1g509nwdKww+XjdljoUOXoI35op1ZeP9fnf
# OTTmLgZYh4uwN1vVU9Eyvv7UnPNbUxkGuaBC2PJYB8q4e/LwvJHyuFkAbYatq4+w
# UUt6q91DL8+Em/OjD6jZZZt5rMV7CyGXxtZJOhXNEi9rAUGPJPL1s3yw9P8aXyME
# Y9xl1dxNQN+Tb93kjnIlzvpzNdct1PmhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgBNT4PCT+ScZf8pdI0BlKYNynCR0ZnPzSjfBmylSRHMQCBmGCCja6
# mxgTMjAyMTExMTExNjUzMzYuNTI3WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY4
# N0EtRTM3NC1EN0I5MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFji2TGyYWWZXYAAAAAAWMwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjIzWhcNMjIwNDExMTkwMjIzWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY4N0EtRTM3NC1EN0I5
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArXEX9hKdyXRikv+o3YWd/CN/SLxr4LgQ
# vPlRnLck5Tnhcf6se/XLcuApga7fCu01IRjgfPnPo9GUQm+/tora2bta8VJ6zuIs
# WFDTwNXiFXHnMXqWXm43a2LZ8k1nokOMxJVi5j/Bph00Wjs3iXzHzv/VJMihvc8O
# JqoCgRnWERua5GvjgQo//dEOCj8BjSjTXMAXiTke/Kt/PTcZokhnoQgiBthsToTY
# tfZwln3rdo1g9kthVs2dO+I7unZ4Ye1oCSfTxCvNb2nPVoYJNSUMtFQucyJBUs2K
# BpTW/w5PO/tqUAidOVF8Uu88hXQknZI+r7BUvE8aGJWzAStf3z+zNQIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFAk1yvF2cmfuPzFan0bHkD7X3z0pMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAAKIQYIH147iU86OMgJh+xOpqb0ip1G0yPbRQEFUuG5+
# 8/3G+Wgjwtn3A4+riwKglJ2EwtrBRZl3ru8WUz+IE/7teSrXT1Np5BITg1z254zX
# l+US9qjhm3MahZNzGkL5qVhjSRUYiPpLEFLGcKShl6xPjhZUhMFAv/jc+YfFUAUP
# QLVwPPNrme/UJKIO+dnio3Gk/pp/0hh8pskHhsnEGrnYVlVCpHh0Do1rsfixOGHU
# Bj+phzqTOZKmFS8TMKrnE9nz5OWyg01ljPpMBHqqd59PYP/cOyfteY77A2MiLoAR
# ZAkdqrAHtHk5Y7tAnunTtGX/hO+Q0zO9mXwEFJ9ftiMwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY4N0EtRTM3NC1E
# N0I5MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQDtLGAe3UndKpNNKrMtyswZlAFh76CBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5Te9IjAiGA8y
# MDIxMTExMTIwMDI0MloYDzIwMjExMTEyMjAwMjQyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN70iAgEAMAoCAQACAiM0AgH/MAcCAQACAhEGMAoCBQDlOQ6iAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAnqYD8yPvoiw8hILRb1Xu8zXfsM4e
# 3InjK8rlmfNaeQX9PwDsxr7NiWWL1U0ZnZ+7q5hatTb3oyNjyp6aZq2W2oROpP3N
# yfbZMJxTAfvc0u/SLBDAYBRO/K7HBM+bAo3fFFjAugLR3WbsGfb1nyWHzbR+T3Jq
# uGHNhABU8vz1cWExggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAWOLZMbJhZZldgAAAAABYzANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCuX0om
# iWoIkS/IQzgj4DRuWN6whfv2mkfdJEUaGvii0jCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIJxZ3ZcdoWOhKKQpuLjL0BgEiksHL1FvXqezUasR9CNqMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFji2TGyYWWZXYA
# AAAAAWMwIgQgbNyOcP0hXvI1cKvMuGogRKjNurAH+Ok0yUHzs1p6YT0wDQYJKoZI
# hvcNAQELBQAEggEAE0TmCl3Bevl+0L6QEIrVE/hrJ1uAvY3KgZTIyvdFbHVf6Ap8
# 7EmihSPixx6h+MQkBwzuvCjFIbotUKzH8H8KpZbg8nCnF48uzH6vTObcO3jvLOQm
# BcU28uuyHp/hXbdSQ1IBJAmmEpekZG3i6mCcLdsVein1OQjGBSMNM29qBUZP0yRB
# TyQlk4po7jqtgy7drOdDevE9cKBjcy8dqEFVOAGNLBbxCXue+oRsNkG1pZ20x1Jn
# WxjKrS9n4w2fTZbCobvf9k3TxU6WDgpMpdmlX/6DIpUHNA6tAEDbzzF47mWEJQfj
# WlCSPCjU8mbs0V3VgxyToDYxu7oMWrWdBFOPjw==
# SIG # End signature block
