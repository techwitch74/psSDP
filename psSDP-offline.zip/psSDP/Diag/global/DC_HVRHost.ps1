﻿#************************************************
# DC_HVRHost.ps1
# Version 1.0 - 7/24/14
# Author: jasonf
#*******************************************************

param ([array]$vmNames)

Function ObtainHVRBrokerHostName()
{
	if(test-path "HKLM:System/CurrentControlSet/Services/Clussvc")
	{
		$HVRBrokerHostName = ((Get-ClusterResource | where {$_.ResourceType -eq "Virtual Machine Replication Broker"}).OwnerNode).name
		return $HVRBrokerHostName
	}
	else
	{
		return $null
	}
}

Function ObtainHVRBrokerProperties()
{
	"`n" | Out-File $outputfilename -Append
	"---------------------------------------------------" | Out-File $outputfilename -Append
	"Failover Cluster Hyper-V Replica broker information" | Out-File $outputfilename -Append
	"---------------------------------------------------" | Out-File $outputfilename -Append
	"`n" | Out-File $outputfilename -Append
	
	if(test-path "HKLM:System/CurrentControlSet/Services/Clussvc")
	{
		$brokerResources = Get-ClusterResource | where {$_.ResourceType -eq "Virtual Machine Replication Broker"} 
		if ($brokerResources.length -gt 0)
		{
			foreach ($resource in $brokerResources)
			{
				$resource | fl | Out-File $outputfilename -Append
				if ($resource.state -ne "Online")
				{
					"[Error]: resource is not online `n" | Out-File $outputfilename -Append
					$resourceStatus = "red"
				}
				else
				{
					if ($resourceStatus -ne "red")
					{
						$resourceStatus = "green"
					}
				}
			}
		}
		else
		{
			"[Error]: $ComputerName is a cluster node but no broker resource is configured `n" | Out-File $outputfilename -Append
			$resourceStatus = "red"
		}
		$TableString += "`t<tr><td>" + $Image.$resourceStatus + "Hyper-V Replica Resource State " + "</td></tr>`r`n"
	}
	else
	{
		"$ComputerName is not a cluster node" | Out-File $outputfilename -Append
	}
}

Function ObtainCertificateProperties()
{
	"`n" | Out-File $outputfilename -Append
	"--------------------------------------" | Out-File $outputfilename -Append
	"certificate information" | Out-File $outputfilename -Append
	"--------------------------------------" | Out-File $outputfilename -Append
	"`n" | Out-File $outputfilename -Append
	$CertificateThumbPrint = (Get-VMReplication $vm).CertificateThumbprint
	$certs = Get-ChildItem cert: -recurse | ?{$_.Thumbprint -eq $CertificateThumbprint}
	
	if ($certs -ne $null)
	{
	foreach ($certificate in $certs)
	{
		$certificate | fl | Out-File $outputfilename -Append
	}
	}
	else
	{
		"[error]:  no certificate with thumbprint $CertificateThumbPrint found in certificate store" | Out-File $outputfilename -Append
	}
}

Function RunPing ([string]$PingCmd="")
{	
	$PingCmdName = $PingCmd.Replace(":", "_")
	$PingCmdLength = $PingCmd.Length + 5
	$pingOutputFileName = Join-Path $PWD.Path "ping.txt"
	
	#"`n" 					| Out-File -FilePath $pingOutputFileName -encoding ASCII -append
	"-" * ($PingCmdLength)	| Out-File -FilePath $pingOutputFileName -encoding ASCII -append
	"Ping $PingCmd"		| Out-File -FilePath $pingOutputFileName -encoding ASCII -append
	"-" * ($PingCmdLength)	| Out-File -FilePath $pingOutputFileName -encoding ASCII -append
	#"`n" 					| Out-File -FilePath $pingOutputFileName -encoding ASCII -append

	$ProcessName = "cmd.exe"
	$Arguments = "/c ping.exe " + $PingCmd + " >> `"$pingOutputFileName`""
	BackgroundProcessCreate -Process $ProcessName -Arguments $Arguments -CollectFiles $false | out-null
	waitforbackgroundprocesses 
	#because of encoding issues with ping.exe, output to temporary file, then get content of temporary file, then delete file. 
	$pingOutput = Get-Content $pingOutputFileName
	$pingOutput | Out-File $outputfilename -Append
	Remove-Item $pingOutputFileName -Force
	#check ping output for a reply, e.g. "time=264ms" or "time<1ms"
	$pingReplyReceived = $false
	$regex = ".*?(time).*?\d+(ms)"
	if (($pingOutput | ?{$_ -match $regex}).count -gt 0)
	{
		#we received a reply
		$pingReplyReceived = $true
	}
	else
	{
		#we didn't receive a reply
	}
	return $pingReplyReceived
}

#use http://msdn.microsoft.com/en-us/library/hh850306(v=vs.85).aspx to test replictation:
#RecoveryConnectionPoint - server name
#RecoveryServerPortNumber - port number
#AuthenticationType - 1 Kerberos, 2 Certificate
#CertificateThumbPrint - Certificate thumbprint to use when the AuthenticationType parameter is certificate based authentication
#BypassProxyServer - Bypass the proxy server when connecting to the replica server

Function TestReplicationConnection ([string]$RecoveryConnectionPoint, [int]$RecoveryServerPortNumber, [int]$AuthenticationType, [string]$CertificateThumbPrint, [bool]$BypassProxyServer)
{
	$MSVMReplicationServiceClass = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_ReplicationService'

	$job = [WMI]$MSVMReplicationServiceClass.TestReplicationConnection($RecoveryConnectionPoint,$RecoveryServerPortNumber,$AuthenticationType,$CertificateThumbPrint,$BypassProxyServer).Job

	$TestVMReplicationSucceeded = $false
	for ($i = 0; $i -lt 5; $i++)
	{
	    if ($job.ErrorCode –ne 0)
	    {
	        start-sleep 1
	    }
	    else
	    {
	        $i=5
	        $TestVMReplicationSucceeded = $true
	    }    
	}

	if ($TestVMReplicationSucceeded)
	{
	    "VM replication test succeeded" | Out-File $outputfilename -Append
	}
	else
	{
	    "[error] VM replication test failed using http://msdn.microsoft.com/en-us/library/hh850306(v=vs.85).aspx.  Dumping job information:`n" | Out-File $outputfilename -Append
	    $job | Out-File $outputfilename -Append
	}
	return $TestVMReplicationSucceeded
}

# Red/Yellow/Green status indicator
$Image = @{ 
"Red" = "<font face=`"Webdings`" color=`"Red`">n </font>"; 
"Yellow" = "<font face=`"Webdings`" color=`"Orange`">n </font>"; 
"Green" = "<font face=`"Webdings`" color=`"Green`">n </font>"; 
}

foreach ($vm in $vmNames)
{	
	$vmReplication = get-vmreplication $vm
	$primaryServer = $vmReplication.PrimaryServer
	$replicaServer = $vmReplication.ReplicaServer
	$authType = $vmReplication.AuthenticationType
	$replicaServerPort = $vmReplication.ReplicaServerPort
	$VMReplicationAuthorizationEntry = Get-VMReplicationAuthorizationEntry 
	$Item_Summary = new-object PSObject
	$outputfilename = join-path $pwd.Path ($ComputerName + "_Hyper-V_Replica_" + $vm) 

	$HVRBrokerHostName = ObtainHVRBrokerHostName
	$isPrimaryClusterNode = $false
	$isReplicaClusterNode = $false
	if ($HVRBrokerHostName -ne $null)
	{
		"[info]:  HVR broker host name:  $HVRBrokerHostName" | WriteTo-StdOut
		if (($primaryServer -ne $ComputerName) -and ($replicaServer -ne $ComputerName))
		{
			$dependencyExpression = (Get-ClusterResourceDependency ((Get-ClusterResource | where {$_.ResourceType -eq "Virtual Machine Replication Broker"}).Name)).DependencyExpression
			if (((($primaryServer).split("."))[0]).ToString() -match ($dependencyExpression.replace("([","")).replace("])",""))
			{
				$isPrimaryClusterNode = $true
			}
			elseif (((($replicaServer).split("."))[0]).ToString() -match ($dependencyExpression.replace("([","")).replace("])",""))
			{
				$isReplicaClusterNode = $true
			}
		}
	}
	
	if (((($primaryServer).split("."))[0] -eq $ComputerName) -or $isPrimaryClusterNode)
	{
		$outputfilename += "_primary.txt"
		
		"--------------------------------------" + ("-" * $ComputerName.length) | Out-File $outputfilename -Append
		"Hyper-V Replica information for host: $ComputerName" | Out-File $outputfilename -Append
		"--------------------------------------" + ("-" * $ComputerName.length) | Out-File $outputfilename -Append
		
		#Primary server configuration
		$vmReplication | fl | Out-File $outputfilename  -Append
		
		#Primary server tests
		
		#################################################
		#Test 3 - Ping replica server from primary server
		#################################################
		$pingReplyReceived = RunPing -PingCmd $replicaServer
		if ($pingReplyReceived -eq $true)
		{
			#green - we were able to get a reply from $replicaserver
			$pingStatus = "green"
		}
		else
		{
			#yellow - we didn't get a reply from $replicaserver when we attempted to ping it
			$pingStatus = "yellow"
		}
		
		#output
		$TableString += "`t<tr><td>" + $Image.$pingStatus + "Ping $replicaServer from $primaryServer " + "</td></tr>`r`n"
	
		
		###########
		#end Test 3
		###########
		
		###################################################
		#Test 4 - Verify that proxy servers are not present
		###################################################
		"`n" | Out-File $outputfilename -Append
		"--------------------------------------" | Out-File $outputfilename -Append
		"Proxy server configuration information" | Out-File $outputfilename -Append
		"--------------------------------------" | Out-File $outputfilename -Append
		"`n" | Out-File $outputfilename -Append
		invoke-expression "Netsh winhttp show proxy" | Out-File $outputfilename -Append
		#todo table
		###########
		#end Test 4
		###########
		
		#########################################
		#test 5 - Primary Server is Authenticated
		#########################################
		"`n" | Out-File $outputfilename -Append
		"-----------------------------------------------------------------------------------------------" | Out-File $outputfilename -Append
		"Test VM replication connectivity using Msvm_ReplicationService.TestReplicationConnection method" | Out-File $outputfilename -Append
		"http://msdn.microsoft.com/en-us/library/hh850306(v=vs.85).aspx" | Out-File $outputfilename -Append
		"-----------------------------------------------------------------------------------------------" | Out-File $outputfilename -Append
		"`n" | Out-File $outputfilename -Append
		
		#todo - logic to decide whether to bypass proxy server
		$BypassProxyServer = $false
		if ($authType -match "Kerberos")
		{
			$intAuthType = 1
		}
		else
		{
			$intAuthType = 2
			$CertificateThumbPrint = (Get-VMReplication $vm).CertificateThumbprint
		}
		$TestReplicationConnection = TestReplicationConnection -RecoveryConnectionPoint $replicaServer -RecoveryServerPortNumber $replicaServerPort -AuthenticationType $intAuthType -CertificateThumbprint $CertificateThumbPrint -BypassProxyServer $BypassProxyServer
		
		if ($TestReplicationConnection -eq $true)
		{
			$TestReplicationConnectionStatus = "green"
		}
		else
		{
			$TestReplicationConnectionStatus = "red"
		}
		$TableString += "`t<tr><td>" + $Image.$TestReplicationConnectionStatus + "Test replication connectivity from $primaryServer to $replicaServer " + "</td></tr>`r`n"
		###########
		#end Test 5
		###########
		
		####################################################################################################
		#Test 10 - If Kerberos authentication is chosen, make sure that both machines are in trusted domains
		####################################################################################################
		if ($authType -match "Kerberos")
		{
			"`n" | Out-File $outputfilename -Append
			"--------------------------------------" | Out-File $outputfilename -Append
			"nltest /domain_trusts output" | Out-File $outputfilename -Append
			"--------------------------------------" | Out-File $outputfilename -Append
			"`n" | Out-File $outputfilename -Append
			invoke-expression "nltest /domain_trusts" | Out-File $outputfilename -Append
			$replicaDomainName = (Get-WmiObject -computername $replicaServer WIN32_ComputerSystem).Domain
			$primaryDomainName = (Get-WmiObject WIN32_ComputerSystem).Domain
			$replicaDomainTrustedStatus = "red"
			if ($primaryDomainName -match $replicaDomainName)
			{
				$replicaDomainTrustedStatus = "green"
			}
			else
			{
				$domainInfo = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
				$domainTrusts = $DomainInfo.GetAllTrustRelationships()
				foreach ($trust in $domainTrusts)
				{
					if ($trust.TargetName -match $replicaDomainName)
					{
						if ($trust.TrustDirection -eq "Bidirectional")
						{
							$replicaDomainTrustedStatus = "green"	
						}
					}
				}
				$forestInfo = [System.DirectoryServices.ActiveDirectory.Forest]::GetCurrentForest()
				$forestTrusts = $ForestInfo.GetAllTrustRelationships()
				foreach ($trust in $forestTrusts)
				{
					if ($trust.TargetName -match $replicaDomainName)
					{
						if ($trust.TrustDirection -eq "Bidirectional")
						{
							$replicaDomainTrustedStatus = "green"
						}
					}
				}
			}
			$TableString += "`t<tr><td>" + $Image.$replicaDomainTrustedStatus + "Check if Domain is trusted" + "</td></tr>`r`n"
		}
		############
		#end Test 10
		############
		
		####################################################################################################
		#Test 11 - If Kerberos authentication is chosen, check if the SPN registration is successful 
		####################################################################################################
		if ($authType -match "Kerberos")
		{
			"`n" | Out-File $outputfilename -Append
			"------------------------------" | Out-File $outputfilename -Append
			"setspn /l $computername output" | Out-File $outputfilename -Append
			"------------------------------" | Out-File $outputfilename -Append
			invoke-expression "setspn /l $computername" | Out-File $outputfilename -Append
			"`n" | Out-File $outputfilename -Append
		}
		############
		#end Test 11
		############
		
		####################################################################################################
		#Test 12 - If Certificate authentication is chosen, check certificate properties
		####################################################################################################
		if ($authType -match "Certificate")
		{
			ObtainCertificateProperties
		}
		############
		#end Test 12
		############
		
		####################################################################################################
		#Test 13 - Check if any third-party monitoring tool is running in the environment
		####################################################################################################
		#todo - revisit QnA
		############
		#end Test 13
		############
		
		#########
		#Cluster
		#########
		ObtainHVRBrokerProperties
		############
		#end cluster
		############
		
		$TableString = ("<table>`r`n" + $TableString + "</table>") 
		add-member -inputobject $Item_Summary -membertype noteproperty -name "Tests Performed" -value $TableString
		$Item_Summary | ConvertTo-Xml2 | update-diagreport -id ("11") -name "Hyper-V Replica Tests for $vm" -verbosity informational
		$TableString = $null	
		$Item_Summary = $null
	}
	elseif (((($replicaServer).split("."))[0] -eq $ComputerName) -or $isReplicaClusterNode)
	{
		$outputfilename += "_replica.txt"

		
		"--------------------------------------" + ("-" * $ComputerName.length) | Out-File $outputfilename -Append
		"Hyper-V Replica information for host: $ComputerName" | Out-File $outputfilename -Append
		"--------------------------------------" + ("-" * $ComputerName.length) | Out-File $outputfilename -Append

		#Replica server configuration
		$vmReplication | fl | Out-File $outputfilename -Append
		
		#Replica server tests

		##############################################################
		#Test 1 - Verify that recovery server is configured as replica
		##############################################################

		"`n" | Out-File $outputfilename -Append
		"--------------------------------------" + ("-" * $vm.length) | Out-File $outputfilename -Append
		"Replication state for virtual machine:  $vm" | Out-File $outputfilename -Append
		"--------------------------------------" + ("-" * $vm.length) | Out-File $outputfilename -Append
		"`n" | Out-File $outputfilename -Append
		(get-vm $vm).ReplicationState | Out-File $outputfilename -Append
		###########
		#end Test 1
		###########	
		
		############################################
		#Test 2 - Verify network listener on replica 
		############################################
		"`n" | Out-File $outputfilename -Append
		"---------------------------------------------------------" | Out-File $outputfilename -Append
		"Hyper-V Replica Network Listener information"
		"`"Netsh http show servicestate | findstr HVRROOT`" output" | Out-File $outputfilename -Append
		"---------------------------------------------------------" | Out-File $outputfilename -Append
		"`n" | Out-File $outputfilename -Append
		
		Invoke-Expression "Netsh http show servicestate | findstr HVRROOT" | Out-File $outputfilename -Append
				
		###########
		#end Test 2
		###########		
		
		###################################################
		#Test 4 - Verify that proxy servers are not present
		###################################################
		"`n" | Out-File $outputfilename -Append
		"--------------------------------------" | Out-File $outputfilename -Append
		"Proxy server configuration information" | Out-File $outputfilename -Append
		"--------------------------------------" | Out-File $outputfilename -Append
		"`n" | Out-File $outputfilename -Append
		invoke-expression "Netsh winhttp show proxy" | Out-File $outputfilename -Append
		###########
		#end Test 4
		###########
		
		#######################################################################
		#Test 6 - Verify that primary server is authorized to write to recovery
		#######################################################################
		"`n" | Out-File $outputfilename -Append
		"------------------------------------------" | Out-File $outputfilename -Append
		"Get-VMReplicationAuthorizationEntry output" | Out-File $outputfilename -Append
		"------------------------------------------" | Out-File $outputfilename -Append
		"`n" | Out-File $outputfilename -Append
		$VMReplicationAuthorizationEntry | Out-File $outputfilename -Append
		###########
		#end Test 6
		###########
		
		################################################################################
		#Test 7 - Verify that the folder given in Hyper-V settings is readable/writeable
		################################################################################
		"`n" | Out-File $outputfilename -Append
		"--------------------------------------" | Out-File $outputfilename -Append
		"Storage location ACL information" | Out-File $outputfilename -Append
		"--------------------------------------" | Out-File $outputfilename -Append
		"`n" | Out-File $outputfilename -Append
		get-acl $VMReplicationAuthorizationEntry.storageloc | fl | Out-File $outputfilename -Append		
		###########
		#end Test 7
		###########
		
		################################################
		#Test 8 - Verify that Firewall rules are enabled
		################################################
		$HVRHTTPListenerRuleStatus = "red"
		if ($authType -match "Kerberos")
		{
			"`n" | Out-File $outputfilename -Append
			"-----------------------------------------------------" | Out-File $outputfilename -Append
			"firewall rule configuration (kerberos authentication)" | Out-File $outputfilename -Append
			"-----------------------------------------------------" | Out-File $outputfilename -Append
			$netshOutput = invoke-expression "netsh advfirewall firewall show rule name=`"Hyper-V Replica HTTP Listener (TCP-In)`"" 
			$netshOutput | Out-File $outputfilename -Append
			$netshOutput | %{if ($_ -match "Yes"){$HVRHTTPListenerRuleStatus = "green"}}
			"`n" | Out-File $outputfilename -Append
		}
		else
		{
			"`n" | Out-File $outputfilename -Append
			"--------------------------------------------------------------" | Out-File $outputfilename -Append
			"firewall rule configuration (certificate-based authentication)" | Out-File $outputfilename -Append
			"--------------------------------------------------------------" | Out-File $outputfilename -Append
			$netshOutput = invoke-expression "netsh advfirewall firewall show rule name=`"Hyper-V Replica HTTPS Listener (TCP-In)`"" 
			$netshOutput | Out-File $outputfilename -Append
			$netshOutput | %{if ($_ -match "Yes"){$HVRHTTPListenerRuleStatus = "green"}}
			"`n" | Out-File $outputfilename -Append
		}
		$TableString += "`t<tr><td>" + $Image.$HVRHTTPListenerRuleStatus + "Verify that firewall rules are enabled" + "</td></tr>`r`n"
		###########
		#end Test 8
		###########
		
		############################################################
		#Test 9 - Check if there are any WAN optimizers in the setup
		############################################################
		#todo - revisit QnA
		###########
		#end Test 9
		###########
		
		####################################################################################################
		#Test 11 - If Kerberos authentication is chosen, check if the SPN registration is successful 
		####################################################################################################
		if ($authType -match "Kerberos")
		{
			"`n" | Out-File $outputfilename -Append
			"------------------------------" | Out-File $outputfilename -Append
			"setspn /l $computername output" | Out-File $outputfilename -Append
			"------------------------------" | Out-File $outputfilename -Append
			invoke-expression "setspn /l $computername" | Out-File $outputfilename -Append
			"`n" | Out-File $outputfilename -Append
		}
		############
		#end Test 11
		############
		
		####################################################################################################
		#Test 12 - If Certificate authentication is chosen, check certificate properties
		####################################################################################################
		if ($authType -match "Certificate")
		{
			ObtainCertificateProperties
		}
		############
		#end Test 12
		############
		
		####################################################################################################
		#Test 13 - Check if any third-party monitoring tool is running in the environment
		####################################################################################################
		#todo - revisit QnA
		############
		#end Test 13
		############
		
		####################################################################################################
		#Test 14 - Check antivirus exclusions for replica directories
		####################################################################################################
		#todo - revisit QnA
		############
		#end Test 14
		############
		
		####################################################################################################
		#Test 15 - Verify that the replica storage location has enough space to accommodate the primary VHDs
		####################################################################################################
		#todo - validate detection logic for this case
		"`n" | Out-File $outputfilename -Append
		"--------------------------------------" | Out-File $outputfilename -Append
		"Free space information" | Out-File $outputfilename -Append
		"--------------------------------------" | Out-File $outputfilename -Append
		"`n" | Out-File $outputfilename -Append
		$vmStorageDrive = split-path ($VMReplicationAuthorizationEntry.storageloc) -qualifier
		$FreeSpace = (Get-WmiObject -Query "Select * from Win32_LogicalDisk where Name =`'$vmStorageDrive`'").FreeSpace /1GB
		"$FreeSpace GB available free space on $vmStorageDrive" | Out-File $outputfilename -Append
		############
		#end Test 15
		############
		
		####################################################################################################
		#Test 16 - Check the replication state of the VM
		####################################################################################################
		############
		#end Test 16
		############
		
		#########
		#Cluster
		#########
		ObtainHVRBrokerProperties
		############
		#end cluster
		############
		
		$TableString = ("<table>`r`n" + $TableString + "</table>") 
		add-member -inputobject $Item_Summary -membertype noteproperty -name "Tests Performed" -value $TableString
		$Item_Summary | ConvertTo-Xml2 | update-diagreport -id ("11") -name "Hyper-V Replica Tests for $vm" -verbosity informational
		$TableString = $null	
		$Item_Summary = $null
	}
	else
	{
		"this host is not primary or replica for the VM:  $vm" | WriteTo-StdOut
	}
	$fileDescription = "$vm replication information"
	$sectionDescription = "Hyper-V Replica Information" 
	collectfiles -filesToCollect $outputfilename -fileDescription $fileDescription -sectionDescription $sectionDescription -noFileExtensionsOnDescription
	$outputfilename = $null
	$fileDescription = $null
	$sectionDescription = $null
}
# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDPt3Mu/Z0Lyxi3
# 63UWBkee/X+6tl6zkhQErX5MsJhphKCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgrmW27u+k
# ILmxmJuZr7suE8qs+zF05cvTlUwJu2r2W60wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAA7QnWiHEh88A07sJrge+sHsyzgtiSkgXeu1kIRuFmCkKG/ORktR01zB
# BkIbpPuKx5HHx2bv5I45zC41o/NFrGoaNG114q2jsGKCi+2OLwZ/Md/fLet+CdGW
# a6Tn4kBeXND6pKhkKLGvdH0PiNqcvrUZJop0sWPfNCdhVpj4yuqdfn9wCY2x6+k2
# F/MFZbGAid4iAJDIrk09JM9tVLnfuSss2aHnhTbcG4/ucFRwqdrDsStpGVEdN1Ot
# l1hXg5b/kOdHa/XchbhUop3i1L9vK5AzMP12hg8ONmtz3BZXs8ykf0NXSRSnlAZ5
# TlMvcQIPi/b7sbRH2mGkx+vArFbiREChghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQggfyYC1Gw+kpYQP8GkkjbAPysa9FBCaDC75kl0NR6rFMCBmCKzptS
# wRgTMjAyMTA1MTkyMjIyNTUuNzY2WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABPIv9ubM/R5f9AAAAAAE8MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyM1oXDTIyMDExMjE3MjgyM1owgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00
# QkIwLTgyNDYxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCYECrpaQOq9jkOBpC345fQ
# 0IvOpRqK8nEe+jopJc/5XNNqzanq5hrd9wib4RdvpuPj68n5Dm/XZu2vCqnWoxhy
# 3ixrbgS/rg3CS3bqp8Ag1UQg/xAz32TueeTOY1cOelcXRahosIcjlrrkv13AacFX
# m4AbYMCgYM6BzdZKARebc6zEv+4QCy4+1AV8RHQHEOdoj42OJpbFWlHvYKzXuM1A
# H4vmjT9o/fCq2mWD7Ig2/CpaId2gHK6R+S909iK27uVkjVap2/Sb4ATOLJbaVQ+X
# 0+hYbEcCesf93g+tAQXuvA8dH63doK5I5zdZCF5U/3Dibfl7ZCFsU6ks+ph4jJrb
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQU4aFn4soS+jazYT8lGOoYvyZnPEYwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAMvcQjJTdl3luSMzFqRkxRklJ+KWRUUlB
# 3I2KJVWb4Gn6eWdJTiWdC1uxejF2oPX0b+X9QIhi8u1AaV792eEit2lQzqVgPify
# TZGLjzK2Oou4Pj/F58Pp2m6HupGfuNAehln+hSvvIE5ggEnCiv9lVkAJOMlLHF38
# DbPv7pyWs0Lzv2sjZwPHvdhtV8lBtOYsE8Nxznlbsyc80vRnReqm8JQK6Z8xAD4S
# eY8duFFXhciETG2E0bh+/N3mwGnzXJzMbSKAKkzIw6Yxqf+zHzWPFim9DGZwmchq
# +6JBKtb4EGT0EFtfqGCrOPD5O7uPwSdj1apgXqo7Hctx7hcs5qjpwjCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAHUt0elneaPLba16Ke63RR3B65OaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPqk8wIhgPMjAyMTA1MTkyMzE2MzFaGA8yMDIxMDUyMDIzMTYzMVowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+qTwIBADAKAgEAAgIYqAIB/zAHAgEAAgIR
# MzAKAgUA5FD7zwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAI+E73p4h9kk
# SYCzO+rXLK7RK5Ia4XU7rSWLex0xaCG/tD8TBNoGZmVMrG4m9+o4FLmoY6aEzPou
# xTR4PEZU7Qh1EwiNCZblZFkfz+rofE0LgYHWkXw/kJuAVExDxVWBlamtk6kY7p1/
# XyFZKWFBMQMEU6Iu1idtHDCvZZNdvLOxMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE8i/25sz9Hl/0AAAAAATwwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgL4x/8h52mdll1z268DIDNfxe9mFQGa9mcYKXrjhkrzEwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCgSQK6TSS/wOc6qbfUfBGv7YhsPfGYhbgV
# IYrhJuhaRjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABPIv9ubM/R5f9AAAAAAE8MCIEIB+co0f6Uly9BxK096y0E+Z8u4RNWInNiBJi
# 2xgL13agMA0GCSqGSIb3DQEBCwUABIIBAEVvtEuK6nH3R6YjQck9eZV++EwqpNGD
# hJQXQvIpYIQ+hqvBmxIPK13YUE+UxteI6FoLTA8Qa+Gf8iG1DpBEDxI7KNmyxxTl
# SbD9XjPdo6o1MZT+XvQbHrJbmKT/PQYAw4q/mUt7fe24dqYik3kLI6f6NNesTRoZ
# NAqpV+iNvHHow1358d+9Y/CcSxV9n6Qfcu7iTs6FRnSTbyqzwo20Wv6osCLqQwSc
# FbxoVElHgamKeMg77IIoQPjMMxsQgKxloZ/1X0GEvpZdiXINXLFo8yZ3sHnGg2la
# A5CqgDAZvVGtTPHznRPF8WSKANOQrF+ucE00BQNu44c0ctCtT2ZZZFw=
# SIG # End signature block
