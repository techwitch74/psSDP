﻿#************************************************
# DC_RDSSH.ps1
# Version 1.0.1
# Date: 21-01-2012
# Author: Daniel Grund - dgrund@microsoft.com
# Description: 
#	This script gets the RDSSH config and
#   checks vital signs to inform user.
# 1.0.0 Beta release
#************************************************
PARAM(
	$TargetHost,
   	$RDSobject,
	$OutputFileName ,
	$OS,
	$bIsRDSSH
)
# globals and function definitions for RDS
$OutputFolder = $PWD.Path 
Import-LocalizedData -BindingVariable RDSSDPStrings

# get all the RDP-Tcp settings
$Query = "Select * from Win32_TSGeneralSetting where TerminalName='RDP-Tcp'" 
[array]$RDPSettings = get-WmiObject -Query $Query -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
$Query = "Select * from Win32_TSLogonSetting where TerminalName='RDP-Tcp'" 
$RDPSettings += get-WmiObject -Query $Query -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
$Query = "Select * from Win32_TSSessionSetting where TerminalName='RDP-Tcp'" 
$RDPSettings += get-WmiObject -Query $Query -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
$Query = "Select * from Win32_TSEnvironmentSetting where TerminalName='RDP-Tcp'" 
$RDPSettings += get-WmiObject -Query $Query -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
$Query = "Select * from Win32_TSRemoteControlSetting where TerminalName='RDP-Tcp'" 
$RDPSettings += get-WmiObject -Query $Query -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
$Query = "Select * from Win32_TSClientSetting where TerminalName='RDP-Tcp'" 
$RDPSettings += get-WmiObject -Query $Query -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
$RDPSettings = FilterWMIObject $RDPSettings 

$OutputFileName = SaveAsXml $RDPSettings  ($TargetHost + "_RDPSettings.xml") $OutputFileName

# See if RDS is enabled otherwise exit
$RDSEnabled = Get-RemoteRegistryKeyProperty -ComputerName $TargetHost -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -Property fDenyTSConnections
$RDSEnabledPol = Get-RemoteRegistryKeyProperty -ComputerName $TargetHost -Path "HKLM:\Software\Policies\Microsoft\Windows NT\Terminal Services" -Property fDenyTSConnections
UpdateAndMessage -Id "RC_RDSENABLED" -Detected (($RDSEnabled.fDenyTSConnections-eq 1) -or ($RDSEnabledPol.fDenyTSConnections -eq 1) )
$OOBEInProgress = Get-RemoteRegistryKeyProperty -ComputerName $TargetHost -Path "HKLM:\SYSTEM\Setup" -Property OOBEInProgress
UpdateAndMessage -Id "RC_RDSOOBE" -Detected ($OOBEInProgress.OOBEInProgress -eq 1)

if ( ($RDSEnabled.fDenyTSConnections-eq 1) -or ($RDSEnabledPol.fDenyTSConnections -eq 1) -or ($OOBEInProgress.OOBEInProgress -eq 1) )
{
	# RDS disabled, no sense to continue
	return
}




# RULE  524 : see what port is configured
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSGetPort
$RDPPort = Get-RemoteRegistryKeyProperty -ComputerName $TargetHost -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp" -Property PortNumber
UpdateAndMessage -Id "RC_RDSPort" -Detected ($RDPPort -eq $null)


#  test if there is something listening on that port
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSListenPort
UpdateAndMessage -Id "RC_RDSListenPortDefault" -Detected  (($RDPPort -ne $null) -and ($RDPPort.PortNumber -ne "3389"))

if (($RDPPort -ne $null) -and ([RDSHelper]::RDPTestPort($TargetHost,$RDPPort.PortNumber) -eq $false))
{ 
	Update-DiagRootCause -Id "RC_RDSListenPort" -Detected $true -Parameter @{"Error" = $RDSSDPStrings.ID_RDSListenPortError + " " + $RDPPort.PortNumber; "Solution" = ""}
	Add-GenericMessage -Id "RC_RDSListenPort"
}else{
	Update-DiagRootCause -Id "RC_RDSListenPort" -Detected $false -Parameter @{"Error" = $RDSSDPStrings.ID_RDSListenPortError + " " + $RDPPort.PortNumber; "Solution" = ""}
}
# END RULE 524

# See if server default listener is up
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSQWinSta
$DefaultListener = (qwinsta "/Server:$($TargetHost)")
if ($DefaultListener -ne $null)
{
    $savepath = $OutputFolder + "\"+ $TargetHost+"_QWinSta.txt"
	[array]$OutputFileName += $savepath
    $DefaultListener | Out-File $savepath
	$IsListening =(!$DefaultListener[$DefaultListener.Length-1].ToString().Contains("65536")) -and (!$DefaultListener[$DefaultListener.Length-1].ToString().Contains("rdp-tcp"))
	UpdateAndMessage -Id "RC_RDSIsListening" -Detected $IsListening

}
$CertNotValid  = $false

#open TCP connection on target port and get cert
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSRDPCert
$certfile = $OutputFolder + "\"+ $TargetHost + "_RDPCert.cer"
$RemoteCertificate = [RDSHelper]::RDPGetCert($TargetHost, $RDPPort.PortNumber, $certfile)
if ($RemoteCertificate -eq $null)
{
	UpdateAndMessage -Id "RC_RDSCert" -Detected $true
}else{
	UpdateAndMessage -Id "RC_RDSCert" -Detected $false
	[array]$OutputFileName += $certfile
	UpdateAndMessage -Id "RC_RDSCertMatch" -Detected ($RDPSettings[0].SSLCertificateSHA1Hash -ne $RemoteCertificate.GetCertHashString())

}

#$ipadress = [RDSHelper]::DNSLookup($node)

# check to see if hardware acceleration is set for rdpdd
UpdateAndMessage -Id "RC_RDSH_RDPDD" -Detected (IsRDPDDAccelerated)

# check for reg permisions on the LICENSE keys
UpdateAndMessage -Id "RC_RDSH_DEVLIC" -Detected (IsRegPermIssue)

if ($bIsRDSSH -eq $true)
{
	# try to verify the license type with the available licenses on the LServer
	$RDSobject = get-WmiObject -Class Win32_TerminalServiceSetting -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
	Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSLicenseServer
	[array]$LicenseServerReport = "Specified RDS License Servers:"
	[array]$SpecifiedLicenseServer = $RDSObject.GetSpecifiedLicenseServerList().SpecifiedLSList
	$LicenseServerReport+= $SpecifiedLicenseServer
	
	#$LicenseServerReport+= ""
	#$LicenseServerReport+= "Discovered RDS License servers:"
	#$LicenseServerReport+=$LicenseServer.Length,$RDSObject.GetRegisteredLicenseServerList().RegisteredLSList.Split(" ")

	if ($SpecifiedLicenseServer -ne $null )
	{
		# RULE 525 get RDS RCM 509 certificate only if we got a specified license server
		UpdateAndMessage -Id "RC_RDSLicenseServer" -Detected $false
		Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSx509Cert
		#[System.Security.Cryptography.X509Certificates.X509CertificateCollection]
		$ByteArray = Get-RemoteRegistryKeyProperty -ComputerName $TargetHost -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM" -Property "X509 Certificate"
		$RDSCertificates = $ByteArray.'X509 Certificate'
		#$ByteArray = Get-RemoteRegistryKeyProperty -ComputerName $TargetHost -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server\RCM" -Property "X509 Certificate2"
		#$RDSCertificates2 = [RDSHelper]::GetCertCollFromReg($ByteArray."X509 Certificate2")
		
		UpdateAndMessage -Id "RC_RDSx509Cert" -Detected ($RDSCertificates -eq $null) # -or ($RDSCertificates2 -eq $null))

		#END RULE 525

	   $LicenseServerReport+= ""
	   $LicenseServerReport +="Connectivity to Specified License Servers:"
	   $CanConnectToLicenseServer = $false
	   $SpecifiedLicenseServer|foreach-object{
		   Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status ($RDSSDPStrings.ID_RDSLicenseServerConnect + " " + $_)
		   $TStoLSConnectivityStatus = $RDSObject.GetTStoLSConnectivityStatus($_).TStoLSConnectivityStatus
		   $string = GetLSConnectDesc $TStoLSConnectivityStatus
		   $LicenseServerReport+= "License Server " + $_ + " status: "+ $string
		   #note dgrund, not enough need more failure status check http://msdn.microsoft.com/en-us/library/windows/desktop/ff955669(v=vs.85).aspx unsure why we need -and here
		   if (($TStoLSConnectivityStatus -ne  1) -and ($TStoLSConnectivityStatus -ne 2) -and ($TStoLSConnectivityStatus -ne 11))
		   {
				UpdateAndMessage -Id "RC_RDSLicenseServerConnect" -RootCause $RDSSDPStrings.ID_RDSLicenseServerConnectError  -Solution ($RDSSDPStrings.ID_RDSLicenseServerConnectSolution + " " + $_) -Detected $true 
		   }else{
		   		$CanConnectToLicenseServer = $true
				Update-DiagRootCause -Id "RC_RDSLicenseServerConnect" -Detected $false 
			}
	   } #end foreach-object


	}else{ #$SpecifiedLicenseServer
		UpdateAndMessage -Id "RC_RDSLicenseServer" -Detected $true
	}

	# get the licenses from the server where the licensetype is the RDS requested licensetype
	$LicenseServerReport+= "The server is configured for: " + (TSLicensingType -Type $RDSobject.LicensingType)
	if ($RDSobject.LicensingType -eq 2) #per device
	{

		$LicenseType= 0
	}else # assume per user
	{

		$LicenseType = 1
	}
	
	# Ask to connect to the remote license server
	if ($SpecifiedLicenseServer -ne $null)
	{
		$Connect = Get-DiagInput -id "QuestionYesNo" -Parameter @{"Question" = $RDSSDPStrings.ID_RDSLSConnectInteract; "QuestionDescription" = $RDSSDPStrings.ID_RDSLSConnectInteractDescription}
		if ($Connect -eq "Yes") 
		{
			foreach ($LicenseServer in $SpecifiedLicenseServer)
			{
				$RDSLServerLicenses = FilterWMIObject (get-WmiObject -Class Win32_TSLicenseKeyPack  -Namespace root\cimv2 -ComputerName $LicenseServer -Authentication PacketPrivacy -Impersonation Impersonate)
	        
				if ($RDSLServerLicenses -ne $null)
				{
					$OutputFileName = SaveAsXml $RDSLServerLicenses  ($LicenseServer + "_RDS_Licenses.xml") $OutputFileName
					$relevantLicenses += $RDSLServerLicenses| where-object {
									($_.TotalLicenses -gt 0) -and ($_.TotalLicenses -lt 4294967295) -and ($_.ProductType -eq $LicenseType) -and
									($_.ProductVersionID -ge [System.Convert]::ToInt32($OS.Version[2].ToString())) } 
					$relevantLicenses| foreach-object {
							$availablelicenses += $_.AvailableLicenses
					}
				}
			} # end foreach ($LicenseServer in $SpecifiedLicenseServer)
			if ($relevantLicenses -ne $null)
			{
				UpdateAndMessage -Id "RC_RDSLSValidLicense" -Detected $false
				$LicenseServerReport+= ""
				$LicenseServerReport+= "Checking for valid licenses in specified license servers:"
				$LicensingName = $RDSObject.LicensingName
				$ProductVersion = $relevantLicenses[0].ProductVersion
				$LicenseServerReport += "Found valid $LicensingName licenses with $availablelicenses available licenses."
			}else{
				UpdateAndMessage -Id "RC_RDSLSValidLicense" -Detected $true
			}

		}
	}
	$savepath = $TargetHost + "_LicenseServerReport.txt"
	$LicenseServerReport | Out-File $savepath
	[array]$OutputFileName += $savepath

# RemotePublishing section
	$remoteAppList = $null
	if( ( (([int]$OS.Version[0] -48) -eq 6 ) -and (([int]$OS.Version[2]- 48) -lt 2) ) -or (([int]$OS.Version[0] -48) -lt 6 )  )
	{
	$remoteAppList =  FilterWMIObject (get-WmiObject -Class Win32_TSPublishedApplication -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
	$OutputFileName = SaveRDPFileContents -Object $remoteAppList -ObjectName "PublishedApplication" -OutputFileName $OutputFileName
	}
	else
	{
	$remoteAppList =  FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedRemoteApplication -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
	$OutputFileName = SaveRDPFileContents -Object $remoteAppList -ObjectName "PublishedRemoteApplication" -OutputFileName $OutputFileName
	$PublishedRemoteDesktop = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedRemoteDesktop -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
	$OutputFileName = SaveRDPFileContents -Object $remoteAppList -ObjectName "PublishedRemoteDesktop" -OutputFileName $OutputFileName
	$workspace = FilterWMIObject (get-WmiObject -Class Win32_Workspace -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
	$OutputFileName = SaveAsXml $workspace  ($TargetHost +"_Workspace.xml") $OutputFileName
	$PublishedFarm = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedFarm -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
	$OutputFileName = SaveAsXml $PublishedFarm  ($TargetHost +"_PublishedFarm.xml") $OutputFileName
	$PublishedDeploymentSettings = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedDeploymentSettings -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
	$OutputFileName = SaveAsXml $PublishedDeploymentSettings  ($TargetHost +"_PublishedDeploymentSettings.xml") $OutputFileName
	$PublishedFileAssociation  = FilterWMIObject (get-WmiObject -Class Win32_RDCentralPublishedFileAssociation -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
	$OutputFileName = SaveAsXml $PublishedFileAssociation  ($TargetHost +"_PublishedFileAssociation.xml") $OutputFileName
	$PersonalDesktopAssignment = FilterWMIObject (get-WmiObject -Class Win32_RDPersonalDesktopAssignment -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
	$OutputFileName = SaveAsXml $PersonalDesktopAssignment  ($TargetHost +"_PersonalDesktopAssignment.xml") $OutputFileName
	}

# end RemotePublishing
}

# SIG # Begin signature block
# MIIazwYJKoZIhvcNAQcCoIIawDCCGrwCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUJ6LK6VP1ZMdVWaz20dpu7AXb
# iaqgghWCMIIEwzCCA6ugAwIBAgITMwAAAG9lLVhtBxFGKAAAAAAAbzANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTUwMzIwMTczMjAy
# WhcNMTYwNjIwMTczMjAyWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAz+ZtzcEqza6o
# XtiVTy0DQ0dzO7hC0tBXmt32UzZ31YhFJGrIq9Bm6YvFqg+e8oNGtirJ2DbG9KD/
# EW9m8F4UGbKxZ/jxXpSGqo4lr/g1E/2CL8c4XlPAdhzF03k7sGPrT5OaBfCiF3Hc
# xgyW0wAFLkxtWLN/tCwkcHuWaSxsingJbUmZjjo+ZpWPT394G2B7V8lR9EttUcM0
# t/g6CtYR38M6pR6gONzrrar4Q8SDmo2XNAM0BBrvrVQ2pNQaLP3DbvB45ynxuUTA
# cbQvxBCLDPc2Ynn9B1d96gV8TJ9OMD8nUDhmBrtdqD7FkNvfPHZWrZUgNFNy7WlZ
# bvBUH0DVOQIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFPKmSSl4fFdwUmLP7ay3eyA0
# R9z9MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAI2zTLbY7A2Hhhle5ADnl7jVz0wKPL33VdP08KCvVXKcI5e5
# girHFgrFJxNZ0NowK4hCulID5l7JJWgnJ41kp235t5pqqz6sQtAeJCbMVK/2kIFr
# Hq1Dnxt7EFdqMjYxokRoAZhaKxK0iTH2TAyuFTy3JCRdu/98U0yExA3NRnd+Kcqf
# skZigrQ0x/USaVytec0x7ulHjvj8U/PkApBRa876neOFv1mAWRDVZ6NMpvLkoLTY
# wTqhakimiM5w9qmc3vNTkz1wcQD/vut8/P8IYw9LUVmrFRmQdB7/u72qNZs9nvMQ
# FNV69h/W4nXzknQNrRbZEs+hm63SEuoAOyMVDM8wggTsMIID1KADAgECAhMzAAAA
# ymzVMhI1xOFVAAEAAADKMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE0MDQyMjE3MzkwMFoXDTE1MDcyMjE3MzkwMFowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJZxXe0GRvqEy51bt0bHsOG0ETkDrbEVc2Cc66e2bho8
# P/9l4zTxpqUhXlaZbFjkkqEKXMLT3FIvDGWaIGFAUzGcbI8hfbr5/hNQUmCVOlu5
# WKV0YUGplOCtJk5MoZdwSSdefGfKTx5xhEa8HUu24g/FxifJB+Z6CqUXABlMcEU4
# LYG0UKrFZ9H6ebzFzKFym/QlNJj4VN8SOTgSL6RrpZp+x2LR3M/tPTT4ud81MLrs
# eTKp4amsVU1Mf0xWwxMLdvEH+cxHrPuI1VKlHij6PS3Pz4SYhnFlEc+FyQlEhuFv
# 57H8rEBEpamLIz+CSZ3VlllQE1kYc/9DDK0r1H8wQGcCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBQfXuJdUI1Whr5KPM8E6KeHtcu/
# gzBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# YjQyMThmMTMtNmZjYS00OTBmLTljNDctM2ZjNTU3ZGZjNDQwMB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQB3XOvXkT3NvXuD2YWpsEOdc3wX
# yQ/tNtvHtSwbXvtUBTqDcUCBCaK3cSZe1n22bDvJql9dAxgqHSd+B+nFZR+1zw23
# VMcoOFqI53vBGbZWMrrizMuT269uD11E9dSw7xvVTsGvDu8gm/Lh/idd6MX/YfYZ
# 0igKIp3fzXCCnhhy2CPMeixD7v/qwODmHaqelzMAUm8HuNOIbN6kBjWnwlOGZRF3
# CY81WbnYhqgA/vgxfSz0jAWdwMHVd3Js6U1ZJoPxwrKIV5M1AHxQK7xZ/P4cKTiC
# 095Sl0UpGE6WW526Xxuj8SdQ6geV6G00DThX3DcoNZU6OJzU7WqFXQ4iEV57MIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBLcwggSz
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAAAymzVMhI1xOFV
# AAEAAADKMAkGBSsOAwIaBQCggdAwGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFKe4
# ixGCDU8Lr5EQVa5JARGz2plSMHAGCisGAQQBgjcCAQwxYjBgoEaARABEAEkAQQBH
# AF8AUgBEAFMAUwBlAHIAdgBlAHIAXwBnAGwAbwBiAGEAbABfAEQAQwBfAFIARABT
# AFMASAAuAHAAcwAxoRaAFGh0dHA6Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEB
# AQUABIIBAH9lYvjjw/W2Y6rC3kE0XKSSlW/VHKHrJtkNsTZnm7njPegXuvdzS7sA
# 3vitUVsBVLBL7f4kW5DLZyvpMlWzJparQfYEMKgYS/VXnM04MnDR4GbrGNzrypm7
# dvnDWwCjjkZUJnofhs/XpPE9ryTQVoGFsbNdf0xK50AZ7mU2/08LogfZ2gxEnLEd
# gpXAg40lnFRSYx8XRA7VBH3OowJ6Ol2mOcoRbgIRsh+9rzq1eNjB9KGVNPryK6oc
# VuKwiZe8+Sx51uZ+SQNaKuHi097uLOqyxZ5eu8+7hw6U80k3uf6OIRCQzjD8v1J4
# ixojJ4qXkLT9J0tOjmUPdZUtKTYXgZqhggIoMIICJAYJKoZIhvcNAQkGMYICFTCC
# AhECAQEwgY4wdzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEh
# MB8GA1UEAxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBAhMzAAAAb2UtWG0HEUYo
# AAAAAABvMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwG
# CSqGSIb3DQEJBTEPFw0xNTA1MTIxNjQzMzRaMCMGCSqGSIb3DQEJBDEWBBRST7Co
# 5PSWPNDBxBjqHEZ5hHOISjANBgkqhkiG9w0BAQUFAASCAQCWQgRoW7jGw6F9ud3P
# NTLI4JHA7ZYazxuoVmKhdJooZSJJ0ENoT/ktyKGmbJCn8Z4j7sdZfy+uuWgCyO6b
# 6FbVve3huUaXUdsbjvmCIOoSbaVxk5kUxGhuP+9VsU5jztay8+4Bu+6V3Y73kU3+
# F1mzmpuNjbhB8y/lConsZjIAF0bXgo6KUyAXOKb57Md8jiZuOIFzqNV35ie92o1U
# gzFo8A1B6st436MUNgM9uNlvtzfupT/mu511z+Q6ra7djUrsLepZULOLz9Xr6AZS
# Y9npF7FsdpLU7bQlehP1ehh5MRhyHeSzeNJ6ZE9y66M18ofkWPdsgLN2M0CnGX4t
# HWvZ
# SIG # End signature block
