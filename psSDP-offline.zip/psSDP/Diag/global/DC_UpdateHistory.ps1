#************************************************
# DC_UpdateHistory.ps1
# Version 1.0.1
# Date: 7/2/2013
# Author: v-maam, waltere 2019.07.15
# Description:  This file will list all updates installed on the local machine
#************************************************
#_#Param($Prefix = '', $Suffix = '', $OutputFormats= @("TXT", "CSV", "HTM"), [int]$NumberOfDays=10, [Switch]$ExportOnly)
Param($Prefix = '', $Suffix = '', $OutputFormats= @("TXT", "CSV"), [int]$NumberOfDays=10, [Switch]$ExportOnly) #_#

trap
{		
	WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[UpdateHistory.ps1] error"
	continue
}

Import-LocalizedData -BindingVariable ScriptStrings

# ***************************
# Store the updates history output information in CSV, TXT, XML format
# ***************************

$Script:SbCSVFormat = New-Object -TypeName System.Text.StringBuilder
$Script:SbTXTFormat = New-Object -TypeName System.Text.StringBuilder
$Script:SbXMLFormat = New-Object -TypeName System.Text.StringBuilder

# Store the WU errors
$Script:WUErrors

# Store the Updated installed in the past $NumberOfDays days when $ExportOnly is not used
if($ExportOnly.IsPresent -eq $false)
{
	$LatestUpdates_Summary= New-Object PSObject
	$LatestUpdates_Summary | Add-Member -MemberType NoteProperty -Name "  Date" -Value ("<table><tr><td width=`"40px`" style=`"border-bottom:1px solid #CCCCCC`">Results</td><td width=`"60px`" style=`"border-bottom:1px solid #CCCCCC`">ID</td><td width=`"300px`" style=`"border-bottom:1px solid #CCCCCC`">Category</td></tr></table>")
	[int]$Script:LatestUpdateCount = 0
}

# ***************************
# Functions
# ***************************

Function GetHotFixFromRegistry
{
	$RegistryHotFixList = @{}
	$UpdateRegistryKeys = @("HKLM:\SOFTWARE\Microsoft\Updates")

	#if $OSArchitecture -ne X86 , should be 64-bit machine. we also need to check HKLM:\SOFTWARE\Wow6432Node\Microsoft\Updates
	if($OSArchitecture -ne "X86")
	{
		$UpdateRegistryKeys += "HKLM:\SOFTWARE\Wow6432Node\Microsoft\Updates"
	}
						  						 	
	foreach($RegistryKey in $UpdateRegistryKeys)
	{
		If(Test-Path $RegistryKey)
		{
			$AllProducts = Get-ChildItem $RegistryKey -Recurse | Where-Object {$_.Name.Contains("KB") -or $_.Name.Contains("Q")}

			foreach($subKey in $AllProducts)
			{
				if($subKey.Name.Contains("KB") -or $subKey.Name.Contains("Q"))
				{
					$HotFixID = GetHotFixID $subKey.Name
					if($RegistryHotFixList.Keys -notcontains $HotFixID)
					{
						$Category = [regex]::Match($subKey.Name,"Updates\\(?<Category>.*?)[\\]").Groups["Category"].Value
						$HotFix = @{HotFixID=$HotFixID;Category=$Category}				
						foreach($property in $subKey.Property)
						{
							$HotFix.Add($property,$subKey.GetValue($property))
						}
						$RegistryHotFixList.Add($HotFixID,$HotFix)
					}
				}
			}
		}
	}
	return $RegistryHotFixList
}

Function GetHotFixID($strContainID)
{
	return [System.Text.RegularExpressions.Regex]::Match($strContainID,"(KB|Q)\d+(v\d)?").Value
}

Function ToNumber($strHotFixID)
{
	return [System.Text.RegularExpressions.Regex]::Match($strHotFixID,"([0-9])+").Value
}

Function FormatStr([string]$strValue,[int]$NumberofChars)
{
	if([String]::IsNullOrEmpty($strValue))
	{
		$strValue = " "
		return $strValue.PadRight($NumberofChars," ")
	}
	else
	{
		if($strValue.Length -lt $NumberofChars)
		{
			return $strValue.PadRight($NumberofChars," ")
		}
		else
		{
			return $strValue.Substring(0,$NumberofChars)
		}
	}
}

# Make sure all dates are with dd/mm/yy hh:mm:ss
Function FormatDateTime($dtLocalDateTime,[Switch]$SortFormat)
{	
	trap
	{		
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[FormatDateTime] Error Convert date time"
		continue
	}

	if([string]::IsNullOrEmpty($dtLocalDateTime))
	{
		return ""
	}
	
	if($SortFormat.IsPresent)
	{
		# Obtain dates on yyyymmdddhhmmss
		return Get-Date -Date $dtLocalDateTime -Format "yyyyMMddHHmmss"
	}
	else
	{
		return Get-Date -Date $dtLocalDateTime -Format G
	}
}

Function ValidatingDateTime($dateTimeToValidate)
{
	trap
	{		
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[ValidateDateTime] Error"
		continue
	}

	if([String]::IsNullOrEmpty($dateTimeToValidate))
	{
		return $false
	}

	$ConvertedDateTime = Get-Date -Date $dateTimeToValidate

	if($ConvertedDateTime -ne $null)
	{
		if(((Get-Date) - $ConvertedDateTime).Days -le $NumberOfDays)
		{
			return $true
		}
	}

	return $false
}

Function GetUpdateResultString($OperationResult)
{
	switch ($OperationResult)
	{
		"Completed successfully"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group id=`"Inf1`" class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"Completed successfully`"><v:oval class=`"vmlimage`" style=`"width:100;height:100;z-index:0`" fillcolor=`"#009933`" strokecolor=`"#C0C0C0`" /></v:group></span>"}
		"In progress"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group class=`"vmlimage`" style=`"width:14px;height:14px;vertical-align:middle`" coordsize=`"100,100`" title=`"In progress`"><v:roundrect class=`"vmlimage`" arcsize=`"10`" style=`"width:100;height:100;z-index:0`" fillcolor=`"#00FF00`" strokecolor=`"#C0C0C0`" /><v:shape class=`"vmlimage`" style=`"width:100; height:100; z-index:0`" fillcolor=`"white`" strokecolor=`"white`"><v:path v=`"m 40,25 l 75,50 40,75 x e`" /></v:shape></v:group></span>"}
		"Operation was aborted"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"Operation was aborted`"><v:roundrect class=`"vmlimage`" arcsize=`"20`" style=`"width:100;height:100;z-index:0`" fillcolor=`"#290000`" strokecolor=`"#C0C0C0`" /><v:line class=`"vmlimage`" style=`"z-index:2`" from=`"52,30`" to=`"52,75`" strokecolor=`"white`" strokeweight=`"8px`" /></v:group></span>"}
		"Completed with errors"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"Completed with errors`"><v:shape class=`"vmlimage`" style=`"width:100; height:100; z-index:0`" fillcolor=`"yellow`" strokecolor=`"#C0C0C0`"><v:path v=`"m 50,0 l 0,99 99,99 x e`" /></v:shape><v:rect class=`"vmlimage`" style=`"top:35; left:45; width:10; height:35; z-index:1`" fillcolor=`"black`" strokecolor=`"black`"></v:rect><v:rect class=`"vmlimage`" style=`"top:85; left:45; width:10; height:5; z-index:1`" fillcolor=`"black`" strokecolor=`"black`"></v:rect></v:group></span>"}
		"Failed to complete"  {return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"Failed to complete`"><v:oval class=`"vmlimage`" style=`"width:100;height:100;z-index:0`" fillcolor=`"red`" strokecolor=`"#C0C0C0`"></v:oval><v:line class=`"vmlimage`" style=`"z-index:1`" from=`"25,25`" to=`"75,75`" strokecolor=`"white`" strokeweight=`"3px`"></v:line><v:line class=`"vmlimage`" style=`"z-index:2`" from=`"75,25`" to=`"25,75`" strokecolor=`"white`" strokeweight=`"3px`"></v:line></v:group></span>"}
		Default { return "<span xmlns:v=`"urn:schemas-microsoft-com:vml`"><v:group id=`"Inf1`" class=`"vmlimage`" style=`"width:15px;height:15px;vertical-align:middle`" coordsize=`"100,100`" title=`"{$OperationResult}`"><v:oval class=`"vmlimage`" style=`"width:100;height:100;z-index:0`" fillcolor=`"#FF9933`" strokecolor=`"#C0C0C0`" /></v:group></span>" }
	}
}

Function GetOSSKU($SKU)
{
	switch ($SKU)
	{
		0  {return ""}
		1  {return "Ultimate Edition"}
		2  {return "Home Basic Edition"}
		3  {return "Home Basic Premium Edition"}
		4  {return "Enterprise Edition"}
		5  {return "Home Basic N Edition"}
		6  {return "Business Edition"}
		7  {return "Standard Server Edition"}
		8  {return "Datacenter Server Edition"}
		9  {return "Small Business Server Edition"}
		10 {return "Enterprise Server Edition"}
		11 {return "Starter Edition"}
		12 {return "Datacenter Server Core Edition"}
		13 {return "Standard Server Core Edition"}
		14 {return "Enterprise Server Core Edition"}
		15 {return "Enterprise Server Edition for Itanium-Based Systems"}
		16 {return "Business N Edition"}
		17 {return "Web Server Edition"}
		18 {return "Cluster Server Edition"}
		19 {return "Home Server Edition"}
		20 {return "Storage Express Server Edition"}
		21 {return "Storage Standard Server Edition"}
		22 {return "Storage Workgroup Server Edition"}
		23 {return "Storage Enterprise Server Edition"}
		24 {return "Server For Small Business Edition"}
		25 {return "Small Business Server Premium Edition"}	
	}	
}

Function GetOS()
{
	$WMIOS = Get-CimInstance -Class Win32_OperatingSystem

	$StringOS = $WMIOS.Caption

	if($WMIOS.CSDVersion -ne $null)
	{
		$StringOS += " - " + $WMIOS.CSDVersion
	}
	else
	{
		$StringOS += " - Service Pack not installed"
	}

	if(($WMIOS.OperatingSystemSKU -ne $null) -and ($WMIOS.OperatingSystemSKU.ToString().Length -gt 0))
	{
		$StringOS += " ("+(GetOSSKU $WMIOS.OperatingSystemSKU)+")"
	}

	return $StringOS
}

# Query SID of an object using WMI and return the account name
Function ConvertSIDToUser([string]$strSID) 
{
	trap
	{		
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[ConvertSIDToUser] Error convert User SID to User Account"
		continue
	}
	
	if([string]::IsNullOrEmpty($strSID))
	{
		return
	}

	if($strSID.StartsWith("S-1-5"))
	{
		$UserSIDIdentifier = New-Object System.Security.Principal.SecurityIdentifier `
    	($strSID)
		$UserNTAccount = $UserSIDIdentifier.Translate( [System.Security.Principal.NTAccount])
		if($UserNTAccount.Value.Length -gt 0)
		{
			return $UserNTAccount.Value
		}
		else
		{
			return $strSID
		}
	}
	
	return $strSID	
}

Function ConvertToHex([int]$number)
{
	return ("0x{0:x8}" -f $number)
}

Function GetUpdateOperation($Operation)
{
	switch ($Operation)
	{
		1 { return "Install" }
		2 { return "Uninstall" }
		Default { return "Unknown("+$Operation+")" }
	}
}

Function GetUpdateResult($ResultCode)
{
	switch ($ResultCode)
	{
		0 { return "Not started" }
		1 { return "In progress" }
		2 { return "Completed successfully" }
		3 { return "Completed with errors" }
		4 { return "Failed to complete" }
		5 { return "Operation was aborted" }
		Default { return "Unknown("+$ResultCode+")" }
	}					
}

Function GetWUErrorCodes($HResult)
{
	if($Script:WUErrors -eq $null)
	{
		$WUErrorsFilePath = Join-Path $PWD.Path "WUErrors.xml"
		if(Test-Path $WUErrorsFilePath)
		{
			[xml] $Script:WUErrors = Get-Content $WUErrorsFilePath
		}
		else
		{
			"[Error]: Did not find the WUErrors.xml file, can not load all WU errors" | WriteTo-StdOut -ShortFormat
		}
	}

	$WUErrorNode = $Script:WUErrors.ErrV1.err | Where-Object {$_.n -eq $HResult}

	if($WUErrorNode -ne $null)
	{
		$WUErrorCode = @()
		$WUErrorCode += $WUErrorNode.name
		$WUErrorCode += $WUErrorNode."#text"
		return $WUErrorCode
	}

	return $null
}

Function PrintHeaderOrXMLFooter([switch]$IsHeader,[switch]$IsXMLFooter)
{
	if($IsHeader.IsPresent)
	{
		if($OutputFormats -contains "TXT")
		{
			# TXT formate Header
			LineOut -IsTXTFormat -Value ([String]::Format("{0} {1} {2} {3} {4} {5} {6} {7} {8}",
												(FormatStr "Category" 20),
												(FormatStr "Level" 6),
												(FormatStr "ID" 10),
												(FormatStr "Operation" 11),
												(FormatStr "Date" 23),
												(FormatStr "Client" 18),
												(FormatStr "By" 28),
												(FormatStr "Result" 23),
												"Title"))																								
			LineOut -IsTXTFormat -Value ("-").PadRight(200,"-")
		}

		if($OutputFormats -contains "CSV")
		{
			# CSV formate Header										
			LineOut -IsCSVFormat -Value ("Category,Level,ID,Operation,Date,Client,By,Result,Title")
		}

		if($OutputFormats -contains "HTM")
		{
			# XML format Header
			LineOut -IsXMLFormat -IsXMLLine -Value "<?xml version=`"1.0`" encoding=`"UTF-8`"?>"
			LineOut -IsXMLFormat -IsOpenTag -TagName "Root"
			LineOut -IsXMLFormat -IsOpenTag -TagName "Updates"
			LineOut -IsXMLFormat -IsXMLLine -Value ("<Title name=`"QFE Information from`">"+$Env:COMPUTERNAME+"</Title>")
			LineOut -IsXMLFormat -IsXMLLine -Value ("<OSVersion name=`"Operating System`">"+(GetOS)+"</OSVersion>")
			LineOut -IsXMLFormat -IsXMLLine -Value ("<TimeField name=`"Local time`">"+[DateTime]::Now.ToString()+"</TimeField>")
		}
	}
	
	if($IsXMLFooter)
	{
		if($OutputFormats -contains "HTM")
		{
			LineOut -IsXMLFormat -IsCloseTag -TagName "Updates"
			LineOut -IsXMLFormat -IsCloseTag -TagName "Root"
		}		
	}
}

Function LineOut([string]$TagName,[string]$Value,[switch]$IsTXTFormat,[switch]$IsCSVFormat,[switch]$IsXMLFormat,[switch]$IsXMLLine,[switch]$IsOpenTag,[switch]$IsCloseTag)
{
	if($IsTXTFormat.IsPresent)
	{		
		[void]$Script:SbTXTFormat.AppendLine($Value)
	}
	
	if($IsCSVFormat.IsPresent)
	{
		[void]$Script:SbCSVFormat.AppendLine($Value)
	}
	
	if($IsXMLFormat.IsPresent)
	{
		if($IsXMLLine.IsPresent)
		{
			[void]$Script:SbXMLFormat.AppendLine($Value)
			return
		}
		
		if(($TagName -eq $null) -or ($TagName -eq ""))
		{
			"[Warning]: Did not provide valid TagName: $TagName, will not add this Tag." | WriteTo-StdOut -ShortFormat
			return
		}
		
		if($IsOpenTag.IsPresent -or $IsCloseTag.IsPresent)
		{
			if($IsOpenTag.IsPresent)
			{
				[void]$Script:SbXMLFormat.AppendLine("<"+$TagName+">")
			}
	
			if($IsCloseTag.IsPresent)
			{
				[void]$Script:SbXMLFormat.AppendLine("</"+$TagName+">")
			}
		}
		else
		{
			[void]$Script:SbXMLFormat.AppendLine("<"+$TagName+">"+$Value+"</"+$TagName+">")
		}
	}
}

Function PrintUpdate([string]$Category,[string]$SPLevel,[string]$ID,[string]$Operation,[string]$Date,[string]$ClientID,[string]$InstalledBy,[string]$OperationResult,[string]$Title,[string]$Description,[string]$HResult,[string]$UnmappedResultCode)
{
	if($OutputFormats -contains "TXT")
	{
		LineOut -IsTXTFormat -Value ([String]::Format("{0} {1} {2} {3} {4} {5} {6} {7} {8}",
												(FormatStr $Category 20),
												(FormatStr $SPLevel 6),
												(FormatStr $ID 10),
												(FormatStr $Operation 11),
												(FormatStr $Date 23),
												(FormatStr $ClientID 18),
												(FormatStr $InstalledBy 28),
												(FormatStr $OperationResult 23),
												$Title))
	}

	if($OutputFormats -contains "CSV")
	{
		LineOut -IsCSVFormat -Value ([String]::Format("{0},{1},{2},{3},{4},{5},{6},{7},{8}",
												  $Category,
												  $SPLevel,
												  $ID,
												  $Operation,
												  $Date,
												  $ClientID,
												  $InstalledBy,
												  $OperationResult,
												  $Title))
	}

	if($OutputFormats -contains "HTM")
	{	
		if($Category -eq "QFE hotfix")
		{
			$Category = "Other updates not listed in history"
		}
		
		if(-not [String]::IsNullOrEmpty($ID))
		{
			$NumberHotFixID = ToNumber $ID
			if($NumberHotFixID.Length -gt 5)
			{
				$SupportLink = "http://support.microsoft.com/kb/$NumberHotFixID"				
			}
		}
		else
		{
			$ID = ""
			$SupportLink = ""
		}	

		if([String]::IsNullOrEmpty($Date))
		{
			$DateTime = ""
		}
		else
		{
			$DateTime = FormatDateTime $Date -SortFormat			
		}

		if([String]::IsNullOrEmpty($Title))
		{
			$Title = ""
		}
		else
		{
			$Title = $Title.Trim()
		}

		if([String]::IsNullOrEmpty($Description))
		{
			$Description = ""
		}
		else
		{
			$Description = $Description.Trim()			
		}

		# Write the Update to XML Formate
		LineOut -IsXMLFormat -TagName "Update" -IsOpenTag
		LineOut -IsXMLFormat -TagName "Category" -Value $Category
		if(-not [String]::IsNullOrEmpty($SPLevel))
		{
			LineOut -IsXMLFormat -TagName "SPLevel" -Value $SPLevel
		}
		LineOut -IsXMLFormat -TagName "ID" -Value $ID
		LineOut -IsXMLFormat -TagName "SupportLink" -Value $SupportLink
		LineOut -IsXMLFormat -TagName "Operation" -Value $Operation
		LineOut -IsXMLFormat -TagName "Date" -Value $Date
		LineOut -IsXMLFormat -TagName "SortableDate" -Value $DateTime
		LineOut -IsXMLFormat -TagName "ClientID" -Value $ClientID
		LineOut -IsXMLFormat -TagName "InstalledBy" -Value $InstalledBy
		LineOut -IsXMLFormat -TagName "OperationResult" -Value $OperationResult
		LineOut -IsXMLFormat -TagName "Title" -Value $Title
		LineOut -IsXMLFormat -TagName "Description" -Value $Description

		if((-not [String]::IsNullOrEmpty($HResult)) -and ($HResult -ne 0))
		{
			$HResultHex = ConvertToHex $HResult
			$HResultArray= GetWUErrorCodes $HResultHex
					
			LineOut -IsXMLFormat -IsOpenTag -TagName "HResult"
			LineOut -IsXMLFormat -TagName "HEX" -Value $HResultHex
			if($HResultArray -ne $null)
			{
				LineOut -IsXMLFormat -TagName "Constant" -Value $HResultArray[0]
				LineOut -IsXMLFormat -TagName "Description" -Value $HResultArray[1]
			}
			LineOut -IsXMLFormat -IsCloseTag -TagName "HResult"
			LineOut -IsXMLFormat -TagName "UnmappedResultCode" -Value (ConvertToHex $UnmappedResultCode)
		}

		LineOut -IsXMLFormat -TagName "Update" -IsCloseTag


		if (($ExportOnly.IsPresent -eq $false) -and (ValidatingDateTime $Date))
		{	
			if($LatestUpdates_Summary.$Date -ne $null)	
			{	
				$LatestUpdates_Summary.$Date = $LatestUpdates_Summary.$Date.Insert($LatestUpdates_Summary.$Date.LastIndexOf("</table>"),"<tr><td width=`"40px`" align=`"center`">" +(GetUpdateResultString $OperationResult) + "</td><td width=`"60px`"><a href=`"$SupportLink`" Target=`"_blank`">$ID</a></td><td>$Category</td></tr>")
			}
			else
			{
				$LatestUpdates_Summary | Add-Member -MemberType NoteProperty -Name $Date -Value ("<table><tr><td width=`"40px`" align=`"center`">" +(GetUpdateResultString $OperationResult) + "</td><td width=`"60px`"><a href=`"$SupportLink`" Target=`"_blank`">$ID</a></td><td>$($Category): $($Title)</td></tr></table>")	
			}
					
			$Script:LatestUpdateCount++
		}	
	}
}

Function GenerateHTMFile([string] $XMLFileNameWithoutExtension)
{
	trap
	{		
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "[GenerateHTMFile] Error creating HTM file"
		continue
	}

	$UpdateXslFilePath = Join-Path $pwd.path "UpdateHistory.xsl"
	if(Test-Path $UpdateXslFilePath)
	{
		$XSLObject = New-Object System.Xml.Xsl.XslTransform
		$XSLObject.Load($UpdateXslFilePath)
		if(Test-Path ($XMLFileNameWithoutExtension + ".XML"))
		{
			$XSLObject.Transform(($XMLFileNameWithoutExtension + ".XML"), ($XMLFileNameWithoutExtension + ".HTM"))
		}
		else
		{
			"Error: HTML file was not generated" | WriteTo-StdOut -ShortFormat
		}
	}
	else
	{
		"Error: Did not find the UpdateHistory.xsl, won't generate HTM file" | WriteTo-StdOut -ShortFormat
	}
}

# ***************************
# Start here
# ***************************

Write-DiagProgress -Activity $ScriptStrings.ID_InstalledUpdates -Status $ScriptStrings.ID_InstalledUpdatesObtaining

# Get updates from the com object
"Querying IUpdateSession Interface to get the Update History" | WriteTo-StdOut -ShortFormat

$Session = New-Object -ComObject Microsoft.Update.Session
$Searcher = $Session.CreateUpdateSearcher()
$HistoryCount = $Searcher.GetTotalHistoryCount()
if ($HistoryCount -gt 0) 
{
	trap [Exception] 
	{
		WriteTo-ErrorDebugReport -ErrorRecord $_ -ScriptErrorText "Querying Update History"
		continue
	}

	$ComUpdateHistory = $Searcher.QueryHistory(1,$HistoryCount)
}
else
{
	$ComUpdateHistory = @()
	"No updates found on Microsoft.Update.Session" | WriteTo-StdOut -ShortFormat
}

# Get updates from the Wmi object Win32_QuickFixEngineering
"Querying Win32_QuickFixEngineering to obtain updates that are not on update history" | WriteTo-StdOut -ShortFormat

$QFEHotFixList = New-Object "System.Collections.ArrayList"
$QFEHotFixList.AddRange(@(Get-CimInstance -Class Win32_QuickFixEngineering))

# Get updates from the regsitry keys
"Querying Updates listed in the registry" | WriteTo-StdOut -ShortFormat
$RegistryHotFixList = GetHotFixFromRegistry

Write-DiagProgress -Activity $ScriptStrings.ID_InstalledUpdates -Status $ScriptStrings.ID_InstalledUpdatesFormateOutPut
PrintHeaderOrXMLFooter -IsHeader

# Format each update history to the stringbuilder
"Generating information for $HistoryCount updates found on update history" | WriteTo-StdOut -ShortFormat
foreach($updateEntry in $ComUpdateHistory)
{	
	#Do not list the updates on which the $updateEntry.ServiceID = '117CAB2D-82B1-4B5A-A08C-4D62DBEE7782'. These are Windows Store updates and are bringing inconsistent results
	if($updateEntry.ServiceID -ne '117CAB2D-82B1-4B5A-A08C-4D62DBEE7782')
	{		
		$HotFixID = GetHotFixID $updateEntry.Title
		$HotFixIDNumber = ToNumber $HotFixID
		$strInstalledBy = ""
		$strSPLevel = ""
	
		if(($HotFixID -ne "") -or ($HotFixIDNumber -ne ""))
		{
			foreach($QFEHotFix in $QFEHotFixList)
			{
				if(($QFEHotFix.HotFixID -eq $HotFixID) -or
		   			((ToNumber $QFEHotFix.HotFixID) -eq $HotFixIDNumber))
				{
					$strInstalledBy = ConvertSIDToUser $QFEHotFix.InstalledBy
					$strSPLevel = $QFEHotFix.ServicePackInEffect

					#Remove the duplicate HotFix in the QFEHotFixList
					$QFEHotFixList.Remove($QFEHotFix)
					break
				}
			}
		}
	
		#Remove the duplicate HotFix in the RegistryHotFixList
		if($RegistryHotFixList.Keys -contains $HotFixID)
		{
			$RegistryHotFixList.Remove($HotFixID)
		}

		$strCategory = ""		
		if($updateEntry.Categories.Count -gt 0)
		{
			$strCategory = $updateEntry.Categories.Item(0).Name
		}
	
		if([String]::IsNullOrEmpty($strCategory))
		{
			$strCategory = "(None)"
		}
	
		$strOperation = GetUpdateOperation $updateEntry.Operation
		$strDateTime = FormatDateTime $updateEntry.Date
		$strResult = GetUpdateResult $updateEntry.ResultCode

		PrintUpdate $strCategory $strSPLevel $HotFixID $strOperation $strDateTime $updateEntry.ClientApplicationID $strInstalledBy $strResult $updateEntry.Title $updateEntry.Description $updateEntry.HResult $updateEntry.UnmappedResultCode
	}
}

# Out Put the Non History QFEFixes
"Generating information for " + $QFEHotFixList.Count + " updates found on Win32_QuickFixEngineering WMI class" | WriteTo-StdOut -ShortFormat
foreach($QFEHotFix in $QFEHotFixList)
{
	$strInstalledBy = ConvertSIDToUser $QFEHotFix.InstalledBy
	$strDateTime = FormatDateTime $QFEHotFix.InstalledOn
	$strCategory = ""

	#Remove the duplicate HotFix in the RegistryHotFixList
	if($RegistryHotFixList.Keys -contains $QFEHotFix.HotFixID)
	{
		$strCategory = $RegistryHotFixList[$QFEHotFix.HotFixID].Category
		$strRegistryDateTime = FormatDateTime $RegistryHotFixList[$QFEHotFix.HotFixID].InstalledDate		
		if([String]::IsNullOrEmpty($strInstalledBy))
		{
			$strInstalledBy = $RegistryHotFixList[$QFEHotFix.HotFixID].InstalledBy
		}

		$RegistryHotFixList.Remove($QFEHotFix.HotFixID)
	}
	
	if([string]::IsNullOrEmpty($strCategory))
	{
		$strCategory = "QFE hotfix"
	}	
	if($strDateTime.Length -eq 0)
	{
		$strDateTime = $strRegistryDateTime
	}
	if([string]::IsNullOrEmpty($QFEHotFix.Status))
	{
		$strResult = "Completed successfully"
	}
	else
	{
		$strResult = $QFEHotFix.Status
	}	

	PrintUpdate $strCategory $QFEHotFix.ServicePackInEffect $QFEHotFix.HotFixID "Install" $strDateTime "" $strInstalledBy $strResult $QFEHotFix.Description $QFEHotFix.Caption
}

"Generating information for " + $RegistryHotFixList.Count + " updates found on registry" | WriteTo-StdOut -ShortFormat
foreach($key in $RegistryHotFixList.Keys)
{
	$strCategory = $RegistryHotFixList[$key].Category
	$HotFixID = $RegistryHotFixList[$key].HotFixID
	$strDateTime = $RegistryHotFixList[$key].InstalledDate
	$strInstalledBy = $RegistryHotFixList[$key].InstalledBy
	$ClientID = $RegistryHotFixList[$key].InstallerName

	if($HotFixID.StartsWith("Q"))
	{
		$Description = $RegistryHotFixList[$key].Description
	}
	else
	{
		$Description = $RegistryHotFixList[$key].PackageName		
	}

	if([string]::IsNullOrEmpty($Description))
	{
		$Description = $strCategory
	}

	PrintUpdate $strCategory "" $HotFixID "Install" $strDateTime $ClientID $strInstalledBy "Completed successfully" $strCategory $Description
}

PrintHeaderOrXMLFooter -IsXMLFooter

Write-DiagProgress -Activity $ScriptStrings.ID_InstalledUpdates -Status $ScriptStrings.ID_InstalledUpdatesOutPutAndCollectFile
$FileNameWithoutExtension = $ComputerName +"_"+ $Prefix + "Hotfixes" + $Suffix

"Creating output files" | WriteTo-StdOut -ShortFormat
if($OutputFormats -contains "CSV")
{
	$Script:SbCSVFormat.ToString() | Out-File ($FileNameWithoutExtension + ".CSV") -Encoding "UTF8"
}

if($OutputFormats -contains "TXT")
{
	$Script:SbTXTFormat.ToString() | Out-File ($FileNameWithoutExtension + ".TXT") -Encoding "UTF8"
}

if($OutputFormats -contains "HTM")
{
	$Script:SbXMLFormat.ToString().replace("&","") | Out-File ($FileNameWithoutExtension + ".XML") -Encoding "UTF8"

	"Generate the HTML Updates file according the UpdateHistory.xsl and XML file" | WriteTo-StdOut -ShortFormat
	GenerateHTMFile $FileNameWithoutExtension
}

$FileToCollects = @("$FileNameWithoutExtension.CSV","$FileNameWithoutExtension.TXT","$FileNameWithoutExtension.HTM")

if($ExportOnly.IsPresent)
{
	Copy-Item $FileToCollects -Destination (Join-Path $PWD.Path "result")
}
else
{
	if($Script:LatestUpdateCount -gt 0)
	{		
		$LatestUpdates_Summary | Add-Member -MemberType NoteProperty -Name "More Information" -Value ("<table><tr><td>For a complete list of installed updates, please open <a href= `"`#" + $FileNameWithoutExtension + ".HTM`">" + $FileNameWithoutExtension + ".HTM</a></td></tr></table>")
		$LatestUpdates_Summary | ConvertTo-Xml2 -sortObject | update-diagreport -id 11_Updates -name "Updates installed in past $NumberOfDays days ($($Script:LatestUpdateCount))" -verbosity informational
	}
	
	CollectFiles -filesToCollect $FileToCollects -fileDescription "Installed Updates and Hotfixes" -sectionDescription "General Information"
}

# --------------------------------------------------------------- added: 2019-07-15 #_#
if ($Global:runFull -eq $True) { # $False = disabling for now for this long-lasting step
#----------WMIC list
	$sectionDescription = "UpdateHistory WMIC QFE"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_Hotfixes-WMIC.txt")
	Write-DiagProgress -Activity $ScriptStrings.ID_InstalledUpdates -Status "WMIC QFEs"
	$CommandToExecute = 'wmic qfe list full /format:texttable '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "wmic qfe list full" -sectionDescription $sectionDescription

#----------Get Windows Update Configuration info
	$sectionDescription = "Windows Update Configuration info"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_WindowsUpdateConfiguration.txt")
	Write-DiagProgress -Activity $ScriptStrings.ID_InstalledUpdates -Status "Windows Update Configuration info"
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Windows Update Configuration info" 					| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	$MUSM = New-Object -ComObject "Microsoft.Update.ServiceManager"
	$MUSM.Services | select Name, IsDefaultAUService, OffersWindowsUpdates | Out-File -FilePath $OutputFile -append
	"`n`n" | Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	"Now get all data" 										| Out-File -FilePath $OutputFile -append
	"===================================================="	| Out-File -FilePath $OutputFile -append
	$MUSM = New-Object -ComObject "Microsoft.Update.ServiceManager" 
	$MUSM.Services | Out-File -FilePath $OutputFile -append
	collectfiles -filesToCollect $OutputFile -fileDescription "Windows Update Configuration" -sectionDescription $sectionDescription
}
# SIG # Begin signature block
# MIIjhwYJKoZIhvcNAQcCoIIjeDCCI3QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBbSYCQ2yhx8Gx3
# O73XKTfBEHJnMK5UsAuD6YVCrkVIyqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXDCCFVgCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgCluqk7Sd
# 829Exw6wa3vWzHLB83LPgLIITcwr1H/VMCAwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAJo/ZEzrdIWX8sAl25FDP5kJKnBjZ3ZGsKJfMPAaC+sfJAMPECRugJ3Y
# rwOjkpywddGT29Ln79nAZgGFFTYNgIW4IZ7bzqxi+dUKVeJY0b1H/FPXnAxKeVU4
# 5tidFFYQaZrILUHLNqdxJwdx++TgEf7rg2zXq09j0yPGQf12FI6AJHiBUGxS919p
# HPd/ZIPppmvzq0JPqYkNu4Uo9yP4ltzKo+3DWGhEwQghptN4oqTJ+8OqugZXl2bF
# Zw6erGLwdWkNVissqMdtiU1nvpKWZ5oK03a+vsOVI0cjq8MA1Hqh5oNlrFfg01Ay
# AVtJ3EW0gQdZ3yZqEKh+i8kGYBT0H7ahghLwMIIS7AYKKwYBBAGCNwMDATGCEtww
# ghLYBgkqhkiG9w0BBwKgghLJMIISxQIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVAYL
# KoZIhvcNAQkQAQSgggFDBIIBPzCCATsCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgtZbiCW1gZtIJXZ64NUm4j+1q/PxahWdSsgFIpynxNyICBmGB3Gir
# aBgSMjAyMTExMTExNjUzMzcuNDJaMASAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3Bl
# cmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046NjBC
# Qy1FMzgzLTI2MzUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2Wggg5EMIIE9TCCA92gAwIBAgITMwAAAVosuW5ENMtvKAAAAAABWjANBgkqhkiG
# 9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMTAxMTQx
# OTAyMTZaFw0yMjA0MTExOTAyMTZaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVy
# dG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046NjBCQy1FMzgzLTI2MzUx
# JTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCwvVwcVw2tJwiu9B3/hooejcUZdZgIcxSX
# aJPG7N8aSfO0zNvKxHh5GQGhPim/RovVL06UN86xFslkqSEJMsb/1n9HCIQNZiTq
# srttEzd5femb4M2K8zv60JT72ylu/aADuPmBbHpEAra8zPYUKEuQWBsD4fUM+ugb
# ksR/UMHssDQULI5FaIpKQcZEvhF0iM6W2tmn750TF+yy3tnq8nPj5T15k0jnx9Vj
# cpHNubvc6OmV9IAHeI1KQc3TC5xwrROtmy9jztNHJgCbIraoGqL/t5Ra33dLDwAs
# ExjvYsppSZW9rGr8I6kp4+UcxuEcRuq1Nou3rW50E6M0e9zhzBjlAgMBAAGjggEb
# MIIBFzAdBgNVHQ4EFgQUZHMlP/Ucj5J+0AaF2Tk0PMDeMWcwHwYDVR0jBBgwFoAU
# 1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0w
# Ny0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkq
# hkiG9w0BAQsFAAOCAQEAAABt7HxYG1IsOIFjFfFTsZWyBvwiDEonIg7SGZzy/ODj
# DeJSXleS3ia/h2AXKMea7lmZuPStvYgZib+lYlzLT/NaWGdRBTO99OmPsyyIf7Uu
# e+D3lrB7zw9EDsUOBzjNhjT7xQHVL6PM+aYFf+RPpT7utblAiAUwxEohzvje62oK
# m9zBEz6kSjyzQCXCjw3GpSs55hj5Z82Oj9c6Kf+2vdFXAR0SikP4U75//AvGOm/j
# L5OZGCYeuyjW1VXLrgVshUjGUxxnpx57h1YPbLx+/pZv1f8CG2VCiiSTtB0JsqHc
# kng/ySwuzTbA2EaRTftvXS0bcdHlsmaLCZk/KimwSDCCBnEwggRZoAMCAQICCmEJ
# gSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18
# aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdN
# uDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NM
# ksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2K
# Qk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZ
# zTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQ
# BgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCB
# jwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAd
# AEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAd
# MA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F
# 4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbM
# QEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mB
# ZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7ti
# X5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S
# 4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3ai
# caoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf
# 5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsb
# iSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJ
# zxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB
# 0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/e
# dIhJEqGCAtIwggI7AgEBMIH8oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQ
# dWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046NjBCQy1FMzgzLTI2
# MzUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAH
# BgUrDgMCGgMVAMyABZi9xhx1nACWIt4WhsJaZRouoIGDMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDlN494MCIYDzIw
# MjExMTExMTY0NzUyWhgPMjAyMTExMTIxNjQ3NTJaMHcwPQYKKwYBBAGEWQoEATEv
# MC0wCgIFAOU3j3gCAQAwCgIBAAICJhQCAf8wBwIBAAICES4wCgIFAOU44PgCAQAw
# NgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgC
# AQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQBGCN6PRJtItBIxxTC83XZyGsQLbydy
# 8HljddQBWERzLVJT6z8M8FPtFo3BMZGeaLoyr1h04LDbws5BqBChtPbc4he2VCS/
# r9Wexb4mIXyrYDZm+fTy2FKVx18SvUHiexgtWtHvyjQwZqDbiZiTvlnoBOx81VMe
# Y9HrneEkcZDQ5zGCAw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAABWiy5bkQ0y28oAAAAAAFaMA0GCWCGSAFlAwQCAQUAoIIBSjAa
# BgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIK0pLssm
# K3ZXgYTP/hRAmzJRBBpDwO8Q8sCMl+FMBBmkMIH6BgsqhkiG9w0BCRACLzGB6jCB
# 5zCB5DCBvQQgk/yoJnTEsuRdMMOCGq/XJn+SLN6TNIVLiCJy+W2xf7AwgZgwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAVosuW5ENMtvKAAA
# AAABWjAiBCAydpm+HOeV6nn9OpwexWmqJt44D1DqotFCo83SzGOy/DANBgkqhkiG
# 9w0BAQsFAASCAQCM7B9dPDO23ZkHDdOy0/S2G2f3FjupDoEzqNPrNJn3PWr0B6V4
# apFe4+O9b11MbJuNtPxQbJz75c0xcPxWo7iFTBgH199NQUFRpEvKcrIjPMd6Brbt
# ho1cso97sBU5+i2L/b9j9OFnz4RCbpqufCT/8LFzovfnGnlW3837hYEYFIFvKdtI
# qCiCvhzAM3u5sgWCnu6K0h1FfcXPJDPtsSoihpMi1Z2L7OYxRiDUearYC/ByxiLZ
# SDGv2aEYZXfXUypLdryIi6NqhCylHmYg4IKL3F/h8GlBP4IxvXZToy+4+sxMBNqA
# qVOPFjXY1tOzjv8iIZLE05reMdI8+AqhUwfd
# SIG # End signature block
