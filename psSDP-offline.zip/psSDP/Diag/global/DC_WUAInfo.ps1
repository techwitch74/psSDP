﻿# ********************************************************************************************
# Version 1.0
# Date: 03-20-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects Windows Update Agent Information.
#		1. Gets WUA Service Status and Start Time
#		2. Gets WUA Version
#		3. Gets WUA DLL Versions
#		4. Exports HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate Registry Key
#		5. Exports HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate Registry Key
#		6. Gets Windows Update Log
#		7. Summarizes all data to a text file for better readability.
# ********************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

TraceOut "Started"

Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "Windows Update Agent"

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WUAInfo -Status $ScriptStrings.ID_SCCM_WUAInfo_WUA

$WUAInfo = New-Object PSObject

# Summary File Header
$WUAFile = Join-Path $Pwd.Path ($ComputerName + "__WUA_Summary.txt")
"===========================================" | Out-File $WUAFile
"Windows Update Agent Configuration Summary:" | Out-File $WUAFile -Append
"===========================================" | Out-File $WUAFile -Append

# -------------
# Computer Name
# -------------
Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "Computer Name" -Value $ComputerName

# ----------------------
# Time zone information:
# ----------------------
$Temp = Get-WmiObject -Namespace root\cimv2 -Class Win32_TimeZone -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "Time Zone" -Value $Temp.Description }
else {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "Time Zone" -Value "Error obtaining value from Win32_TimeZone WMI Class" }

$Temp = Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "Daylight In Effect" -Value $Temp.DaylightInEffect }
else {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "Daylight In Effect" -Value "Error obtaining value from Win32_ComputerSystem WMI Class" }

# -----------------------
# WUA Service Status
# -----------------------
$Temp = Get-Service | Where-Object {$_.Name -eq 'WuAuServ'} | Select-Object Status
If ($Temp -ne $null) {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUA Service Status" -Value $Temp.Status
}
Else {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUA Service Status" -Value "ERROR: Service Not found"
}

# --------------------------
# WUA Service StartTime
# --------------------------
$Temp = Get-Process | Where-Object {($_.ProcessName -eq 'SvcHost') -and ($_.Modules -match 'wuaueng.dll')} | Select-Object StartTime
If ($Temp -ne $null) {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUA Service StartTime" -Value $Temp.StartTime
}
Else {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUA Service StartTime" -Value "ERROR: Service Not running"
}

# ------------
# WUA Version
# ------------
trap [Exception]
{
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUA Version" -Value -Value ("ERROR: " + ($_.Exception.Message))
}
$WUA = New-Object -com "Microsoft.Update.AgentInfo" -ErrorAction SilentlyContinue -ErrorVariable WUAError
If ($WUAError.Count -eq 0) {
	$Temp = $WUA.GetInfo("ProductVersionString")
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUA Version" -Value $Temp
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WUAInfo -Status $ScriptStrings.ID_SCCM_WUAInfo_SoftDist

# --------------------------------------------
# File List in SoftwraeDistribution Directory
# --------------------------------------------
$TempFileName = ($ComputerName + "_WUA_FileList.txt")
$OutputFile = join-path $pwd.path $TempFileName
Get-ChildItem (Join-Path $env:windir "SoftwareDistribution") -Recurse -ErrorVariable DirError -ErrorAction SilentlyContinue | `
	Select-Object CreationTime, LastAccessTime, FullName, Length, Mode | Sort-Object FullName | Format-Table -AutoSize | `
	Out-File $OutputFile -Width 1000
If ($DirError.Count -eq 0) {
	Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "SoftwareDistribution Directory List" -Value "Review $TempFileName"
	CollectFiles -filesToCollect $OutputFile -fileDescription "WUA File List" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
}
else {
	$DirError.Clear()
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WUAInfo -Status $ScriptStrings.ID_SCCM_WUAInfo_FileVer

# -----------------
# WUA DLL Versions
# -----------------
$TempFileName = ($ComputerName + "_WUA_FileVersions.txt")
$VersionFile  = Join-Path $Pwd.Path $TempFileName
Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUA Related File Versions" -Value "Review $TempFileName"
"-----------------------------------" | Out-File $VersionFile -Append
"Windows Update Agent DLL Versions: " | Out-File $VersionFile -Append
"-----------------------------------" | Out-File $VersionFile -Append
Get-ChildItem (Join-Path $Env:windir "system32\wu*.dll") -Exclude WUD*.dll -ErrorAction SilentlyContinue | `
	foreach-object {[System.Diagnostics.FileVersionInfo]::GetVersionInfo($_)} | `
	Select-Object FileName,FileVersion,ProductVersion | Format-Table -AutoSize -HideTableHeaders | `
	Out-File $VersionFile -Append -Width 1000

# ------------------
# BITS DLL Versions
# ------------------
"-------------------" | Out-File $VersionFile -Append
"BITS DLL Versions: " | Out-File $VersionFile -Append
"-------------------" | Out-File $VersionFile -Append
Get-ChildItem (Join-Path $Env:windir "system32\bits*.dll"), (Join-Path $Env:windir "system32\winhttp*.dll"), (Join-Path $Env:windir "system32\qmgr*.dll") -ErrorAction SilentlyContinue | `
	foreach-object {[System.Diagnostics.FileVersionInfo]::GetVersionInfo($_)} | `
	Select-Object FileName,FileVersion,ProductVersion | Format-Table -AutoSize -HideTableHeaders | `
	Out-File $VersionFile -Append -Width 1000

# -----------------
# MSI DLL Versions
# -----------------
"--------------------------------" | Out-File $VersionFile -Append
"Windows Installer DLL Versions: " | Out-File $VersionFile -Append
"--------------------------------" | Out-File $VersionFile -Append
Get-ChildItem (Join-Path $Env:windir "system32\msi*.*") -ErrorAction SilentlyContinue | `
	foreach-object {[System.Diagnostics.FileVersionInfo]::GetVersionInfo($_)} | `
	Select-Object FileName,FileVersion,ProductVersion | Format-Table -AutoSize -HideTableHeaders | `
	Out-File $VersionFile -Append -Width 1000

# -----------------
# MSXML DLL Versions
# -----------------
"--------------------" | Out-File $VersionFile -Append
"MSXML DLL Versions: " | Out-File $VersionFile -Append
"--------------------" | Out-File $VersionFile -Append
Get-ChildItem (Join-Path $Env:windir "system32\msxml*.dll") -ErrorAction SilentlyContinue | `
	foreach-object {[System.Diagnostics.FileVersionInfo]::GetVersionInfo($_)} | `
	Select-Object FileName,FileVersion,ProductVersion | Format-Table -AutoSize -HideTableHeaders | `
	Out-File $VersionFile -Append -Width 1000

CollectFiles -filesToCollect $VersionFile -fileDescription "WUA File Versions"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WUAInfo -Status $ScriptStrings.ID_SCCM_WUAInfo_SecDesc

# ---------------------
# Security Descriptors
# ---------------------
$TempFileName = ($ComputerName + "_WUA_SecurityDesc.txt")
$SDFile  = Join-Path $Pwd.Path $TempFileName
Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUA Related Security Descriptors" -Value "Review $TempFileName"
"----------------------------------------------" | Out-File $SDFile -Append
"Security Descriptors for WU Related Services: " | Out-File $SDFile -Append
"----------------------------------------------" | Out-File $SDFile -Append
"" | Out-File $SDFile -Append
"WUAUServ: " | Out-File $SDFile -Append
$CmdToRun = "cmd /c sc sdshow wuauserv >> $SDFile"
RunCmd -commandToRun $CmdToRun -collectFiles $false
"" | Out-File $SDFile -Append
"BITS: " | Out-File $SDFile -Append
$CmdToRun = "cmd /c sc sdshow bits >> $SDFile"
RunCmd -commandToRun $CmdToRun -collectFiles $false
"" | Out-File $SDFile -Append
"Windows Installer: " | Out-File $SDFile -Append
$CmdToRun = "cmd /c sc sdshow msiserver >> $SDFile"
RunCmd -commandToRun $CmdToRun -collectFiles $false
"" | Out-File $SDFile -Append
"Task Scheduler: " | Out-File $SDFile -Append
$CmdToRun = "cmd /c sc sdshow Schedule >> $SDFile"
RunCmd -commandToRun $CmdToRun -collectFiles $false

CollectFiles -filesToCollect $SDFile -fileDescription "WUA Security Descriptors"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ---------------------------
# Collect WU Registry keys
# ---------------------------
$TempFileName = $ComputerName + "_RegistryKey_WU.txt"
$RegFileWU = Join-Path $Pwd.Path $TempFileName

$TempKey = "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
Export-RegKey -RegKey $TempKey -outFile $RegFileWU -fileDescription "WU Registry Key" -collectFiles $false

$TempKey = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate"
Export-RegKey -RegKey $TempKey -outFile $RegFileWU -fileDescription "WU Registry Key" -collectFiles $false

Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WU Registry Keys" -Value "Review $TempFileName"
CollectFiles -filesToCollect $RegFileWU -fileDescription "WU Registry Keys"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ---------------------------
# Collect WUFB Registry keys
# ---------------------------
$TempFileName = $ComputerName + "_RegistryKey_WUFB.txt"
$RegFileWUFB = Join-Path $Pwd.Path $TempFileName

$TempKey = "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX"
Export-RegKey -RegKey $TempKey -outFile $RegFileWUFB -fileDescription "WUFB Registry Keys" -collectFiles $false

$TempKey = "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UpdatePolicy"
Export-RegKey -RegKey $TempKey -outFile $RegFileWUFB -fileDescription "WUFB Registry Keys" -collectFiles $false

$TempKey = "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate"
Export-RegKey -RegKey $TempKey -outFile $RegFileWUFB -fileDescription "WUFB Registry Keys" -collectFiles $false

$TempKey = "HKLM\SOFTWARE\Microsoft\PolicyManager\default\Update"
Export-RegKey -RegKey $TempKey -outFile $RegFileWUFB -fileDescription "WUFB Registry Keys" -collectFiles $false

Add-Member -InputObject $WUAInfo -MemberType NoteProperty -Name "WUFB Registry Keys" -Value "Review $TempFileName"
CollectFiles -filesToCollect $RegFileWUFB -fileDescription "WUFB Registry Keys"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------------------------------
# Output WUAInfo PSObject to Summary File
# ----------------------------------------
$WUAInfo | Out-File $WUAFile -Append -Width 500

# --------------------
# Collect WUA Summary
# --------------------
CollectFiles -filesToCollect $WUAFile -fileDescription "WUA Summary"  -sectionDescription $global:SummarySectionDescription -noFileExtensionsOnDescription

TraceOut "Completed"
# SIG # Begin signature block
# MIIa3AYJKoZIhvcNAQcCoIIazTCCGskCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUb4vGBlr7+RYtjy45WrKtxNlw
# xHOgghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTDMIIE
# vwIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHcMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBT2
# jXWjTAFR1I/2m2pvf/4NT+pIYDB8BgorBgEEAYI3AgEMMW4wbKBSgFAARABJAEEA
# RwBfAEMAVABTAF8AUwBDAEMATQBfADIAMAAxADIAXwBnAGwAbwBiAGEAbABfAEQA
# QwBfAFcAVQBBAEkAbgBmAG8ALgBwAHMAMaEWgBRodHRwOi8vbWljcm9zb2Z0LmNv
# bTANBgkqhkiG9w0BAQEFAASCAQCPP9rilanEbWQjyWhhUSMq8fjFPxj5Q2B9BYeu
# tXzh8ugQMTXyDTIEd98Ac5OQJIwtQqVJf2wYi7crv1VTx73q8CyKwN0KOCIj7nru
# +uTuuZ76DQFwPQu8/Mfp3N7VSKYkrTGmF8c+cWRPQzCgzNKQgoGxIM+LA7TQT1r+
# rYzT0uxyoI+lkC6cBmenkWELghmGYANp/ttDVTzXyImEkbM/NNpEu3WLgC3QrcRn
# M8Ib36OKVgqDr/UEXgebAOZz+AfMjlFU384npKMi8XvVq3P1REBO9HgZQ4CgihXs
# YAUzxBjxcl8IEk+EbJvA3vt2VKfFknUXbaY7EsY7pmR83rIcoYICKDCCAiQGCSqG
# SIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQQIT
# MwAAAMZ4gDYBdRppcgAAAAAAxjAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsG
# CSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcwNDI3MTQyMzMwWjAjBgkqhkiG
# 9w0BCQQxFgQUq82aRPhqJjb4SxRIMKaG0NXkHO8wDQYJKoZIhvcNAQEFBQAEggEA
# CWRfdwlJIA5hPvG23ujYyA/KJYnoPAMCHBTBan1ioKFapeePV2ak0ObyaTUMlvLA
# L9N+5P1HbYpVe1hv7a0M3RDPCsft+22/vAvSxHBBackfsBE0nURc7gdAhYVjaVfY
# xMbAhegU5OwBjFjbw7h7r23J+eUIDvyhW8h2aaJLLc+ibe5noQbJ8DyKEDDuDUVd
# 2Vhn7hPBytX5ckPWhy8XgzjCO+9FCRU3EzLRFfIUqFYby4PFePg1+xQ0vcSmOYVh
# KZhCbsS7xiD8jDorfZ7rKZLZxpqS5OPkbOXz+LtVsi6OagUC0EtKXI7+Tu/+WNqb
# 5poR86g6BUg6XUQHusuSlA==
# SIG # End signature block
