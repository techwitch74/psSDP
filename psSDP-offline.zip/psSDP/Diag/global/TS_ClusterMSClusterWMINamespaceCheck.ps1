﻿#************************************************
# TS_ClusterMSClusterWMINamespaceCheck.ps1
# Version 1.0.0
# Date: 2/12/2013
# Author: jasonf,v-kaw
# Description:  [Idea ID 6500] [Windows] Invalid Namespace error on 2008 and 2012 Clusters
# Rule number:  6500
# Rule URL:  http://sharepoint/sites/rules/Rule Submissions/Forms/DispForm.aspx?ID=6500
#************************************************

Import-LocalizedData -BindingVariable ScriptStrings
Display-DefaultActivity -Rule -RuleNumber 6500

$RuleApplicable = $false
$RootCauseDetected = $false
$RootCauseName = "RC_ClusterMSClusterWMINamespaceCheck"
$InformationCollected = new-object PSObject

# ***************************
# Data Gathering
# ***************************
Function IsCluster                  #Check if this machine is cluster.
{
	$ClusterKeyName = "HKLM:\Cluster"      
	if (Test-Path -Path $ClusterKeyName) 
	{
		return $true
	}
	else
	{
		return $false
	}
} 

Function AppliesToSystem
{
	#Add your logic here to specify on which environments this rule will appy + Win10
	return ((($OSVersion.Major -eq 6) -and ($OSVersion.Minor -ge 0) -or ($OSVersion.Major -eq 10)) -and (IsCluster) )  
}

# **************
# Detection Logic
# **************

#Check to see if rule is applicable to this computer
if (AppliesToSystem)
{
	$RuleApplicable = $true
	trap [Exception] 
	{	    		
		$Script:ErrorCode = "0X{0:X}" -f $Error[0].Exception.ErrorCode.value__    # {0x(exceptioncode)}
		WriteTo-ErrorDebugReport -ErrorRecord $_
	    $Error.Clear()
		continue
	}		
	$result = (get-wmiobject -class "MSCluster_CLUSTER" -namespace "root\MSCluster" -authentication PacketPrivacy -computername $ComputerName -erroraction stop).__SERVER	
	if ($result -eq $null)
	{
		$RootCauseDetected = $true
		$InformationCollected | add-member -membertype noteproperty -name "Cluster Machine missing MSCluster namespace" -value $ComputerName		
		$InformationCollected | add-member -membertype noteproperty -name "Exception accessing MSCluster_CLUSTER Class" -value $Script:ErrorCode	
	}
}		
	

# *********************
# Root Cause processing
# *********************

if ($RuleApplicable)
{
	if ($RootCauseDetected)
	{
		# Red/ Yellow Light
		Update-DiagRootCause -id $RootCauseName -Detected $true
		Add-GenericMessage -Id $RootCauseName -InformationCollected $InformationCollected 
	}
	else
	{
		# Green Light
		Update-DiagRootCause -id $RootCauseName -Detected $false
	}
}
