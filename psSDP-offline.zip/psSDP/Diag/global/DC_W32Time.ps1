﻿
#************************************************
# DC_W32Time.ps1
# Version 1.0
# Date: 12-22-2010
# Author: clandis
# Description: Collects W32Time information
#************************************************

Import-LocalizedData -BindingVariable W32TimeStrings -FileName DC_W32Time -UICulture en-us

Write-DiagProgress -Activity $W32TimeStrings.ID_W32TimeOutput -Status $W32TimeStrings.ID_W32TimeObtaining

# If you specify a file name but not a full path for FileLogName, W32Time will try to write to %windir%\system32 but will fail with Access is Denied.
# So there is no point in checking for a file name but no full path, since it wouldn't allow debugging to actually be enabled anyway since the file wouldn't get written.

# Read the FileLogName value into the $FileLogName variable

$FileLogName = (get-itemproperty HKLM:\SYSTEM\CurrentControlSet\services\W32Time\Config\).FileLogName

# If $FileLogName is null (because FileLogName is not set) then throw an error.
If ($FileLogName -eq $null)	{
	"FileLogName registry value is not set. W32Time debug logging is not enabled." | Out-Host 
	} 
# If $FileLogName is populated, check if the path exists and if so, copy the file to current directory, prepending the computer name.
Else {
	"FileLogName = $FileLogName" | Out-Host 
	If (Test-Path $FileLogName) {
		"Copying $FileLogName to .\" + ($ComputerName + "_W32Time.log") | Out-Host
		Copy-Item $FileLogName (".\" + $ComputerName + "_W32Time.log")
		If (Test-Path (".\" + $ComputerName + "_W32Time.log")) {
			"File copy succeeded." | Out-Host 
			}
		Else {
			"File copy failed." | Out-Host 
			}
	Else {
		"File not found." | Out-Host 
		}
	}
}

# w32tm /query /status for local machine, PDC, and authenticating DC.
$OutputFile = $ComputerName + "_W32TM_Query_Status-output.TXT"	#_#

$Domain = [adsi]("LDAP://RootDSE")
$AUTHDC_DNSHOSTNAME = $Domain.dnshostname
$DomainDN = $Domain.defaultNamingContext
 
$PDC_NTDS_DN = ([adsi]("LDAP://"+ $DomainDN)).fsmoroleowner
$PDC_NTDS = [adsi]("LDAP://"+ $PDC_NTDS_DN)
$PDC = $PDC_NTDS.psbase.get_parent() -ErrorAction SilentlyContinue
if ($PDC -ne $null) { $PDC_DNSHOSTNAME = $PDC.dnshostname }

"This output is best viewed in the Support Diagnostic Console (SDC) or Internet Explorer. " | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append
"The following errors are expected to occur under the following conditions: " | Out-File -FilePath $OutputFile -append
"   -  'Access is Denied' is expected if MSDT was run with an account that does not have local administrative rights on the target machine. " | Out-File -FilePath $OutputFile -append
"   -  'The procedure is out of range' is expected if the target machine is not running Windows Server 2008 or later. " | Out-File -FilePath $OutputFile -append
"   -  'The RPC server is unavailable' is expected if Windows Firewall is enabled on the target machine, or the target machine is otherwise unreachable. " | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append
"Output of 'w32tm /query /status /verbose' - " | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append
cmd /d /c w32tm /query /status /verbose | Out-File -FilePath $OutputFile -append
" " | Out-File -FilePath $OutputFile -append

if ($Global:skipHang -ne $true) {  #_#
	If ($PDC_DNSHOSTNAME -ne $null) {
		"The PDC Emulator for this computer's domain is $PDC_DNSHOSTNAME" | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		"Output of 'w32tm /query /computer:$PDC_DNSHOSTNAME /status /verbose' - " | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		cmd /d /c w32tm /query /computer:$PDC_DNSHOSTNAME /status /verbose | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		}
	Else {
		"Unable to determine the PDC Emulator for the domain." | Out-File -FilePath $OutputFile -append
		}

	If ($AUTHDC_DNSHOSTNAME -ne $null) {
		" " | Out-File -FilePath $OutputFile -append
		"This computer's authenticating domain controller is $AUTHDC_DNSHOSTNAME" | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		"Output of 'w32tm /query /computer:$AUTHDC_DNSHOSTNAME' /status /verbose" | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		cmd /d /c w32tm /query /computer:$AUTHDC_DNSHOSTNAME /status /verbose | Out-File -FilePath $OutputFile -append
		" " | Out-File -FilePath $OutputFile -append
		}
	Else {
		"Unable to determine this computer's authenticating domain controller." | Out-File -FilePath $OutputFile -append
		}

	If ($PDC_DNSHOSTNAME -ne $null) {
		"The PDC Emulator for this computer's domain is $PDC_DNSHOSTNAME" | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		"Output of 'w32tm /stripchart /computer:$PDC_DNSHOSTNAME /samples:5 /dataonly' - " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		cmd /d /c w32tm /stripchart /computer:$PDC_DNSHOSTNAME /samples:5 /dataonly | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		}
	Else {
		"Unable to determine the PDC Emulator for the domain." | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		}

	If ($AUTHDC_DNSHOSTNAME -ne $null) {
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		"This computer's authenticating domain controller is $AUTHDC_DNSHOSTNAME" | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		"Output of 'w32tm /stripchart /computer:$AUTHDC_DNSHOSTNAME /samples:5 /dataonly" | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		cmd /d /c w32tm /stripchart /computer:$AUTHDC_DNSHOSTNAME /samples:5 /dataonly | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		" " | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		}
	Else {
		"Unable to determine this computer's authenticating domain controller." | Out-File (".\" + $ComputerName + "_W32TM_Stripchart.txt") -append
		}
} #_#
$OutputFile1 = join-path $pwd.path ($ComputerName + "_W32Time_Service_Status.txt")
#$command1 = "cmd.exe /d /c sc query w32time > " + $ComputerName + "_W32Time_Service_Status.txt"
$command1 = $Env:windir + "\system32\cmd.exe /d /c sc query w32time > `"$OutputFile1`""

$OutputFile2 = join-path $pwd.path ($ComputerName + "_W32Time_Service_Perms.txt")
#$command2 = "cmd.exe /d /c sc sdshow w32time > " + $ComputerName + "_W32Time_Service_Perms.txt"
$command2 = $Env:windir + "\system32\cmd.exe /d /c sc sdshow w32time > `"$OutputFile2`""

Write-DiagProgress -Activity $W32TimeStrings.ID_W32TimeOutput -Status "w32tm /monitor"
$OutputFile3 = join-path $pwd.path ($ComputerName + "_W32TM_Monitor.txt")
#$command3 = "cmd.exe /d /c w32tm /monitor > " + $ComputerName + "_W32TM_Monitor.txt"
$command3 = $Env:windir + "\system32\cmd.exe /d /c w32tm /monitor > `"$OutputFile3`""

Write-DiagProgress -Activity $W32TimeStrings.ID_W32TimeOutput -Status "w32tm /testif /qps"
$OutputFile4 = join-path $pwd.path ($ComputerName + "_W32TM_TestIf_QPS.txt")
#$command4 = "cmd.exe /d /c w32tm /testif /qps > " + $ComputerName + "_W32TM_TestIf_QPS.txt"
$command4 = $Env:windir + "\system32\cmd.exe /d /c w32tm /testif /qps > `"$OutputFile4`""

$OutputFile5 = join-path $pwd.path ($ComputerName + "_W32TM_TZ.txt")
#$command5 = "cmd.exe /d /c w32tm /tz > " + $ComputerName + "_W32TM_TZ.txt"
$command5 = $Env:windir + "\system32\cmd.exe /d /c w32tm /tz > `"$OutputFile5`""

CollectFiles -filesToCollect ($ComputerName + "_W32Time.log") -fileDescription "W32Time Debug Log" -sectionDescription "W32Time" -noFileExtensionsOnDescription
#RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\W32Time" -OutputFile (".\" + $ComputerName + "_W32Time_Reg_Key.txt") -fileDescription "W32Time Reg Key" -sectionDescription "W32Time" -recursive $true
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\W32Time" -OutputFile ($ComputerName + "_W32Time_Reg_Key.txt") -fileDescription "W32Time Reg Key" -sectionDescription "W32Time" -recursive $true #_# removed .\ /WalterE

Get-Acl HKLM:\SYSTEM\CurrentControlSet\services\W32Time | Format-List | Out-File (".\" + $ComputerName + "_W32Time_Reg_Key_Perms.txt")
CollectFiles -filesToCollect ($ComputerName + "_W32Time_Reg_Key_Perms.txt") -fileDescription "W32Time Reg Key Perms" -sectionDescription "W32Time" -noFileExtensionsOnDescription
RunCmD -commandToRun $command1 -sectionDescription "W32Time" -filesToCollect $OutputFile1 -fileDescription "W32Time Service Status" -noFileExtensionsOnDescription
#RunCmD -commandToRun $command2 -sectionDescription "W32Time" -filesToCollect $OutputFile2 -fileDescription "W32Time Service Perms" -noFileExtensionsOnDescription
#RunCmD -commandToRun $command3 -sectionDescription "W32Time" -filesToCollect $OutputFile3 -fileDescription "W32TM /Monitor" -noFileExtensionsOnDescription
RunCmD -commandToRun $command4 -sectionDescription "W32Time" -filesToCollect $OutputFile4 -fileDescription "W32TM /TestIf /QPS" -noFileExtensionsOnDescription
### (Andret) Removed due http://bugcheck/Bugs/WindowsOSBugs/1879349 and http://bugcheck/bugs/Windows7/35226
### RunCmD -commandToRun $command5 -sectionDescription "W32Time" -filesToCollect $OutputFile5 -fileDescription "W32TM /TZ" -noFileExtensionsOnDescription

CollectFiles -filesToCollect ($ComputerName + "_W32TM_Query_Status.txt") -fileDescription "W32TM Query Status" -sectionDescription "W32Time" -noFileExtensionsOnDescription
CollectFiles -filesToCollect ($ComputerName + "_W32TM_Stripchart.txt") -fileDescription "W32TM Stripchart" -sectionDescription "W32Time" -noFileExtensionsOnDescription

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}

# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDFDjJGCgren71e
# DoNCHnwVvIaT3UvjbWys5dt786YCNqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgCoC/Op9j
# f/1P6tuPVuTP0TkCyls9dB4/q6dsrTrtvfUwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAH9j9kMcARHB7YK6E6oFQ5yYtX67Wp9pMwdfxfGukpRDgWAOQ1i1JZCC
# fOpuEwSf1wdp6S7yFVCU5mTbDKIM5mu4E9BlupYcchWx/tZXOll6U0pI4YSSPfQf
# Zp+H0zWfD57YxfeE6BQjxTLbUm+ScolZH7LQczWdTCRnJ+lmXLqoI4O9949OawPf
# RGBR+S6X24OS6oPiUudqAXDQ7eTp6i+2m9QALHb/rr/5dzlW+12kJaaIJfgGd2Y7
# MBoVRgANSSsoqESmh2Has5upqBFoCkiCjMyK/rYe0Cu0nWPAHAOcpT7i4CtHk99B
# O7GTKKGqY3ckrD6R5ANCVLxESGH1xduhghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg9+pYOw9naNUhG0B6xKL6L9Au2ScK8AVEMbrJ3U3JmTYCBmCKzptV
# 8xgTMjAyMTA1MTkyMjIzNTUuMTQ3WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABPIv9ubM/R5f9AAAAAAE8MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyM1oXDTIyMDExMjE3MjgyM1owgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00
# QkIwLTgyNDYxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCYECrpaQOq9jkOBpC345fQ
# 0IvOpRqK8nEe+jopJc/5XNNqzanq5hrd9wib4RdvpuPj68n5Dm/XZu2vCqnWoxhy
# 3ixrbgS/rg3CS3bqp8Ag1UQg/xAz32TueeTOY1cOelcXRahosIcjlrrkv13AacFX
# m4AbYMCgYM6BzdZKARebc6zEv+4QCy4+1AV8RHQHEOdoj42OJpbFWlHvYKzXuM1A
# H4vmjT9o/fCq2mWD7Ig2/CpaId2gHK6R+S909iK27uVkjVap2/Sb4ATOLJbaVQ+X
# 0+hYbEcCesf93g+tAQXuvA8dH63doK5I5zdZCF5U/3Dibfl7ZCFsU6ks+ph4jJrb
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQU4aFn4soS+jazYT8lGOoYvyZnPEYwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAMvcQjJTdl3luSMzFqRkxRklJ+KWRUUlB
# 3I2KJVWb4Gn6eWdJTiWdC1uxejF2oPX0b+X9QIhi8u1AaV792eEit2lQzqVgPify
# TZGLjzK2Oou4Pj/F58Pp2m6HupGfuNAehln+hSvvIE5ggEnCiv9lVkAJOMlLHF38
# DbPv7pyWs0Lzv2sjZwPHvdhtV8lBtOYsE8Nxznlbsyc80vRnReqm8JQK6Z8xAD4S
# eY8duFFXhciETG2E0bh+/N3mwGnzXJzMbSKAKkzIw6Yxqf+zHzWPFim9DGZwmchq
# +6JBKtb4EGT0EFtfqGCrOPD5O7uPwSdj1apgXqo7Hctx7hcs5qjpwjCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAHUt0elneaPLba16Ke63RR3B65OaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPqk8wIhgPMjAyMTA1MTkyMzE2MzFaGA8yMDIxMDUyMDIzMTYzMVowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+qTwIBADAKAgEAAgIYqAIB/zAHAgEAAgIR
# MzAKAgUA5FD7zwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAI+E73p4h9kk
# SYCzO+rXLK7RK5Ia4XU7rSWLex0xaCG/tD8TBNoGZmVMrG4m9+o4FLmoY6aEzPou
# xTR4PEZU7Qh1EwiNCZblZFkfz+rofE0LgYHWkXw/kJuAVExDxVWBlamtk6kY7p1/
# XyFZKWFBMQMEU6Iu1idtHDCvZZNdvLOxMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE8i/25sz9Hl/0AAAAAATwwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgTafOcAA9KavB3GW2kXZAiAsTKzehVC2Sg2e8m5GycP8wgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCgSQK6TSS/wOc6qbfUfBGv7YhsPfGYhbgV
# IYrhJuhaRjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABPIv9ubM/R5f9AAAAAAE8MCIEIB+co0f6Uly9BxK096y0E+Z8u4RNWInNiBJi
# 2xgL13agMA0GCSqGSIb3DQEBCwUABIIBAEqjRY7e82Dsln24w0PuQB4ct4qFZnhN
# T1cMI9zIOv0cXPXGM9G4R2LMqf9BrwX8HAdNEo5ajcJQGvcP8G2qF+5l1TYC9xRT
# CuzTACNmxo3/IMeJCwJf4FzItQnvrcr1wjUOKCTwSSqoIRE2D2G9/LR1NNNzZXjB
# XZEInCsZThiVYaAE62OkivymaSoE1ldOPh7w8iZgJloDF2WiTUOwpFyduWTbFncO
# evCeKi1Zea9LLxymOCuPK0Hdk6UjgnBjvPA5biIUgW6lsqufRa6BJdKzcP9F3M4K
# XdbQ65F3XEU7bt+HOUqzsXxFAB2fy6hA2YiLbh+MjJhApXZbu9PBXTI=
# SIG # End signature block
