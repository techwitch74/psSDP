﻿#************************************************
# DC_DSRegEntries.ps1
# Version 1.0
# Date: 2009-2019
# Author: + Walter Eder (waltere@microsoft.com)
# Description: Collects Directory Services Registry Entries
# Called from: TS_AutoAddCommands_DOM.ps1, TS_AutoAddCommands_NET.ps1
#*******************************************************

function InsertRegHeader(
	[string] $RegHeader="",
	[string]$OutputFile)
{
	if($RegHeader -ne "")
	{
		$RegHeader | Out-File -FilePath $OutputFile -Append -Encoding Default
		"=" * ($RegHeader.Length) | Out-File -FilePath $OutputFile -Append -Encoding Default
	}
}

Import-LocalizedData -BindingVariable InboxCommandStrings
	
Write-DiagProgress -Activity $InboxCommandStrings.ID_DSRegentriesActivity -Status $InboxCommandStrings.ID_DSRegentriesStatus

$OutputFile = $ComputerName + "_reg_DS_REGENTRIES.txt"
$fileDescription = "Directory Services Registry Entries"

InsertRegHeader -OutputFile $OutputFile -RegHeader "Authentication registry Key - Credential Providers and Filters, LogonUI (Vista/2008 only)"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Authentication" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "LSA registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Control\Lsa" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Winlogon registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Winlogon registry key in the user's profile"
RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Winlogon" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "LanManServer and LanManWorkstation Parameters Registry Keys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\lanmanworkstation\parameters","HKLM\SYSTEM\CurrentControlSet\Services\lanmanserver\parameters" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Netlogon\Parameters registry Key"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\parameters" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "NTDS\Parameters registry Key"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\NTDS\parameters" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Product Options registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Control\ProductOptions" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "RPC registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Rpc" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "System's and user's NetCache registry key where Offline Files settings are stored"
RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\NetCache","HKCU\Software\Microsoft\Windows\CurrentVersion\NetCache" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Registry keys showing scripts assigned to the user via Group Policy"
RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows\CurrentVersion\Group Policy\Scripts" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Group Policy assigned 'Run at user logon' programs - programs assigned to run at user logon"
RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "RUN registry keys for the current user"
RegQuery -RegistryKeys "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run","HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce","HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnceEx" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "RUN registry keys for the local machine"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run","HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce","HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnceEx" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "TCPIP\Parameters registry key"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -OutputFile $OutputFile -fileDescription $fileDescription -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "W32Time registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Services\w32time" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile -RegHeader "Winreg registry key and subkeys"
RegQuery -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Control\SecurePipeServers\winreg" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $false
InsertRegHeader -OutputFile $OutputFile  -RegHeader "ProfileList registry key listing local profiles"
RegQuery -RegistryKeys "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList" -OutputFile $OutputFile -fileDescription $fileDescription -Recursive $true -AddFileToReport $true

Trap{WriteTo-StdOut "$($_.InvocationInfo.ScriptName)($($_.InvocationInfo.ScriptLineNumber)): $_" -shortformat;Continue}
