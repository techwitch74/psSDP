﻿#************************************************
# DC_RDSHelper.ps1
# Version 1.0.1
# Date: 21-01-2012
# Author: Daniel Grund - dgrund@microsoft.com /#_# WalterE
# Description: 
#	RDS helper file 
# 1.0.0 Beta release
# 1.0.1 Added advapi32 to get userrightsassigments
#************************************************
PARAM(
    $RDSHelper,
	$RDSSDPStrings
)

$RDSHelper=@"
using System;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using System.Net;
using System.Net.Sockets;
using System.Net.Security;
using System.Security;
using System.ComponentModel;
using System.Collections;

public class RDSHelper
{
		public struct Collection
		{
			public string CollectionName;
			public string[] CollectionServers;
		}

		public struct ConnectionBroker
		{
			public string ConnectionBrokerName;
			public Collection[] Collections;
		}

        [StructLayout(LayoutKind.Sequential,Pack=1)]
        struct CertChain
        {
            public int Version;
            public int Count;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8000)]
            /*
            struct _Cert_Blob
            {
                public int cbCert;     // size of this certificate blob
                [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8000)]
                public byte[] abCert;    // beginning byte of this certificate

            }*/
            public byte[] Certs;

        }

        [StructLayout(LayoutKind.Sequential,Pack=1)]
        struct _Cert_Blob
        {
            public int cbCert;     // size of this certificate blob
            public byte[] abCert;    // beginning byte of this certificate

        }
    public static bool RDPTestPort(string HostName, int port)
    { 
        // 5985 will be new Win8 'remoting' port
        // Create a TCP/IP client socket.
        // machineName is the host running the server application.
        TcpClient client = new TcpClient(HostName,port);
        if (client.Connected) return true;
        return false;
    }    
    public static X509Certificate RDPGetCert(string HostName, int port, string SavePath)
    { 
        X509Certificate cert = null;
       // Create a TCP/IP client socket.
        // machineName is the host running the server application.
        TcpClient client = new TcpClient(HostName,port);
		// sets the time out for the read and write to 5 seconds.
		client.ReceiveTimeout =5000;
        client.SendTimeout = 5000;
        try 
        {
			// Create an SSL stream that will close the client's stream.
	        SslStream sslStream = new SslStream(
	            client.GetStream(), 
	            false,
	            // always accept certificate 
	            new RemoteCertificateValidationCallback (delegate {return true;}), 
	            null
	            );
			// Set timeouts for the read and write to 5 seconds.
		    sslStream.ReadTimeout = 5000;
			sslStream.WriteTimeout = 5000;
            sslStream.AuthenticateAsClient(HostName);
            cert = sslStream.RemoteCertificate ;
            FileStream FS = new FileStream(SavePath, FileMode.Create);
            byte[] certBytes = cert.Export(X509ContentType.Cert, "");
            FS.Write(certBytes, 0, certBytes.Length);
            FS.Close();
        } 
        catch (System.Security.Cryptography.CryptographicException e)
        {
            // must do something with e to satisfy compiler or compile with -ignorewarning
        }
        client.Close();
        return cert ;
    }

	public static X509CertificateCollection GetCertCollFromReg( byte[] Cert)
        {
            X509CertificateCollection CertColl = null;
            try
            {
                GCHandle Handle = GCHandle.Alloc(Cert, GCHandleType.Pinned);
                IntPtr Ptr = Handle.AddrOfPinnedObject();
                CertChain certChain = (CertChain) Marshal.PtrToStructure(Ptr,typeof (CertChain));
                CertColl = new X509CertificateCollection();
                byte[] sCert = ((CertChain)Marshal.PtrToStructure(Ptr, typeof(CertChain))).Certs;
                
                int SizeCert = 0, offset = 0 ;
                GCHandle CHandle = GCHandle.Alloc(sCert, GCHandleType.Pinned);
                IntPtr CPtr = CHandle.AddrOfPinnedObject();
                
                for (int x = 0; x < certChain.Count ;x++ )
                {
                
                    SizeCert = sCert[offset +3];
                    SizeCert = SizeCert *256 + sCert[offset +2];
                    SizeCert = SizeCert *256 + sCert[offset +1];
                    SizeCert = SizeCert * 256 + sCert[offset + 0];
                    byte[] Cert1 = new byte[SizeCert];
                    uint uPtr = (uint)CPtr;
                    uPtr += 4;
                    CPtr = (IntPtr)uPtr;
                    Marshal.Copy(CPtr, Cert1, 0 , SizeCert );
                   CertColl.Add(new X509Certificate(Cert1));
                   offset += 4 + SizeCert;
                   uPtr += (uint) SizeCert;
                   CPtr = (IntPtr)uPtr;
                   
                }
                Handle.Free();
                CHandle.Free();
                return CertColl;
            }
            catch( System.Security.Cryptography.CryptographicException e)
            {
                // must do something with e to satisfy compiler or compile with -ignorewarning
                 
                return CertColl;
            }
            
        }
        
        public static IPAddress[] DNSLookup(string HostName)
        {
            IPHostEntry rdhost = Dns.GetHostEntry(HostName);
            return rdhost.AddressList;
        }

		public static int GetHttpsCert(string HostName, string SavePath)
		{
			bool Success = false;
			string Error = "";
			int nError = 0;
			X509Certificate cert = null;
			string targetURL = "https://" + HostName + "/rpc";
            HttpWebRequest webreq = (HttpWebRequest)WebRequest.Create(targetURL);
            HttpWebResponse webresp;
			try
			{
				webreq.UseDefaultCredentials = true;
				// should be set automaticly when UseDefaultCredentials is set to true.. just to be sure
                webreq.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials;
				// accept all certificates
				ServicePointManager.ServerCertificateValidationCallback = new RemoteCertificateValidationCallback(delegate {return true;});
				Uri Host = new Uri(targetURL);
				webresp = (HttpWebResponse)webreq.GetResponse();
			}
			catch (Exception gwe)
            {
                Error = gwe.Message;
            }

			if (Error !="")
			{
				// first of all did we get to the Rpc page...?
				if (Error.Contains("401")) // auth error, page must exist
					nError = 1 ;  //Supplied credentials did not work

				if (Error.Contains("404")) // auth error, page must exist
					nError = 2; //There is no Rpc web site, required for SOAP calls to the AAEdge/Gateway

				if (Error.Contains("Unable to connect")) // no HTTPS
					nError = 3; //There is no HTTPS web service at the address

				if (Error.Contains("503")) 
                    nError = 4; //"The remote server returned an error: (503) Server Unavailable."
				
			}
			if (webreq.ServicePoint.Certificate != null)
            {
				// now save the retrieved certificate.
				cert = webreq.ServicePoint.Certificate;
				FileStream FS = new FileStream(SavePath, FileMode.Create);
				byte[] certBytes = cert.Export(X509ContentType.Cert, "");
				FS.Write(certBytes, 0, certBytes.Length);
				FS.Close();
				return 0; //Success
			}
			if (nError ==0) // only log error if we did not get certificate......
			return 5; //No certificate found.
			return nError;
		}
		
		    [StructLayout(LayoutKind.Sequential)]
    struct OBJECT_ATTRIBUTES
    {
        internal int Length;
        internal IntPtr RootDirectory;
        internal IntPtr ObjectName;
        internal int Attributes;
        internal IntPtr SecurityDescriptor;
        internal IntPtr SecurityQualityOfService;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    struct UNICODE_STRING
    {
        internal ushort Length;
        internal ushort MaximumLength;
        [MarshalAs(UnmanagedType.LPWStr)]
        internal string Buffer;
    }

    [StructLayout(LayoutKind.Sequential)]
    struct ENUMERATION_INFORMATION
    {
        internal IntPtr PSid;
    }

    sealed class advapi32
    {
        [DllImport("advapi32", CharSet = CharSet.Unicode, SetLastError = true),
        SuppressUnmanagedCodeSecurityAttribute]
        internal static extern uint LsaOpenPolicy(
            UNICODE_STRING[] SystemName,
            ref OBJECT_ATTRIBUTES ObjectAttributes,
            int AccessMask,
            out IntPtr PolicyHandle);

        [DllImport("advapi32", CharSet = CharSet.Unicode, SetLastError = true),
        SuppressUnmanagedCodeSecurityAttribute]
        internal static extern uint LsaEnumerateAccountsWithUserRight(
            IntPtr PolicyHandle,
            UNICODE_STRING[] UserRights,
            out IntPtr EnumerationBuffer,
            out int CountReturned);

        [DllImport("advapi32")]
        internal static extern int LsaClose(IntPtr PolicyHandle);

        [DllImport("advapi32", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern bool ConvertSidToStringSid(
            IntPtr pSid, 
            out IntPtr strSid);

    }
    public class Lsa : IDisposable
    {
        IntPtr PolicyHandle;
        enum Access : int
        {
            POLICY_READ = 0x20006,
            POLICY_ALL_ACCESS = 0x00F0FFF,
            POLICY_EXECUTE = 0X20801,
            POLICY_WRITE = 0X207F8
        }

        public Lsa()
            : this(null)
        { }

        public Lsa(string TargetHost)
        {
            OBJECT_ATTRIBUTES ObjectAttributes;
            ObjectAttributes.RootDirectory = IntPtr.Zero;
            ObjectAttributes.ObjectName = IntPtr.Zero;
            ObjectAttributes.Attributes = 0;
            ObjectAttributes.SecurityDescriptor = IntPtr.Zero;
            ObjectAttributes.SecurityQualityOfService = IntPtr.Zero;
            ObjectAttributes.Length = Marshal.SizeOf(typeof(OBJECT_ATTRIBUTES));
            PolicyHandle = IntPtr.Zero;
            UNICODE_STRING[] SystemName = null;
            if (TargetHost != null)
            {
                SystemName = new UNICODE_STRING[1];
                SystemName[0] = InitUnicodeString(TargetHost);
            }

            uint ret = advapi32.LsaOpenPolicy(SystemName, ref ObjectAttributes, (int)Access.POLICY_ALL_ACCESS, out PolicyHandle);
            return;

        }

        public string[] ReadUserRightAssigment(string UserRight)
        {
            UNICODE_STRING[] UserRights = new UNICODE_STRING[1];
            UserRights[0] = InitUnicodeString(UserRight);
            IntPtr EnumerationBuffer;
            int CountReturned = 0;
            uint Status = advapi32.LsaEnumerateAccountsWithUserRight(PolicyHandle, UserRights, out EnumerationBuffer, out CountReturned);
            string[] SidStrings = new string[CountReturned];
            if (Status == 0)
            {

                ENUMERATION_INFORMATION[] EnumInfo = new ENUMERATION_INFORMATION[CountReturned];

                for (int i = 0, BufferOffset = (int)EnumerationBuffer; i < CountReturned; i++)
                {
                    IntPtr ptrSid;
                    EnumInfo[i] = (ENUMERATION_INFORMATION)Marshal.PtrToStructure(
                           (IntPtr)BufferOffset, typeof(ENUMERATION_INFORMATION));
                    advapi32.ConvertSidToStringSid(EnumInfo[i].PSid, out ptrSid);
                    SidStrings[i] = Marshal.PtrToStringAuto(ptrSid);
                    BufferOffset += Marshal.SizeOf(typeof(ENUMERATION_INFORMATION));
                }
            }
            return SidStrings;
        }

        public void Dispose()
        {
            if (PolicyHandle != IntPtr.Zero)
            {
                advapi32.LsaClose(PolicyHandle);
                PolicyHandle = IntPtr.Zero;
            }
            GC.SuppressFinalize(this);
        }
        ~Lsa()
        {
            Dispose();
        }

        static UNICODE_STRING InitUnicodeString(string _string)
        {
            UNICODE_STRING UnicodeString = new UNICODE_STRING();
            UnicodeString.Buffer = _string;
            UnicodeString.Length = (ushort)(_string.Length * sizeof(char));
            UnicodeString.MaximumLength = (ushort)(UnicodeString.Length + sizeof(char));
            return UnicodeString;
        }
    }
	public static bool IsLocalPolicyAllowingNetwork()
	{
        using (RDSHelper.Lsa lsa = new RDSHelper.Lsa())
        {
            string Everyone = "S-1-1-0";
            string AuthenticatedUsers = "S-1-5-11";
            bool Found = false;
            string[] Users = lsa.ReadUserRightAssigment("SeNetworkLogonRight");
           if (((IList)Users).Contains(Everyone) || ((IList)Users).Contains(AuthenticatedUsers))
           {
               Found = true;
           }
		   return Found;
        }
	}
}
"@

Add-Type -TypeDefinition $RDSHelper -IgnoreWarnings

Function Get-RemoteRegistryKeyProperty {
    param(
      $ComputerName = $(throw "Please specify a computer name."),
      $Path = $(throw "Please specify a registry path"),
      $Property = "*"
      ) 


    ## Validate and extract out the registry key
    if($path -match "^HKLM:\\(.*)")
    {
        $baseKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(
            "LocalMachine", $computername)
    }
    elseif($path -match "^HKCU:\\(.*)")
    {
        $baseKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(
            "CurrentUser", $computername)
    }
    else
    {
        Write-Error ("Please specify a fully-qualified registry path " +
            "(i.e.: HKLM:\Software) of the registry key to open.")
        return
    } 

    ## Open the key
    $key = $baseKey.OpenSubKey($matches[1])
    $returnObject = New-Object PsObject 

    ## Go through each of the properties in the key
    foreach($keyProperty in $key.GetValueNames())
    {
        ## If the property matches the search term, add it as a
        ## property to the output
        if($keyProperty -like $property)
        {
            $returnObject |
                Add-Member NoteProperty $keyProperty $key.GetValue($keyProperty)
        }
    } 

    ## Return the resulting object
    $returnObject 

    ## Close the key and base keys
    $key.Close()
    $baseKey.Close()
}

Function GetLSConnectDesc {
    param(
        [int]$ConnectResult = 0
    )
    switch($ConnectResult){
    0{"The connectivity status cannot be determined."}
 
    1{"Remote Desktop Services can connect to the Windows Server 2008 R2 license server."}
 
    2{"Remote Desktop Services can connect to the Windows Server 2008 license server."}
 
    3{"Remote Desktop Services can connect to the license server, but one of the servers is running a beta version of the operating system."}
 
    4{"Remote Desktop Services can connect to the license server, but there is an incompatibility between the license server and the Remote Desktop Services host server."}
 
    5{"Security group policy is enabled in license server, but Remote Desktop Services is not a part of the group policy."}
 
    6{"Remote Desktop Services cannot connect to the license server."}
 
    7{"The license server can be connected to, but the validity of the connection cannot be determined."}
 
    8{"Remote Desktop Services can connect to the license server, but the user account does not have administrator privileges on the license server."}
    
    9{"Remote Desktop Services can connect to the Windows Server 2008 SP1 with VDI support license server."}

	10{"Feature not supported."}

	11{"The license server is valid"}
    }
 
}

Function TSLicensingType {
	param(
		[int]$Type = 5
	)
	switch($Type){
		0{"Personal RD Session Host server."}
		1{"Remote Desktop for Administration."}
		2{"Per Device. Valid for application servers."}
		3{"Invalid!!"}
		4{"Per User. Valid for application servers."}
		5{"Not configured."}

	}
}

Function TSProtocol {
    param(
        [int]$Protocol = 0
    )
    switch($Protocol){
    0{"This session is running on a physical console."}
 
    1{"A proprietary third-party protocol is used for this session."}
 
    2{"Remote Desktop Protocol (RDP) is used for this session."}
 
    }
 
}

Function SessionState {
    param(
        [int]$Session = 0
    )
    switch($Session){
    0{"The session is active."}
 
    1{"The session is disconnected."}
 
    }
 
}

Function ReportError
	{
		param(
			$RootCause = "No known error",
			$Solution = "No known solution",
			$RCNum,
			$Detected = $true
  		)

		$RootCauseName = "RC_RDS" + $RCNum
		"Found Rootcause: " + $RootCause + " Found Solution: " + $Solution | WriteTo-StdOut
		Update-DiagRootCause -Id $RootCauseName -Detected $Detected -Parameter @{"Error" = $RootCause; "Solution" = $Solution}

		# $InformationCollected = new-object PSObject
		# add-member -inputobject $InformationCollected -membertype noteproperty -name $RootCause + " found:"  -value  $RootCause
		# add-member -inputobject $InformationCollected -membertype noteproperty -name $RootCause + " solution: " -value  $Solution 
		# Write-GenericMessage -RootCauseId $RootCauseName  -InformationCollected $InformationCollected -Visibility 4 -Component "Windows Remote Desktop Services"
	}

Function UpdateAndMessage
	{
		param(
			$Id,
			$Detected,
			$RootCause = "",
			$Solution = ""
		)
		"Entering UpdateAnMessage() $Id $Detected" |  WriteTo-StdOut
		Update-DiagRootCause -Id $Id -Detected $Detected
		if ($Detected)
		{
			$InformationCollected = new-object PSObject
				
			if ($RootCause -ne "")
			{
				add-member -inputobject $InformationCollected -membertype noteproperty -name ($Id + " found:")  -value  $RootCause
				if ($Solution -ne "")
				{
					add-member -inputobject $InformationCollected -membertype noteproperty -name ($Id + " solution:") -value  $Solution 
				}
			}
				Add-GenericMessage -Id $Id  -InformationCollected $InformationCollected 

		}

	}

Function SaveAsXml
	{
		param(
			$Object,
			$FileName,
			[array]$OutputFileName
			)
		$PItext = "type='text/xsl' href='RDS.xslt'"
		$File = $PWD.Path  + "\" + $FileName
	    $xml = ConvertTo-Xml $Object
		if($xml.HasChildNodes)
        {
			$Objects = $xml.SelectNodes("Objects/Object/Property")
			if(($Objects -ne $null) -and ($xml.SelectSingleNode("Objects/Object").Attributes.GetNamedItem("Type")."#text" -eq "System.Object[]"))
			{
				foreach( $xmlnode in $Objects)
				{
					$start = ($xmlnode.SelectSingleNode("Property[@Name = 'ClassPath']"))."#text".indexof(':')
					$name = ($xmlnode.SelectSingleNode("Property[@Name = 'ClassPath']"))."#text".Substring($start+1)
					$xmlnode.Attributes.Item(0)."#text" = $name
					$xmlnode.SelectSingleNode("Property[@Name = 'ClassPath']").RemoveAll()
				}
			}
			else
			{
				$xml.SelectSingleNode("Objects/Object").Attributes.RemoveAll()
				$start = ($xml.SelectSingleNode("Objects/Object/Property[@Name = 'ClassPath']"))."#text".indexof(':')
				$name = ($xml.SelectSingleNode("Objects/Object/Property[@Name = 'ClassPath']"))."#text".Substring($start+1)
				$aatr = $xml.CreateAttribute("Type")
				$aatr.Value = $name
				$xml.SelectSingleNode("Objects/Object").Attributes.Append($aatr)
				$xml.SelectSingleNode("Objects/Object/Property[@Name = 'ClassPath']").RemoveAll()
			}
			$newPI = $xml.CreateProcessingInstruction("xml-stylesheet",$PItext)
			$xml.InsertAfter($newPI,$xml.FirstChild)
			$xml.save($File)
			[array]$OutputFileName += $File
			[xml] $xslContent = Get-Content ./rds.xslt
			$xslobject = New-Object system.Xml.Xsl.XslTransform
			$xslobject.Load($xslContent)
			$htmlfile =$File.substring(0,$File.length -4) + ".html"
			$xslobject.Transform($File,$htmlfile)
			[array]$OutputFileName += $htmlfile
		}
		$OutputFileName
	}

Function FilterWMIObject
	{
		param ($Object)
		$Object | Select-Object * -excludeproperty "_*",Options,Properties,Systemproperties,Path,Description,InstallDate,Caption,Scope,Qualifiers,Site,Container,Status
	}

Function SaveRDPFileContents
	{
		param ($Object,
			$ObjectName,
			[array]$OutputFileName)
		
		if ($Object -ne $null)
		{
			
			foreach ($remoteresource in $Object)
			{
				$savepath = $TargetHost +"_" + $remoteresource.Alias + "_" + $ObjectName + ".RDP"
				$remoteresource.RDPFileContents | Out-File $savepath
				[array]$OutputFileName += $savepath
				$remoteresource.RDPFileContents = "Saved as: " + $savepath
			}
			$OutputFileName = SaveAsXml $Object  ($TargetHost +"_" + $ObjectName + ".xml") $OutputFileName
			
		}
		$OutputFileName
	}

Function out-zip 
	{ 
	  Param([string]$ZipPath, $Files) 

	  if (-not $ZipPath.EndsWith('.zip')) {$ZipPath += '.zip'} 

	  if (-not (test-path $ZipPath)) { 
		set-content $ZipPath ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18)) 
	  } 
	  $ZipFile = (new-object -com shell.application).NameSpace($ZipPath) 
	  foreach ($File in $Files)
	  {
		"Saving $File in  $ZipPath"| WriteTo-StdOut
		$ZipFile.CopyHere($File, 1052)
	  } 

	}

Function IsEventLogged
	{
		param($EventLog,
			$EventId)
		$output = wevtutil qe $EventLog "/q:*[System [(EventID = $EventId)]]" /c:1
		if($output -ne $null)
		{
			$true
		}else
		{
			$false
		}
	}

Function WMISecGroupsNotPresent
	{
		$security = Get-WmiObject -Namespace root/cimv2/terminalservices -Class __SystemSecurity
		$converter = new-object system.management.ManagementClass Win32_SecurityDescriptorHelper
		$binarySD = @($null)
		$result = $security.PsBase.InvokeMethod("GetSD",$binarySD)
		$WMIDescriptor = ($converter.BinarySDToWin32SD($binarySD[0])).Descriptor
		$RDSGroup = "RDS Management Servers","RDS Remote Access Servers","RDS Endpoint Servers"
		$Count = 0
		foreach ($DACL in $WMIDescriptor.dacl)
		{
			if ($DACL.Trustee.Name -eq "TS Web Access Computers") {return $false}
			if ($RDSGroup.Contains($DACL.Trustee.Name)){ $Count++}
			if ($Count -eq 3) {return $false}
		}
		$true
	}

function CheckNode
	{
	 Param( $Node, $Checked)
	 if($Node -ne $null)
	 {
	  foreach ($ChildNode in $Node.Nodes)
	  {
		$ChildNode.Checked = $Checked
		if( $ChildNode.Nodes.Count -gt 0)
		{
			CheckNode -Node $ChildNode -Checked $Checked
		}
	   }  
	  }
	}

function GetNodesChecked
	{
		Param ($objTreeView, [array]$ServersToCollect)
		if($objTreeView -ne $null)
		{
			for($x=0; $x -lt $objTreeView.Nodes.GetNodeCount($false);$x++)
			{
				for($y = 0;$y -lt $objTreeView.Nodes.Nodes[$x].GetNodeCount($True); $y++)
				{
					if($objTreeView.Nodes.Nodes[$x].Nodes[$y].Checked -eq $true)
					{
						[array]$ServersToCollect+= $objTreeView.Nodes.Nodes[$x].Nodes[$y].Text
					}

				}
			}
        
		}else
		{
			$ServersToCollect = $null
		}
		$ServersToCollect
	}

function AddCBtoTreeView
	{
		param ($objTreeView, $ConnectionBroker)
		$objTreeNode = New-Object System.Windows.Forms.TreeNode($ConnectionBroker.ConnectionBrokerName)
		$objTreeNode.Name = $ConnectionBroker.ConnectionBrokerName
		$objTreeView.Nodes.Add($objTreeNode)
		foreach($Collect in $ConnectionBroker.Collections)
		{
			$objChildNode = New-Object System.Windows.Forms.TreeNode($Collect.CollectionName);
			$objChildNode.Name = $Collect.CollectionName;
			$objTreeView.Nodes[$ConnectionBroker.ConnectionBrokerName].Nodes.Add($objChildNode);
			foreach($Server in  $Collect.CollectionServers)
			{
				$objServer = New-Object System.Windows.Forms.TreeNode($Server);
				$Server.Name = $Server
				$objTreeView.Nodes[$ConnectionBroker.ConnectionBrokerName].Nodes[$Collect.CollectionName].Nodes.Add($Server);
			}
		}
		$objTreeView.add_AfterCheck({
			if($_.Action -ne [System.Windows.Forms.TreeViewAction]::Unknown)
			{
				if($_.Node.Nodes.Count -gt 0)
				{
    
					CheckNode -Node $_.Node -Checked $_.Node.Checked
				}
			}
		 })
	}


Function CreateTreeViewUI
	{
		param ($ConnectionBroker)
		[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
		[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 
		$objForm = New-Object System.Windows.Forms.Form 
		$objForm.Text = "Select a Computer"
		$objForm.Size = New-Object System.Drawing.Size(500,200) 
		$objForm.StartPosition = "CenterScreen"


		$OKButton = New-Object System.Windows.Forms.Button
		$OKButton.Location = New-Object System.Drawing.Size(320,120)
		$OKButton.Size = New-Object System.Drawing.Size(75,23)
		$OKButton.Text = "OK"
		$OKButton.Add_Click({$objForm.Close()})
		$objForm.Controls.Add($OKButton)

		$CancelButton = New-Object System.Windows.Forms.Button
		$CancelButton.Location = New-Object System.Drawing.Size(395,120)
		$CancelButton.Size = New-Object System.Drawing.Size(75,23)
		$CancelButton.Text = "Cancel"
		$CancelButton.Add_Click({$objForm.Close()})
		$objForm.Controls.Add($CancelButton)

		$objLabel = New-Object System.Windows.Forms.Label
		$objLabel.Location = New-Object System.Drawing.Size(10,20) 
		$objLabel.Size = New-Object System.Drawing.Size(480,20) 
		$objLabel.Text = "Please check Computers or Collection to collect data from."
		$objForm.Controls.Add($objLabel) 

		$objTreeView = New-Object System.Windows.Forms.TreeView 
		$objTreeView.Location = New-Object System.Drawing.Size(10,40) 
		$objTreeView.Size = New-Object System.Drawing.Size(460,20) 
		$objTreeView.Height = 80
		$objTreeView.CheckBoxes = $True
	
		AddCBtoTreeView -objTreeView $objTreeView -ConnectionBroker $ConnectionBroker
	
		$objForm.Controls.Add($objTreeView) 
		$objForm.Topmost = $True
		$objForm.Add_Shown({$objForm.Activate()})
		[void] $objForm.ShowDialog()
		$objTreeView
	}

    Function IsRDPDDAccelerated
    {
		if((Get-Item HKLM:SYSTEM\CurrentControlSet\services\rdpdd -EA SilentlyContinue) -ne $null) #_# -EA
		{
			"IsRDPDDAccelerated () Found rdpdd " | WriteTo-StdOut
            foreach($key in Get-ChildItem HKLM:SYSTEM\CurrentControlSet\services\rdpdd)
	       {
                if($key.Name.Contains("Device"))
                {
				"IsRDPDDAccelerated () Found rdpdd\Device " | WriteTo-StdOut
					foreach($property in $key.Property)
					{
						if ($property.Contains("Acceleration.Level"))
                        {
						"IsRDPDDAccelerated () Found rdpdd\Device\Acceleration.Level " | WriteTo-StdOut
                        return $True
                        }
					}
				}
			}              
         }
      return $False
    }

# code for reg permisions checking  on the LICENSE keys
	Function CheckRegPerm
	{
		Param ( $RegPath, $Rights)
		 ((get-acl $RegPath).Access | where-object -Property IdentityReference -Like $Users| where-object -Property RegistryRights -Contains $Rights) -ne $null
	}

	Function IsRegPermIssue
	{
		$RegRights=[System.Security.AccessControl.RegistryRights]("SetValue, CreateSubKey, ReadKey")
		$RegDelRights = [System.Security.AccessControl.RegistryRights]("Delete")
		$Users = [System.Security.Principal.NTAccount]("BUILTIN\Users") 
		if((CheckRegPerm –RegPath "HKLM:\SOFTWARE\Microsoft\MSLicensing\Store"-Rights $RegRights) -eq $false)
		{return $true}

		if( $Licenses = (dir HKLM:\SOFTWARE\Microsoft\MSLicensing\Store).Name.Replace("HKEY_LOCAL_MACHINE", "HKLM:"))
		{
			[array]$Results = $null
			Foreach( $License in $Licenses){ [array]$Results+= CheckRegPerm –RegPath $License -Rights $RegDelRights}
			return $Results.Contains($false) -eq $true
    
		}
		$false
	}
