﻿trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

If (!$Is_SiteServer) {
	TraceOut "ConfigMgr Site Server not detected. This script gathers data only from a Site Server. Exiting."
	exit 0
}

TraceOut "Started"

Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "Configuration Manager Server Information"

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ServerInfo -Status $ScriptStrings.ID_SCCM_CM07ServerInfo_ServerInfo
TraceOut "    Getting Server Information"

# ----------------------
# Current Time:
# ----------------------
AddTo-CMServerSummary -Name "Current Time" -Value $CurrentTime

# -------------
# Computer Name
# -------------
AddTo-CMServerSummary -Name "Server Name" -Value $ComputerName

# ----------
# Site Code
# ----------
$Temp = Get-RegValueWithError ($Reg_SMS + "\Identification") "Site Code"
AddTo-CMServerSummary -Name "Site Code" -Value $Temp

# ----------
# Site Code
# ----------
$Temp = Get-RegValueWithError ($Reg_SMS + "\Identification") "Parent Site Code"
AddTo-CMServerSummary -Name "Parent Site Code" -Value $Temp

# ----------
# Site Type
# ----------
# $SiteType = Get-RegValueWithError ($Reg_SMS + "\Setup") "Type"
If ($SiteType -eq 8) {
	AddTo-CMServerSummary -Name "Site Type" -Value "Central Administration Site" }
ElseIf ($SiteType -eq 1) {
	AddTo-CMServerSummary -Name "Site Type" -Value "Primary Site" }
ElseIf ($SiteType -eq 2) {
	AddTo-CMServerSummary -Name "Site Type" -Value "Secondary Site" }
else {
	AddTo-CMServerSummary -Name "Site Type" -Value $SiteType
}

# -------------
# Site Version
# -------------
$Temp = Get-RegValueWithError ($Reg_SMS + "\Setup") "Full Version"
AddTo-CMServerSummary -Name "Site Version" -Value $Temp

# ----------------
# Monthly Version
# ----------------
if ($global:SiteType -eq 2) {
	AddTo-CMServerSummary -Name "MonthlyReleaseVersion" -Value "Not Available on a Secondary Site"
}
else {
	$Temp = Get-WmiObject -Computer $SMSProviderServer -Namespace $SMSProviderNamespace -Class SMS_Identification -ErrorAction SilentlyContinue
	If ($Temp -is [WMI]) {
		AddTo-CMServerSummary -Name "MonthlyReleaseVersion" -Value $Temp.MonthlyReleaseVersion }
	else {
		AddTo-CMServerSummary -Name "MonthlyReleaseVersion" -Value "Not Available" }
}

# -------------
# CU Level
# -------------
$Temp = Get-RegValueWithError ($Reg_SMS + "\Setup") "CULevel"
AddTo-CMServerSummary -Name "CU Level" -Value $Temp

# -------------
# ADK Version
# -------------
$global:ADKVersion = Get-ADKVersion
AddTo-CMServerSummary -Name "ADK Version" -Value $global:ADKVersion

# ----------------------------------------------------------
# Installation Directory - defined in utils_ConfigMgr12.ps1
# ----------------------------------------------------------
If ($SMSInstallDir -ne $null) {
	AddTo-CMServerSummary -Name "Installation Directory" -Value $SMSInstallDir }
else {
	AddTo-CMServerSummary -Name "Installation Directory" -Value "Error obtaining value from Registry" }

# -----------------
# Provider Location
# -----------------
if ($global:SiteType -eq 2) {
	AddTo-CMServerSummary -Name "Provider Location" -Value "Not available on a Secondary Site"
}
else {
	If ($global:SMSProviderServer -ne $null) {
		AddTo-CMServerSummary -Name "Provider Location" -Value $SMSProviderServer }
	else {
		AddTo-CMServerSummary -Name "Provider Location" -Value "Error obtaining value from Registry" }
}

# -----------
# SQL Server
# -----------
$Temp = Get-RegValue ($Reg_SMS + "\SQL Server\Site System SQL Account") "Server"
AddTo-CMDatabaseSummary -Name "SQL Server" -Value $Temp -NoToSummaryQueries

# --------------
# Database Name
# --------------
$Temp = Get-RegValueWithError ($Reg_SMS + "\SQL Server\Site System SQL Account") "Database Name"
AddTo-CMDatabaseSummary -Name "Database Name" -Value $Temp -NoToSummaryQueries

# ----------------
# SQL Ports
# ----------------
$Temp = Get-RegValueWithError ($Reg_SMS + "\SQL Server\Site System SQL Account") "Port"
AddTo-CMDatabaseSummary -Name "SQL Port" -Value $Temp -NoToSummaryQueries

$Temp = Get-RegValueWithError ($Reg_SMS + "\SQL Server\Site System SQL Account") "SSBPort"
AddTo-CMDatabaseSummary -Name "SSB Port" -Value $Temp -NoToSummaryQueries

# -----------------------
# SMSExec Service Status
# -----------------------
$Temp = Get-Service | Where-Object {$_.Name -eq 'SMS_Executive'} | Select-Object Status
If ($Temp -ne $null) {
	if ($Temp.Status -eq 'Running') {
		$Temp2 = Get-Process | Where-Object {$_.ProcessName -eq 'SMSExec'} | Select-Object StartTime
		AddTo-CMServerSummary -Name "SMS_Executive Status" -Value "Running. StartTime = $($Temp2.StartTime)"
	}
	else {
		AddTo-CMServerSummary -Name "SMS_Executive Status" -Value $Temp.Status
	}
}
Else {
	AddTo-CMServerSummary -Name "SMS_Executive Status" -Value "ERROR: Service Not found"
}

# -----------------------
# SiteComp Service Status
# -----------------------
$Temp = Get-Service | Where-Object {$_.Name -eq 'SMS_SITE_COMPONENT_MANAGER'} | Select-Object Status
If ($Temp -ne $null) {
	if ($Temp.Status -eq 'Running') {
		$Temp2 = Get-Process | Where-Object {$_.ProcessName -eq 'SiteComp'} | Select-Object StartTime
		AddTo-CMServerSummary -Name "SiteComp Status" -Value "Running. StartTime = $($Temp2.StartTime)"
	}
	else {
		AddTo-CMServerSummary -Name "SiteComp Status" -Value $Temp.Status
	}
}
Else {
	AddTo-CMServerSummary -Name "SiteComp Status" -Value "ERROR: Service Not found"
}

# ----------------------
# SMSExec Thread States
# ----------------------
$TempFileName = $ComputerName + "_CMServer_SMSExecThreads.TXT"
$OutputFile = join-path $Env:windir ("TEMP\" + $TempFileName)
Get-ItemProperty HKLM:\Software\Microsoft\SMS\Components\SMS_Executive\Threads\* -ErrorAction SilentlyContinue -ErrorVariable DirError `
	| Select-Object PSChildName, 'Current State', 'Startup Type', 'Requested Operation', DLL `
	| Sort @{Expression='Current State';Descending=$true}, @{Expression='PSChildName';Ascending=$true} `
	| Format-Table -AutoSize | Out-String -Width 200 | Out-File -FilePath $OutputFile
If ($DirError.Count -eq 0) {
	CollectFiles -filesToCollect $OutputFile -fileDescription "SMSExec Thread States" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	AddTo-CMServerSummary -Name "SMSExec Thread States" -Value "Review $TempFileName" -NoToSummaryReport
	Remove-Item $OutputFile -Force
}
else {
	AddTo-CMServerSummary -Name "SMSExec Thread States" -Value ("ERROR: " + $DirError[0].Exception.Message) -NoToSummaryReport
	$DirError.Clear()
}

# -----------------
# SQL Server SPN's
# -----------------
#TraceOut "    Getting SQL SPNs"
#$TempFileName = ($ComputerName + "_CMServer_SQLSPN.TXT")
#$FileToCollect = join-path $pwd.Path $TempFileName
#$CmdToRun = ".\psexec.exe /accepteula -s $pwd\ldifde2K3x86.exe -f $FileToCollect -l serviceprincipalname -r `"(serviceprincipalname=MSSQLSvc/$ConfigMgrDBServer*)`" -p subtree"

#RunCmD -commandToRun $CmdToRun -collectFiles $false
#If (Test-Path $FileToCollect) {
#	If ((Get-Content $FileToCollect) -ne $null) {
#		If ((Get-Content $FileToCollect) -ne "") {
#			CollectFiles -filesToCollect $FileToCollect -fileDescription "SQL SPNs"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
#			AddTo-CMServerSummary -Name "SQL Server SPNs" -Value ("Review $TempFileName") -NoToSummaryReport
#		}
#		Else {
#			TraceOut "    No SPN's found. Output file was null."
#			# AddTo-CMServerSummary -Name "SQL Server SPNs" -Value ("Error. No SPNs found!") -NoToSummaryReport
#		}
#	}
#	Else {
#		TraceOut "    No SPN's found. Output file was empty."
#		# AddTo-CMServerSummary -Name "SQL Server SPNs" -Value ("Error. No SPNs found!") -NoToSummaryReport
#	}
#}
#Else {
#	TraceOut "    No SPN's found. Output file was not found."
#	AddTo-CMServerSummary -Name "SQL Server SPNs" -Value ("Error. SPN Query Failed!") -NoToSummaryReport
#}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ServerInfo -Status $ScriptStrings.ID_SCCM_CM07ServerInfo_Hierarchy
TraceOut "    Getting Site Hierarchy"

# ------------------
# Hierarchy Details
# ------------------
$TempFileName = $ComputerName + "_CMServer_Hierarchy.TXT"
$OutputFile = join-path $Env:windir ("TEMP\" + $TempFileName)
$CommandLineToExecute = $Env:windir + "\system32\cscript.exe GetCM12Hierarchy.VBS"

If (($RemoteStatus -eq 0) -or ($RemoteStatus -eq 1)) {
	# Local Execution
	If ($global:DatabaseConnectionError -eq $null) {
		RunCmD -commandToRun $CommandLineToExecute -sectionDescription $sectiondescription -filesToCollect $OutputFile -fileDescription "Hierarchy Details" -noFileExtensionsOnDescription
		AddTo-CMServerSummary -Name "Hierarchy Details" -Value ("Review $TempFileName") -NoToSummaryReport
		Remove-Item $OutputFile -Force
	}
	Else {
		AddTo-CMServerSummary -Name "Hierarchy Details" -Value $DatabaseConnectionError -NoToSummaryReport
	}
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ServerInfo -Status $ScriptStrings.ID_SCCM_CM07ServerInfo_FileVer
TraceOut "    Getting File Versions"

# ---------------------
# Binary Versions List
# ---------------------
$TempFileName = ($ComputerName + "_CMServer_FileVersions.TXT")
$OutputFile = join-path $pwd.path $TempFileName
Get-ChildItem ($SMSInstallDir + "\bin") -recurse -include *.dll,*.exe -ErrorVariable DirError -ErrorAction SilentlyContinue | `
	ForEach-Object {[System.Diagnostics.FileVersionInfo]::GetVersionInfo($_)} | `
	Select-Object FileName, FileVersion, ProductVersion | Format-Table -AutoSize | `
	Out-File $OutputFile -Width 1000
If ($DirError.Count -eq 0) {
	CollectFiles -filesToCollect $OutputFile -fileDescription "Server File Versions" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	AddTo-CMServerSummary -Name "File Versions" -Value ("Review $TempFileName") -NoToSummaryReport
}
else {
	AddTo-CMServerSummary -Name "File Versions" -Value ("ERROR: " + $DirError[0].Exception.Message) -NoToSummaryReport
	$DirError.Clear()
}

# --------------------
# RCM Inbox File List
# --------------------
TraceOut "    Getting File List for RCM.box"
$TempFileName = ($ComputerName + "_CMServer_RCMFileList.TXT")
$OutputFile = join-path $pwd.path $TempFileName
Get-ChildItem ($SMSInstallDir + "\inboxes\RCM.box") -Recurse -ErrorVariable DirError -ErrorAction SilentlyContinue | `
	Select-Object CreationTime, LastAccessTime, FullName, Length, Mode | Sort-Object FullName | Format-Table -AutoSize | `
	Out-File $OutputFile -Width 1000
If ($DirError.Count -eq 0) {
	AddTo-CMServerSummary -Name "RCM.box File List" -Value ("Review $TempFileName") -NoToSummaryReport
	CollectFiles -filesToCollect $OutputFile -fileDescription "RCM.box File List" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
}
else {
	AddTo-CMServerSummary -Name "RCM.box File List" -Value ("ERROR: " + $DirError[0].Exception.Message) -NoToSummaryReport
	$DirError.Clear()
}

# Server Info File is collected in DC_CM12SQLInfo.ps1. Need to make sure this script runs before that.
# $ServerInfo | Out-File $ServerInfoFile -Append -Width 200

TraceOut "Completed"
# SIG # Begin signature block
# MIIa6wYJKoZIhvcNAQcCoIIa3DCCGtgCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUC0x+od9lqAc644Zlnhr8HKWP
# AlWgghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTSMIIE
# zgIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHrMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBRC
# GXDLHbI98sNT+PWtVI4OoGEnUzCBigYKKwYBBAGCNwIBDDF8MHqgYIBeAEQASQBB
# AEcAXwBDAFQAUwBfAFMAQwBDAE0AXwAyADAAMQAyAF8AZwBsAG8AYgBhAGwAXwBE
# AEMAXwBDAE0AMQAyAFMAZQByAHYAZQByAEkAbgBmAG8ALgBwAHMAMaEWgBRodHRw
# Oi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQAwHks/2k2g1XbbMjEl
# wf2pWTa//1sEjXiIr25NvAXrO3cItlB0hhYS+B4Mf7fQdBhhYRXbGGF7WtptIzr4
# LraSgwRMyOzlvwvWHsNjYwlbhIsMM1i14vOImJWegUPk5eqpOiWbxjmRzZ/UlxmT
# RXXV8jdCypI56U2vD4IVwpNz9bTXKECLS2sBCH1cvtcDScsPVjRNRQxkcdzHC9y2
# tOPi25E1s80jqQPHf+ojM+zECrc4ylZ5LwAPt4BrYzJ/4uJyheKv9B5dJbctL2sC
# 1sZaolNPYs0/Jud01reteqbkRPxb7t541TIMRc07QcIhcqdyhuexgh2RA/9RlEIX
# ad2NoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQQITMwAAAMZ4gDYBdRppcgAAAAAAxjAJBgUrDgMCGgUAoF0w
# GAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcwNDI3
# MTQyMzMzWjAjBgkqhkiG9w0BCQQxFgQUWzOIiPXSTO/IBIwFZnzRE2Yhwf0wDQYJ
# KoZIhvcNAQEFBQAEggEAMuo8Ak1brZH3xPJsn0S+2IFrVwqFfXL3Oa4yc9M1nPfe
# QE00gNVLY4MVctUNfBVAR7FMiBZYJwj/QS7VbNH7nrz7q/8ocn6Ry2ck/+wfuXlG
# aJ5bbdkiXfQMNXRoIlMzzoDYu3GmmzsQ5lT0+dJOdQl76TauValuMnsD9U6nv6Nj
# uB2k/2G8jSm9dtSyXmbOVZ9t3UkarxUevx3G4Ge4aXXQ1Y9A8nvJHakCIC7TOGYT
# POwDH3yI7h5IF1/HWdze8SMXODhfpKjYXXtn1FopEjxTLX4w4A9JyssJSR5tOp82
# QjW9wQCJDHauGS5P/uxRESQ4syBOe0S0YBI6uqAFMQ==
# SIG # End signature block
