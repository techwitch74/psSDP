#************************************************
# GetDPMInfo.ps1
# Version 2.0.0
# Date: 09-27-2011
# Author: Patrick Lewis - patlewis@microsoft.com
# Description: This script gathers info on the DPM server
#************************************************

####################################################################################
# Check to be see if DPM is installed
####################################################################################
function IsDPMInstalled
{
	$IsDPMInstalled = $false
	if (Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup")
	{
		$IsDPMInstalled =(get-itemproperty "HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\Setup").InstallPath 
		if(!([string]::IsNullOrEmpty($IsDPMInstalled)))
		{
			$IsDPMInstalled = $true
		}
	}
	return $IsDPMInstalled
}

####################################################################################
# Check to be sure the DPM namespace is loaded, if not then load it
####################################################################################
function LoadDPMNamespace ()
{	
	$DPMFolder = GetDPMInstallFolder	
	$DPMVersion = DPMVersion ($DPMFolder)
	Switch ($DPMVersion)
	{	
		2	{
				if (!(get-PSSnapin | ? { $_.name -eq 'Microsoft.DataProtectionManager.PowerShell'}))
				{
					Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell
				}
			}
		3	{
				if (!(get-PSSnapin | ? { $_.name -eq 'Microsoft.DataProtectionManager.PowerShell'}))
				{
					Add-PSSnapin -name Microsoft.DataProtectionManager.PowerShell
				}
			}
		4	{
				Import-Module -name dataprotectionmanager
			}
	}
} 

####################################################################################
# Check the command line arguments passed in
####################################################################################
function GetDPMServerName()
{
	if(!$args[0])
	{
		if(!$DPMServerName)
		{
			$DPMServerName = $Env:COMPUTERNAME
		}
	}
  
	$DPMServerName = $DPMServerName.Trim(" ")
	return $DPMServerName
}
####################################################################################
# PrintInfo
####################################################################################
function PrintInfo([string]$ServerName)
{
	"**************************************************" | out-file $OutputBase 
	"*          DPM Server Report Version 1.0         *" | out-file $OutputBase -Append
	"**************************************************" | out-file $OutputBase -Append

	$Server = Get-CimInstance win32_operatingsystem
	$ds = Connect-DPMServer -DPMServerName $ServerName
   
	if (!$ds) 
	{
		"Unable to connect to DPM Server or service not running on: " + $ServerName | Out-File $OutputBase -Append
		$error[-1]                                                                  | Out-File $OutputBase -Append
		whoami                                                                      | Out-File $OutputBase -Append
		return
	}

	$dpmVersion = $ds.GetProductInformation().ProductName
	$Serverobj = New-Object PSObject
	$Serverobj | Add-Member NoteProperty -name "DPM Server" -value $ServerName
	$Serverobj | Add-Member NoteProperty -name "OS Version" -value $Server.Caption
	$Serverobj | Add-Member NoteProperty -name "Architecture" -value $Server.OSArchitecture
	$Serverobj | Add-Member NoteProperty -name "SP Level" -value $Server.ServicePackMajorVersion
	## TODO: Add entry for Total memory
	## TODO: Add pagefile size 1.5* Total memory
	$Serverobj | Add-Member NoteProperty -name "Available Memory" -value $Server.FreePhysicalMemory
	$Serverobj | Add-Member NoteProperty -name "DPM Version" -value $dpmVersion
	$Serverobj | Add-Member NoteProperty -name "DPM Build" -value $ds.GetProductInformation().Version.ToString()

	$Serverobj | Out-File $OutputBase -append

	#Now that we have a valid connect let's get the disk information for the dpmServer
	[System.Array]$dpmDisk = Get-DPMDisk $ServerName 

	#Gather tape library info
	$dpmLibrary = Get-DPMLibrary -DPMServerName $ServerName

	#Build list of datasources and protection groups
	$dpmPG = Get-ProtectionGroup -DPMServerName $ServerName
	
	"**************************************************" | Out-File $OutputBase -append
	"*          STORAGE POOL DISK INFORMATION         *" | Out-File $OutputBase -append
	"**************************************************" | Out-File $OutputBase -append
	$dpmDisk | Format-List | Out-File $OutputBase -append

	"**************************************************" | Out-File $OutputBase -append
	"*          TAPE LIBRARY INFORMATION              *" | Out-File $OutputBase -append
	"**************************************************" | Out-File $OutputBase -append
	# We have to check to be sure a tape library is present...
	if ($dpmLibrary)
	{   
		$dpmLibrary | Format-List |  Out-File $OutputBase -append
		"**************************************************" | Out-File $OutputBase -append
		"*          TAPE DRIVE INFORMATION                *" | Out-File $OutputBase -append
		"**************************************************" | Out-File $OutputBase -append
		$TDobj = New-Object PSObject
			foreach ($TapeLib in $dpmLibrary)
			{
				$TDobj | Add-Member NoteProperty -Force -name "Name" -value $TapeLib.UserFriendlyName
				$TDobj | Add-Member NoteProperty -Force -name "Product ID" -value $TapeLib.ProductId
				$TDobj | Add-Member NoteProperty -Force -name "Serial #" -value $TapeLib.SerialNumber
				$TDobj | Add-Member NoteProperty -Force -name "Tape Drive Enabled?" -value $TapeLib.IsEnabled
				$TDobj | Add-Member NoteProperty -Force -name "Tape Drive offline?" -value $TapeLib.IsOffline
				$TDobj | Out-File $OutputBase -append
			}
	} else {
		"WARNING: NO TAPE LIBRARIES FOUND" | Out-File $OutputBase -append
	}

	"**************************************************" | Out-File $OutputBase -append
	"*          PROTECTION GROUPS                     *" | Out-File $OutputBase -append
	"**************************************************" | Out-File $OutputBase -append
    ""                                                   | Out-File $OutputBase -append

	if ($dpmPG)
	{
#-------------------------------------------------- NEW CHANGE START -------------------
		add-pssnapin sqlservercmdletsnapin100 -ErrorAction SilentlyContinue
		Push-Location; Import-Module SQLPS -ErrorAction SilentlyContinue ; Pop-Location

        function recovery ($Datasource)
        {
            $RPList = @(Get-RecoveryPoint $Datasource)
            if ($RPList.count -gt 0)
            {
                "             Backup Time              Location   Generation" | Out-File $OutputBase -append
                "             ----------------------   --------   ----------" | Out-File $OutputBase -append
                foreach ($RP in $RPList)
                {
                    ("             {0,22}   {1,8}   {2}" -f $rp.BackupTime, $RP.Location, $RP.RecoverySourceLocations.generation) | Out-File $OutputBase -append
                }     
            }
            else
            {
                "             No recovery point found for this datasource" | Out-File $OutputBase -append
            }
        }

        # Get DPM server FQDN and DPM Database
        $DPMServerConnection = (Connect-DPMServer (&hostname))
        $DPMServer = $DPMServerConnection.name

        # Find out where DPMDB is located for he local DPM Server
        $DPMDB = $dpmserverconnection.dpmdatabaselogicalpath.substring($dpmserverconnection.DPMDatabaseLogicalPath.LastIndexOf('\') + 1,$dpmserverconnection.DPMDatabaseLogicalPath.Length - $dpmserverconnection.DPMDatabaseLogicalPath.LastIndexOf('\') -1 )
        $DPM   = $dpmserverconnection.dpmdatabaselogicalpath.substring(0,$dpmserverconnection.DPMDatabaseLogicalPath.LastIndexOf('\'))

        $DPMMajorVersion = (dir ((get-itemProperty "HKLM:\SOFTWARE\Microsoft\Microsoft Data Protection Manager\setup\").installpath + "bin\msdpm.exe")).VersionInfo.fileversion.split('.')[0]
        
        $PGList = @(Get-ProtectionGroup (&hostname) | Sort-Object name)
        foreach ($pg in $PGList)
        {
            if ($DPMMajorVersion -eq '3') # DPM 2010
            {
               "Protection Group............: " + $pg.friendlyname | out-file $OutputBase -append
            }
            else
            {
              "Protection Group............: " + $pg.name             | out-file $OutputBase -append
              "Protection Method...........: " + $pg.ProtectionMethod | out-file $OutputBase -append
              if ($pg.IsDiskShortTerm)
              {
                    "Short-Term Disk Backup time.: " + (Get-DPMPolicySchedule -ProtectionGroup $PG -ShortTerm).ScheduleDescription | out-file $OutputBase -append
                    "Short-Term Disk Retention...: " + (Get-DPMPolicyObjective -ProtectionGroup $pg -ShortTerm).retentionrange.range + " " + (Get-DPMPolicyObjective -ProtectionGroup $pg -ShortTerm).retentionrange.unit | out-file $OutputBase -append
              }
              if ($pg.IsTapeShortTerm)
              {
                    "Short-Term Tape Backup time.: " + (Get-DPMPolicySchedule -ProtectionGroup $PG -ShortTerm).ScheduleDescription | out-file $OutputBase -append
                    "Short-Term Tape Retention...: " + $pg.ArchiveIntent.RetentionPolicy.OnsiteFather.ToString() | out-file $OutputBase -append
            }
              if ($pg.IsTapeLongTerm)
              {
                    "Long-Term Backup time Goal 1: " + @((Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm Tape) | sort-object jobtype -Descending)[0].ScheduleDescription  | out-file $OutputBase -append
                    "Long_term Retention Goal 1..: " + $pg.ArchiveIntent.RetentionPolicy.OffsiteFather.ToString() | out-file $OutputBase -append
                    if ($pg.ArchiveIntent.RetentionPolicy.OffsiteGrandfather.Enabled)
                    {
                        "Long-Term Backup time Goal 2: " + @((Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm Tape) | sort-object jobtype -Descending)[1].ScheduleDescription | out-file $OutputBase -append
                        "Long_term Retention Goal 2..: " + $pg.ArchiveIntent.RetentionPolicy.OffsiteGrandfather.ToString() | out-file $OutputBase -append
                        if ($pg.ArchiveIntent.RetentionPolicy.OffsiteGreatGrandfather.Enabled)
                        {
                            "Long-Term Backup time Goal 3: " + @((Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm Tape) | sort-object jobtype -Descending)[2].ScheduleDescription | out-file $OutputBase -append
                            "Long_term Retention Goal 3..: " + $pg.ArchiveIntent.RetentionPolicy.OffsiteGreatGrandfather.ToString() | out-file $OutputBase -append
                        }
                    }
              }
              if ($pg.IsCloudLongTerm)
            {
                    "Online Backup time..........: " + (Get-DPMPolicySchedule -ProtectionGroup $pg -LongTerm online).scheduledescription | out-file $OutputBase -append
                    if ((Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeDaily.range)
                    {
                        "Daily Retention Range.......: " + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeDaily.range + " "  + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeDaily.unit | out-file $OutputBase -append
                    }
                    if ((Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeWeekly.range)
                    {
                        "Weekly Retention Range......: " + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeWeekly.range + " "  + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeWeekly.unit | out-file $OutputBase -append
                    }
                    if ((Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeMonthly.range)
                    {
                        "Monthly Retention Range.....: " + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeMonthly.range + " "  + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeMonthly.unit | out-file $OutputBase -append
                    }
                    if ((Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeYearly.range)
                    {
                        "Yearly Retention Range......: " + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeYearly.range + " "  + (Get-DPMPolicyObjective $PG -LongTerm Online).RetentionRangeYearly.unit | out-file $OutputBase -append
                    }
              }

              "Performance Optimization....: " + $pg.PerformanceSettings | out-file $OutputBase -append
            }
            $DSList = @(Get-Datasource $pg | Sort-Object ProductionServerName, name)
            $ComputerName = $DSList[0].ProductionServerName
            "   Computer: " + $ComputerName | out-file $OutputBase -append
            foreach ($DS in $DSList)
            {
                if ($ds.ProductionServerName -ne $ComputerName)
                {
                    $ComputerName = $DS.ProductionServerName
                    "   Computer: " + $ComputerName | out-file $OutputBase -append
                }
                ("       type: {0,-20} - Datasource Name: {1}" -f $ds.ObjectType, $ds.DisplayPath ) 
                ("       type: {0,-20} - Datasource Name: {1}" -f $ds.ObjectType, $ds.DisplayPath ) | out-file $OutputBase -append
        	    if ($DPMMajorVersion -eq '3') # DPM 2010
                {
                   $ObjectType = $ds.type.name
                }
                else
                {
                   $ObjectType = $ds.ObjectType
                }

                switch ($ObjectType)
                {
                    'System Protection' {   $query = "select ComponentName 
                                                      from tbl_IM_ProtectedObject 
                                                      where ProtectedInPlan = 1 and 
	                                                  (ComponentName like 'Bare Metal Recovery' or ComponentName like 'System State') and 
	                                                  DataSourceId like '"+ $ds.DatasourceId + "'"
                                            $DSTypeList = @(Invoke-Sqlcmd -ServerInstance $DPM -Database $DPMDB -Query $query)
                                            foreach ($DSType in $DSTypeList)
                                            {                                        
                                                "            " + $DSType.ComponentName | out-file $OutputBase -append
                                            }
                                        }
                    'SharePoint Farm'   {   $query = "select ComponentName 
                                                      from tbl_IM_ProtectedObject 
                                                      where ProtectedInPlan = 1 and
	                                                  ReferentialDataSourceId like '"+ $ds.DatasourceId + "' order by convert(varchar(max),LogicalPath)"
                                            $DSTypeList = @(Invoke-Sqlcmd -ServerInstance $DPM -Database $DPMDB -Query $query)
                                            foreach ($DSType in $DSTypeList)
                                            {                                        
                                                 "         " + $DSType.ComponentName | out-file $OutputBase -append
                                           }
                                        }
                    'Volume'            {   $query = "select LogicalPath
                                                      from tbl_IM_ProtectedObject 
                                                      where ProtectedInPlan = 1 and
	                                                  DataSourceId like '"+ $ds.DatasourceId + "' order by convert(varchar(max),LogicalPath)"
                                            $DSTypeList = @(Invoke-Sqlcmd -ServerInstance $DPM -Database $DPMDB -Query $query)
                                            Foreach ($DSType in $DSTypeList)
                                            {
                                                [xml]$xml = $DSType.LogicalPath
                                                $type = ($xml.ArrayOfInquiryPathEntryType.InquiryPathEntryType)[-1]
                                                if ($type.type -eq 'NonRootTargetShare')
                                                {
                                                    "             Share  - " +  $Type.value | out-file $OutputBase -append
                                                }
                                                else
                                                {
                                                    "             " + $type.type + " - " + $Type.value | out-file $OutputBase -append
                                                }
                                            }
                                        }
                }
            }
            "" | out-file $OutputBase -append
        }
#-------------------------------------------------- NEW CHANGE END   -------------------
<#
		$dpmPG | Format-List | Out-File $OutputBase -append
		"--------------------------------------------------" | Out-File $OutputBase -append
		"Shorterm Retention Range: " | Out-File $OutputBase -append
		$dpmPG.OnsiteRecoveryrange | fl | Out-File $OutputBase -append
		"--------------------------------------------------" | Out-File $OutputBase -append
		"Longterm Retention Range: " | Out-File $OutputBase -append
		$dpmPG.OffsiteRecoveryRange | fl | Out-File $OutputBase -append

		foreach ($pgName in $dpmPG)
		{
			"**************************************************" | Out-File $OutputBase -append
			"Protection Group: " + $pgName.FriendlyName | Out-File $OutputBase -append
			"**************************************************" | Out-File $OutputBase -append
			"--------------------------------------------------" | Out-File $OutputBase -append
			"*          DATA SOURCES SUMMARY                  *" | Out-File $OutputBase -append
			"--------------------------------------------------" | Out-File $OutputBase -append
			$dpmDS = Get-Datasource -ProtectionGroup $pgName
			$dpmDS | format-list -property ProductionServerName, Name | Out-File $OutputBase -append
 
			#Now go through each datasource and print additional info
			"--------------------------------------------------" | Out-File $OutputBase -append
			"*          DATA SOURCE DETAILS                   *" | Out-File $OutputBase -append
			"--------------------------------------------------" | Out-File $OutputBase -append
			#Setup an event since Get-DataSource is async
			$global:DSCount = 0
			$LoopCounter = 0
			foreach ($dsName in $dpmDS)
			{
				if ($dsName.TotalRecoveryPoints -eq 0) {
					Register-ObjectEvent -InputObject $dsName -EventName DatasourceChangedEvent -SourceIdentifier "EVENT$LoopCounter" -Action {$global:DSCount++} 
					$LoopCounter++
				} else {
					$global:DSCount++
				}
			}

			#trigger the event to signal
			$dpmDS.TotalRecoveryPoints > $null

			#Check to see if signaled yet
			if ($dpmDS.TotalRecoveryPoints -eq 0)
			{
				$begin = get-date
				$m = Measure-Command {
					while (((Get-Date).subtract($begin).seconds -lt 120) -and ($global:DSCount -ne 0))
					{
						sleep -Milliseconds 100
					}
				}
			}

			#Event has been signaled or we reached the 120 second timeout. Now update the datasources
			$dpmDS = Get-Datasource -ProtectionGroup $pgName
			$DSObj = New-Object PSObject

			foreach ($dsName in $dpmDS)
			{
				$DSobj | Add-Member NoteProperty -Force -name "Computer" -value $dsName.ProductionServerName
				$DSobj | Add-Member NoteProperty -Force -name "Datasource Name" -value $dsName.Name
				$DSobj | Add-Member NoteProperty -Force -name "Disk allocation" -value  $dsName.DiskAllocation
				$DSobj | Add-Member NoteProperty -Force -name "Total recovery points" -value $dsName.TotalRecoveryPoints

				if ($dsName.TotalRecoveryPoints -ne 0) 
				{
					$DSobj | Add-Member NoteProperty -Force -name "Latest recovery point" -value $dsName.LatestRecoveryPoint
					$DSobj | Add-Member NoteProperty -Force -name "Oldest recovery point" -value $dsName.OldestRecoveryPoint
				} else {
					if ($dsName.TotalRecoveryPoints -eq 0)
					{
						$DSobj | Add-Member NoteProperty -Force -name "Latest recovery point" -value "NO VALID RECOVERY POINTS"
						$DSobj | Add-Member NoteProperty -Force -name "Oldest recovery point" -value "NO VALID RECOVERY POINTS"
					} else {
						$DSobj | Add-Member NoteProperty -Force -name "Latest recovery point" -value $dsName.LatestRecoveryPoint
						$DSobj | Add-Member NoteProperty -Force -name "Oldest recovery point" -value $dsName.OldestRecoveryPoint
					}
				}
			}
			# Unregister-Event *
			$DSObj | Out-File $OutputBase -append

			#Now add longterm backup info

			"--------------------------------------------------" | Out-File $OutputBase -append
			"*              LONG TERM - TAPE                  *" | Out-File $OutputBase -append
			"--------------------------------------------------" | Out-File $OutputBase -append
			switch ($dpmversion)
			{
				"Microsoft System Center Data Protection Manager 2010" {
					$policySchedule = @(Get-PolicySchedule -ProtectionGroup $pgName -longterm tape)
					}
				default {
					"NOT TESTED ON THIS DPM VERSION" | Out-File $OutputBase -append
					 }
			}

			$tb = Get-TapeBackupOption $pgName;$tb.labelinfo
			$label = @($tb.label);
			$count = $policySchedule.count -1
			while ($count -ne -1)
			{
				if ($label[$count].length -eq 0 -or $label[$count].length -eq $null)
				{ 
					"Default Label Name" | Out-File $OutputBase -append
				}
				else
				{
					"Tape Label: " + $label[$count] | Out-File $OutputBase -append
				}
				$policyschedule[$count] | fl * | Out-File $OutputBase -append
				$count--
			}
		}
		"--------------------------------------------------" | Out-File $OutputBase -append
		"* TAPES LOADED INTO SLOTS THAT ARE OFFLINE READY *" | Out-File $OutputBase -append
		"--------------------------------------------------" | Out-File $OutputBase -append
		$count = 0
		$dpmLibrary = @($dpmlibrary | ? { $_.Isoffline -eq $false })
		if ($dpmlibrary)
		{
			foreach ($library in $dpmlibrary)
			{
				$tapelist = get-tape $library
				foreach ($tape in $tapelist)
				{
					if ($tape.IsOffsiteReady -eq $true)
					{
						("{0,-30} | {1,-9} | {2,-25} | {3,-50}" -f $tape.libraryname, $tape.location, $tape.barcode, $tape.Label) | Out-File $OutputBase -append
						$count++
					}
				}
			}
			if ($count -eq 0)
			{
				"No Tapes are marked as offsite ready"  | Out-File $OutputBase -append
			}
		}
		else
		{
			"No online library was found on this system"  | Out-File $OutputBase -append
		}
	}
#>  
}
else {
		"WARNING: NO PROTECTION GROUPS FOUND" | Out-File $OutputBase -append
	}

	return
}

####################################################################################
# Main
####################################################################################
Import-LocalizedData -BindingVariable LocalizedGetDPMInfo -FileName DC_GetDPMInfo -UICulture en-us

Write-DiagProgress -Activity $LocalizedGetDPMInfo.ID_DPM_ACTIVITY -Status $LocalizedGetDPMInfo.ID_DPM_STATUS_GetDPMInfo

# Check first to be sure DPM is installed otherwise exit
if (IsDPMInstalled)
{
	$LocalizedGetDPMInfo.ID_DPM_INSTALLED | ConvertTo-Xml | Update-DiagReport -Id $LocalizedGetDPMInfo.ID_DPM_INFO -Name $LocalizedGetDPMInfo.ID_DPM_INFORMATION
} else {
	$LocalizedGetDPMInfo.ID_DPM_NOT_INSTALLED | ConvertTo-Xml | Update-DiagReport -Id $LocalizedGetDPMInfo.ID_DPM_INFO -Name $LocalizedGetDPMInfo.ID_DPM_INFORMATION -verbosity "Warning"
	exit 1
}

$DPMVersion = DPMVersion (GetDPMInstallFolder)
if($DPMVersion -ne $null)
{
	$DPMServerName = GetDPMServerName
	$OutputBase= $DPMServerName + "_DPM_Info.txt"
	LoadDPMNamespace

	# Prints the info
	PrintInfo $DPMServerName

	Disconnect-DPMServer -DPMServer $DPMServername
	CollectFiles -filesToCollect $OutputBase -fileDescription $LocalizedGetDPMInfo.ID_DPM_SETTINGS -sectionDescription $LocalizedGetDPMInfo.ID_DPM_INFORMATION

	exit 0
}
else
{
	"Script DC_GetDPMInfo.ps1 running on a Protected Server, no data will be collected" | WriteTo-StdOut -ShortFormat
}

# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAhCWdm7zs3oQc8
# xeZ1jI2bT6lZ5/vX9/kxB+CUWQJO1qCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgVlQsN5gc
# ilFlAHSpgCtDKeBYdhLJACrBlsLD7M4qhiswOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBABk462rmfm9CrLvRMdpN4ebo5k0Hl2KxhPGS1dJ+ocQZRezgqwIbyuIl
# yftXpkWqHzMOzzxPml0tPp7ma50u+WPporKtIBVZfmex+0HwYpnxboNwwj+0FJQd
# /k6JlS8zAlmDj1yhxmEFIwOuzJbBCixxmvEzHbjvuhqPtvT6cCb8Eh6/5+/Nfm6A
# odpHOeixQ8uGKeyjvK+PTsKnqqeXau1z0gYbKBWDOUJQaTweiyN5IeYurfp7m+aO
# sZKNQkoTLVQHwljpbibc89kxPy2NqOfEGXY8SfJCrC45GRKKlVgCrRb37lJMPYmh
# LuYlkmD3mywvqlzf3ksP+BZXF/AHR5KhghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgUQ1v9xPnPvJnnVOwQYDTiY/aZhTa268fblhfs+/90ZACBmGB++Yl
# YRgTMjAyMTExMTExNjUzMzYuMTc5WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjg5
# N0EtRTM1Ni0xNzAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFgByDwkkjavusAAAAAAWAwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjIwWhcNMjIwNDExMTkwMjIwWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjg5N0EtRTM1Ni0xNzAx
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtDGAHNDyxszxUjM+CY31NaRazaTxLUJl
# TI3nxIvMtbfXnytln87iXrwZvhKQT+IFRKTjJV6wEo5WidssvecDAheaxiGfkFHR
# Fc8j1cuLPNWqyVSAc/NM9G0y1m76O3KAKmHkx+q4GJr9KnQeOPuUQOs0dH8L/X/E
# JpnJCmAhHuUBEkhpFWHnL5apuqZtSwUigXlQfDDMkUmk5fFi0DS5a6toql0JTMDO
# HrCQpmAyRGtc/cT/DlyzhTtxiJiNlEaWbcav68mCTJOwpbc4GJO2Rpb96O2lb5Lq
# m7817NcWoDPC5ION4giY454Rq+UD071WkJ7GjXPpUKmnQRvf3Ti6EwIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFKebHvi3qBfgmuF1Mgl1fNDrvh9jMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBABU0mAibOgWmiVB1Tydh1xfvJKUoQ/fn2qDlD9IWnt7i
# Pl0DVX6Sy+Yp1kHWOGOwGzYiY04i3I1ja7Y3CNrgk3EV/7bL8pNw/wYT3sfyiCv1
# z5VvW4cXuC2d7cXy+e/QJvv0riZuGLpLRAiGo9wjxzfpSp4/AowubfYn6873C4pb
# Y0ry/1sDmBC73YCPq5/sAYC41gciHSJmiT5ty4mlg8opjWe9LYRrWDOYXwn+Ks9j
# gxby/j+Bp6Qmix+RzqBuiZrjDWAUMYqAqG/u2VPX7ne4cZHZNLWoxh43AZ8a2OJP
# FDUGVARmJuTs8V8J74pGFNFMJG3NadKDc0QTTLaoudQwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjg5N0EtRTM1Ni0x
# NzAxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQD7MpJ0dYtE3MiXKodXFdmAqdnQoqCBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5Teu0zAiGA8y
# MDIxMTExMTE5MDEzOVoYDzIwMjExMTEyMTkwMTM5WjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN67TAgEAMAoCAQACAiSoAgH/MAcCAQACAhF3MAoCBQDlOQBTAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAfYkTPHXSlglA8KZNnZFdrFPK4gJe
# Qcne7X2mCetvtwVWfnDvugAxeyoT2Lrctm+IWuYTcvqj9fKoBLVNKNBcjCtwSTY0
# dcvVi2RFSi4+jrl6tTbJG720B+3HU055iDzbS1z+/HdFFCNuRUaUhKKWkfujYbp9
# hIsAf5sRNadSC7UxggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAWAHIPCSSNq+6wAAAAABYDANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDvYFOl
# Dk8fpKduoiwapuCHBWsPUHEXPDdYjg7oiwH6SzCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIAISo72jcy6XW0Wnrx7qK8p+ldL/j1wXCeJeSPeosGW5MIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFgByDwkkjavusA
# AAAAAWAwIgQg//lvRRYAzeFQS4o0SMpCvFYIOJJBoNBV+JxjN1IgCOUwDQYJKoZI
# hvcNAQELBQAEggEAb6g3zFxY77iRZX0MLewmsvlJiEMWXR6lvnsxolpFvashfkpq
# AtTnmdAUhXJNlMDC5Y/hBMjqHeJHE3RegXvkkPiY5cqavaAxEXNUs9sMR0WOD5iE
# tLYGGy4UsqrF9VXXMxfTmA9nUlJ114iYo07vzZsOu/yC8G53/fs82abgyDV9eicz
# z1lwP5geg7W686b8vTy9HSi5uyhxYnHG+7VENuf/rDkuZbZ2lcfSb8GpURhvVJIh
# pDdq1QvD94Df/Nj3FY1i4pTH8xaWbXqQPLDA0vcWbDBO4VUuz5KNBU446y4IAPtw
# zY8YHxZa6HM4uKchOUFDeB6mCvYW2e/MFlxBQg==
# SIG # End signature block
