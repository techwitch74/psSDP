﻿# *****************************************************************************************
# Version 1.0
# Date: 06-12-2013, 2021
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects Windows Logs
#
# *****************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

TraceOut "Started"

Import-LocalizedData -BindingVariable ScriptStrings

If ($ManifestName -eq "WSUS") {
	$sectionDescription = "Windows Logs"
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectWindowsLogs -Status $ScriptStrings.ID_SCCM_Windows_OSD_CollectConfigMgrLogs
}
else {
	$sectionDescription = "Configuration Manager Logs"
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Windows_OSD_CollectConfigMgrLogs
}

# --------------
# Getting Ready
# --------------

$Destination = Join-Path $Pwd.Path ($ComputerName + "_Logs_Windows+OSD")
$ZipName = "Logs_Windows+OSD.zip"
$fileDescription = "Windows & OSD Logs"

# Remove temp destination directory if it exists
If (Test-Path $Destination) {
	Remove-Item -Path $Destination -Recurse
}

################
# WINDOWS LOGS #
################

# --------------------
#  Windows\Temp logs
# --------------------
$TempLogPath = Join-Path $Env:windir "Temp"
$TempDestination = Join-Path $Destination "Temp_Logs"
# New-Item -ItemType "Directory" $TempDestination
Copy-FilesWithStructure -Source $TempLogPath -Destination $TempDestination -Include *.lo*

# ----------------
# User Temp Logs
# ----------------
$TempLogPath = (Get-Item $env:temp).FullName
$TempDestination = Join-Path $Destination ("Temp_Logs_User_" + "$env:username")
Copy-FilesWithStructure -Source $TempLogPath -Destination $TempDestination -Include *.lo*

# ----------------------------
# Windows Update ETL Traces (Win 10)
# Cannot use Get-WindowsUpdateLog because it presents a prompt to accept Terms for Public Symbol Server and there doesn't appear to be a way to skip the prompt, which is absolutely stupid
# and prevents use of this CmdLet for automation. https://connect.microsoft.com/PowerShell/Feedback/Details/1690411
# ----------------------------
$TempLogPath = Join-Path $Env:windir "Logs\WindowsUpdate"
$TempDestination = Join-Path $Destination "WindowsUpdate_ETL"
Copy-FilesWithStructure -Source $TempLogPath -Destination $TempDestination -Include *.etl

# Verbose WindowsUpdate ETL Log
Copy-Files -Source $env:SystemDrive -Destination $TempDestination -Filter WindowsUpdateVerbose.etl

# -------------------------------
# Setup Clean Task Logs (Win 10)
# -------------------------------
$TempLogPath = Join-Path $Env:windir "Logs\SetupCleanupTask"
$TempDestination = Join-Path $Destination "SetupCleanupTask_Logs"
Copy-FilesWithStructure -Source $TempLogPath -Destination $TempDestination -Include *.xml, *log

# ---------
# CBS Log
# ---------
$TempLogPath = Join-Path $Env:windir "Logs\CBS"
$TempDestination = Join-Path $Destination "CBS_Logs"
Copy-FilesWithStructure -Source $TempLogPath -Destination $TempDestination -Include CBS.log, *.cab

# --------------------------
# WindowsUpdate.log (AGAIN!)
# --------------------------
$TempLogPath = Join-Path $Env:windir "SoftwareDistribution"
Copy-Files -Source $TempLogPath -Destination $Destination -Filter ReportingEvents.log
Copy-Files -Source $Env:windir -Destination $Destination -Filter WindowsUpdate.log

############
# OSD LOGS #
############

# ------------
# SMSTS Logs
# ------------
$SMSTSLocation1 = if ($CCMLogPath -ne $null) { $CCMLogPath } else { Join-Path $Env:windir "CCM\Logs" }
$SMSTSLocation2 = $SMSTSLocation1 + "\SMSTSLog"
$SMSTSLocation3 = Join-Path $env:SystemDrive "_SMSTaskSequence"
$SMSTSLocation4 = Join-Path $env:SystemDrive "SMSTSLog"
$SMSTSLocation5 = Join-Path $env:windir "Temp"

$TempDestination = $Destination + "\SMSTS_Logs"
New-Item -ItemType "Directory" $TempDestination

Copy-Files -Source $SMSTSLocation1 -Destination $TempDestination -Filter *SMSTS*.lo* -Recurse -RenameFileToPath
Copy-Files -Source $SMSTSLocation1 -Destination $TempDestination -Filter ZTI*.lo* -Recurse -RenameFileToPath
Copy-Files -Source $SMSTSLocation2 -Destination $TempDestination -Filter *.lo* -Recurse -RenameFileToPath
Copy-Files -Source $SMSTSLocation3 -Destination $TempDestination -Filter *.lo* -Recurse -RenameFileToPath
Copy-Files -Source $SMSTSLocation4 -Destination $TempDestination -Filter *.lo* -Recurse -RenameFileToPath
Copy-Files -Source $SMSTSLocation5 -Destination $TempDestination -Filter *SMSTS*.lo* -RenameFileToPath

# --------------
# Panther logs
# --------------

# \Windows\Panther directory
$PantherLocation = Join-Path $Env:windir "Panther"
$PantherDirNewName = ($PantherLocation -replace "\\","_") -replace ":",""
$PantherDirDestination = Join-Path $Destination $PantherDirNewName
Copy-FilesWithStructure -Source $PantherLocation -Destination $PantherDirDestination -Include *.xml,*.lo*,*.etl

# \Windows\System32\Panther directory
$PantherLocation = Join-Path $Env:windir "System32\sysprep\Panther"
$PantherDirNewName = ($PantherLocation -replace "\\","_") -replace ":",""
$PantherDirDestination = Join-Path $Destination $PantherDirNewName
Copy-FilesWithStructure -Source $PantherLocation -Destination $PantherDirDestination -Include *.xml,*.log,*.etl

# \$Windows.~BT\Sources\Panther directory (Win 10)
$PantherLocation = Join-Path $Env:systemdrive "`$Windows.~BT\Sources\Panther"
$PantherDirNewName = ($PantherLocation -replace "\\","_") -replace ":",""
$PantherDirDestination = Join-Path $Destination $PantherDirNewName

# Try using psexec to copy these files, since the user may not have taken ownership of the folder
$CmdToRun = "psexec.exe /accepteula -s robocopy /S /NP /NC /NFL /NDL /W:5 $PantherLocation $PantherDirDestination *.xml *.log *.etl *.evt *.evtx"
RunCmd -commandToRun $CmdToRun -collectFiles $false -useSystemDiagnosticsObject

# \$Windows.~BT\Sources\Rollback\ (Win 10)
$RollbackLocation = Join-Path $Env:systemdrive "`$Windows.~BT\Sources\Rollback"
$RollbackLocationNewName = ($RollbackLocation -replace "\\","_") -replace ":",""
$RollbackLocationDestination = Join-Path $Destination $RollbackLocationNewName

# Try using psexec to copy these files, since the user may not have taken ownership of the folder
$CmdToRun = "psexec.exe /accepteula -s robocopy /S /NP /NC /NFL /NDL /W:5 $RollbackLocation $RollbackLocationDestination *.xml *.log *.etl *.txt *.evt *.evtx"
RunCmd -commandToRun $CmdToRun -collectFiles $false -useSystemDiagnosticsObject

# ----------
# INF Logs
# ----------

# \Windows\inf\*.log's
$InfLogLocation = Join-Path $Env:windir "INF"
$TempDestination = $Destination + "\INF_Logs"
New-Item -ItemType "Directory" $TempDestination
Copy-Files -Source $InfLogLocation -Destination $TempDestination -Filter *.lo* -Recurse

# ---------------------------
# \Windows\Logs\DISM\*.log's
# ---------------------------

$DismLogPath = Join-Path $Env:windir "Logs\DISM"
$TempDestination = $Destination + "\DISM_Logs"
New-Item -ItemType "Directory" $TempDestination
Copy-Files -Source $DismLogPath -Destination $TempDestination -Filter *.lo*

# -------------------------------
# DPX Logs (Win 10)
# -------------------------------
$TempLogPath = Join-Path $Env:windir "Logs\DPX"
$TempDestination = $Destination + "\DPX_Logs"
Copy-FilesWithStructure -Source $TempLogPath -Destination $TempDestination -Include *.xml, *lo*

# -------------------------------
# MOSETUP Logs (Win 10)
# -------------------------------
$TempLogPath = Join-Path $Env:windir "Logs\MoSetup"
$TempDestination = $Destination + "\MoSetup_Logs"
Copy-FilesWithStructure -Source $TempLogPath -Destination $TempDestination -Include *.xml, *lo*

# ----------------------
# \Windows\UDI\*.log's
# ----------------------

$UdiLogLocation = Join-Path $Env:windir "UDI"
$TempDestination = $Destination + "\UDI_Logs"
New-Item -ItemType "Directory" $TempDestination
Copy-FilesWithStructure -Source $UdiLogLocation -Destination $TempDestination -Include *.lo*,*.xml,*.config,*.app,*.reg

# -------------
# Netsetup.log
# -------------
$TempLogPath = Join-Path $Env:windir "debug"
Copy-FilesWithStructure -Source $TempLogPath -Destination $Destination -Include Netsetup.log

#################
# DEVCON OUTPUT #
#################

If ($ManifestName -ne "WSUS") {
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectWindowsLogs -Status $ScriptStrings.ID_SCCM_Windows_OSD_CollectDevCon

	$TempFileName = "DevCon_Output.txt"
	$OutputFile = Join-Path $Destination $TempFileName

	"DRIVER NODE INFORMATION`r`n" + "-" * 23 + "`r`n" | Out-File -FilePath $OutputFile
	$CommandToExecute = "cmd.exe /c devcon.exe drivernodes * >> $OutputFile"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -collectFiles $false

	"`r`nHARDWARE ID INFORMATION `r`n" + "-" * 23 + "`r`n" | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c devcon.exe hwids * >> $OutputFile"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -collectFiles $false

	"`r`nHARDWARE RESOURCE USAGE INFORMATION `r`n" + "-" * 35 + "`r`n" | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c devcon.exe resources * >> $OutputFile"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -collectFiles $false

	"`r`nHARDWARE STACK INFORMATION `r`n" + "-" * 35 + "`r`n" | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c devcon.exe stack * >> $OutputFile"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -collectFiles $false

	"`r`nHARDWARE STATUS INFORMATION `r`n" + "-" * 35 + "`r`n" | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c devcon.exe status * >> $OutputFile"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -collectFiles $false

	"`r`nDRIVER FILES INFORMATION `r`n" + "-" * 35 + "`r`n" | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c devcon.exe driverfiles * >> $OutputFile"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -collectFiles $false

	"`r`nCLASSES INFORMATION `r`n" + "-" * 35 + "`r`n" | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c devcon.exe classes * >> $OutputFile"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -collectFiles $false

	"`r`nFIND ALL INFORMATION `r`n" + "-" * 35 + "`r`n" | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c devcon.exe findall * >> $OutputFile"
	RunCmD -commandToRun $CommandToExecute -sectionDescription $sectionDescription -filesToCollect $OutputFile -fileDescription $fileDescription -collectFiles $false
}

# --------------------------------------------------
# Compress and Collect Logs if something was copied
# --------------------------------------------------
If (Test-Path $Destination)
{
	If ($ManifestName -eq "WSUS") {
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectWindowsLogs -Status $ScriptStrings.ID_SCCM_Compress_CollectConfigMgrLogs
	}
	else {
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Compress_CollectConfigMgrLogs
	}
	compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription $fileDescription -Recursive -ForegroundProcess -noFileExtensionsOnDescription
	Remove-Item -Path $Destination -Recurse -Force
}

Traceout "Completed"
