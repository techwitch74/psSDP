﻿#************************************************
# DC_CollectSqllogs.ps1
# Version 1.0.0
# Date: 10-2011
#
# Description: 
#			Collects SQL Server errorlogs and SQL Server Agent logs for all installed instances passed to script via the $Instances parameter
#			Can operate in "offline" mode where errorlog files are located using the registry or "online" mode
#			where errorlogs are enmerated and collected via xp_readerrorlog.
#
# Visibility:
#			Public - You should call this script to collect SQL Server errorlogs
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Script Parameters:
#			$Instances
#				Array of instances to collect errorlogs for
#           $CollectSqlErrorlogs
#               Switch parameter that indicates whether to collect SQL Server errorlogs 
#           $CollectSqlAgentLogs
#               Switch parameter that indicates whether to collect SQL Server Agent logs
#
# NOTE: This script expects the $Instances array to have been populated by the Enumerate-SqlInstances
#		function stored in "DSD\Scripts\SQL Server\Shared\Utilities\utils_DSD.ps1" and relies upon that format 
#       to function properly
#
# Author: Dan Shaver - dansha@microsoft.com
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Eliminated $Offline switch parameter as we no longer support "online" collection
#
#_# Date: 5-26-2021 added Get-SqlWriterLogs

# This script has dependencies on utils_CTS and utils_DSD
#
param( [Object[]] $instances, [switch]$CollectSqlErrorlogs, [switch] $CollectSqlAgentLogs) 

Import-LocalizedData -BindingVariable errorlogsCollectorStrings

#
# Function : Get-SqlAgentLogPath
# ----------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is used to find the path to the SQL Server errorlog for a given instance of SQL Server
# 
# Arguments:
#			$InstanceName
#			Function will find the path to the errorlogs for the instance passed 
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
function Get-SqlAgentLogPath([string]$SqlInstance)
{
	trap 
	{
		'[Get-SqlAgentLogPath] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error 
	}

    # Check if required parameter specified
	if ($null -ne $SqlInstance)
    {
        # Get instance folder name under SQL Root directory
        $InstanceKey = Get-SqlInstanceRootKey -SqlInstanceName $SqlInstance
    	
        if (($null -ne $InstanceKey) -and (0 -lt $InstanceKey.Length))
    	{
    		$SqlAgentKey = Join-Path -Path $InstanceKey -ChildPath '\SqlServerAgent'								
    								
    		# Test for valid Sql Agent registry key.  
    		if ($true -eq (Test-Path -Path $SqlAgentKey))
    		{	
                
                if ($false -eq (Test-RegistryValueIsNull -RegistryKey $SqlAgentKey -RegistryValueName 'ErrorLogFile'))
                {			
        			# Get the Sql Agent Errorlog path
        			$SqlAgentLogPath = [System.IO.Path]::GetDirectoryName((Get-ItemProperty -Path $SqlAgentKey).ErrorLogFile)
                                 
                    # Command Fail?
                    if ($false -eq $?)
                    {
                        "[Get-SqlAgentLogPath] : [ERROR] Failed to retrieve SQL Agent log path from [{0}\ErrorLogFile]" -f $SqlAgentKey | WriteTo-StdOut
                        Report-Error
                    }
                }
                else
                {
                    "[Get-SqlAgentLogPath] : [ERROR] Failed to retrieve SQL Agent log path from [{0}\ErrorLogFile] because the 'ErrorlogFile' registry value is null" -f $SqlAgentKey | WriteTo-StdOut
                }
    		}
    		else
    		{
    			# Report that we could not locate the SQL Agent log path
    			"[Get-SqlAgentLogPath] : Unable to locate SQL Agent log path for SQL Instance: [{0}]" -f $SqlInstance | WriteTo-StdOut
                "[Get-SqlAgentLogPath] : Registry key: [{0}] is invalid" -f $SqlAgentKey | WriteTo-StdOut
                Report-Error                            
    		}
            
    	} # if ($null -ne $InstanceKey)
    	else
    	{
    		"[Get-SqlAgentLogPath] : Failed to retrieve Instance Root key [{0}]" -f $InstanceKey | WriteTo-StdOut
    		Report-Error
    	}

    } # if ($null -eq $SqlInstance)
    else
    {
        '[Get-SqlAgentLogPath] : Required parameter: -SqlInstance was not specified' | WriteTo-StdOut
    }
    
	return $SqlAgentLogPath
}



#
# Function : Get-SqlAgentLogsOffline
# ----------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all Sql Agent logs for the instance passed to the function
#			This is an "offline" collector in that it does not rely on making a connection to the SQL Server instance to
#			find and collect the Sql Agent log files (via xp_readerrorlog). 
#			Finds the location of the Sql Agent logs from the registry and collects the files from the \log folder for the install
# 
# Arguments:
#			$InstanceName
#			Function will find the path to the Sql Agent errorlog for the instance passed 
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#

function Get-SqlAgentLogsOffline ([string]$InstanceToCollect )
{
	trap 
	{
		'[Get-SqlAgentLogsOffline] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error  
	}
	
    if ($null -ne $InstanceToCollect)
    {
        # Send a status message to stdout.log
    	"[Get-SqlAgentLogsOffline] : [INFO] Attempting to collect Sql Agent logs for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut

    	# Set the SectionDescription to the instance name that errorlogs were collected from
    	$SectionDescription = 'SQL Server Agent Logs for instance: ' + $InstanceToCollect

		# Get path to SQL Server Agent log files from registry
		$SqlAgentLogPath = Get-SqlAgentLogPath -SqlInstance $InstanceToCollect
    		
    	if (($null -ne $SqlAgentLogPath) -and (0 -lt $SqlAgentLogPath.Length))
    	{		
    		
            if ($true -eq (Test-Path -Path $SqlAgentLogPath))
    		{
            	
                # Enumerate and then copy the files
				$Files = @()
                $Files = Copy-FileSql -SourcePath $SqlAgentLogPath `
                         -FileFilters @('SQLAGENT.*') `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_ERRORLOGS `
                         -InstanceName $InstanceToCollect `
						 -SectionDescription $SectionDescription `
						 -LCID (Get-LcidForSqlServer -SqlInstanceName $InstanceToCollect) `
						 -RenameCollectedFiles
                 
    			if (0 -eq $Files.Count)
    			{
                    #SQL Agent Log path is valid but no SQLAget log files exists ...
                    "[Get-SqlAgentLogsOffline] : [INFO] There are no Sql Agent log files for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
                }
    		} 
    		else 
    		# Invalid path to SQL Agent log files retrieved from registry.  
    		{
				# Does the log path reference a cluster disk that is offline from this node at this time?
                if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceToCollect -PathToTest $SqlAgentLogPath)) 
				{
    				# If above function returns true the drive is online but the path is bad
                    "[Get-SqlAgentLogsOffline] : [ERROR] Path to Sql Agent Log Files: [{0}] for instance: {1} is invalid" -f $SqlAgentLogPath, $InstanceToCollect | WriteTo-StdOut
                }              
    		}
    	} 
    	else 
    	{
    		"[Get-SqlAgentLogsOffline] : [ERROR] Could not locate errorlog path in the registry for instance: [{0}]. No Sql Agent log files will be collected. " -f $InstanceToCollect | WriteTo-StdOut
    	}
        
    } #if ($null -eq $InstanceToCollect)
    else
    {
        '[Get-SqlAgentLogsOffline] : [ERROR] Required parameter: -InstanceToCollect was not specified' | WriteTo-StdOut
    }
} 

#
# Function : Get-ErrorlogsOffline
# -------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all errorlogs for the instance passed to the function
#			This is an "offline" collector in that it does not rely on making a connection to the SQL Server instance to
#			find and collect the errorlog files. 
#			Finds the location of the errorlogs from the registry and collects the files from the \log folder for the install
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$IsClustered
#				This variable tells the collector whether to run an additional check if a drive appears offline preventing collection
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#

function Get-ErrorlogsOffline ([string]$InstanceToCollect)
{
	trap 
	{
		"[Get-ErrorlogsOffline] : [ERROR] Trapped exception ..." | WriteTo-StdOut
		Report-Error
	}
	
	if ($null -ne $InstanceToCollect)
    {
        # Write status message to stdout.log
        "[Get-ErrorlogsOffline] : [INFO] Attempting to collect errorlogs for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
    	
    	$SqlErrorLogPath = Get-SqlServerLogPath -SqlInstance $InstanceToCollect
    	
    	if ($null -ne $SqlErrorLogPath)
    	{		
    		if ( $true -eq (Test-Path -Path $SqlErrorLogPath) )
    		{
    			
                # Set the SectionDescription to the instance name that errorlogs were collected from
    			$SectionDescription = 'SQL Server Errorlogs for instance: ' + $InstanceToCollect 
             
                # Enumerate and then copy the files
				$Files = @()
				$Files = Copy-FileSql -SourcePath $SqlErrorLogPath `
                         -FileFilters @('ERRORLOG*') `
                         -FilePolicy $global:SQL:FILE_POLICY_SQL_SERVER_ERRORLOGS `
                         -InstanceName $InstanceToCollect `
						 -SectionDescription $SectionDescription `
						 -LCID (Get-LcidForSqlServer -SqlInstanceName $InstanceToCollect) `
						 -RenameCollectedFiles
                 
    			if (0 -eq $Files.Count)
    			{
                    "[Get-ErrorlogsOffline] : [INFO] There are no Sql errorlog files for instance: {0}" -f $InstanceToCollect | WriteTo-StdOut
                }
                
    		} # if ( $true -eq (Test-Path -Path $SqlErrorLogPath) )
    		# Errorlog path is invalid
    		else 
    		{
    			if ($true -eq (Check-IsSqlDiskResourceOnline -InstanceName $InstanceToCollect -PathToTest $SqlErrorLogPath))
    	        {
    	            "[Get-ErrorlogsOffline] : [ERROR] No SQL errorlogs will be collected. Path to errorlogs: [{0}] for instance: {1} is invalid" -f $SqlErrorLogPath, $InstanceToCollect | WriteTo-StdOut
    	        }
    		}
    	}
    	# Couldn't locate errorlog path
    	else
    	{
    		"[Get-ErrorlogsOffline] : [ERROR] No SQL errorlogs will be collected. Could not locate the errorlog path in the registry for instance: {0} is invalid" -f $InstanceToCollect | WriteTo-StdOut
    	}
    } #if ($null -ne $InstanceToCollect)
    else
    {
        "[Get-ErrorlogsOffline] : [ERROR] Required parameter -InstanceToCollect was not specified" -f $InstanceToCollect | WriteTo-StdOut
    }
} 

#
# Function : Get-ErrorlogsOnline
# -------------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function finds and collects all errorlogs for the instance passed to the function
#			This is an "online" collector that utilizes SQLCMD and xp_readerrorlog to collect the SQL Server errorlogs
#			This collector uses the same exact scrip that PSSDiag uses in order to maintain compatibility with any 
#			post-processing of errorlogs performed by SqlNexus
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
#function Get-ErrorlogsOnline ( [string]$InstanceName
#                             , [string]$NetName )
#{
#	trap 
#	
#		'[Get-ErrorlogsOnline] : Trapped error ...' | WriteTo-StdOut
#		Show-ErrorDetails -ErrorRecord $error[0] 
#
#		# Now clear all errors since we reported them
#		$Error.Clear() 
#	}
#	
#	New-Variable ERRORLOG_COLLECTOR_SCRIPT -Value 'collecterrorlog.sql' -Option ReadOnly
#	
#	if (('DEFAULT' -eq $InstanceName) -or ( 'MSSQLSERVER' -eq $InstanceName))
#	{
#		$ConnectToName = $NetName
#		$ErrorlogOutFileName = "{0}__SQL_Base_Errorlog_Shutdown.out" -f $NetName
#	} else {
#		$ConnectToName = $NetName+'\'+$InstanceName
#		$ErrorlogOutFileName = "{0}_{1}_SQL_Base_Errorlog_Shutdown.out" -f $NetName, $InstanceName
#	}
#
#	Execute-SqlScript -ConnectToName $ConnectToName `
#                     -ScriptToExecute $ERRORLOG_COLLECTOR_SCRIPT `
#                      -OutputFileName $ErrorlogOutFileName `
#                      -SectionDescription ("SQL Server Errorlogs for instance: {0}" -f $ConnectToName) `
#                      -FileDescription 'ERRORLOGS'
#}

#
# Function : Get-SqlErrorlogs
# ------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is a wrapper that calls Get-ErrorlogsOffline
#           This script used to support online and offline collection modes 
#           The "online" collector utilized SQLCMD and xp_readerrorlog to collect the SQL Server errorlogs
#			However, xp_readerrorlog wraps lines and this caused issues for loading the files in UDE so we no longer collect in this format
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
#

function Get-SqlErrorLogs ([object]$Instance)
{
	trap 
	{
		# Handle and report any exceptions that occur in this function, and then allow execution to resume 
		# Since this is only a wrapper function and doesn't do much to setup the excution of Get-ErrorlogsOffline, 
		# the called function may still succeed
		#
		'[Get-SqlErrorLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error
	}
	
    # Check if required parameter was passed
    if ($null -ne $Instance)
    {
       	# Update msdt dialog with progress message
    	Write-DiagProgress -Activity $errorlogsCollectorStrings.ID_SQL_CollectSqlErrorlogs -Status ($errorlogsCollectorStrings.ID_SQL_CollectSqlErrorlogsDesc + ": " + $instance.InstanceName)
    	
        if ($null -ne $Instance.InstanceName)
        {
        	"[Get-SqlErrorLogs] : [INFO] Collecting logs for instance {0}" -f $Instance.InstanceName | WriteTo-StdOut
        	Get-ErrorlogsOffline -InstanceToCollect $Instance.InstanceName 	
        }
        else
        {
            '[Get-SqlErrorLogs] : [ERROR] Passed instance name ($Instance.InstanceName) is null' | WriteTo-StdOut
        }
	}
    else
    {
        if ($null -eq $Instance)
        {
            '[Get-SqlErrorLogs] : [ERROR] Required parameter: -Instance was not specified' | WriteTo-StdOut
        }
    }	
	
}

#
# Function : Get-SqlAgentLogs
# ------------------------
#
# PowerShell Version:
#			Written to be compatible with PowerShell 1.0
#
# Visibility:
#			Private/Internal - Do not call this function from your PowerShell scripts.  
#
# Description:
# 			This function is a wrapper that calls Get-SqlAgentLogsOffline
#			Wrapper exists in case we want to add offline and online (via xp_readerrorlog) collection modes.  This is the function
#			
# 
# Arguments:
#			$InstanceName
#				Function will find the path to the errorlogs for the instance passed 
#			$NetName
#				This is the server or virtual SQL network name to connect to
# 
# Owner:
#			DanSha 
#
# Revision History:
#
#           1.0 11/2011    DanSha
#               Original Version
#			1.1 01/18/2012 DanSha
#				Replaced double quotes with single quotes when variable expansion not desired.
#               Removed logic for "online" collection
#               Added parameter metadata to prevent null, missing and empty parameters
#
#
function Get-SqlAgentLogs ([object]$Instance)
{
	trap 
	{
		'[Get-SqlAgentLogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
		Report-Error 
	}
	
	# Update msdt dialog with progress message
	Write-DiagProgress -Activity $errorlogsCollectorStrings.ID_SQL_CollectSqlAgentlogs -Status ($errorlogsCollectorStrings.ID_SQL_CollectSqlAgentlogsDesc + ": " + $instance.InstanceName)
	
    # Check if required parameter specified
    if ($null -ne $Instance)
    {
        # Write to debug log
    	"[Get-SqlAgentLogs] : [INFO] Collecting Sql Agent logs for instance {0}" -f $Instance.InstanceName | WriteTo-StdOut
    	Get-SqlAgentLogsOffline -InstanceToCollect $Instance.InstanceName 
    }
    else
    {
        '[Get-SqlAgentLogs] : [ERROR] Required parameter -Instance was not specified' | WriteTo-StdOut
    }
}

#_# add function for collecting SQL Server 2019 SqlWriterLogger
function Get-SqlWriterLogs([string]$SqlVersion)
{
	$SQLPath = (join-path ([Environment]::GetFolderPath("ProgramFiles")) "Microsoft SQL Server\$SqlVersion\Shared")
	if($debug -eq $true){[void]$shell.popup($SQLPath)}

	if ((test-path $SQLPath) -eq $true)
		{
			if($debug -eq $true){[void]$shell.popup("Valid Path")}
			
			$OutputFileName= $ComputerName + "_SQL" + $SqlVersion + "_SqlWriterLogger.Cab"
			if($debug -eq $true){[void]$shell.popup($OutputFileName)}

			#Create Array of Files to Collect
			[Array] $DC_GetSQLWriterLoggerOutputFiles = $SQLPath + "\SqlWriterLogger*.txt"

			CompressCollectFiles -filesToCollect $DC_GetSQLWriterLoggerOutputFiles -DestinationFileName $OutputFileName -fileDescription "SQL $SqlVersion SqlWriterLogger Logs" -sectionDescription "Additional Data" -Recursive -ForegroundProcess
		}
		else
			{
				if($debug -eq $true){[void]$shell.popup("Invalid Path")}
			}
}

# Clear errors at entry to script
#
$Error.Clear()           
trap 
{
	'[DC-CollectSqllogs] : [ERROR] Trapped exception ...' | WriteTo-StdOut
	Report-Error 
}

if ($true -eq $global:SQL:debug)
{
    $CollectSqlErrorlogs=$true
    $CollectSqlAgentLogs=$true
}

# Check to be sure that there is at least one SQL Server installation on target machine before proceeding
#
if ($true -eq (Check-SqlServerIsInstalled))
{
	# If $instance is null, get errorlogs for all instances installed on machine
	#

	if ($null -eq $instances)
	{
		$instances = Enumerate-SqlInstances -Offline
	}
	
	if ($null -ne $instances)
    {
    
		foreach ($instance in $instances)
		{
			if ('DEFAULT' -eq $instance.InstanceName) {$instance.InstanceName='MSSQLSERVER'}
        
			if ($true -eq $CollectSqlErrorlogs)
			{
				Get-SqlErrorlogs -Instance $instance
			}
            
			if ($true -eq $CollectSqlAgentLogs)
			{
				Get-SqlAgentLogs -Instance $instance
			}
            
		}
        
	} # if ($null -ne $instances)
    else
    {
        "[DC_CollectSqllogs] : [WARN] No sql server instances were found on: [{0}] yet SQL Server appears to be installed" -f $ComputerName | WriteTo-StdOut 
    }
} # if ($true -eq (Check-SqlServerIsInstalled))

else 
{
    "[DC_CollectSqllogs] : No sql server instances are installed on: [{0}]" -f $ComputerName | WriteTo-StdOut 
}



#_# Collect SQL 90 SqlWriter Logs
Write-DiagProgress -Activity $GetSQLSetupLogs.ID_SQL_setup_collect_writer_logs -Status $GetSQLSetupLogs.ID_SQL_writer_Collect_2019_Logs
Get-SqlWriterLogs -SqlVersion "90"
