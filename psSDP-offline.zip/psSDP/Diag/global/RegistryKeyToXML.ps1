﻿# Copyright ?2010, Microsoft Corporation. All rights reserved.

# You may use this code and information and create derivative works of it,
# provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for
# troubleshooting a) Windows and b) products for Windows, in either case using
# the Windows Troubleshooting Platform
# 2. Any copies of this code and information
# and any derivative works must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
# INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
# WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.
#************************************************

#************************************************
# RegistryKeyToXML.ps1
# Version 1.0.0
# Date: 05-04-2011
# Author: Jeremy LaBorde - jlaborde@microsoft.com
# Description: This script provides functionality for gathering a registry key in
#  XML format, including data entries and permissions, along with functions
#  to navigate said XML data
#
# Note: do NOT use this format for large keys ( ex. HKCR ), as this
#  script uses get-item, which is considerably slower then other
#  methods to dump the registry
#
#************************************************


###########################################################
#
# Last Update: 5-3-2011
# Author: jlaborde
#
# Description:
#  convert from the type of entry returned in powershell for a registry entry to a REG_* type
#
# Usage:
#  Get-REG_Type <PS_type>
#
# Example:
#  Get-REG_Type "String"
#   returns "REG_SZ"
#
###########################################################

function Get-REG_Type( [string] $local:PS_Type )
{	switch( $local:PS_Type )
	{	"String"		{ return "REG_SZ" }
		"Binary"		{ return "REG_BINARY" }
		"DWord"			{ return "REG_DWORD" }
		"QWord"			{ return "REG_QWORD" }
		"MultiString"	{ return "REG_MULTI_SZ" }
		"ExpandString"	{ return "REG_EXPAND_SZ" }
	}
	return "REG_SZ"
}

###########################################################
#
# Last Update: 4-26-2011
# Author: jlaborde
#
# Description:
#  recusive function to dump a reg key & to an XML file
#
# Notes:
#  should always wrap data returned in an external XML tag for well-formatted XML
#  see Get-MSDTCRegistryKeysAsXML for an example in DC_MSDTC_Collector.ps1
#
# Usage:
#  Get-RegistryKeyAsXML <path> <recurse subkeys> <tab characters to prepend>
#
# Example:
#  Get-RegistryKeyAsXML "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" $true "`t"
#
###########################################################

function Get-RegistryKeyAsXML( [string]$local:path, [bool]$local:recurse, [string]$local:tabs )
{
	#name / header output
	$local:lpath	= "registry::" + $local:path
	$local:_retv	= $local:tabs + "<RegistryKey Name=`"" + $local:path + "`" >`r`n"

	#check to see if we can open the key...
	if( Test-Path( $local:lpath ) )
	{
		$local:regkey	= Get-Item( $local:lpath )


		#list the rights
		$local:perms			= ((Get-Acl $local:lpath).Access)
		$local:_retv			= $local:_retv + $local:tabs + "`t<Permissions>`r`n"
		foreach( $local:perm in $local:perms )
		{
			$local:_retv		= $local:_retv + $local:tabs + "`t`t<PermEntry ID=`""

			foreach( $local:t1 in $local:perm )
			{
				$local:_retv	= $local:_retv + $local:t1.IdentityReference + "`">`r`n"
				$local:_retv	= $local:_retv + $local:tabs + "`t`t`t<Type>" + $local:t1.AccessControlType + "</Type>`r`n"
				$local:_retv	= $local:_retv + $local:tabs + "`t`t`t<Rights>" + $local:t1.RegistryRights + "</Rights>`r`n"
			}

			$local:_retv		= $local:_retv + $local:tabs + "`t`t</PermEntry>`r`n"
		}
		$local:_retv			= $local:_retv + $local:tabs + "`t</Permissions>`r`n"


		#if there is a default value, save it
		$local:_retv		= $local:_retv + $local:tabs + "`t<Value>"
		$local:default		= ($local:regkey).GetValue( "", $null )
		if( $local:default -ne $null )
		{	$local:_retv	= $local:_retv + $local:default
		}
		$local:_retv		= $local:_retv + "</Value>`r`n"


		#save (Default) type ( which should always be REG_SZ... right? )
		$local:regentries	= ($local:regkey).GetValueNames( )
		$local:_retv		= $local:_retv + $local:tabs + "`t<Type>"
		# if a null value, just hardcode a REG_SZ
		if( $local:default -ne $null )
		{	$local:_retv		= $local:_retv + (Get-REG_Type $($local:regkey.GetValueKind( "" )) )
		} else
		{	$local:_retv		= $local:_retv + "REG_SZ"
		}
		$local:_retv		= $local:_retv + "</Type>`r`n"


		#list any entries in this key
		$local:_retv	= $local:_retv + $local:tabs + "`t<Entries>`r`n"
		if( $local:regentries -ne $null )
		{	foreach( $local:regentry in $local:regentries )
			{	if( $local:regentry -eq "" )
				{	continue;}
				$local:regvalue	= (Get-ItemProperty $local:lpath $local:regentry).$local:regentry
				$local:_retv	= $local:_retv + $local:tabs + "`t`t"   + "<Entry Name=`"" + $local:regentry + "`">`r`n"
				$local:_retv	= $local:_retv + $local:tabs + "`t`t"   + "<Type>" + (Get-REG_Type $($regkey.GetValueKind( $local:regentry )) ) + "</Type>`r`n"
				$local:_retv	= $local:_retv + $local:tabs + "`t`t`t" + "<Value>" + $local:regvalue + "</Value>`r`n"
				$local:_retv	= $local:_retv + $local:tabs + "`t`t"   + "</Entry>`r`n"
			}
		}
		$local:_retv	= $local:_retv + $local:tabs + "`t</Entries>`r`n"

		
		#recurse subkeys
		if( $local:recurse -eq $true )
		{	$local:regsubkeys		= Get-Item( $local:lpath + "\*" ) -ErrorAction SilentlyContinue
			if( $local:regsubkeys -ne $null )
			{	foreach( $local:subkey in $local:regsubkeys )
				{	$local:_retv	= $local:_retv + (Get-RegistryKeyAsXML $local:subkey $local:recurse (($local:tabs + "`t")) )
				}
			}
		}

	}
	else
	{	return ($local:tabs + "<KeyNotFound>" + $local:path + "</KeyNotFound>`r`n")
	}	

	$local:_retv	= $local:_retv + $local:tabs + "</RegistryKey>`r`n"

	return $local:_retv
}

###########################################################
#
# Last Update: 4-26-2011
# Author: jlaborde
#
# Description:
#  return the value from XML representation of a registry hive entry
#
# Usage:
#  Get-XMLRegistryEntryValue <XMLElement> <Entry Name>
#
# Example:
#  Get-XMLRegistryEntryValue $local:security "AccountName"
#   where $local:security == [XMLElement] set to "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSDTC\Security"
#
###########################################################

function Get-XMLRegistryEntryValue( [System.Xml.XmlElement]$local:node, [string]$local:item )
{	#null or the value
	$local:entry	= $local:node.Entries.Entry | Where-Object { $_.Name -like $local:item }
	if( $local:entry -eq $null )
	{	return $null
	}
	return $local:entry.Value
}

###########################################################
#
# Last Update: 5-3-2011
# Author: jlaborde
#
# Description:
#  return the type from XML representation of a registry hive entry
#
# Usage:
#  Get-XMLRegistryEntryType <XMLElement> <Entry Name>
#
# Example:
#  Get-XMLRegistryEntryType $local:security "AccountName"
#   where $local:security == [XMLElement] set to "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSDTC\Security"
#
###########################################################

function Get-XMLRegistryEntryType( [System.Xml.XmlElement]$local:node, [string]$local:item )
{	#null or the value
	$local:entry	= $local:node.Entries.Entry | Where-Object { $_.Name -like $local:item }
	if( $local:entry -eq $null )
	{	return $null
	}
	return $local:entry.Type
}

###########################################################
#
# Last Update: 4-26-2011
# Author: jlaborde
#
# Description:
#  return true or false from XML representation of a registry hive entry
#
# Usage:
#  Get-XMLRegistryEntryOnOrOff <XMLElement> <Entry Name>
#
# Example:
#  Get-XMLRegistryEntryOnOrOff $local:security "NetworkDtcAccess"
#   where $local:security == [XMLElement] set to "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSDTC\Security"
#
###########################################################

function Get-XMLRegistryEntryOnOrOff( [System.Xml.XmlElement]$local:node, [string]$local:item )
{	#0 or null == false, else true
	$local:value	= Get-XMLRegistryEntryValue $local:node $local:item
	if( $local:value -eq $null -or $local:value -eq 0 )
	{	return $false
	}
	return $true
}

###########################################################
#
# Last Update: 3-31-2012
# Author: jlaborde
#
# Description:
#  return true or false from XML representation of a registry hive entry to see if it exists
#
# Usage:
#  Get-XMLRegistryEntryExists <XMLElement> <Entry Name>
#
# Example:
#  Get-XMLRegistryEntryOnOrOff $local:security "NetworkDtcAccess"
#   where $local:security == [XMLElement] set to "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSDTC\Security"
#
###########################################################

function Get-XMLRegistryEntryExists( [System.Xml.XmlElement]$local:node, [string]$local:item )
{	#null == false, else true
	$local:value	= Get-XMLRegistryEntryValue $local:node $local:item
	if( $local:value -eq $null )
	{	return $false
	}
	return $true
}

###########################################################
#
# Last Update: 4-26-2011
# Author: jlaborde
#
# Description:
#  return the XML element representing the registry key
#
# Usage:
#  Get-XMLRegistryKey <XMLElement> <Full Key Name>
#
# Example:
#  Get-XMLRegistryKey $local:node "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSDTC\Security"
#   where $local:node == [XMLElement] set to "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\MSDTC"
#
###########################################################

function Get-XMLRegistryKey( [System.Xml.XmlElement]$local:node, [string]$local:item )
{	#null or the XMLElement
	$local:entry	= $local:node.RegistryKey | Where-Object { $_.Name -like $local:item }
	return $local:entry
}

###########################################################
#
# Last Update: 4-27-2011
# Author: jlaborde
#
# Description:
#  find XML node /subkey based on presence of an inner subkey, possibly at a certain default value
#
# Usage:
#  Get-XMLRegistryKeyBasedOnSubkey [System.Xml.XmlElement]$local:node, [string]$local:subkeyname, [string]$local:subkeyvalue
#
# Example:
#  Get-XMLRegistryKeyBasedOnSubkey $local:node, "Description", "MSDTC"
#   where $local:node is set to HKEY_LOCAL_MACHINE\SOFTWARE\Classes\CID & 
#    we're looking for the subkey who contains a subkey name Description set to default value MSDTC
#
###########################################################

function Get-XMLRegistryKeyBasedOnSubkey( [System.Xml.XmlElement]$local:node, [string]$local:subkeyname, [string]$local:subkeyvalue )
{
	# loop through this node's subkeys
	foreach( $local:subnode in $local:node.RegistryKey )
	{
		# find the subkey off the looping subkey
		$local:s2	= Get-XMLRegistryKey $local:subnode ($local:subnode.Name + "\" + $local:subkeyname)
		if( $local:s2 -ne $null )
		{	# if we don't care about the default value, return this key
			if( $local:subkeyvalue -eq $null -or $local:subkeyvalue -eq "" )
			{	return $local:subnode
			}
			# if we do care about the default value, make sure we have one and compare it
			if( $local:s2.Value -ne $null -and $local:s2.Value.CompareTo( $local:subkeyvalue ) -eq 0 )
			{	return $local:subnode
			}
		}
	}
	return $null
}
