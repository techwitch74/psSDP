﻿#************************************************
# DC_DnsServer-Component.ps1
# Version 1.0: Script created. Collecting output from DnsCmd, Registry and Event logs.
# Version 1.1: Added DNS pscmdlets for WS2012 and later
# Version 1.2.08.24.14: Made changes so the pscmdlets file would be created regardless of OS, and added the overview headings for DnsCmd. TFS264122
# Date: 2009-2014, 2020
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about the DNS Server.
# Called from: Networking Diags
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSDNSServer -Status $ScriptVariable.ID_CTSDNSServerDescription

function RunNetSH ([string]$NetSHCommandToExecute="")
{
	
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDNSServer -Status "netsh $NetSHCommandToExecute"
	
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength) + "`r`n" + "netsh $NetSHCommandToExecute" + "`r`n" + "-" * ($NetSHCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	# displays the current PowerShell cmdlet
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDNSServer -Status "$RunPScmd"
	
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n`n`n"	| Out-File -FilePath $OutputFile -append	
}


function RunDnsCmd ([string]$DnsCmdCommand="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDNSServer -Status "DnsCmd $DnsCmdCommand"
	
	$DnsCmdCommandLength = $DnsCmdCommand.Length + 6
	"-" * ($DnsCmdCommandLength) + "`r`n" + "DnsCmd $DnsCmdCommand" + "`r`n" + "-" * ($DnsCmdCommandLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c DnsCmd.exe " + $DnsCmdCommand + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n"	| Out-File -FilePath $OutputFile -append
}


$sectionDescription = "DNS Server"


#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$outputFile= $Computername + "_DnsServer_info_pscmdlets.TXT"
"========================================"	| Out-File -FilePath $OutputFile -append
"DNS Server Powershell Cmdlets"				| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"Overview"	| Out-File -FilePath $OutputFile -append
"----------------------------------------"	| Out-File -FilePath $OutputFile -append
"DNS Server Configuration"	| Out-File -FilePath $OutputFile -append
"  1. Get-DnsServer"	| Out-File -FilePath $OutputFile -append
"     This powershell cmdlet includes the following output:"	| Out-File -FilePath $OutputFile -append
"       ServerSetting              (Get-DnsServerSetting)"	| Out-File -FilePath $OutputFile -append
"       ServerDsSetting            (Get-DnsServerDsSetting)"	| Out-File -FilePath $OutputFile -append
"       ServerScavenging           (Get-DnsServerScavenging)"	| Out-File -FilePath $OutputFile -append
"       ServerRecursion            (Get-DnsServerRecursion)"	| Out-File -FilePath $OutputFile -append
"       ServerDiagnostics          (Get-DnsServerDiagnostics)"	| Out-File -FilePath $OutputFile -append
"       ServerGlobalNameZones      (Get-DnsServerGlobalNameZones)"	| Out-File -FilePath $OutputFile -append
"       ServerCache                (Get-DnsServerCache)"	| Out-File -FilePath $OutputFile -append
"       ServerGlobalQueryBlockList (Get-DnsServerGlobalQueryBlockList)"	| Out-File -FilePath $OutputFile -append
"       ServerEdns                 (Get-DnsServerEdns)"	| Out-File -FilePath $OutputFile -append
"       ServerForwarder            (Get-DnsServerForwarder)"	| Out-File -FilePath $OutputFile -append
"       ServerRootHint             (Get-DnsServerRootHint)"	| Out-File -FilePath $OutputFile -append
"       ServerZone                 (Get-DnsServerZone)"	| Out-File -FilePath $OutputFile -append
"       ServerZoneAging            (Get-DnsServerZoneAging)"	| Out-File -FilePath $OutputFile -append
"  2. Get-DnsServerQueryResolutionPolicy"	| Out-File -FilePath $OutputFile -append
"  3. Get-DnsServerClientSubnet"			| Out-File -FilePath $OutputFile -append
"  4. Get-DnsServerRecursionScope"			| Out-File -FilePath $OutputFile -append
"  5. Get-DnsServerZoneTransferPolicy"		| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append


"=============================================="	| Out-File -FilePath $OutputFile -append
"DNS Server Configuration"	| Out-File -FilePath $OutputFile -append
"=============================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
if ($bn -ge 9200)
{
	$dnsServerServiceStatus = get-service * | where {$_.name -eq "dns"}	
	if ($dnsServerServiceStatus -ne $null)
	{
		if ((Get-Service "dns").Status -eq 'Running')
		{
			RunPS "Get-DnsServer" 								# W8/WS2012, W8.1/WS2012R2	# large output with both ft and fl
			RunPS "Get-DnsServerQueryResolutionPolicy | fl *" 
			RunPS "Get-DnsServerClientSubnet | fl *"    	
			RunPS "Get-DnsServerRecursionScope | fl *"	
			RunPS "Get-DnsServerZoneTransferPolicy | fl *"
		}
		else
		{
			"The DNS Server service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The DNS Server service does not exist on this computer. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The Get-DnsServer pscmdlet is only available in WS2012 and later. Not running pscmdlet."	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $OutputFile -fileDescription "DNS Server Information (Powershell)" -SectionDescription $sectionDescription



# DnsCmd Section
$outputFile= $Computername + "_DnsServer_info_DnsCmd.TXT"
"========================================"	| Out-File -FilePath $OutputFile -append
"DNS Server DnsCmd Output"					| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"Overview"	| Out-File -FilePath $OutputFile -append
"----------------------------------------"	| Out-File -FilePath $OutputFile -append
"DNS Server Configuration"	| Out-File -FilePath $OutputFile -append
"  1. DnsCmd /Info"	| Out-File -FilePath $OutputFile -append
"  2. DnsCmd /EnumDirectoryPartitions"	| Out-File -FilePath $OutputFile -append
"  3. DnsCmd /EnumZones"	| Out-File -FilePath $OutputFile -append
"  4. DnsCmd /Statistics"	| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append

$dnsServerServiceStatus = get-service * | where {$_.name -eq "dns"}	
if ($dnsServerServiceStatus -ne $null)
{
	if ((Get-Service "DNS").Status -eq 'Running')
	{
		RunDnsCmd "/Info"
		RunDnsCmd "/EnumDirectoryPartitions"
		RunDnsCmd "/EnumZones"
		RunDnsCmd "/Statistics"
	}
	else
	{
		"The DNS Server service is not Running. Not running DnsCmd commands." 	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The DNS Server service does not exist on this computer. Not running DnsCmd commands." 	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $OutputFile -fileDescription "DnsCmd Output" -SectionDescription $sectionDescription




#DNS Server Registry Section
$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\DNS"
if (Test-Path $SvcKey) 
{
	#----------Registry
	$OutputFile= $Computername + "_DnsServer_reg_.TXT"
	$CurrentVersionKeys = "HKLM\SYSTEM\CurrentControlSet\services\DNS" 
	$sectionDescription = "DNS Server registry"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true  -OutputFile $OutputFile -fileDescription "DNS Server Registry Key" -SectionDescription $sectionDescription
	
	$OutputFile= $Computername + "_DnsServer_Softw_reg_.TXT"
	$CurrentVersionKeys = "HKLM\Software\Microsoft\Windows NT\CurrentVersion\DNS Server" 
	$sectionDescription = "DNS Server registry Software"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true  -OutputFile $OutputFile -fileDescription "DNS Server Software Registry Key" -SectionDescription $sectionDescription
}


#----------Collect the DNS Server event log
#DNS Server Event Log
$EventLogNames = "DNS Server"
$Prefix = ""
$Suffix = "_evt_"
.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix


# SIG # Begin signature block
# MIIjlAYJKoZIhvcNAQcCoIIjhTCCI4ECAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDfoBSg8LdwIGpY
# LeEOAOiCgkt010Q8YqNaJxIEzs+Fh6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVaTCCFWUCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg+noDwy2a
# FtMb+uRTd1krNGk34Ujeo81qvHzmULOofmEwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBADZKwJVHnZltYuZWj7KTkGywW4Y5QukxJhUwwDsPgRHMFNOIEEndAI5v
# 4a9L/F4fwRS6hhkFr7KqZlB6e2IuAeFW49PAeDqdG9+5v5IY7UR1RhXpNtS20tpU
# Tv4QV82GLC6ZaCq6iGawHhjwvTN8vX6t78m3Oa8+wRgXhR+qvbBtRhTgiUgVc1QS
# ORfsBrsxS3cwg9dU7j0mM7heNvCsUYVaCfOEDQ1+xXZKTP2qiBcqvEvhMX0XG/6u
# l9tomjcNPo5Mt3WqhVxHPTEAejIRVRrRb0YmfZk1cQd+hE4Ky6XhLaLi/YrdDmEF
# +Ius2OBi0xcRdYXZZPGD/f+6yevH3iehghL9MIIS+QYKKwYBBAGCNwMDATGCEukw
# ghLlBgkqhkiG9w0BBwKgghLWMIIS0gIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWAYL
# KoZIhvcNAQkQAQSgggFHBIIBQzCCAT8CAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgT/EXUKY3MSjU1ClSUHpCoLw9fYcX4ux2eAuHIll4DSkCBmCKzjBg
# kBgSMjAyMTA1MTkyMjIyNTUuNjNaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjNCRDQtNEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIOTTCCBPkwggPhoAMCAQICEzMAAAE7EhuSI1ICWqUAAAAAATswDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjAx
# MDE1MTcyODIyWhcNMjIwMTEyMTcyODIyWjCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjozQkQ0LTRC
# ODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAOM21pXQ1uUwGAcBUvPC91UA
# rbFP2chd56rQsPlUSuHhsZjV3UCFIW33AqybJe3bpHq8PLkopZafgB+YQPYDkXNy
# ACQvjex5WVl1/+aAJDba2zGmTIWFg4TDweE5SsPCncDqc2WReMZw4Gllmbm5fkJ1
# gdqrdrny2UuuKgvt7BowNvBDotZ+1M5WpB/rxepaAi+WOiH6t7+Qk6uwnuPWQdmQ
# lsGKZB+O3GJ3r0TMptxALPTdPkLwml4jqLCyMW4Zar4ygCub/SRQkoxE3aVGikoE
# 0lZWw1Pke/cEs73bFoD3005NDW5om69wMSVFO/oBX3biNAKN+psiZCUINdAhRDEC
# AwEAAaOCARswggEXMB0GA1UdDgQWBBTHz4/N4uhXoIpWZAlBRbq+7+aIkTAfBgNV
# HSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVo
# dHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1T
# dGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAC
# hj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBD
# QV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUF
# BwMIMA0GCSqGSIb3DQEBCwUAA4IBAQBBsPG05rk1r1UH+zEtTK/c7pA1RDH1pwFv
# 3mPzlf3lbW1Nh12AMKK/Ing2fr5lps0uPbN/VWBvkAQL76NbFWiZzWtmZBjUKPbJ
# +wifpX2qe2/M0I3BFdmNdGWT3dcthT513SO2km1XbxiK5PAXsOYlmq+mEkGceSuM
# qCQ9apcefzxe5vyhnpHKbTH4+Yf/uB3HhRPTKp1YkZySI1Yp5ic5uqlzVPlUEarm
# skYYueAPjmdKGKPvYbJGLHmRbIZQmOh9VQxSAxOoASN/TA+xRs51LIKknLiunlAh
# xLn1/BWhC4+CW7CbKeqtHKV4pEvFyp+cm9Lp5lBUF1XuPa7TyyIXMIIGcTCCBFmg
# AwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUw
# NzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDV
# pQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/x
# YIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFn
# kV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13
# Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaI
# CDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOC
# AeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYb
# xTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYw
# DwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoY
# xDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/
# BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUH
# AgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBl
# AG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z
# 66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lT
# jMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIA
# rzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWv
# L/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/
# fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZ
# JQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqw
# UB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d
# 9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLix
# qduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh
# 0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4I
# uto229Nfj950iEkSoYIC1zCCAkACAQEwggEAoYHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjNCRDQtNEI4MC02OUMzMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAoM8LvuSnUnUbrez5FdSTlglx95KCBgzCB
# gKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUA
# AgUA5E+p8DAiGA8yMDIxMDUxOTIzMTQ1NloYDzIwMjEwNTIwMjMxNDU2WjB3MD0G
# CisGAQQBhFkKBAExLzAtMAoCBQDkT6nwAgEAMAoCAQACAiBzAgH/MAcCAQACAhE4
# MAoCBQDkUPtwAgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAI
# AgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAG1WdY3W7nZLe
# RWGaiejc2Ho7BDWqi4OTZaYuIvmpExsSHSETjQV2mXX7usLwxTiHeQu7NRRentRb
# YMHSMFmcRk4KGwOM6IeJ3cJ0r4GrSb+n2fow403DPv6oz1xbie/T1aEOfPcq3Ol4
# AGHCmw1rBra3PW988OieiMbMsENV6qQxggMNMIIDCQIBATCBkzB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAATsSG5IjUgJapQAAAAABOzANBglghkgB
# ZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3
# DQEJBDEiBCBXPSMnF0C37y8Pd6nO2rKKPxzLoo/83FcPKfXVn2KenzCB+gYLKoZI
# hvcNAQkQAi8xgeowgecwgeQwgb0EIBw25zd5xSbYAm3Zn+9CxVW3UWtY7QDGUb0W
# O2ThxEAcMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMA
# AAE7EhuSI1ICWqUAAAAAATswIgQg7Y/LXJVlCCom7N8yK1gcv9Q4ek7CrjVywWV4
# i3KuP1QwDQYJKoZIhvcNAQELBQAEggEAOV0wDb046cDOCgiS1+zxjw2ozlwO/PFm
# CxVysc8OdP3+TskZCEtwzkiEl5u2Qdo4DC4pA1hx8gaFXWs85DNmqVUbyWV9wL+o
# vvjPoDWy2WN7E64ZE7wd7Z0SHKfvIh3g3sBmc39IPnbwxyk073YHrjViUuTvGp8R
# jLhV6trDoCKwbCRyDiAvBqH31iE8uHEkblNk4UNk/62P3LxjW08sKFXWSNEMs0PY
# ehpY8exoUp9znhb5y52OmejRlbLsVAbdnhYiCwoEp2hOVnLpViZzTb2cm+m/5RtA
# PC69m7XM+YISlxnB/xmAdnu6eKA2ZJC/wN43CoY6J8Hl0aSjtXNAeQ==
# SIG # End signature block
