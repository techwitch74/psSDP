﻿#************************************************
# DC_DnsServer-Component.ps1
# Version 1.0: Script created. Collecting output from DnsCmd, Registry and Event logs.
# Version 1.1: Added DNS pscmdlets for WS2012 and later
# Version 1.2.08.24.14: Made changes so the pscmdlets file would be created regardless of OS, and added the overview headings for DnsCmd. TFS264122
# Date: 2009-2014, 2020
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about the DNS Server.
# Called from: Networking Diags
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSDNSServer -Status $ScriptVariable.ID_CTSDNSServerDescription

function RunNetSH ([string]$NetSHCommandToExecute="")
{
	
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDNSServer -Status "netsh $NetSHCommandToExecute"
	
	$NetSHCommandToExecuteLength = $NetSHCommandToExecute.Length + 6
	"-" * ($NetSHCommandToExecuteLength) + "`r`n" + "netsh $NetSHCommandToExecute" + "`r`n" + "-" * ($NetSHCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c netsh.exe " + $NetSHCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	# displays the current PowerShell cmdlet
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDNSServer -Status "$RunPScmd"
	
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n`n`n"	| Out-File -FilePath $OutputFile -append	
}


function RunDnsCmd ([string]$DnsCmdCommand="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSDNSServer -Status "DnsCmd $DnsCmdCommand"
	
	$DnsCmdCommandLength = $DnsCmdCommand.Length + 6
	"-" * ($DnsCmdCommandLength) + "`r`n" + "DnsCmd $DnsCmdCommand" + "`r`n" + "-" * ($DnsCmdCommandLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c DnsCmd.exe " + $DnsCmdCommand + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n"	| Out-File -FilePath $OutputFile -append
}


$sectionDescription = "DNS Server"


#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

$outputFile= $Computername + "_DnsServer_info_pscmdlets.TXT"
"========================================"	| Out-File -FilePath $OutputFile -append
"DNS Server Powershell Cmdlets"				| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"Overview"	| Out-File -FilePath $OutputFile -append
"----------------------------------------"	| Out-File -FilePath $OutputFile -append
"DNS Server Configuration"	| Out-File -FilePath $OutputFile -append
"  1. Get-DnsServer"	| Out-File -FilePath $OutputFile -append
"     This powershell cmdlet includes the following output:"	| Out-File -FilePath $OutputFile -append
"       ServerSetting              (Get-DnsServerSetting)"	| Out-File -FilePath $OutputFile -append
"       ServerDsSetting            (Get-DnsServerDsSetting)"	| Out-File -FilePath $OutputFile -append
"       ServerScavenging           (Get-DnsServerScavenging)"	| Out-File -FilePath $OutputFile -append
"       ServerRecursion            (Get-DnsServerRecursion)"	| Out-File -FilePath $OutputFile -append
"       ServerDiagnostics          (Get-DnsServerDiagnostics)"	| Out-File -FilePath $OutputFile -append
"       ServerGlobalNameZones      (Get-DnsServerGlobalNameZones)"	| Out-File -FilePath $OutputFile -append
"       ServerCache                (Get-DnsServerCache)"	| Out-File -FilePath $OutputFile -append
"       ServerGlobalQueryBlockList (Get-DnsServerGlobalQueryBlockList)"	| Out-File -FilePath $OutputFile -append
"       ServerEdns                 (Get-DnsServerEdns)"	| Out-File -FilePath $OutputFile -append
"       ServerForwarder            (Get-DnsServerForwarder)"	| Out-File -FilePath $OutputFile -append
"       ServerRootHint             (Get-DnsServerRootHint)"	| Out-File -FilePath $OutputFile -append
"       ServerZone                 (Get-DnsServerZone)"	| Out-File -FilePath $OutputFile -append
"       ServerZoneAging            (Get-DnsServerZoneAging)"	| Out-File -FilePath $OutputFile -append
"  2. Get-DnsServerQueryResolutionPolicy"	| Out-File -FilePath $OutputFile -append
"  3. Get-DnsServerClientSubnet"			| Out-File -FilePath $OutputFile -append
"  4. Get-DnsServerRecursionScope"			| Out-File -FilePath $OutputFile -append
"  5. Get-DnsServerZoneTransferPolicy"		| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"`n`n`n`n`n"	| Out-File -FilePath $OutputFile -append


"=============================================="	| Out-File -FilePath $OutputFile -append
"DNS Server Configuration"	| Out-File -FilePath $OutputFile -append
"=============================================="	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
if ($bn -ge 9200)
{
	$dnsServerServiceStatus = get-service * | where {$_.name -eq "dns"}	
	if ($dnsServerServiceStatus -ne $null)
	{
		if ((Get-Service "dns").Status -eq 'Running')
		{
			RunPS "Get-DnsServer" 								# W8/WS2012, W8.1/WS2012R2	# large output with both ft and fl
			RunPS "Get-DnsServerQueryResolutionPolicy | fl *" 
			RunPS "Get-DnsServerClientSubnet | fl *"    	
			RunPS "Get-DnsServerRecursionScope | fl *"	
			RunPS "Get-DnsServerZoneTransferPolicy | fl *"
		}
		else
		{
			"The DNS Server service is not Running. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The DNS Server service does not exist on this computer. Not running pscmdlets." 	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The Get-DnsServer pscmdlet is only available in WS2012 and later. Not running pscmdlet."	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $OutputFile -fileDescription "DNS Server Information (Powershell)" -SectionDescription $sectionDescription



# DnsCmd Section
$outputFile= $Computername + "_DnsServer_info_DnsCmd.TXT"
"========================================"	| Out-File -FilePath $OutputFile -append
"DNS Server DnsCmd Output"					| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"Overview"	| Out-File -FilePath $OutputFile -append
"----------------------------------------"	| Out-File -FilePath $OutputFile -append
"DNS Server Configuration"	| Out-File -FilePath $OutputFile -append
"  1. DnsCmd /Info"	| Out-File -FilePath $OutputFile -append
"  2. DnsCmd /EnumDirectoryPartitions"	| Out-File -FilePath $OutputFile -append
"  3. DnsCmd /EnumZones"	| Out-File -FilePath $OutputFile -append
"  4. DnsCmd /Statistics"	| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append
"`n"	| Out-File -FilePath $OutputFile -append

$dnsServerServiceStatus = get-service * | where {$_.name -eq "dns"}	
if ($dnsServerServiceStatus -ne $null)
{
	if ((Get-Service "DNS").Status -eq 'Running')
	{
		RunDnsCmd "/Info"
		RunDnsCmd "/EnumDirectoryPartitions"
		RunDnsCmd "/EnumZones"
		RunDnsCmd "/Statistics"
	}
	else
	{
		"The DNS Server service is not Running. Not running DnsCmd commands." 	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The DNS Server service does not exist on this computer. Not running DnsCmd commands." 	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $OutputFile -fileDescription "DnsCmd Output" -SectionDescription $sectionDescription




#DNS Server Registry Section
$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\DNS"
if (Test-Path $SvcKey) 
{
	#----------Registry
	$OutputFile= $Computername + "_DnsServer_reg_.TXT"
	$CurrentVersionKeys = "HKLM\SYSTEM\CurrentControlSet\services\DNS" 
	$sectionDescription = "DNS Server registry"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true  -OutputFile $OutputFile -fileDescription "DNS Server Registry Key" -SectionDescription $sectionDescription
	
	$OutputFile= $Computername + "_DnsServer_Softw_reg_.TXT"
	$CurrentVersionKeys = "HKLM\Software\Microsoft\Windows NT\CurrentVersion\DNS Server" 
	$sectionDescription = "DNS Server registry Software"
	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true  -OutputFile $OutputFile -fileDescription "DNS Server Software Registry Key" -SectionDescription $sectionDescription
}


#----------Collect the DNS Server event log
#DNS Server Event Log
$EventLogNames = "DNS Server"
$Prefix = ""
$Suffix = "_evt_"
.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix

