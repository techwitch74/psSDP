﻿###########################################################################
# DC_Get-Network
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Creates Autotuning.txt, Firewall.txt, Netsh.txt, Winsock.txt, 
# Bitsadmin.txt, WPAD & PAC File Collection
###########################################################################



Import-LocalizedData -BindingVariable Net -FileName DC_Get_Network -UICulture en-us
Write-DiagProgress -Activity $Net.ID_Network -Status $Net.ID_Autotuning


$Blocks = "==========================================================================="

function command ($cmd)
	{
		$CommandLineToExecute = "cmd.exe /c $cmd >> $OutputFile"
		RunCmD -commandToRun $CommandLineToExecute
		$Blocks | Out-File ($OutputFile) -append
	}
	
function firewall ($cmd)
	{
		Invoke-Expression -Command $cmd | Out-File -Append $outputfile -Encoding ascii
	}
	
#Netsh_Autotuning.txt

if ($OSVersion.Major -gt 6)
{
	$OutputFile = $ComputerName + "_Netsh_Autotuning.txt"
	logStart 
	$Header = "Querying Active State..."
	#$Header | Out-File $OutputFile 
	$cmd = "netsh interface tcp show global" 
	command $cmd 
	Add-Content $OutputFile "To view Auto-Tuning settings: netsh interface tcp show global" -Encoding unknown 
	Add-content $Outputfile "To Disable Auto-Tuning:       netsh interface tcp set global autotuninglevel=disabled (requires restart)" -Encoding Unknown
	Add-content $OutputFile "Enable Auto-Tuning:           netsh interface tcp set global autotuninglevel=normal (requires restart)" -Encoding Unknown 
	
	CollectFiles -filesToCollect $OutputFile -fileDescription "Netsh Autotuning"  -sectionDescription "Network Configuration"
	logStop 
}

#Netsh_Firewall.txt
logstart 
Write-DiagProgress -Activity $Net.ID_Network -Status $Net.ID_Firewall
#Setting $OutputFile
$OutputFile = $ComputerName + "_Netsh_Firewall.txt"


#Add Header for Netsh Firewall Commands
Add-Content $OutputFile "Netsh Firewall commands..." 

$Header = "netsh firewall show allowedprogram - Shows firewall allowed program configuration."
$cmd = "netsh firewall show allowedprogram"
firewall $cmd
 
$Header = "netsh firewall show config - Shows firewall configuration."
$cmd = "netsh firewall show config" 
firewall $cmd

$Header = "netsh firewall show allowedprogram - Shows firewall allowed program configuration."
$cmd = "netsh firewall show currentprofile"
firewall $cmd

$Header = "netsh firewall show icmpsetting - Shows firewall ICMP configuration."
$cmd = "netsh firewall show icmpsetting"

$Header = "netsh firewall show logging - Shows firewall logging configuration."
$cmd = "netsh firewall show logging"
firewall $cmd

$Header = "netsh firewall show multicastbroadcastresponse - Shows firewall multicast/broadcast response configuration."
$cmd = "netsh firewall show multicastbroadcastresponse"
firewall $cmd

$Header = "netsh firewall show notifications - Shows firewall notification configuration."
$cmd = "netsh firewall show notifications"
firewall $cmd 

$Header = "netsh firewall show opmode - Shows firewall operational configuration."
$cmd = "firewall show opmode"
firewall $cmd

$Header = "netsh firewall show portopening - Shows firewall port configuration."
$cmd = "netsh firewall show portopening "
firewall $cmd 

$Header = "netsh firewall show service - Shows firewall service configuration."
$cmd = "netsh firewall show service"
firewall $cmd 

$Header = "netsh firewall show state - Shows current firewall state."
$cmd = "netsh firewall show state "
firewall $cmd
 
$Header = "netsh advfirewall show allprofiles - Displays properties for all profiles."
$cmd = "netsh advfirewall show allprofiles"
firewall $cmd
  
$Header = "netsh advfirewall show allprofiles - Displays properties for all profiles."
$cmd = "advfirewall show allprofiles"
firewall $cmd 
  
$Header = "netsh advfirewall show currentprofile - Displays properties for the active profile."
$cmd = "netsh advfirewall show currentprofile"
firewall $cmd 
 
$Header = "netsh advfirewall show store - Displays the policy store for the current session."
$cmd = "netsh advfirewall show store"
firewall $cmd 

$Header = "netsh advfirewall show global - Displays the global properties."
$cmd = "netsh dvfirewall show global"
firewall $cmd 
CollectFiles -filesToCollect $OutputFile -fileDescription "Firewall Configuration" -sectionDescription "Network Configuration"
logstop

#Collecting Netstat.txt
Write-DiagProgress -Activity $Net.ID_Network -Status $Net.ID_Netstat

$OutputFile = $ComputerName + "_Netstat.txt"
logstart
$CommandLineToExecute = "cmd.exe /c netstat -ano > $OutputFile"
RunCmD -commandToRun $CommandLineToExecute -filesToCollect ($OutputFile) -fileDescription "Netstat" -sectionDescription "Network Configuration"
logstop

#Network.txt
Write-DiagProgress -Activity $Net.ID_Network

$OutputFile = $ComputerName + "_Network.txt"
logstart
$Header = "ipconfig /all"
command $Header 


#net statistics server 
$Header = "net statistics server"
command $Header 

#net statistics Workstation
$Header = "net statistics workstation"
command $Header 

#arp -a  
$Header = "arp -a "
command $Header 

#nbtstat -c  
$Header = "nbtstat -c"
command $Header 
  
$Header = "netstat -r"
command $Header 

#ipconfig /displaydns  
$Header = "ipconfig /displaydns"
command $Header 

CollectFiles -filesToCollect $OutputFile -fileDescription "Network.txt" -sectionDescription "Network Configuration"
logstop

#Winsock.txt
Write-DiagProgress -Activity $Net.ID_Network -Status $Net.ID_Winsock

$ComputerName = $ENV:COMPUTERNAME
$OutputFile = $ComputerName + "_Winsock.txt"
logstart

$Header = "netsh winsock show catalog "
command $Header 

$Header = "netsh winsock show helper"
command $Header 

$Header = "netsh winsock show alias"
command $Header 

$Header = "REG.exe QUERY HKLM\SYSTEM\CurrentControlSet\Services\WinSock /s"
command $Header 

$Header = "REG QUERY HKLM\SYSTEM\CurrentControlSet\Services\WinSock2 /s"
command $Header 

CollectFiles -filesToCollect $OutputFile -fileDescription "Winsock.txt" -sectionDescription "Network Configuration"
logstop 

$OutputFile = ""

# WPAD and PAC Files
#Write-DiagProgress -Activity $Net.ID_Network -Status $Net.ID_PAC
#"Start collecting PAC and WPAD Files" | WriteTo-StdOut 

if ($OSVersion.Major -gt 6)
	{
		$source = "$ENV:HOMEDRIVE\Users"
		"Windows Vista or higher detected" | WriteTo-StdOut
		"Setting profile path to " + $source | WriteTo-StdOut 
	}
else
	{
		"Windows XP or 2003 detected" | WriteTo-StdOut 
		$source = "$ENV:HOMEDRIVE\Documents and Settings"
		"Setting profile path to " + $source | WriteTo-StdOut
	}

function get-wpad ($dir)
	{	
		Get-ChildItem -Recurse -Force $dir -Include *.dat | Where-Object {$_.Name -like "*wpad*"} | ForEach-Object {
		Get-Content $_.FullName} | ForEach-Object {
		$OutputFile = $ComputerName + "_WPAD.DAT_" + $fName
	    "Collecting " + $OutputFile | WriteTo-StdOut 
		}
		
		CollectFiles -filesToCollect $OutputFile -fileDescription "WPAD File"  -sectionDescription "Network Configuration"

		Get-ChildItem -Recurse -Force $dir -Include *.dat | Where-Object {$_.Name -like "*pac*"} | ForEach-Object {
		Get-Content $_.FullName} | ForEach-Object {
		$OutputFile = $ComputerName + "_PACFile_" + $fName 
		"Collecting " + $OutputFile | WriteTo-StdOut 
		}

		CollectFiles -filesToCollect $OutputFile -fileDescription "PAC File" -sectionDescription "Network Configuration"
	}


#$dir = $ENV:HOMEPATH
#$fName = $ENV:USERNAME + ".txt"
#get-wpad $dir

#$dir = $source + "\NetworkService"
#$fName = "NetworkService.txt"
#get-wpad $dir 

#$dir = $source + "\Default User"
#$fName = "DefaultUser.txt"
#get-wpad $dir

#$dir = $source + "\Administrator"
#$fName = "Administrator.txt"
#get-wpad $dir

#$dir = $source + "\LocalService"
#$fName = "LocalService.txt"
#get-wpad $dir

#"Finished collecting PAC and WPAD Files" | WriteTo-StdOut

# Bitsadmin

$AllUsers = $Env:ALLUSERSPROFILE
$OutputFile = $ComputerName + "_BitsAdmin.txt"
logstart 
Add-Content $OutputFile "bitsadm.txt"

#$Blocks = "======================================================================================="

function bits ($bitscmd)
	{
		$CommandLineToExecute = "cmd.exe /c bitsadmin.exe $bitscmd >> $OutputFile"
		#$Blocks | Out-File -Append $OutputFile 
		#$CommandLineToExecute 
		Invoke-Expression -command $bitscmd | Out-File -Append $outputfile -Encoding ascii 
		#RunCmD -commandToRun $CommandLineToExecute 
	}

$bitscmd = "bitsadmin.exe /list /allusers /verbose"
bits $bitscmd

$bitscmd = "bitsadmin.exe /util /GetIEProxy LocalSystem"
bits $bitscmd 

$bitscmd = "bitsadmin.exe util /GetIEProxy networkservice"
bits $bitscmd  

$bitscmd = "bitsadmin.exe /util /version /verbose"
bits $bitscmd 

Get-ChildItem "$AllUsers\Application Data\Microsoft\Network\Downloader\*.*" | Out-File $OutputFile -Append -Encoding ascii 


#$CommandLineToExecute = "cmd.exe /c dir `"$AllUsers\Application Data\Microsoft\Network\Downloader\*.*`" /X /OD /TC /S /L >> $OutputFile"
#bits $bitscmd 

CollectFiles -filesToCollect $OutputFile -fileDescription "BITS Data" -sectionDescription "Network Configuration"

logstop 
