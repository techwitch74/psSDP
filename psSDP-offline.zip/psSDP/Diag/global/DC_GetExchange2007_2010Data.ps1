﻿#################################################################################
# Copyright © 2008, Microsoft Corporation. All rights reserved.
#
# You may use this code and information and create derivative works of it, provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for # troubleshooting a) Windows and b) products for Windows, in either case using the Windows Troubleshooting Platform
# 2. Any copies of this code and information and any derivative works must retain the above copyright notice, this list of # conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
#    WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
#    OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
#    INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
#    WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.
#################################################################################
# DC_GetExchange2007_2010Data.ps1
# Version 3.7.0
# Date: 2013-04-25
# Author: Brian Prince - brianpr@microsoft.com
# Description: Collects Exchange Server 2007 and Exchange Server 2010 information
#################################################################################

PARAM ([switch]$getSetupLogs, [switch]$getExBPA)

######################
## Output Functions ##
######################

function out-zip ($FilePath,$zipFileName){
        $oZipFileName = $zipFileName
        $ZipFileName = ($PWD.Path) + "\" + ($env:COMPUTERNAME + "_") + $zipFileName
        if (-not $zipFileName.EndsWith('.zip')) {$zipFileName += '.zip'} 
        
        Write-DiagProgress -Activity ($GetExchDataStrings.ID_GetExchDataCompressingAct) -Status ($GetExchDataStrings.ID_GetExchDataCompressingStatus + " " + $oZipFileName + ".zip")
        
        if (-not (Test-Path($ZipFileName))) {Set-Content $ZipFileName ("PK" + [char]5 + [char]6 + ("$([char]0)" * 18))}
        
        $ZipFileObj = (new-object -com Shell.Application).NameSpace($ZipFileName)
        
        $sleepCounter = 0
        $zipItemCounter = 0
        $itemsToZipCount = $FilePath.count
        $InitialZipItemCount = 0
        $InitialZipItemCount = $ZipFileObj.Items().Count            
        
        foreach ($file in $FilePath){
        
            $ZipFileObj.CopyHere($file.FullName)
            $zipItemCounter += 1
            
            do{
                sleep -Milliseconds 500
                $sleepCounter += 1
            } while (($ZipFileObj.Items().Count -lt $zipItemCounter) -and ($sleepCounter -lt 600))
        }

        return $zipFileName
}

Function New-DDF($path,$filePath)
{
 $ddfFile = Join-Path -path $path -childpath temp.ddf
 $cabName = Split-Path -path $filepath -leaf
 #"DDF file path is $ddfFile"
 $ddfHeader =@"
;*** MakeCAB Directive file
;
.OPTION EXPLICIT      
.Set CabinetNameTemplate=$cabName.cab
.set DiskDirectory1=$path
.set CompressionType=MSZIP
.Set MaxDiskSize=0
.Set Cabinet=on
.Set Compress=on
"@
 #"Writing ddf file header to $ddfFile" 
 $ddfHeader | Out-File -filepath $ddfFile -force -encoding ASCII
 #"Generating collection of files from $filePath"
 Get-ChildItem -path $filePath | Where-Object { !$_.psiscontainer } | ForEach-Object `
 { 
 '"' + $_.fullname.tostring() + '"' | 
 Out-File -filepath $ddfFile -encoding ASCII -append
 }
 #"ddf file is created. Calling New-Cab function"
 New-Cab($ddfFile)
} #end New-DDF

Function New-Cab($ddfFile)
{
 #"Entering the New-Cab function. The DDF File is $ddfFile"
 makecab /f $ddfFile | Out-Null
} #end New-Cab

#############################################
#############################################
##                                         ##
##  Begin Exchange Data Collection Section ##
##                                         ##
#############################################
#############################################

################
# Main Exchange Data Collection Function
################
function Get-ExchangeData {
    "Starting Get-ExchangeData" | WriteTo-StdOut
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    #Get the machine name
    $machineName = ${env:computername}
    
    #Initialize the Output Filename Prefix and Exchange Server Name variables
    $script:rootOutFile = Join-Path $pwd.Path.ToString() $machinename
    $Script:ExchangeServerName = $null
    Write-DebugLog ("Calling utils_exchange Function: GetExchangeVersionInstalled")
    
    If (($global:ExchInstalled -eq $true) -and ($global:IsExchPSSnapin -eq $true)) #values should be populated by utils_exchange
	{
        if (Get-ExchangeServerLocalCached){#($isExchServerFound = $true){
            Write-DebugLog ("Exchange Server Name: $Script:ExchangeServerName")
            $ExVersion = (Get-ExchangeServerLocalCached).AdminDisplayVersion.Major 
            if ($ExVersion -eq 8){[bool]$script:Exchange2007 = $true}
            elseif ($ExVersion -eq 14){[bool]$script:Exchange2010 = $true}
            Write-DebugLog ("Exchange Version: $ExVersion")

            $ExchangeServer = Get-ExchangeServerLocalCached
			$Script:ExchangeServerName = $ExchangeServer.Name
          
            Write-DebugLog ("Function: GetCommonServerData")
            GetCommonServerData

            Write-DebugLog ("Function: GetIISInfo")
            GetIISInfo

            if($ExchangeServer.IsMailboxServer){
                Write-DebugLog ("Function: GetMailboxServerData")
                GetMailboxServerData
            }
            if($ExchangeServer.IsClientAccessServer){
                Write-DebugLog ("Function: GetClientAccessServerData")
                GetClientAccessServerData
            }
            if($ExchangeServer.IsHubTransportServer){
                Write-DebugLog ("Function: GetHubTransportServerData")
                GetHubTransportServerData
            }
            if($ExchangeServer.IsUnifiedMessagingServer){
                Write-DebugLog ("Function: GetUnifiedMessagingServerData")
                GetUnifiedMessagingServerData
            }
            if(((Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\ExchangeDominoConnector") -eq $true)-or ((Test-Path "HKLM:\SYSTEM\CurrentControlSet\Services\MSExchangeCalcon")-eq $true)){
                Write-DebugLog ("Function: GetTransporterSuite")
                GetTransporterSuite
            }
            
            Write-DebugLog ("Done!")
                    
            CollectFiles -filestocollect ($script:rootOutFile + "__GetExchangeData_LOG.TXT") -filedescription ("Get-ExchangeData Script Log" ) -sectiondescription ("zExchange Troubleshooter Logs") -noFileExtensionsOnDescription
            CollectFiles -filestocollect ($script:rootOutFile + "__GetExchangeData_No_Result.TXT") -filedescription "Get-ExchangeData Script cmd without result" -sectiondescription ("zExchange Troubleshooter Logs") -noFileExtensionsOnDescription
        }

    }    
    Else{
        "Exchange Server Not Installed or Exchange Powershell Snapin Failed to Load or Get-ExchangeServer Failed." | WriteTo-StdOut
    }
#
#"Clearing Error." | WriteTo-StdOut
#$Error.Clear()
}

#############################
# Basic data collected for all Exchange server roles
#############################
function GetCommonServerData {
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Server and Organization Baseline"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerCommon)
    #[void]$shell.popup($script:RActivity)
    #[void]$shell.popup($GetExchDataStrings.ID_GetExchDataCollectingAct)
    
    $installPath = $global:exinstall
    $exSetup = (Join-Path $installPath \bin\exsetup.exe)
    $script:productversion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($exSetup).ProductVersion
	
	#Detect Service Pack
	$script:SPInstalled = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($exSetup).ProductMinorPart
	
	#Detect Update Rollup
	If (Test-Path HKLM\SOFTWARE\MICROSOFT\UPDATES)
	{
		$UpdatedProducts = Resolve-Path -Path 'HKLM:SOFTWARE\MICROSOFT\UPDATES\*'
		ForEach ($Product in $UpdatedProducts)
		{
			If ($Product = "Exchange 2007")
			{
				$E2K7Updates_SP = Resolve-Path -Path 'HKLM:SOFTWARE\MICROSOFT\UPDATES\EXCHANGE 2007\*'
				Foreach ($E2K7UpdateSP in $E2K7Updates_SP)
				{
					$E2K7Updates_KB = Resolve-Path -Path 'HKLM:SOFTWARE\MICROSOFT\UPDATES\EXCHANGE 2007\*'
				}
			}
			If ($Product = "Exchange 2010")
			{
			
			}
			
		}
	}
	
    
	#Detect Interim Updates
    $IUDetected = $global:exregSetupKey.GetValue("InterimUpdate")
    If ($IUDetected){
        $script:IUInstalled = $IUDetected.ToString()
    } 
    Else{
        $script:IUInstalled = "None"
    }
    
    # Update MSDT report with Exchange Server version and roles if run under WTP / PowerShell 2.0
    if($Host.Version.Major -ge 2){
        displayExchangeServers
    }

    ExportResults -cmdlet "Write-Output '$Script:ExchangeServerName exsetup.exe ProductVersion: $script:productversion' ; Get-ExchangeServer | Select-Object Name,AdminDisplayVersion,Site,ServerRole" -outformat "FL" -filename "AllExchangeServers" -filedescription "All Exchange Servers - Version Site and Roles"
    ExportResults -cmdlet "Get-ExchangeCertificate" -outformat "FL" -filename "ExchangeCertificate"
    ExportResults -cmdlet "Get-ExchangeServer -identity $Script:ExchangeServerName -status"
    ExportResults -cmdlet "Get-AcceptedDomain"
    ExportResults -cmdlet "Get-RemoteDomain"
    ExportResults -cmdlet "Get-OrganizationConfig"
    ExportResults -cmdlet "Get-EmailAddressPolicy"
    ExportResults -cmdlet "Get-AvailabilityAddressSpace"
    ExportResults -cmdlet "Get-AvailabilityConfig"
    
##### Exchange 2010-specific output #########
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-UserPrincipalNamesSuffix"
        ExportResults -cmdlet "Get-ThrottlingPolicy" #56c20cd2-91c7-48d3-889d-be2a9510569a
        ExportResults -cmdlet "Get-PowerShellVirtualDirectory -Server '$Script:ExchangeServerName'" -outformat "FL"
        If (Get-FederationTrust){
            ExportResults -cmdlet "Get-FederationTrust"
            ExportResults -cmdlet "Test-FederationTrustCertificate"
            ExportResults -cmdlet "Get-FederatedOrganizationIdentifier -IncludeExtendedDomainInfo ?Verbose"
            ExportResults -cmdlet "Get-OrganizationRelationship"
            # Get-FederationInformation -Domain <the hosted Exchange domain namespace> - run against all domains in accepteddomain
			# on O365, run against verified domains from MSOL
			# Get-MSOLDomain returns all domains. One of the properties is status "verified" or "not verified"
			# http://support.microsoft.com/kb/2626696/EN-US
            
        }
        GetHybridConfigLogs
        
    }
#####/End Exchange 2010-specific output #####
#############################################

    Write-DebugLog ("Function: GetFiles -sourcePath $exinstall -targetFolder 'ExchangeConfigFiles' -reportsection 'Exchange Setup Information' -include '*.config' -recurse -cab")
    GetFiles -sourcePath $exinstall -targetFolder "ExchangeConfigFiles" -reportsection "Exchange Setup Information" -include "*.config" -recurse -cab
    
    
    if ($script:paramGetSetupLogs -eq $true){
        $ExchangeSetupLogPath = (Join-Path $global:SystemDrv "ExchangeSetupLogs")
		If (Test-Path $ExchangeSetupLogPath)
		{
			$ExchangeSetupLogPath = Join-Path -Path $ExchangeSetupLogPath -ChildPath "\*.*"
        	CompressCollectFiles -filesToCollect $ExchangeSetupLogPath -fileDescription ("Setup logs modified in past 14 days") -DestinationFileName "ExchangeSetupLogs.zip" -sectionDescription "Exchange Setup Information" -NumberOfDays 14 -Recursive 
        }
    }
    
    
    Write-DebugLog ("Function: GetExchangeRegistryKeys")
    GetExchangeRegistryKeys

#### Exchange Toolbox Output Collection #####
    #Get files from most recent Exchange Performance Troubleshooting Analyzer if less than 14 days old.
    If (Test-Path HKCU:Software\Microsoft\ExchangeServer\v14\ExPTA){
        $PTADataFolderPath = (Get-ItemProperty HKCU:Software\Microsoft\ExchangeServer\v14\ExPTA).DefaultDataFolder
    }
    If (Test-Path HKCU:Software\Microsoft\Exchange\ExPTA){
        $PTADataFolderPath = (Get-ItemProperty -Path HKCU:Software\Microsoft\Exchange\ExPTA -Name DefaultDataFolder)
    }
    If ($PTADataFolderPath -ne $null){
        $PTADataFolder = "ExPTA_" + (Split-Path $PTADataFolderPath -Leaf)
        If ((Test-Path $PTADataFolderPath)-and ((Get-Item $PTADataFolderPath).CreationTime -ge (get-date).AddDays(-14))){
            Write-DebugLog ("Function: GetFiles -sourcePath '$PTADataFolderPath' -targetFolder 'ExPTAData' -filedescription 'Exchange Performance Troubleshooting Assistant Files' -include '*.*' -recurse -cab")
            GetFiles -sourcePath "$PTADataFolderPath" -targetFolder "ExPTAData" -filedescription "Exchange Performance Troubleshooting Assistant Files" -reportsection "Exchange Toolbox" -include "*.*" -recurse -cab
        }
    }
    
    #Get files from Exchange Troubleshooting Analyzer Tracing
    $LogLocationXMLFileName = Join-Path -Path $global:exbin -childpath TraceFileConfig.xml
    If (Test-Path $LogLocationXMLFileName){
        [xml]$LogLocationXML = Get-Content -Path $LogLocationXMLFileName
        $ETLLogpath = ($LogLocationXML.selectsinglenode("TraceFile")).getattribute("FilePath")
        If ((Get-ChildItem $ETLlogpath -include *.etl -Recurse) -ne $null){
            Write-DebugLog ("Function: GetFiles -sourcePath '$ETLLogpath' -targetFolder 'ExTRATrace' -filedescription 'Exchange Troubleshooting Analyzer Trace Files' -include '*.etl' -recurse -cab")
            GetFiles -sourcePath "$ETLlogpath" -targetFolder "ExTRATrace" -filedescription "Exchange Troubleshooting Assistant Trace Files" -reportsection "Exchange Toolbox" -include "*.etl" -recurse -agemaxdays "14" -cab
        }
    }
}

#======================================
# Write Exchange Server version and role(s) information to MSDT diagnostic report when running under Win7 Troubleshooting Framework
#======================================
function displayExchangeServers{
    trap [System.Exception]{
    Write-DebugLog ("ERROR: " + $_); Continue}
    
    $allExchangeServers = (Get-ExchangeServer $Script:ExchangeServerName)
    $allExchangeServers_Summary = New-Object PSCustomObject
    #$script:IUInstalled
    foreach ($Server in $allExchangeServers)
	{
        $exServername = $Server.Name
        If ($script:IUInstalled -eq "None"){
            $exServerVersionRole = "ProductVersion:" + $script:productversion + "<br/>" + "InterimUpdate: " + $script:IUInstalled + "<br/>" + "Site: " + $Server.Site + "<br/>" + "Role(s): " + ([system.string]::join(",",($Server.ServerRole)))
        }
        Else{
            $exServerVersionRole = "ProductVersion:" + $script:productversion + "<br/>" + "InterimUpdate: " + $script:IUInstalled + "<br/>" + "Site: " + $Server.Site + "<br/>" + "Role(s): " + ([system.string]::join(",",($Server.ServerRole)))
        }
        Add-Member -InputObject $allExchangeServers_Summary -MemberType NoteProperty -Name $exServername -Value $exServerVersionRole
			# Site
    $sb.AppendFormat("Site: {0}<br/>", $server.Site) | Out-Null
    }
    $allExchangeServers_Summary | ConvertTo-Xml2 | Update-DiagReport -Id 00_ExchangeServer_Summary -Name "Exchange Server Version Site and Role" -Verbosity informational #Get Name from Strings File
    #[void]$shell.popup(($allExchangeServers_Summary | ConvertTo-Xml2).innerxml)
}


##################
# Data Collected for Exchange Mailbox Server Role
##################

function GetMailboxServerData{
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Mailbox Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerMailbox)

    $mailboxDatabases = Get-MailboxDatabase -server $ExchangeServer
    $publicFolderDatabases = Get-PublicFolderDatabase -server $ExchangeServer
    $WorkingDirPath = (get-itemproperty -path HKLM:\SYSTEM\CurrentControlSet\Services\MSExchangeIS\ParametersSystem)."Working Directory"
    
    ExportResults -cmdlet "Get-MailboxServer -identity $Script:ExchangeServerName -Status" -outformat "FL"

    #Dump properties and EDB File Path inventory for each Mailbox Database
    foreach($mailboxDatabase in $mailboxDatabases){
        $mbEdbFilePath = Split-Path -Path ($mailboxDatabase.EdbFilePath) -Parent
        if ($ExchangeVersion -eq 8){
            $mbdbn = ("SG_" + $mailboxDatabase.StorageGroupName + "_DBMb_" + $mailboxDatabase.Name + "_")
            $edbfp = ("SG_" + $mailboxDatabase.StorageGroupName + "_DBMb_" + $mailboxDatabase.name + "_EDBFilePath")
        }
        if ($ExchangeVersion -eq 14){
            $mbdbn = ("DBMb_" + $mailboxDatabase.Name + "_")
            $edbfp = ("DBMb_" + $mailboxDatabase.name + "_EDBFilePath_Contents")
        }
        ExportResults -cmdlet "Get-MailboxDatabase '$mailboxDatabase' -Status" -outformat "FL" -filename "$mbdbn"
        ExportResults -cmdlet "Get-Childitem -path '$mbEdbFilePath'" -outformat "FT" -filename "$edbfp"
    }
    
    #Dump properties, \NON_IPM_SUBTREE and EDB File Path inventory for each Public Folder Database
    if ($publicFolderDatabases -ne $null){
        foreach($publicFolderDatabase in $publicFolderDatabases){
            $pfEDBFilePath = Split-Path -Path ($publicFolderDatabase.EdbFilePath) -Parent
            if ($ExchangeVersion -eq 8){
                $pfdbn = ("SG_" + $publicFolderDatabase.StorageGroupName + "_DBPf_" + $publicFolderDatabase.Name + "_")
                $edbfp = ("SG_" + $publicFolderDatabase.StorageGroupName + "_DBPf_" + $publicFolderDatabase.name + "_EDBFilePath")
                $nipmflds = ("SG_" + $publicFolderDatabase.StorageGroupName + "_DBPf_" + $publicFolderDatabase.name + "_NON_IPM_SUBTREE")
            }
            if ($ExchangeVersion -eq 14){
                $pfdbn = ("DBPf_" + $publicFolderDatabase.Name + "_")
                $edbfp = ("DBPf_" + $publicFolderDatabase.name + "_EDBFilePath")
                $nipmflds = ("DBPf_" + $publicFolderDatabase.name + "_NON_IPM_SUBTREE")
            }
            ExportResults -cmdlet "Get-PublicFolderDatabase '$publicFolderDatabase'" -outformat "FL" -filename "$pfdbn"
            ExportResults -cmdlet "Get-Childitem -path '$pfEDBFilePath'" -outformat "FT" -filename "$edbfp"    
            ExportResults -cmdlet "Get-PublicFolder -server '$ExchangeServer' -identity '\NON_IPM_SUBTREE' -Recurse" -outformat "FT FL CSV" -filename "$nipmflds"
        }
    }
    
    ## Collect any Store.FCL files that are present under Exchange/Logging folder if last write time less than 14 days.
    $FCLLoggingPath = Join-Path $global:exinstall Logging
    $FCLFiles = Get-ChildItem $FCLLoggingPath -Filter *.fcl
    
    If ($FCLFiles -ne $null){
        ForEach ($file in $FCLFiles){
            If ($file.LastWriteTime -ge (Get-Date).AddDays(-14)){
                $collectFCL = $true
            }
        }
        $StoreFCLFolder = "ExchangeStoreFCL" #+ (Split-Path $FCLLoggingPath -Leaf)
        If ($collectFCL -eq $true){
            Write-DebugLog ("Function: GetFiles -sourcePath '$FCLLoggingPath' -targetFolder '$StoreFCLFolder' -filedescription 'Exchange Store.FCL File(s)' -include '*.fcl' -recurse -cab")
            GetFiles -sourcePath "$FCLLoggingPath" -targetFolder "$StoreFCLFolder" -filedescription "Exchange Store.FCL File(s)" -include "*.fcl" -recurse -cab
        }
    }
    


    ###################
    #Exchange 2007-only
    ###################
    if ($ExchangeVersion -eq 8){
        $storageGroups = Get-StorageGroup -Server $ExchangeServer

        #Dump properties for each Storage Group, and log & system folder directory inventory 
        foreach($storageGroup in $storageGroups)
        {
        $sgName = ("SG_" + $storageGroup.name + "_")
        $SgLf = ("SG_" + $storageGroup.name + "_LogFolderPath")
        $SgSf = ("SG_" + $storageGroup.name + "_SystemFolderPath")
        $LogFldPath = $storageGroup.LogFolderPath.PathName
        $SysFldPath = $storageGroup.SystemFolderPath.PathName
            ExportResults -cmdlet "Get-StorageGroup '$storageGroup'" -outformat "FL" -filename "$sgName"
            ExportResults -cmdlet "Get-ChildItem -path '$LogFldPath'" -outformat "FT" -filename "$SgLf"
            ExportResults -cmdlet "Get-ChildItem -path '$SysFldPath'" -outformat "FT" -filename "$SgSf"
        }
        if ($ExchangeServer.IsMemberOfCluster -eq "Yes"){
            ExportResults -cmdlet "Get-ClusteredMailboxServerStatus -Identity '$Script:ExchangeServerName'" -outformat "FL"
            ExportResults -cmdlet "Get-StorageGroupCopyStatus" -outformat "FL"
            
            #Export status of SCR-enabled storage groups if present - Added 04/30/2010
            $SCRSGs = Get-StorageGroup -Server $ExchangeServer | Where-Object {$_.StandbyMachines.Count -gt 0} 
            If ($SCRSGs -ne $null){
                ForEach ($SG in $SCRSGs){
                    $SCRStandbyMachines = $SCRSGs | ForEach-Object {$_.standbymachines}
                    ForEach ($node in $SCRStandbyMachines){
                        $nn = ($node.NodeName).tostring()
                        $fn = ("SG_" + $SG.name + "_StandbyMachine_" + $nn)
                        ExportResults -cmdlet "Get-StorageGroupCopyStatus -Identity '$SG' -StandbyMachine '$nn'" -outformat "FL" -filename "$fn"
                    }    
                }
            }
        }
    }
    
    ###################
    #Begin Exchange 2010-only section
    ###################
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-MailboxDatabaseCopyStatus -Server '$ExchangeServer'" -outformat "FL"
        ExportResults -cmdlet "Get-StoreUsageStatistics -Server '$ExchangeServer'" -outformat "FL"
    
        #Dump Log Folder Path, Database Availability Group properties for each Mailbox Database
        $DAGnames = $null
        foreach($mailboxDatabase in $mailboxDatabases){
            $mbLogFolderPath = $mailboxDatabase.LogFolderPath.PathName
            
            if ($mbEdbFilePath -ne $mbLogFolderPath){
                $fn = ("DBMb_" + $mailboxDatabase.name + "_LogFolderPath")
                ExportResults -cmdlet "Get-ChildItem -path '$mbLogFolderPath'" -outformat "FT" -filename "$fn"
            }
            if ($mailboxDatabase.MasterType -eq "DatabaseAvailabilityGroup"){
                $DAGnames += $mailboxDatabase.MasterServerOrAvailabilityGroup
            }
        }

        if ($DAGnames -ne $null){
            $uDagNames = ($DAGNames | Get-Unique)
            foreach($uDAG in $uDagNames){
                ExportResults -cmdlet "Get-DatabaseAvailabilityGroup -id '$uDAG' -Status" -filename "DAG_$uDAG" 
            }
            ExportResults -cmdlet "Get-DatabaseAvailabilityGroupNetwork -server '$ExchangeServer'" -filename "DAGNetworks" -outformat "FL"
        }
        
        
        #Dump Log Folder Path inventory for each Public Folder Database
        if ($publicFolderDatabases -ne $null){
            foreach($publicFolderDatabase in $publicFolderDatabases){
                $pfLogFolderPath = $publicFolderDatabase.LogFolderPath.PathName
                $fn = ("DBPf_" + $publicFolderDatabase.name + "_LogFolderPath")
                ExportResults -cmdlet "Get-ChildItem -path '$pfLogFolderPath'" -outformat "FT" -filename "$fn"
            }
        }
    }
    
    ##
    #End version-specific information
    ##
    
    #Properties of the server InformationStore object from Active Directory via ADSI
    $ExchangeServerDn = $ExchangeServer.DistinguishedName
      $isDn = "CN=InformationStore," + $ExchangeServerDn
      $LDAPAddress = "LDAP://" + $isDN
      $InformationStore = [ADSI]$LDAPAddress
    $ADSI_MSExchISPropertiesFromAD = $InformationStore.psBase.Properties
    ExportResults -cmdlet ('$ADSI_MSExchISPropertiesFromAD') -outformat "FT FL" -filename "InformationStore_ADSIProperties"
    
    #Inventory of files, if any, in MSExchangeIS Working Directory
    If ((Get-Childitem -path $WorkingDirPath) -ne $null){
        ExportResults -cmdlet "Get-ChildItem -Path '$WorkingDirPath' -recurse -Include *.* | Where-Object { !`$_.psiscontainer } | Select-Object DirectoryName, FullName, Length, IsReadOnly, CreationTimeUtc, LastWriteTimeUtc" -outformat "FL" -filename "MSExchangeIS_WorkingDirectory"
    }
}

##################
# Data Collected for Exchange Client Access Server Role
##################

function GetClientAccessServerData {
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Client Access Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerCAS)
    
    Write-DebugLog (Get-ReportSection)
    ExportResults -cmdlet "Get-ClientAccessServer -Identity '$Script:ExchangeServerName'"
    ExportResults -cmdlet "Get-PopSettings -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-ImapSettings -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-ActiveSyncVirtualDirectory -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-ActiveSyncMailboxPolicy"
    ExportResults -cmdlet "Get-OutlookAnywhere -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-OutlookProvider" #Added 10/29/2010 brianpr
    ExportResults -cmdlet "Get-AutodiscoverVirtualDirectory -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-OabVirtualDirectory -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-OwaVirtualDirectory -Server '$ExchangeServer'"
    ExportResults -cmdlet "Get-WebServicesVirtualDirectory -Server '$ExchangeServer'"
    
    $regkeys = "HKLM:SOFTWARE\Microsoft\Rpc\RpcProxy"
      $outfile = ($script:rootOutFile + "_REG_RPCPROXY.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:SOFTWARE\Microsoft\Rpc\RpcProxy*") -sectiondescription (Get-ReportSection) -Recursive $true
    
    Write-DebugLog ("Function: GetIISLogs")
    GetIISLogs
    
    ###################
    #Exchange 2010-only cmdlets
    ###################
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-RPCClientAccess"
        Write-DebugLog ("Function: GetRPCClientAccessLogs")
        GetRPCClientAccessLogs
        Write-DebugLog ("Function: GetAddressBookServiceLogs")
        GetAddressBookServiceLogs
        
        # RID:2944 SSID:f446a1fe-2d73-4adb-91e3-a913afeafae2 DA:20120229
            ExportResults -cmdlet "Get-EcpVirtualDirectory -Server '$ExchangeServer'"
        
        
    }
    
    #####
    #ToDo
    #####
    #Need to get the list of mobile devices to support the following command
    #InvokeExpression(("Get-ActiveSyncDeviceStatistics -Server " + $ExchangeServer.identity))
}

##################
# Data Collected for All Transport Server Roles
##################
function GetCommonTransportServerData(){
    trap [Exception] {
        Log-Error $_
        Continue
    }
    #global:section = "Exchange Transport Server Roles"

    ExportResults -cmdlet "Get-TransportConfig"
    ExportResults -cmdlet "Get-TransportServer -identity '$Script:ExchangeServerName'"
    ExportResults -cmdlet "Get-ReceiveConnector -server '$ExchangeServer'"
    ExportResults -cmdlet "Get-SendConnector"
    ExportResults -cmdlet "Get-TransportAgent"
    ExportResults -cmdlet "Get-TransportPipeline"
    ExportResults -cmdlet "Get-EdgeSubscription"
    ExportResults -cmdlet "Get-Queue"
    
    #Get the newest 4 routing logs
    $TransportServer = Get-TransportServer -identity $Script:ExchangeServerName
    $routingLogPath = ($TransportServer.RoutingTableLogPath.PathName + "\")
    GetFiles -sourcePath "$routingLogPath" -targetFolder "Logs_Routing" -include "Routing*.xml" -Recurse -newest "4" -cab

    #Get the newest 5 agent logs
    If (Test-Path (Join-Path $global:exinstall TransportRoles\Logs\AgentLog\*.log)){
        $AgentLogPath = (Join-Path $global:exinstall TransportRoles\Logs\AgentLog)
        GetFiles -sourcePath "$AgentLogPath" -targetFolder "Logs_Agent" -include "*.log" -Recurse -newest "5" -cab
    }
    
    Write-DebugLog ("Function: GetMessageTrackingLogs")
    GetMessageTrackingLogs
	
	Write-DebugLog ("Function: GetConnectivitylogs")
	GetConnectivitylogs

    ###################
    #Exchange 2010-only
    ###################
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-EdgeSyncServiceConfig"
    }
    
    
    Write-DebugLog ("GetTransportRules")
    GetTransportRules
    
    Write-DebugLog ("GetAntispamConfig")
    GetAntispamConfig
}

function GetTransportRules
{
    trap [Exception] {
        Log-Error $_
        Continue
    }

    ExportResults -cmdlet "Get-TransportRule" -outformat "FL"
    
    if ($ExchangeVersion -eq 8){
        
        #Delete the TransportRuleCollection if it already exists, otherwise script may hang here
        $ExportedTransportRules = $script:rootOutFile + "_ExportedTransportRules.xml"
        If( [System.IO.File]::Exists($ExportedTransportRules) ){
            Remove-Item $ExportedTransportRules
        }
        
        Write-DebugLog ("Export-TransportRuleCollection $ExportedTransportRules")
        Export-TransportRuleCollection $ExportedTransportRules
        CollectFiles -filestocollect ($ExportedTransportRules) -filedescription ("Export-TransportRuleCollection") -sectiondescription (Get-ReportSection) -noFileExtensionsOnDescription
    }
    
    if ($ExchangeVersion -eq 14){
        $ExportedTransportRules = Export-TransportRuleCollection
        Set-Content -Path ($script:rootOutFile + "_ExportedTransportRules.xml") -Value $ExportedTransportRules.FileData -Encoding Byte

        $ExportedLegacyTransportRules = Export-TransportRuleCollection -ExportLegacyRules
        Set-Content -Path ($script:rootOutFile + "_ExportedLegacyTransportRules.xml") -Value $ExportedLegacyTransportRules.FileData -Encoding Byte
        CollectFiles -filestocollect ($script:rootOutFile + "_ExportedTransportRules.xml") -filedescription ("Export-TransportRuleCollection") -sectiondescription (Get-ReportSection) -noFileExtensionsOnDescription
        CollectFiles -filestocollect ($script:rootOutFile + "_ExportedLegacyTransportRules.xml") -filedescription ("Export-TransportRuleCollection -ExportLegacyRules") -sectiondescription (Get-ReportSection) -noFileExtensionsOnDescription    
    }
}

function GetAntiSpamConfig(){
  trap [Exception] {
        Log-Error $_
        Continue
    }

    ExportResults -cmdlet "Get-ContentFilterConfig"
    ExportResults -cmdlet "Get-ContentFilterPhrase"
    ExportResults -cmdlet "Get-IPBlockListConfig"
    ExportResults -cmdlet "Get-IPBlockListEntry"
    ExportResults -cmdlet "Get-IPBlockListProvidersConfig"
    ExportResults -cmdlet "Get-IPBlockListProvider"
    ExportResults -cmdlet "Get-IPAllowListConfig"
    ExportResults -cmdlet "Get-IPAllowListEntry"
    ExportResults -cmdlet "Get-IPAllowListProvidersConfig"
    ExportResults -cmdlet "Get-IPAllowListProvider"
    ExportResults -cmdlet "Get-SenderIdConfig"
    ExportResults -cmdlet "Get-SenderReputationConfig"
    ExportResults -cmdlet "Get-SenderFilterConfig"
    ExportResults -cmdlet "Get-RecipientFilterConfig"
    ExportResults -cmdlet "Get-AntispamUpdates -identity '$Script:ExchangeServerName'"
    
}


##################
# Data Collected for Exchange Hub Server Role
##################
function GetHubTransportServerData(){
	trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Hub Transport Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerHub)

      Write-DebugLog ("GetCommonTransportServerData")
        GetCommonTransportServerData
    
    ExportResults -cmdlet "Get-ForeignConnector"
    ExportResults -cmdlet "Get-RoutingGroupConnector"
    ExportResults -cmdlet "Get-JournalRule" -outformat "FL" -filename "JournalRules"
    
    ###################
    #Exchange 2010-only
    ###################
    if ($ExchangeVersion -eq 14){
        ExportResults -cmdlet "Get-IRMConfiguration"
    }
}

##################
# Data Collected for Exchange Edge Server Role
##################
function GetEdgeServerData(){
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Edge Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerEdge)

      Write-DebugLog ("GetCommonTransportServerData")
        GetCommonTransportServerData
    ExportResults -cmdlet "Get-AddressRewriteEntry"
    ExportResults -cmdlet "Get-AttachmentFilterListConfig"
    ExportResults -cmdlet "Get-AttachmentFilterEntry"
}

##################
# Data Collected for Exchange Unified Messaging Server Role
##################
function GetUnifiedMessagingServerData(){
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Unified Messaging Server Role"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerUM)
    
    ExportResults -cmdlet "Get-UMServer -identity $Script:ExchangeServerName"
    ExportResults -cmdlet "Get-UMDialPlan"
    ExportResults -cmdlet "Get-UMIPGateway"
    ExportResults -cmdlet "Get-UMHuntGroup"
    ExportResults -cmdlet "Get-UMMailboxPolicy"
    ExportResults -cmdlet "Get-UMVirtualDirectory"
    ExportResults -cmdlet "Get-UMAutoAttendant"
    
    foreach ($dialplan in Get-UMDialPlan){
        $DialPlanInCountryOrRegionGroups = $dialplan.ConfiguredInCountryOrRegionGroups
        $DialPlanInternationalGroups = $dialplan.ConfiguredInternationalGroups
        $cFileDialPlanName = ("UMDialPlan_" + $dialplan.Name + "_CountryOrRegionGroups")
        $iFileDialPlanName = ("UMDialPlan_" + $dialplan.Name + "_InternationalGroups")
        ExportResults -cmdlet "'$DialPlanInCountryOrRegionGroups'" -filename "'$cFileDialPlanName'"
        ExportResults -cmdlet "'$DialPlanInternationalGroups'" -filename "'$iFileDialPlanName'"
    }
    
    foreach ($UMAutoAttendant in Get-UMAutoAttendant){
        $UMAA_BusinessHoursKeyMapping = $UMAutoAttendant.BusinessHoursKeyMapping
        $UMAA_AfterHoursKeyMapping = $UMAutoAttendant.AfterHoursKeyMapping
        $bFileUMAAName = ("UMAutoAttendant_" + $UMAutoAttendant.Name + "_BusinessHoursKeyMapping")
        $aFileUMAAName = ("UMAutoAttendant_" + $UMAutoAttendant.Name + "_AfterHoursKeyMapping")
        ExportResults -cmdlet "'$UMAA_BusinessHoursKeyMapping'" -filename "'$bFileUMAAName'"
        ExportResults -cmdlet "'$UMAA_AfterHoursKeyMapping'" -filename "'$aFileUMAAName'"
    }
}

Function GetExchangeRegistryKeys {
    trap [Exception] {
        Log-Error $_
        Continue
    }

    #Collect Exchange HKLM:SYSTEM\CCS\SVCS registry keys and values
    $regkey = "HKLM:SYSTEM\CurrentControlSet\Services"
    $regKeys = Get-ChildItem $regKey | where{$_.Name -like "*Exchange*"} | FOREACH-OBJECT {$_.name -replace ("HKEY_LOCAL_MACHINE\\","HKLM:")}
    $outfile = ($script:rootOutFile + "_REG_SERVICES_EXCHANGE.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:SYSTEM\CCS\SVCS\*Exchange*") -sectiondescription (Get-ReportSection) -Recursive $true

    #Collect Exchange HKLM:Software\Microsoft\Exchange* keys and values
    $regkey = "HKLM:SOFTWARE\Microsoft" 
    $regKeys = Get-ChildItem $regKey | where{$_.Name -like "*Exchange*"} | FOREACH-OBJECT {$_.name -replace ("HKEY_LOCAL_MACHINE\\","HKLM:")}
    $outfile = ($script:rootOutFile + "_REG_SOFTWARE_EXCHANGE.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:Software\Microsoft\Exchange*") -sectiondescription (Get-ReportSection) -Recursive $true
    
    #Colect HKLM:Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options keys and values
    $regkey = "HKLM:SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" 
    $regKeys = Get-ChildItem $regKey | FOREACH-OBJECT {$_.name -replace ("HKEY_LOCAL_MACHINE\\","HKLM:")}
    $outfile = ($script:rootOutFile + "_REG_ImageFileExecutionOptions.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:Software\...ImageFileExecutionOptions") -sectiondescription (Get-ReportSection) -Recursive $true

    #Collect Exchange trace key if it is present (unlikely)
    $regkeys = "HKLM:Software\Microsoft\MosTrace"
    $outfile = ($script:rootOutFile + "_REG_MOSTRACE.TXT")

    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:Software\Microsoft\MosTrace") -sectiondescription (Get-ReportSection) -Recursive $true

    #Collect Windows Installer keys and values for the installed version of Exchange
    If ($global:ExchangeVersion -eq "14"){
        [array]$regkeys = "HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\AE1D439464EB1B8488741FFA028E291C"
    }
    Else{
        [array]$regkeys = "HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Products\461C2B4266EDEF444B864AD6D9E5B613"
    }
    
    #If found, add Windows Installer Patch keys for the installed version of Exchange
    $exchPatchesKey = Join-Path $regkeys[0] Patches
    If ((Get-ChildItem $exchPatchesKey).count -gt 0){
        $regkeys += Get-ChildItem $exchPatchesKey | ForEach-Object {Join-Path HKLM:SOFTWARE\Microsoft\Windows\CurrentVersion\Installer\UserData\S-1-5-18\Patches (Split-Path $_.Name -Leaf)}
    }
    
    $outfile = ($script:rootOutFile + "_REG_INSTALLER_EXCHANGE.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("HKLM:SOFTWARE\..\Installer\[Exchange]") -sectiondescription "Exchange Setup Information" -Recursive $true
}

function GetTransporterSuite(){
    Set-ReportSection "Exchange Transporter Suite"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerTransSuite)
    trap [Exception] {
        Log-Error $_
        Continue
    }
    $ExchangeDominoConnector = $null
    $CalCon = $null
    
    $ExchangeDominoConnector = (get-item HKLM:\SYSTEM\CurrentControlSet\Services\ExchangeDominoConnector)
    $CalCon = (Get-Item HKLM:\SYSTEM\CurrentControlSet\Services\MSExchangeCalcon)
    
    #Load snap-ins if either of these is available
    if(($ExchangeDominoConnector -ne $null) -or ($CalCon -ne $null)){
        Add-PSSnapin -Name "Microsoft.Exchange.Transporter.DominoConnector"
        Add-PSSnapin -Name "Microsoft.Exchange.Transporter"
    }
    $TransporterBin = (Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Transporter).ApplicationBase
    
    #Calendar Connector is installed
    if($CalCon -ne $null){
        ExportResults -cmdlet "Get-DominoFreeBusyConnector"
    }
    
    #Exchange Domino Connector is installed
    if($ExchangeDominoConnector -ne $null){
        ExportResults -cmdlet "Get-DominoDirectoryConnector"
        
        $DominoDirectoryConnectors = Get-DominoDirectoryConnector
        foreach($dominoDirectoryConnector in $DominoDirectoryConnectors){
            #Try to get the Notes.ini file
            $notesini = $dominoDirectoryConnector.NotesINIFile
            
            if($notesini -ne $null){
                if([System.IO.File]::Exists($notesini)){
                    $iniFile = ($pwd.Path.ToString() + "\" + $dominoDirectoryConnector.Name.ToString() + "_Notes.ini")
                    copy-item -path $notesini -destination $iniFile -recurse
                    GetFiles -sourcePath "$iniFile" -recurse
                }
                else{
                    $iniFileMissing = ($pwd.Path.ToString() + "\" + $dominoDirectoryConnector.Name.ToString() + "_Missing_Notes.ini")
                    out-file -filepath $iniFileMissing -InputObject ("Notes.INI file for " + $dominoDirectoryConnector.Name.ToString() + " is missing!!!")
                    GetFiles -sourcePath "$iniFileMissing"
                }
            }
        }
    }
}

##################
# Collect IIS-related information
##################
function GetIISInfo {
    trap [Exception] {
        Log-Error $_
        Continue
    }
    Set-ReportSection "Exchange Server IIS Information"
    Set-CurrentActivity ($GetExchDataStrings.ID_GetExchDataCollectingAct + " " + $GetExchDataStrings.ID_GetExchServerIIS)

    $CopyToPath = ($pwd.Path.ToString())
    $inetSrvPath = (join-path $env:systemroot system32\inetsrv)
    $metabase_xml = ($env:systemroot + "\system32\inetsrv\metabase.xml")
    $filePrefix = ($env:COMPUTERNAME + "_")
    $regkeys = "HKLM:SYSTEM\CurrentControlSet\Services\IISADMIN", "HKLM:SYSTEM\CurrentControlSet\Services\InetInfo","HKLM:SYSTEM\CurrentControlSet\Services\W3SVC", "HKLM:SYSTEM\CurrentControlSet\Services\msdtc", "HKLM:SOFTWARE\Microsoft\Transaction Server", "HKLM:SOFTWARE\Microsoft\InetStp", "HKLM:SOFTWARE\Microsoft\InetMGR", "HKLM:SOFTWARE\Microsoft\Keyring"
    $outfile = ($script:rootOutFile + "_REG_IIS.TXT")
    RegQuery -RegistryKeys $regKeys -OutputFile $outfile -fileDescription ("IIS and Related Registry Keys/Values") -sectiondescription (Get-ReportSection) -Recursive $true

    GetFiles -sourcePath "$metabase_xml" -filedescription "IIS Metabase" -prefix $filePrefix -sectiondescription (Get-ReportSection)
}
########################
# Collect and .cab two most recent IIS logs for every website (called only if CAS role is detected)
########################
function GetIISLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }

    $server = $env:computername
    $iis = [ADSI]"IIS://$server/W3SVC" 
    $sites = $iis.psbase.children | where { $_.keyType -eq "IIsWebServer"}
    foreach($site in $sites){
        $sp = $site.psbase.path
        $lfd = $site.logfiledirectory
        $slf = $sp.substring($sp.indexof("W3SVC")) | %{$_.replace("/","")}
        $w3logpath = Join-Path -Path $lfd -ChildPath $slf
        $tfldr = ($slf + "LogFiles")
        if  (Test-Path $w3logpath){
            GetFiles -sourcePath $w3logpath -targetFolder "$tfldr" -reportsection "Exchange Server IIS Information" -filedescription "Logs_$slf (newest two)" -include "*.log" -recurse -cab -newest "2"
        }
        Else{
            Write-DebugLog ("GetIISLogs: IIS Log Path was expected but not found on filesystem: " + $w3logpath)
        }
    }
}

########################
# Collect and .zip two most recent RPC Client Access Logs (called only if CAS role is detected)
########################
function GetRPCClientAccessLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    $LogLocationXMLFileName = Join-Path -Path $global:exbin -childpath Microsoft.Exchange.RpcClientAccess.Service.exe.config
    If (Test-Path $LogLocationXMLFileName)
	{
        [xml]$LogLocationXML = Get-Content -Path $LogLocationXMLFileName
        $RPCLogPathFromConfig = $loglocationxml.configuration.appsettings.selectsinglenode("add[@key='LogPath']").value
        If ($rpclogpathfromconfig.tolower().startswith("%exchangeinstalldir%") -eq $true)
		{
            $RPCLogPath = $RPCLogPathFromConfig.replace("%ExchangeInstallDir%\",$global:exinstall)
        }
        Else
		{
            $RPCLogPath = $RPCLogPathFromConfig
        }
    }
    
    if (Test-Path $RPCLogPath){
		If ($rpclogpathfromconfig.tolower().endswith("\") -eq $false)
		{
			$RPCLogPath += "\"
		}
		Write-DebugLog ("RPC Client Access Log Path: '$RPCLogPath'")
        CompressCollectFiles -filesToCollect ($RPCLogPath + '*.log')-fileDescription ("RPCClientAccess logs modified in past 5 days") -DestinationFileName "Logs_RPCClientAccess.zip" -sectionDescription (Get-ReportSection) -NumberOfDays 5 #-Recursive 
    }
	Else
	{
        Write-DebugLog ("Logs_RPCCLientAccess: No Files Found to Zip At '$RPCLogPath'")
	}
}

########################
# Collect and .zip two most recent AddressBook Service Logs (called only if CAS role is detected)
########################
function GetAddressBookServiceLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    $LogLocationXMLFileName = Join-Path -Path $global:exbin -childpath Microsoft.Exchange.addressbook.Service.exe.config
    If (Test-Path $LogLocationXMLFileName){
        [xml]$LogLocationXML = Get-Content -Path $LogLocationXMLFileName
        $ABServiceLogPath = $loglocationxml.configuration.appsettings.selectsinglenode("add[@key='LogFilePath']").value
    }
    
    If (Test-Path $ABServiceLogPath){
        $ABServiceLogs = Get-ChildItem $ABServiceLogPath | Where-Object {!$_.psiscontainer } | sort LastWriteTime -Descending | select-object -First 2
        "ABService Logs: " + $ABServiceLogs | WriteTo-StdOut
        if ($ABServiceLogs.length -gt 0){
            $ABServiceLogsZipFile = out-zip -FilePath $ABServiceLogs -zipFileName "Logs_AddressBookService"
            CollectFiles -filestocollect ($ABServiceLogsZipFile) -filedescription ("Logs_AddressBookService") -sectiondescription (Get-ReportSection) #-noFileExtensionsOnDescription
        }
            Else{
            Write-DebugLog ("Logs_AddressBookService: No Files Found to Zip At '$ABServiceLogPath'")
        }
    }
}

########################
# Collect and .zip 5 most recent Connectivity Logs (called only if Transport role is detected)
########################
function GetConnectivitylogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }
 
    $Connectivitylogpath = (Get-TransportServerCached).connectivitylogpath.PathName

    
    If (Test-Path $Connectivitylogpath){
        $ConnectivityLogs = Get-ChildItem $Connectivitylogpath | Where-Object {!$_.psiscontainer } | sort LastWriteTime -Descending | select-object -First 5
        "Connectivity Logs: " + $ConnectivityLogs | WriteTo-StdOut
        if ($ConnectivityLogs.length -gt 0){
            $ConnectivityLogsZipFile = out-zip -FilePath $ConnectivityLogs -zipFileName "Logs_Connectivity"
            CollectFiles -filestocollect ($ConnectivityLogsZipFile) -filedescription ("Logs_Connectivity") -sectiondescription (Get-ReportSection) #-noFileExtensionsOnDescription
        }
            Else{
            Write-DebugLog ("Logs_Connectivity: No Files Found to Zip At '$Connectivitylogpath'")
        }
    }
}


########################
# Collect and .zip 5 most recent Message Tracking Logs (called only if Transport role is detected)
########################
function GetMessageTrackingLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }

    $MessageTrackingLogPath = (Get-TransportServerCached).MessageTrackingLogPath.PathName
    
    If (Test-Path $MessageTrackingLogPath){
        $MessageTrackingLogs = Get-ChildItem $MessageTrackingLogPath | Where-Object {!$_.psiscontainer } | sort LastWriteTime -Descending | select-object -First 5
        "Message Tracking Logs: " + $MessageTrackingLogs | WriteTo-StdOut
        if ($MessageTrackingLogs.length -gt 0){
            $MessageTrackingLogsZipFile = out-zip -FilePath $MessageTrackingLogs -zipFileName "Logs_MessageTracking"
            CollectFiles -filestocollect ($MessageTrackingLogsZipFile) -filedescription ("Logs_MessageTracking") -sectiondescription (Get-ReportSection) #-noFileExtensionsOnDescription
        }
            Else{
            Write-DebugLog ("Logs_MessageTracking: No Files Found to Zip At '$MessageTrackingLogPath'")
        }
    }
}

########################
# Collect and .zip two most recent Update-HybridConfiguration Logs if present
########################
function GetHybridConfigLogs{
    trap [Exception] {
        Log-Error $_
        Continue
    }
    
    $HybridConfigLogPath = Join-Path -Path $global:exinstall -ChildPath "Logging\Update-HybridConfiguration"
    
    If (Test-Path $HybridConfigLogPath){
        $HybridConfigLogs = Get-ChildItem $HybridConfigLogPath | Where-Object {!$_.psiscontainer } | sort LastWriteTime -Descending | select-object -First 2
        "HybridConfiguration Logs: " + $HybridConfigLogs | WriteTo-StdOut
        if ($HybridConfigLogs.length -gt 0){
            $HybridConfigLogsZipFile = out-zip -FilePath $HybridConfigLogs -zipFileName "Logs_Update-HybridConfiguration"
            CollectFiles -filestocollect ($HybridConfigLogsZipFile) -filedescription ("Logs_Update-HybridConfiguration") -sectiondescription (Get-ReportSection) #-noFileExtensionsOnDescription
        }
            Else{
            Write-DebugLog ("Logs_Update-HybridConfiguration: No Files Found to Zip At '$HybridConfigLogPath'")
        }
    }
}

############################################################# 
#                                                           # 
# Script Starts Here                                        #
#                                                           #
#############################################################
    
#======================================
# Load localized strings
#======================================
Import-LocalizedData -BindingVariable GetExchDataStrings

#======================================
# Set global variables regardless of Exchange version inestalled
#======================================
$global:SystemDrv = (Get-ChildItem env:systemdrive).value


#======================================
# Tracks Script Execution count and disables confirmation
#======================================
$script:count = 0
$ConfirmPreference = "NONE"
$script:executedNoResults

If ($getExBPA){$script:paramGetExBPA = $true}
If ($getSetupLogs){$script:paramGetSetupLogs = $true}
#======================================
# Call the  Get-ExchangeData function
#======================================

"Calling Get-ExchangeData" | WriteTo-StdOut
    Get-ExchangeData

# Collect Debug logs
Collect-DebugLog

# SIG # Begin signature block
# MIIjlAYJKoZIhvcNAQcCoIIjhTCCI4ECAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDfWmCBsu0J5pGG
# ARLiiTo21MVulkZPuJ468y/Kcc49U6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVaTCCFWUCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgSmAt5wIJ
# il5OoKUlDq8+EKfwgra6apG1vob0CGH7oZ0wOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBADRlDLm/iyC2lHyaNfqn2l0z8I9N0Q2CYOq6zE/ngHo9RS/XMM+G6ni3
# O02U7dXgepQfnrl2VIjIFT9tyrw+8u63LrPJcgwcCkTQdWJDJt3Zu7eV5yD+4Du/
# 0ggYj/qooUCoJaMTzbpKu//SglL2mCSUADDjV11ifzJq3stkH8nWfoLnqfS3Sxtg
# I5+KbaxlHdupH1lhZy4NeIBe5zSgSBZjO4n5CD2RxOUHCUzyXDfI1s8LC+DjRWZn
# ZU25PWmglP68lorchEc92mbS5TLqgmreGxNLC826qXecaWQMtsAkHD6YWrPqUSpA
# VXzZvJQW0BsL6WfHwNh7zLBMDJm6pzehghL9MIIS+QYKKwYBBAGCNwMDATGCEukw
# ghLlBgkqhkiG9w0BBwKgghLWMIIS0gIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWAYL
# KoZIhvcNAQkQAQSgggFHBIIBQzCCAT8CAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgEFemw4GggmP3EWI5ZVr9XeW7a3Nh5leSgQRr7Dz2GoMCBmCKzjK5
# mBgSMjAyMTA1MTkyMjIyNTQuNzZaMASAAgH0oIHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloIIOTTCCBPkwggPhoAMCAQICEzMAAAE5zOjoQ4vwNOEAAAAAATkwDQYJ
# KoZIhvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjAx
# MDE1MTcyODIxWhcNMjIwMTEyMTcyODIxWjCB0jELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IElyZWxhbmQgT3Bl
# cmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjowODQyLTRC
# RTYtQzI5QTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBANoT+YzjJZMloY6zKgb8onj4
# Wh+YN09/UMHbuh6gJ1nC5c/f2SqAv0Bc+OYG9GndeCL6hWhZtieqPr4YW3+KECTh
# w03I2VwSkE20E/8Oiwlr3Ql5xUJdmvJxHeNhJhO68UVZirpmx6BClfkMGHRnO9Ku
# TvDNmJKif0rXKxYRbZoRcXL1WfoIOGs87xPO/rKCM2Fes6jNiljv00svWXqIuV+E
# KG1egCrsCR9PMkmdpUAV853fK8A88uvgWKiV4pvm/lfuxN++NW+nEPX5jjQKRy4Z
# BqqNO/wdeDZBqqjve/IQI17VaEKSoyrussV87LKUJ49K5X7Ffx8klv5fos8eyk8C
# AwEAAaOCARswggEXMB0GA1UdDgQWBBSZnpuGclTCmdqSirGfRvZQLQYM6TAfBgNV
# HSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVo
# dHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1T
# dGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAC
# hj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBD
# QV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUF
# BwMIMA0GCSqGSIb3DQEBCwUAA4IBAQBYXChq8/83GoXNwVrtQ4KIvxANsSb7uvYR
# iJOhbSDx11jIrlZrUUB3/KckPWrJz9nHH0c/3TKpcpP6vPiDXAixBJaUoJvdcbgh
# WGxYQISybaKM39/Gh+a2NmcVjfW7gxJJyX4hoiukPvJJAjVpm1o9g8UcBBfCHwcI
# xexD4WA4HYpSs+POrsIYKLKK9Rrg1opWIxqDDat5a8AyJGP/NylKSYaK5aYgXZCD
# RLFZAn88hC5nvQt7WpmbTEl8a1GcF+lq393UmBAKst+jyWSa4sE8Ib84yHqg/His
# 1FId7nxNvxIxAG2mwYQqNvrVKMp0+kwCbY3Yr2uIOz+9/1UK0nDHMIIGcTCCBFmg
# AwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMx
# EzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoT
# FU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUw
# NzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDV
# pQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/x
# YIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFn
# kV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13
# Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaI
# CDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOC
# AeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYb
# xTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYw
# DwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoY
# xDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYB
# BQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20v
# cGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/
# BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUH
# AgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBl
# AG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z
# 66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lT
# jMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIA
# rzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWv
# L/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/
# fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZ
# JQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqw
# UB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d
# 9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLix
# qduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh
# 0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4I
# uto229Nfj950iEkSoYIC1zCCAkACAQEwggEAoYHYpIHVMIHSMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMS0wKwYDVQQLEyRNaWNyb3NvZnQgSXJl
# bGFuZCBPcGVyYXRpb25zIExpbWl0ZWQxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNO
# OjA4NDItNEJFNi1DMjlBMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQANTZT+G96WhI10Px3uSgTGs2WMB6CBgzCB
# gKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUA
# AgUA5E+p9TAiGA8yMDIxMDUxOTIzMTUwMVoYDzIwMjEwNTIwMjMxNTAxWjB3MD0G
# CisGAQQBhFkKBAExLzAtMAoCBQDkT6n1AgEAMAoCAQACAiQPAgH/MAcCAQACAhG8
# MAoCBQDkUPt1AgEAMDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAI
# AgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEARfm80WrFtl3V
# aLA49fqHQjZ7OVC7Fs+8mhcC8HhbRKZzUUzACNyfrAOupz15m3yWA+WbCUDeNkEW
# rlPTJZqxe3NujW2FxsvjFmWOJ1rtT1LiSWAkPqT40rdYd893X5pdwCbYSWEMGpLG
# flXw7OmgB+FEAmPxGfcA5r0YGZVFxQAxggMNMIIDCQIBATCBkzB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAATnM6OhDi/A04QAAAAABOTANBglghkgB
# ZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3
# DQEJBDEiBCAkZ8F3OeOExJ/bAtxQJPbPkcsjWoCg0LzaKGRT+IAb0zCB+gYLKoZI
# hvcNAQkQAi8xgeowgecwgeQwgb0EIDyhjuQ4o9ckezFCseKBBa58alUn85p6nyam
# 1KAHD/yfMIGYMIGApH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMA
# AAE5zOjoQ4vwNOEAAAAAATkwIgQgvuZR1phk5ppezRxYZZ9gcbfGkXrQylaSSuaH
# 1f4ToFkwDQYJKoZIhvcNAQELBQAEggEAqCk/6ne4OequoytHOs7XqtK1qsCAF7o/
# u/k3cjJ9cZkR4h4d3MBl0AqfUNDQQsWa7He/5LS+ov2Kcmx58buuxf6X6dCPwBc4
# T0nuGFOJtD0re/ZccwcsXLYoz7WZ/EwSPBcNA8pxz+kIbHKGakleSGhdzFji05/T
# ob4azvfQO8EjxTM6KUk4WXvqyIdSHK3vHY9Ax8e1UWgaWX/bqeZ7Lj27uRIDxyGk
# W5N4VPP0NbdKBMAKBQDvFXR84h6U2oIbE1LNCe+5J8OjvHKOMr+m3OZD7xdE0aOA
# BLGpq7W5dHYs2bPPhfvW+Ep9j37qjFUmgt6uMDlo5Qcklvbrwb4Z5g==
# SIG # End signature block
