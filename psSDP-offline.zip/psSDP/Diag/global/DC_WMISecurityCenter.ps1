﻿
Import-LocalizedData -BindingVariable WMIStrings -FileName DC_WMISecurityCenter -UICulture en-us
Write-DiagProgress -Activity $WMIStrings.ID_SecurityCenter -Status $WMIStrings.ID_SecurityCenterDesc

$OutputFile= $ComputerName + "_SecurityCenter.txt"
$file = new-item -type file $filename

# Computer name
$strComputer = "."

 # Antivirus Product
"========================================================" >> $filename
"Antivirus Product" >> $filename
"========================================================" >> $filename
#$colItems = get-wmiobject -class "AntivirusProduct" -Recurse -namespace "root\securitycenter2" -computername $strComputer | Select-Object * -ExcludeProperty "__*","Site","Container","Qualifiers","SystemProperties","instanceGuid","Options"
get-wmiobject -class "AntivirusProduct" -Recurse -namespace "root\securitycenter2" -computername $strComputer | Select-Object * -ExcludeProperty "__*","Site","Container","Qualifiers","SystemProperties","instanceGuid","Options" | Out-File -append $outputfile | Format-wide

#$colItems >> $filename

"" >> $filename

# AntiSpyware Product
"========================================================" >> $filename
"AntiSpyware Product" >> $filename
"========================================================" >> $filename
 #$colItems = get-wmiobject -class "AntiSpywareProduct" -Recurse -namespace "root\securitycenter2" -computername $strComputer | Select-Object * -ExcludeProperty "__*","Site","Container","Qualifiers","SystemProperties","instanceGuid","Options"
 get-wmiobject -class "AntiSpywareProduct" -Recurse -namespace "root\securitycenter2" -computername $strComputer | Select-Object * -ExcludeProperty "__*","Site","Container","Qualifiers","SystemProperties","instanceGuid","Options" | Out-File -Append $OutputFile | Format-Wide
 
 #$colItems >> $filename


CollectFiles -filesToCollect $OutputFile -fileDescription "Security Center.log" -sectionDescription "System Information" 
 
