﻿
$ClusterSvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\ClusSvc"

if (Test-Path $ClusterSvcKey)
{
	Import-LocalizedData -BindingVariable ClusterReportsStrings
	
	Write-DiagProgress -Activity $ClusterReportsStrings.ID_ClusterReportsFolder -Status $ClusterReportsStrings.ID_ClusterReportsFolderObtaining

	if ($OSVersion.Major -ge 6)
	{
		$sectionDescription = $ClusterReportsStrings.ID_ClusterReportsFolderOutput

		$filesToCollect = "$Env:windir\Cluster\Reports\*.mht"
		$filesDescription = $ClusterReportsStrings.ID_ClusterReportsFolderOutputMHT

		if (test-path $FilesToCollect) 
		{
			CompressCollectFiles -DestinationFileName ($ComputerName + "_ClusterReportMHT.zip") -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription
			#CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true
		}
		#_# adding *.htm 
		$filesToCollect = "$Env:windir\Cluster\Reports\*.htm"
		$filesDescription = $ClusterReportsStrings.ID_ClusterReportsFolderOutputHTM

		if (test-path $FilesToCollect) 
		{
			CompressCollectFiles -DestinationFileName ($ComputerName + "_ClusterReportHTM.zip") -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription
		}


		$filesToCollect = "$Env:windir\Cluster\Reports\*.xml"
		$filesDescription = $ClusterReportsStrings.ID_ClusterReportsFolderOutputXML

		if (test-path $FilesToCollect) 
		{
			CompressCollectFiles -DestinationFileName ($ComputerName + "_ClusterReportXML.zip") -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription 
			#CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true
		}

		$filesToCollect = "$Env:windir\Cluster\Reports\Validate*.log"
		$filesDescription = $ClusterReportsStrings.ID_ClusterReportsFolderOutputLog

		if (test-path $FilesToCollect) 
		{
			CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true
		}
	}
}
else
{
	"Machine is not a cluster"
}
