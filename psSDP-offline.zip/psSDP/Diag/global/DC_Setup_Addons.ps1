#************************************************
# DC_Setup_Addons.ps1
# Version 1.1
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects additional Setup information.
# Called from: TS_AutoAddCommands_Setup.ps1
#*******************************************************

Param($MachineName = $Computername, $Path = "")

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_Setup_Addons.ps1"

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $ScriptVariable.ID_CTSAddonsDescription


# detect OS version
$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

function isOSVersionAffected
{
	if ([int]$bn -gt [int](9600))
	{
		return $true
	}
	else
	{
		return $false
	}
}

function RunNet ([string]$NetCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}

#--- Section CBS & PNP info, components hive, SideBySide hive, Iemain.log
$sectionDescription = "Windows logs folders"

if(test-path (join-path $Env:windir "Logs"))
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Compress \Logs"
	$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\Logs" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_Windows-Logs.zip") -fileDescription "Windows Log Folder" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DestinationTempFolder -Force -Recurse
}
if(test-path (join-path $Env:windir "System32\LogFiles"))
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Compress \System32\LogFiles"
	$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\System32\LogFiles" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_Windows-System32-Logs.zip") -fileDescription "System32 LogFiles Folders" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DestinationTempFolder -Force -Recurse
}

Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status (join-path $Env:windir "Servicing\Sessions")
$arrWindirLogsFiles = get-childitem -force -path (join-path $Env:windir "Servicing\Sessions") -recurse -exclude *.temp,*.tmp | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrWindirLogsFiles -fileDescription "Windows\Servicing\Sessions folder" -sectionDescription "Servicing\Sessions Folder" -DestinationFileName ($MachineName + "Windows-Servicing-Sessions.zip") -RenameOutput $true -recursive 

Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status (join-path $Env:windir "inf")
$arrWindirLogsFiles = get-childitem -force -path (join-path $Env:windir "inf\*") -include *.log | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrWindirLogsFiles -fileDescription "Windows\inf\*.log" -sectionDescription "inf\*.log" -DestinationFileName ($MachineName + "Windows-Inf-logs.zip") -RenameOutput $true -recursive 

	$filesToCollect = "$env:WinDir\servicing\sessions\sessions.xml"
	$filesDescription = "servicing\sessions\sessions.xml"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

	$filesToCollect = "$env:WinDir\Logs\MoSetup\UpdateAgent.log"
	$filesDescription = "MoSetup\UpdateAgent.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

	$filesToCollect = "$env:WinDir\iemain.log"
	$filesDescription = "iemain.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

#----------Registry
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Collect Registry files"

	$OutputFile= $MachineName + "_reg_Component_Based_Servicing.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing" -OutputFile $OutputFile -fileDescription "Components CBS Hive"

	$OutputFile= $MachineName + "_reg_SideBySide.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\CurrentVersion\SideBySide" -OutputFile $OutputFile -fileDescription "SideBySide Hive"

	$OutputFile= $MachineName + "_reg_SideBySide.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\SideBySide" -OutputFile $OutputFile -fileDescription "SideBySide Reg key" -Recursive $true
		
#----------Registry Section Misc Registry Info
	$OutputFile= $MachineName + "_reg_Langpack.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\MUI\UILanguages" -OutputFile $OutputFile -fileDescription "Langpack Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_services.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Services" -OutputFile $OutputFile -fileDescription "services Reg key" -Recursive $true
	$OutputFile= $MachineName + "_reg_services.HIV"
	RegSave -RegistryKey "HKLM\System\CurrentControlSet\Services" -OutputFile $OutputFile -fileDescription "services Reg Hive" -Recursive $true
			
	$OutputFile= $MachineName + "_reg_CurrentVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion" -OutputFile $OutputFile -fileDescription "Windows NT\CurrentVersion Reg key" -Recursive $true
	$OutputFile= $MachineName + "_reg_CurrentVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion" -OutputFile $OutputFile -fileDescription "Windows\CurrentVersion Reg key" -Recursive $true
	
	$OutputFile= $MachineName + "_reg_BuildInfo.txt"
	$RegKeysValues = "BuildLab", 
					"BuildLabEx", 
					"UBR", 
					"ProductName"
	RegQueryValue -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion" -RegistryValues $RegKeysValues -OutputFile $OutputFile -fileDescription "BuildInfo" -CollectResultingFile $true
	
	$OutputFile= $MachineName + "_reg_AppModelVersion.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\AppModel" -OutputFile $OutputFile -fileDescription "AppModel Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_FirmwareResources.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\FirmwareResources" -OutputFile $OutputFile -fileDescription "FirmwareResources Reg key" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\AppModel" -OutputFile $OutputFile -fileDescription "AppModel Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Appx.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Appx" -OutputFile $OutputFile -fileDescription "Appx Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Superfetch.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Superfetch" -OutputFile $OutputFile -fileDescription "Superfetch Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Uninstall.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Uninstall" -OutputFile $OutputFile -fileDescription "Uninstall Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall" -OutputFile $OutputFile -fileDescription "Uninstall Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_Recovery.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\CrashControl" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Session Manager" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Session Manager\Memory Management" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\AeDebug" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Image File Execution Options" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\Windows Error Reporting" -OutputFile $OutputFile -fileDescription "Recovery Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_Startup.txt"
	RegQuery -RegistryKeys "HKCU\Software\Microsoft\Windows\CurrentVersion\Run" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Runonce" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\ShellServiceObjectDelayLoad" -OutputFile $OutputFile -fileDescription "Startup Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_TimeZone.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\TimeZoneInformation" -OutputFile $OutputFile -fileDescription "TimeZone Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\Time Zones" -OutputFile $OutputFile -fileDescription "TimeZone Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_TermServices.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\Terminal Server" -OutputFile $OutputFile -fileDescription "TermServices Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_SVCHost.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\SvcHost" -OutputFile $OutputFile -fileDescription "SVCHost Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_ProfileList.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows NT\CurrentVersion\ProfileList" -OutputFile $OutputFile -fileDescription "ProfileList Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_DriverDatabase.HIV"
	RegSave -RegistryKey "HKLM\System\DriverDatabase" -OutputFile $OutputFile -fileDescription "DriverDatabase Hive"
	$OutputFile= $MachineName + "_reg_DriverDatabase.txt"
	RegQuery -RegistryKeys "HKLM\System\DriverDatabase" -OutputFile $OutputFile -fileDescription "DriverDatabase Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_.NET-Framework-Setup.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\NET Framework Setup\NDP" -OutputFile $OutputFile -fileDescription ".NET-Framework-Setup Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Winevt.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\currentversion\winevt" -OutputFile $OutputFile -fileDescription "Winevt Hive"
	$OutputFile= $MachineName + "_reg_Winevt.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\currentversion\winevt" -OutputFile $OutputFile -fileDescription "Winevt Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Setup.txt"
	RegQuery -RegistryKeys "HKLM\System\Setup" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\OOBE" -OutputFile $OutputFile -fileDescription "Setup Reg keys"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\State" -OutputFile $OutputFile -fileDescription "Setup Reg keys"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\Sysprep" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\Setup\SysPrepExternal" -OutputFile $OutputFile -fileDescription "Setup Reg keys" -Recursive $true

	$OutputFile= $MachineName + "_reg_WMI.txt"
	RegQuery -RegistryKeys "HKLM\System\CurrentControlSet\Control\WMI" -OutputFile $OutputFile -fileDescription "WMI Reg key" -Recursive $true

	$OutputFile= $MachineName + "_reg_Drivers.HIV"
	RegSave -RegistryKey "HKLM\DRIVERS" -OutputFile $OutputFile -fileDescription "Drivers Hive"

#----------Directory listing 
	$sectionDescription = "Dir $env:WinDir\Winsxs\temp"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_winsxsTEMP.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\Winsxs\temp" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription

	$sectionDescription = "Dir $env:WinDir\Winsxs"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_winsxs.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\Winsxs" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription
	
	$sectionDescription = "Dir $env:WinDir\servicing\packages"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_servicing-packages.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\servicing\packages" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription

#----------Directory listing: Get registry size info including Config and profile info
	$sectionDescription = "Dir $env:WinDir\system32\config"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_registry_list.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\system32\config" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	$CommandToExecute = 'dir /a /s "c:\users\ntuser.dat" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription


#---------- Section Windows Store info
	$sectionDescription = "Copying Windows Store logs"
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectionDescription

	$filesToCollect = "$Env:Temp\winstore.log"
	$filesDescription = "$Env:Temp\winstore.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Env:Temp\winstore.log"
	$filesDescription = "$Env:Temp\winstore.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}
	
if (test-path "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log" -fileDescription "Winstore log" -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
}
if (test-path "$env:localappdata\Temp\WinStore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Temp\WinStore.log" -fileDescription "Broker log" -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
}
	
#---------- MUSE logs for Win10+
if (get-service usosvc -EA SilentlyContinue)
 {
	$sectionDescription = "Copying MUSE logs for Win10"
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectionDescription

		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy UsoPrivate\UpdateStore"
		$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:programdata\UsoPrivate\UpdateStore" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_UsoPrivate-UpdateStore.zip") -fileDescription "UsoPrivate-UpdateStore Folder" -sectionDescription $sectionDescription -Recursive
		Remove-Item $DestinationTempFolder -Force -Recurse
		
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy UsoShared\Logs"
		$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:programdata\USOShared\Logs" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_USOShared-Logs.zip") -fileDescription "USOShared-Logs Folder" -sectionDescription $sectionDescription -Recursive
		Remove-Item $DestinationTempFolder -Force -Recurse
		
	  # robocopy %_OLDPROGRAMDATA%\USOPrivate\UpdateStore %_TEMPDIR%\Windows.old\MUSE %_ROBOCOPY_PARAMS% /S > nul
	  # robocopy %_OLDPROGRAMDATA%\USOShared\Logs %_TEMPDIR%\Windows.old\MUSE %_ROBOCOPY_PARAMS% /S > nul

	$sectionDescription = "SCHTASKS /query /v /TN \Microsoft\Windows\UpdateOrchestrator\"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_MUSE_ScheduledTasks.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "MUSE ScheduledTasks"
		$CommandToExecute = 'SCHTASKS /query /v /TN \Microsoft\Windows\UpdateOrchestrator\ '
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "MUSE: ScheduledTasks" -sectionDescription $sectionDescription
}
#---------- Section Delivery Optimizaton logs and powershell for Win10+
if (get-service dosvc -EA SilentlyContinue) {
	$sectionDescription = "Copying DeliveryOptimization logs"
	if (test-path "$Env:windir\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs" )
	{
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy DeliveryOptimization\Logs"
		$arrDOlogsFiles = get-childitem -force -path (join-path $Env:windir "ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs") -recurse -include *.log,*.etl | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrDOlogsFiles -fileDescription "DeliveryOptimization\Logs folder" -sectionDescription "DeliveryOptimization\Logs Folder" -DestinationFileName ($MachineName + "DeliveryOptimization-logs.zip") -RenameOutput $true -recursive 
	}
	if (test-path "$Env:windir\SoftwareDistribution\DeliveryOptimization\SavedLogs" )
	{
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy DeliveryOptimization\SavedLogs"
		$arrDOsavedLogsFiles = get-childitem -force -path (join-path $Env:windir "SoftwareDistribution\DeliveryOptimization\SavedLogs") -recurse -include *.log,*.etl | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrDOsavedLogsFiles -fileDescription "DeliveryOptimization\SavedLogs folder" -sectionDescription "DeliveryOptimization\SavedLogs Folder" -DestinationFileName ($MachineName + "DeliveryOptimization-SavedLogslogs.zip") -RenameOutput $true -recursive 
	}
}
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Get DeliveryOptimization Registry"
	$OutputFile= $ComputerName + "_reg_DeliveryOptimization.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization" -OutputFile $OutputFile -fileDescription "DeliveryOptimization Reg key" -Recursive $true
	
	$OutputFile = $ComputerName + "_DeliveryOptimization_info.txt"
	Get-DeliveryOptimizationPerfSnap -Debug -Verbose | Out-File -FilePath $OutputFile -append 
	Get-DeliveryOptimizationStatus -Debug -Verbose | Out-File -FilePath $OutputFile -append 
 
#---------- Windows Upgrade logs, see *.ps1


#W8/WS2012 and later
if ($bn -gt 9000)
{
	#----------Event Logs - Windows Setup 
	$sectionDescription = "Event Logs - Windows Store Apps"
	$EventLogNames = "Setup", "Microsoft-Windows-WMI-Activity/Operational", "Microsoft-Windows-Setup/Analytic", "General Logging", "HardwareEvents", "Microsoft-Windows-Crashdump/Operational", "Microsoft-Windows-Dism-Api/Analytic", "Microsoft-Windows-EventLog-WMIProvider/Debug", "Microsoft-Windows-EventLog/Analytic", "Microsoft-Windows-EventLog/Debug", "Microsoft-Windows-Kernel-Boot/Operational" 
	$Prefix = "_evt_"
	$Suffix = ""
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}
 
#----------  Disk Info
$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_Storage_Info.txt")
Get-PhysicalDisk  | Out-File -FilePath $OutputFile -append
$Pdisk= Get-PhysicalDisk 
ForEach ( $LDisk in $PDisk )
                {
                $LDisk.FriendlyName | Out-File -FilePath $OutputFile -append
                $LDisk.HealthStatus | Out-File -FilePath $OutputFile -append
                $LDisk | Get-StorageReliabilityCounter | Select-Object * | FL | Out-File -FilePath $OutputFile -append
                "==================" | Out-File -FilePath $OutputFile -append 
                } 

#---------- Running process info
Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Getting Process info"

	$sectionDescription = "Process_and_Service_Tasklist"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_Process_and_Service_info.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Process_and_Service_Tasklist"
		$CommandToExecute = 'tasklist /svc /fo list'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		$CommandToExecute = 'tasklist /v'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		$CommandToExecute = 'tasklist /M'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "Process_and_Service_Tasklist" -sectionDescription $sectionDescription

	$sectionDescription = "Process_and_Service_info"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_Process_and_Service_info.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "Process_and_Service_info"
		$CommandToExecute = 'wmic process get * /format:texttable'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "Process_and_Service_info" -sectionDescription $sectionDescription


Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Getting app list"
if ($bn -gt 9000) {
	$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_GetAppxPackage.txt")
	import-module appx;get-appxpackage -allusers | Out-File -FilePath $OutputFile -append
}
if ($bn -gt 9600) {
	$OutputFile = Join-Path $pwd.path ($Env:ComputerName + "_GetAppxPackageBundle.txt")
	get-appxpackage -packagetype bundle | Out-File -FilePath $OutputFile -append
	
	$sectionDescription = "Dism /Get-ProvisionedAppxPackages"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_GetAppxProvisioned.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status $sectionDescription
		$CommandToExecute = 'dism /online /Get-ProvisionedAppxPackages'
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "$CommandToExecute" -sectionDescription $sectionDescription
}


Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_Setup_Addons.ps1"

# SIG # Begin signature block
# MIIjhgYJKoZIhvcNAQcCoIIjdzCCI3MCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCBsK8ojXLizEjn
# gtbCOuEni/xRdEU4zmDizZCRdGNdy6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVWzCCFVcCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgThSdIBiR
# XTZ94Jxed9OYKV2FFgkPVJmpmKk4aMTe9wYwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAGHmkGm9eL+nMPcZp9bM+UeJWuyw/HgAf9dSrTQ+HIBY81wyIl1hFR0T
# zutdvED5nkU1Lugm9KOg+42rIE8RrtDFDnFQaXskHoPcQWEte/oGBUP/25/6iHAG
# LTbiJcNOJvlpOtwIRba46uDWf5hZ505kmt1x3zkRUbl1ATGp8b0bt5W2QKsLGx8o
# UCZc0wP9wv2Ntv+yIzPgm/L4NjtCsWaNbBse03e9RWSDNKhD4c+1uN8uvYjJPdcW
# q8GhbeCyN//c51F03q048gW0F7BgjIXiPc6HmaeempX/0/3YsYx4IF6rvDpPRx0u
# +yyWaoTtqupe9vwEQ/FycVEI6ihjqrChghLvMIIS6wYKKwYBBAGCNwMDATGCEtsw
# ghLXBgkqhkiG9w0BBwKgghLIMIISxAIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUwYL
# KoZIhvcNAQkQAQSgggFCBIIBPjCCAToCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgHQQ9krEErM05kU6zQL17jzW12VGcVSdm6eVOeP7DTCACBmGB8A0Q
# QRgRMjAyMTExMTExNjUzMzUuN1owBIACAfSggdSkgdEwgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpGNzdG
# LUUzNTYtNUJBRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZaCCDkQwggT1MIID3aADAgECAhMzAAABXp0px1+HBaHqAAAAAAFeMA0GCSqGSIb3
# DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAk
# BgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIxMDExNDE5
# MDIxOVoXDTIyMDQxMTE5MDIxOVowgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpX
# YXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQg
# Q29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0
# byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpGNzdGLUUzNTYtNUJBRTEl
# MCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZI
# hvcNAQEBBQADggEPADCCAQoCggEBAJrTI4OQehn3oKp2zuh6WP2Zib/Dxw/srLee
# yTb9ed7PX+fLg7zBA0yl6ivF2n6lauGH8W7EBwRPEv7ZCSXwXgYZ6GGaH8aU+OrD
# XAbc4BXTO5XnLGwSbaye9R2+uQHdCJmaMtz/lEBWUK5xvHoj0TUrXOZdZ/vv7TqM
# WA4h1AT1w/JBR4kHtV1i8KWdlQ+dZX/gNHpA72IoLoOmpImbGRzcGQ4Z2Kzq4eMB
# 9wjaFRV1JF/wz1hLFIjGtlU3eGjRBiBEEVI7UEMMSvI4rK+CfLAIZnULu7SzlIfq
# SU3R0pSNUahwpWdCiB6fKzIq94Z+9888moQuo95RAPmzHQW1MI0CAwEAAaOCARsw
# ggEXMB0GA1UdDgQWBBSqcny6Dd1L5VTCEACezlR41fgfKzAfBgNVHSMEGDAWgBTV
# YzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3Js
# Lm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAx
# MC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8v
# d3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3
# LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqG
# SIb3DQEBCwUAA4IBAQB/IfxZhMYkBMqRmXnh/Vit4bfxyioAlr7HJ1XDSHTIvRwD
# D1PGr0upZE/vrrI/QN/1Wi6vDcKmnJ2r7Xj6pWZOZqc9Bp+uBvpPaulue4stu3Tq
# KTc9Fu2K5ibctpF4oHPfZ+IKeChop+Mk9g7N5llHzv0aCDiaM0w2aAT3rj3QHQS8
# ijnQ5/qhtzwo1AoUnV1y2urWwX5aHdUzaoeAJrvnf2ee89Kf4ycjjyafNJSUp/qa
# XBlbjMu90vNubJstdSxOtvwcxeeHP6ZaYbTl2cOla4cokiPU+BUjIZA/t/IZfYoa
# zMGmBtLWFJZdC9LYWWmLLsNJ2W21qkeSSpEAw4pmMIIGcTCCBFmgAwIBAgIKYQmB
# KgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNh
# dGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1
# WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77Xxo
# SyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024
# OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0yS
# wcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpC
# TUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnN
# POcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAG
# CSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8E
# TzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBM
# MEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRz
# L01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGP
# BgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0
# LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0A
# TABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0w
# DQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXi
# qf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxA
# QEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl
# 2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2Jf
# mttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLh
# nPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJx
# qgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/n
# MQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJ
# KlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnP
# GUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR
# 3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950
# iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpGNzdGLUUzNTYtNUJB
# RTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcG
# BSsOAwIaAxUAVkmPV/8hZVS9FzbtoX2x3Z2xYyqggYMwgYCkfjB8MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQg
# VGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOU3owUwIhgPMjAy
# MTExMTExODExMTdaGA8yMDIxMTExMjE4MTExN1owdzA9BgorBgEEAYRZCgQBMS8w
# LTAKAgUA5TejBQIBADAKAgEAAgId3wIB/zAHAgEAAgIRcjAKAgUA5Tj0hQIBADA2
# BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIB
# AAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAMVcQ6DA337B+nYZS4Nu3GnQ2dLtPG94
# XD0a3OLUC8hyyzXH/O1HSCsiZeRQBI90IknG3BRnIyZYKA+DUCTE052jTqnCr8X/
# AqZYUAlzpZSVmZdljLEuBbzSsdvlwW7WhfJR5Ed2yJNJU4KBHGk9WFWa/7+QLiLD
# ud0cPtbNOf6wMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENB
# IDIwMTACEzMAAAFenSnHX4cFoeoAAAAAAV4wDQYJYIZIAWUDBAIBBQCgggFKMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQg7fGJgwf9
# Psfk5k2obONekg10DH771olEkdq2vIWuyK4wgfoGCyqGSIb3DQEJEAIvMYHqMIHn
# MIHkMIG9BCB+5YTslNSXjuB+5mQDTKRkM7prkewhXnevXpLv8RLT4jCBmDCBgKR+
# MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMT
# HU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABXp0px1+HBaHqAAAA
# AAFeMCIEIA7+a3GKWHnFe1xvtOIbZidJlYhPJVlpSKVJ8AP5NjGDMA0GCSqGSIb3
# DQEBCwUABIIBADyx7S2XNIJlipQdrdXKxDMwZZ/DOH0hp5flpr4oexs0vli3wSCY
# 1YbY/yf8sgh5WA7uV0diR4XiDXhgCHePlw73rK9kNG+maDmMhkvA3lYT/SrnrO1S
# 9ctkKeXLQwqG7OK8o5cY19iF+2WMbOPdrGgcYnrmxegqnapz11/NDH+CbrYvbsXo
# UXK0LHAwezWGyFAxhVauOJyq7uJTnHfPjH3Du2c3octcHVQ0wRtizkCF+EFXyBq2
# Aqv3u7yIuemd0J1mGdRbL9iGD21+T299WdFB9tBik6XB1LRablRs3U9i+dApawHR
# wzhRUFMCbYIcT1pTj8AJCAHedFtEvQvVoUo=
# SIG # End signature block
