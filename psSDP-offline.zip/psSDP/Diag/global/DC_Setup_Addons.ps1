#************************************************
# DC_Setup_Addons.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects additional Setup information.
# Called from: TS_AutoAddCommands_Setup.ps1
#*******************************************************

Param($MachineName = $Computername, $Path = "")

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_Setup_Addons.ps1"

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $ScriptVariable.ID_CTSAddonsDescription


# detect OS version
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber

function isOSVersionAffected
{
	if ([int]$bn -gt [int](9600))
	{
		return $true
	}
	else
	{
		return $false
	}
}

function RunNet ([string]$NetCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBClient -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append

	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n`n`n" | Out-File -FilePath $OutputFile -append
}

#--- Section CBS & PNP info, components hive, SideBySide hive, Iemain.log
$sectionDescription = "Windows logs folders"

if(test-path (join-path $Env:windir "Logs"))
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Compress \Logs"
	$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\Logs" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_Windows-Logs.zip") -fileDescription "Windows Log Folder" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DestinationTempFolder -Force -Recurse
}
if(test-path (join-path $Env:windir "System32\LogFiles"))
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Compress \System32\LogFiles"
	$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
	Copy-Item "$env:WinDir\System32\LogFiles" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
	CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_Windows-System32-Logs.zip") -fileDescription "System32 LogFiles Folders" -sectionDescription $sectionDescription -Recursive
	Remove-Item $DestinationTempFolder -Force -Recurse
}

Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status (join-path $Env:windir "Servicing\Sessions")
$arrWindirLogsFiles = get-childitem -force -path (join-path $Env:windir "Servicing\Sessions") -recurse -exclude *.temp,*.tmp | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrWindirLogsFiles -fileDescription "Windows\Servicing\Sessions folder" -sectionDescription "Servicing\Sessions Folder" -DestinationFileName ($MachineName + "Windows-Servicing-Sessions.zip") -RenameOutput $true -recursive 

Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status (join-path $Env:windir "inf")
$arrWindirLogsFiles = get-childitem -force -path (join-path $Env:windir "inf\*") -include *.log | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrWindirLogsFiles -fileDescription "Windows\inf\*.log" -sectionDescription "inf\*.log" -DestinationFileName ($MachineName + "Windows-Inf-logs.zip") -RenameOutput $true -recursive 

	$filesToCollect = "$env:WinDir\servicing\sessions\sessions.xml"
	$filesDescription = "servicing\sessions\sessions.xml"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

	$filesToCollect = "$env:WinDir\Logs\MoSetup\UpdateAgent.log"
	$filesDescription = "MoSetup\UpdateAgent.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

	$filesToCollect = "$env:WinDir\iemain.log"
	$filesDescription = "iemain.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -RenameOutput $true -MachineNamePrefix $ComputerName
	}

#----------Registry
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Collect Registry files"

	$OutputFile= $MachineName + "_reg_Component_Based_Servicing.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\CurrentVersion\Component Based Servicing" -OutputFile $OutputFile -fileDescription "Components Hive"

	$OutputFile= $MachineName + "_reg_SideBySide.HIV"
	RegSave -RegistryKey "HKLM\Software\Microsoft\Windows\CurrentVersion\SideBySide" -OutputFile $OutputFile -fileDescription "Components Hive"

	$OutputFile= $ComputerName + "_reg_SideBySide.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\SideBySide" -OutputFile $OutputFile -fileDescription "SideBySide Reg key" -Recursive $true
		
#----------Directory listing 
	$sectionDescription = "Dir $env:WinDir\Winsxs\temp"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_winsxsTEMP.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\Winsxs\temp" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription

	$sectionDescription = "Dir $env:WinDir\Winsxs"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_winsxs.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\Winsxs" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription
	
	$sectionDescription = "Dir $env:WinDir\servicing\packages"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_dir_servicing-packages.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$env:WinDir\servicing\packages" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription $fileDescription -sectionDescription $sectionDescription
	
#---------- Section Windows Store info
	$sectionDescription = "Copying Windows Store logs"
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectionDescription

	$filesToCollect = "$Env:Temp\winstore.log"
	$filesDescription = "$Env:Temp\winstore.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}

	$filesToCollect = "$Env:Temp\winstore.log"
	$filesDescription = "$Env:Temp\winstore.log"
	if (test-path $FilesToCollect) {
		CollectFiles -filesToCollect $filesToCollect -fileDescription $filesDescription -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
	}
	
if (test-path "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Packages\WinStore_cw5n1h2txyewy\AC\Temp\Winstore.log" -fileDescription "Winstore log" -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
}
if (test-path "$env:localappdata\Temp\WinStore.log")
{
	CollectFiles -filesToCollect "$env:localappdata\Temp\WinStore.log" -fileDescription "Broker log" -sectionDescription $sectionDescription -renameOutput $true -MachineNamePrefix $MachineName
}
	
#---------- MUSE logs for Win10+
if (get-service usosvc -EA SilentlyContinue)
 {
	$sectionDescription = "Copying MUSE logs for Win10"
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status $sectionDescription

		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy UsoPrivate\UpdateStore"
		$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:programdata\UsoPrivate\UpdateStore" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_UsoPrivate-UpdateStore.zip") -fileDescription "UsoPrivate-UpdateStore Folder" -sectionDescription $sectionDescription -Recursive
		Remove-Item $DestinationTempFolder -Force -Recurse
		
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy UsoShared\Logs"
		$DestinationTempFolder = Join-Path ($PWD.Path) ([System.Guid]::NewGuid().ToString())
		Copy-Item "$env:programdata\USOShared\Logs" -Destination $DestinationTempFolder -Force -Recurse -ErrorAction SilentlyContinue
		CompressCollectFiles -filesToCollect $DestinationTempFolder -DestinationFileName ($ComputerName + "_USOShared-Logs.zip") -fileDescription "USOShared-Logs Folder" -sectionDescription $sectionDescription -Recursive
		Remove-Item $DestinationTempFolder -Force -Recurse
		
	  # robocopy %_OLDPROGRAMDATA%\USOPrivate\UpdateStore %_TEMPDIR%\Windows.old\MUSE %_ROBOCOPY_PARAMS% /S > nul
	  # robocopy %_OLDPROGRAMDATA%\USOShared\Logs %_TEMPDIR%\Windows.old\MUSE %_ROBOCOPY_PARAMS% /S > nul

	$sectionDescription = "SCHTASKS /query /v /TN \Microsoft\Windows\UpdateOrchestrator\"
		$OutputFile = Join-Path $pwd.path ($ComputerName + "_MUSE_ScheduledTasks.txt")
		Write-DiagProgress -activity $ScriptStrings.ID_WindowsUpdateLogCollect -Status "MUSE ScheduledTasks"
		$CommandToExecute = 'SCHTASKS /query /v /TN \Microsoft\Windows\UpdateOrchestrator\ '
		RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
		collectfiles -filesToCollect $OutputFile -fileDescription "MUSE: ScheduledTasks" -sectionDescription $sectionDescription
}
#---------- Section Delivery Optimizaton logs and powershell for Win10+
if (get-service dosvc -EA SilentlyContinue) {
	$sectionDescription = "Copying DeliveryOptimization logs"
	if (test-path "$Env:windir\ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs" )
	{
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy DeliveryOptimization\Logs"
		$arrDOsavedLogsFiles = get-childitem -force -path (join-path $Env:windir "ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Logs") -recurse -include *.log,*.etl | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrDOsavedLogsFiles -fileDescription "DeliveryOptimization\Logs folder" -sectionDescription "DeliveryOptimization\Logs Folder" -DestinationFileName ($MachineName + "DeliveryOptimization-logs.zip") -RenameOutput $true -recursive 
	}
	if (test-path "$Env:windir\SoftwareDistribution\DeliveryOptimization\SavedLogs" )
	{
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Copy DeliveryOptimization\SavedLogs"
		$arrDOsavedLogsFiles = get-childitem -force -path (join-path $Env:windir "SoftwareDistribution\DeliveryOptimization\SavedLogs") -recurse -include *.log,*.etl | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrDOsavedLogsFiles -fileDescription "DeliveryOptimization\Logs folder" -sectionDescription "DeliveryOptimization\Logs Folder" -DestinationFileName ($MachineName + "DeliveryOptimization-logs.zip") -RenameOutput $true -recursive 
	}
}
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons  -Status "Get DeliveryOptimization Registry"
	$OutputFile= $ComputerName + "_reg_DeliveryOptimization.txt"
	RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows\CurrentVersion\DeliveryOptimization" -OutputFile $OutputFile -fileDescription "DeliveryOptimization Reg key" -Recursive $true
	
	$OutputFile= $ComputerName + "_DeliveryOptimization_info.txt"
	Get-DeliveryOptimizationPerfSnap -Debug -Verbose | Out-File -FilePath $OutputFile -append 
	Get-DeliveryOptimizationStatus -Debug -Verbose | Out-File -FilePath $OutputFile -append 
 
#---------- Windows Upgrade logs
  
<#----------Copy Components Registry hive -- done in DC_ServicingLogs.ps1
# $ComponentsHivOutputFileName = Join-Path $pwd.path ($ComputerName + "_reg_Components.HIV")
# copy $ENV:windir\system32\config\components $ComponentsHivOutputFileName /y
$sectionDescription = "Additional Components Registry hive"
$OutputFile = $ComputerName + "_reg_Components.HIV"
$ComponentsHiv = "$ENV:windir\system32\config\components"
if (test-path $ComponentsHiv)
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Copy $ComponentsHiv"
	Copy-Item -Path $ComponentsHiv -Destination $OutputFile
	CollectFiles -filesToCollect $OutputFile -fileDescription "Components Registry hive file" -SectionDescription $sectionDescription
}
else
{
  "$ComponentsHiv Does not exist" | WriteTo-StdOut
}
#>


<#

#--- Section for App Compat Info  Only run if flag set
	$sectiondescription = "App Compat AppPatch files"
		#		Command: All logs in %windir%\AppPatch*\CompatAdmin.log
		#		OutputFileName: wds_tracing_logs.zip
	if (test-path $env:SystemRoot\AppPatch\CompatAdmin.log)
		{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Compress AppPatch files"
			compresscollectfiles -filesToCollect (join-path $env:SystemRoot "AppPatch\CompatAdmin.log") -Recursive -fileDescription "App Compat Log Files" -sectionDescription $sectiondescription -DestinationFileName "AppCompat_logs.zip" -RenameOutput $true
		}
	else
		{
		  "$env:SystemRoot\AppPatch\CompatAdmin.log Does not exist" | WriteTo-StdOut
		}
	$sectiondescription = "App Compat AppPatch64 files"	
	if (test-path $env:SystemRoot\AppPatch64\CompatAdmin.log)
		{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Compress AppPatch64 files"
			compresscollectfiles -filesToCollect (join-path $env:SystemRoot "AppPatch64\CompatAdmin.log") -Recursive -fileDescription "App Compat 64 Log Files" -sectionDescription $sectiondescription -DestinationFileName "AppCompat64_logs.zip" -RenameOutput $true
		}
	else
		{
		  "$env:SystemRoot\AppPatch64\CompatAdmin.log Does not exist" | WriteTo-StdOut
		}

#----------Registry
		$InstallerKey = 'HKLM\Software\Microsoft\Windows\CurrentVersion\Installer'
		$OutputFile= $ComputerName + "_AppCompat_Reg_WindowsInstaller.txt"
		RegQuery -RegistryKeys $Installerkey -OutputFile $OutputFile -fileDescription "Installer Reg key" -Recursive $true
		Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "App Compat Reg_WindowsInstaller files"
	<#	
	$sectiondescription = "App Compat Reg_WindowsInstaller files"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_AppCompat_Reg_WindowsInstaller.txt")
	$fileDescription = "HKLM\Software\Microsoft\Windows\CurrentVersion\Installer - registry key export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKLM\Software\Microsoft\Windows\CurrentVersion\Installer" ' + $OutputFile
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true
#>
<#
	$sectiondescription = "App Compat AppCompatFlags_Reg_HKLM files"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_AppCompatFlags_Reg_HKLM.txt")
	$fileDescription = "HKLM\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags - registry key export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKLM\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags" ' + $OutputFile
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

	$sectiondescription = "App Compat AppCompatFlags_Reg_HKCU files"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_AppCompatFlags_Reg_HKCU.txt")
	$fileDescription = "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags - registry key export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKCU\Software\Microsoft\Windows NT\CurrentVersion\AppCompatFlags" ' + $OutputFile
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

	$sectiondescription = "Reg_LocalMachine-Software Hive TXT file"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_Reg_LocalMachine-Software_HKLM.txt")
	$fileDescription = "HKLM\Software - registry export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKLM\Software" ' + $OutputFile
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

	$sectiondescription = "Reg_CurrentUser-Software Hive TXT file"
	$OutputFile = Join-Path $pwd.path ($ComputerName +  "_Reg_CurrentUser-Software_HKCU.txt")
	$fileDescription = "HKCU\Software - registry export"
	$CommandToExecute = 'cmd.exe /c REG EXPORT "HKCU\Software" ' + $OutputFile
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	RunCmD -commandToRun $CommandToExecute 
	collectfiles -filestocollect $OutputFile -filedescription $fileDescription -sectiondescription $sectionDescription -noFileExtensionsOnDescription -RenameOutput $true

#----------Event Logs
	$sectiondescription = "App Compat EventLog files"
	#		Command: All App Compat EventLogs in %windir%\System32\Winevt\Logs
	#		OutputFileName: AppCompat_*_EventLogs.zip
	if (test-path $env:SystemRoot\System32\Winevt\Logs\*compatibility*.evtx)
	{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription compatibility*.evtx"
		compresscollectfiles -filesToCollect (join-path $env:SystemRoot "System32\Winevt\Logs\*compatibility*.evtx") -Recursive -fileDescription "App Compat Event Logs" -sectionDescription $sectiondescription -DestinationFileName "AppCompat_evt_compatibility_EventLogs.zip" -RenameOutput $true
	}
	if (test-path $env:SystemRoot\System32\Winevt\Logs\*inventory*.evtx)
	{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription *inventory*.evtx"
		compresscollectfiles -filesToCollect (join-path $env:SystemRoot "System32\Winevt\Logs\*inventory*.evtx") -Recursive -fileDescription "App Compat Event Logs" -sectionDescription $sectiondescription -DestinationFileName "AppCompat_evt_inventory_EventLogs.zip" -RenameOutput $true
	}
	if (test-path $env:SystemRoot\System32\Winevt\Logs\*program-telemetry*.evtx)
	{	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription *program-telemetry*.evtx"
		compresscollectfiles -filesToCollect (join-path $env:SystemRoot "System32\Winevt\Logs\*program-telemetry*.evtx") -Recursive -fileDescription "App Compat Event Logs" -sectionDescription $sectiondescription -DestinationFileName "AppCompat_evt_program-telemetry_EventLogs.zip" -RenameOutput $true
	}

#----------Dir Outputs
	$sectionDescription = "App Compat: Dir C:\Program Files\"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_AppCompat_Dir_ProgramFiles.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	# RunPS "get-Childitem $ENV:Programfiles -recurse -Exclude *Defender*,*ScriptStore*,*CSC*,*RtBackup* -ErrorAction SilentlyContinue"
	$CommandToExecute = 'dir /a /s "C:\Program Files\" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "App Compat: Dir C:\Program Files\ output" -sectionDescription $sectionDescription
	
	$sectionDescription = "App Compat: Dir C:\Program Files (x86)\"
	$OutputFile = Join-Path $pwd.path ($ComputerName + "_AppCompat_Dir_ProgramFilesx86.txt")
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSAddons -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "C:\Program Files (x86)" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "App Compat: Dir C:\Program Files (x86)\ output" -sectionDescription $sectionDescription

#----------End section
# Waiting until Process DXdiag completes
	if ($dxdiagID) {
		Write-Host "$(Get-Date -UFormat "%R:%S") ...waiting max 40 seconds on DXdiag $dxdiagID to complete"
		Wait-Process -Id $dxdiagID -Timeout 40 -EA SilentlyContinue
		#Wait-Process -Name DXdiag -Timeout 40 -EA SilentlyContinue
		collectfiles -filesToCollect $dxdiagOutputFileName -fileDescription "dxdiag output" -sectionDescription "Additional Components DXdiag"
	}
#>
Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_Setup_Addons.ps1"