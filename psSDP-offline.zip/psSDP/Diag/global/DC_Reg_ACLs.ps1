﻿###########################################################################
# DC_Hardware
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Imports WURegValues.txt and gets the ACL's for each 
# key and subkey
###########################################################################

Import-LocalizedData -BindingVariable RegACls -FileName DC_Reg_ACLs -UICulture en-us
Write-DiagProgress -Activity $RegACLs.ID_RegACLs

"Start collecting " + $OutputFile + "`nSetting PS Drive to HKCR" | write-tosdtout 
New-PSDrive -PSProvider registry -Name HKCR -Root HKEY_CLASSES_ROOT

$OutputFile = $ComputerName + "_RegACLS.txt"
$Reg = ".\WURegValues.txt"


Set-Content $OutputFile ""
Get-Content $Reg | ForEach{
	Write-Host $_ 
	Get-Acl $_ | format-wide | Out-File $OutputFile -Append -Encoding ascii
	Get-ChildItem $_ | Get-Acl | Format-List | Out-File $OutputFile -Append -Encoding ascii
}

CollectFiles -filesToCollect $OutputFile -fileDescription "WU related registry ACL's" -sectionDescription "Windows Update Information"
logstop