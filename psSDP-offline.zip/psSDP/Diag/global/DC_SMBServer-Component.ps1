﻿#************************************************
# DC_SMBServer-Component.ps1
# Version 1.0
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about SMB Server.
# Called from: Networking Diags
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBServer -Status $ScriptVariable.ID_CTSSMBServerDescription

function RunNet ([string]$NetCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBServer -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


$sectionDescription = "SMB Server"


#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


$OutputFile= $Computername + "_SmbServer_info_pscmdlets.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"SMB Server Powershell Cmdlets"							| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"   1. Get-SmbServerConfiguration"						| Out-File -FilePath $OutputFile -append
"   2. Get-SmbServerNetworkInterface"					| Out-File -FilePath $OutputFile -append
"   3. Get-SmbShare"									| Out-File -FilePath $OutputFile -append
"   4. Get-SmbMultichannelConnection"					| Out-File -FilePath $OutputFile -append
"   5. Get-SmbMultichannelConstraint"					| Out-File -FilePath $OutputFile -append
"   6. Get-SmbOpenFile"									| Out-File -FilePath $OutputFile -append
"   7. Get-SmbSession"									| Out-File -FilePath $OutputFile -append
"   8. Get-SmbWitnessClient"							| Out-File -FilePath $OutputFile -append
"   9. Get-SmbBandWidthLimit"							| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n`n`n`n"	| Out-File -FilePath $OutputFile -append


$smbServerServiceStatus = get-service * | where {$_.name -eq "lanmanserver"}	
if ($smbServerServiceStatus -ne $null)
{
	if ((Get-Service "lanmanserver").Status -eq 'Running')
	{
		if ($bn -ge 9200)
		{
			# Reference:
			#	The basics of SMB PowerShell, a feature of Windows Server 2012 and SMB 3.0
			#   http://blogs.technet.com/b/josebda/archive/2012/06/27/the-basics-of-smb-powershell-a-feature-of-windows-server-2012-and-smb-3-0.aspx

			RunPS "Get-SmbServerConfiguration"			# W8/WS2012, W8.1/WS2012R2	#default fl
			RunPS "Get-SmbServerNetworkInterface"	-ft	# W8/WS2012, W8.1/WS2012R2	#default ft		
			RunPS "Get-SmbShare"					-ft	# W8/WS2012, W8.1/WS2012R2	#default ft
			#RunPS "Get-SmbShare | select Name, ScopeName, FolderEnumerationMode, Path, Description" -ft
			RunPS "Get-SmbShare | select Name, FolderEnumerationMode, Path, ShareState, ScopeName, CachingMode, LeasingMode, ContinuouslyAvailable, CATimeout, AvailabilityType" -ft
			RunPS "Get-SmbShare | select Name, EncryptData, SecurityDescriptor, Description" -ft
			RunPS "Get-SmbMultichannelConnection"	-ft	# W8/WS2012, W8.1/WS2012R2	#default ft			# run on both client and server
			RunPS "Get-SmbMultichannelConstraint"		# W8/WS2012, W8.1/WS2012R2	#default <unknown>	# run on both client and server
			RunPS "Get-SmbOpenFile"					-ft # W8/WS2012, W8.1/WS2012R2	#default ft	
			RunPS "Get-SmbSession"					-ft	# W8/WS2012, W8.1/WS2012R2	#default ft	
			RunPS "Get-SmbWitnessClient"				# W8/WS2012, W8.1/WS2012R2	#default <unknown>

			# Check if OS is W8.1/WS2012R2 and if the Windows Feature has been installed (FS-SMBBW)
			if ($bn -ge 9600)
			{
				if (Test-path "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SmbBandwidthLimitFilter")
				{
					RunPS "Get-SmbBandWidthLimit"			# W8.1/WS2012R2				#default <unknown>
				}
				else
				{
					"The `"SMB Bandwidth Limit`" feature is not installed."			| Out-File -FilePath $OutputFile -append
				}
			}
			else
			{
				"The `"SMB Bandwidth Limit`" feature and the Get-SmbBandWidthLimit ps cmdlet are only available on WS2012R2."			| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"The powershell cmdlets are only available on W8/WS2012 and later."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The `"Server`" service is not running. Not running pscmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $OutputFile -fileDescription "SMB Server Information from Powershell cmdlets" -SectionDescription $sectionDescription



		<#
		The following cmdlets have not be included:

		Get-SmbDelegation
			This 
			PS C:\windows\system32> Get-SmbDelegation -SmbServer "."
			CheckDelegationPrerequisites : SMB Delegation cmdlets require the installation of the Active Directory module for Windows PowerShell.
			At C:\windows\system32\windowspowershell\v1.0\Modules\SmbShare\SmbScriptModule.psm1:72 char:14
			+     $check = CheckDelegationPrerequisites
			+              ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				+ CategoryInfo          : NotSpecified: (:) [Write-Error], WriteErrorException
				+ FullyQualifiedErrorId : Microsoft.PowerShell.Commands.WriteErrorException,CheckDelegationPrerequisites


		Get-SmbShareAccess
			PS C:\> Get-SmbShareAccess

			cmdlet Get-SmbShareAccess at command pipeline position 1
			Supply values for the following parameters:
			Name[0]: Get-SmbWitnessClient
			Name[1]:
			Get-SmbShareAccess : No MSFT_SMBShare objects found with property 'Name' equal to 'Get-SmbWitnessClient'.  Verify the value of the property and
			retry.
			At line:1 char:1
			+ Get-SmbShareAccess
			+ ~~~~~~~~~~~~~~~~~~
				+ CategoryInfo          : ObjectNotFound: (Get-SmbWitnessClient:String) [Get-SmbShareAccess], CimJobException
				+ FullyQualifiedErrorId : CmdletizationQuery_NotFound_Name,Get-SmbShareAccess
		#>




#----------Net Commands
$OutputFile= $Computername + "_SmbServer_info_net.txt"
"========================================"	| Out-File -FilePath $OutputFile -append
"SMB Server Net Commands"					| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"Overview"									| Out-File -FilePath $OutputFile -append
"----------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. net accounts"						| Out-File -FilePath $OutputFile -append
"   2. net config server"					| Out-File -FilePath $OutputFile -append
"   3. net session"							| Out-File -FilePath $OutputFile -append
"   4. net files"							| Out-File -FilePath $OutputFile -append
"   5. net share"							| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
RunNet "accounts"

$smbServerServiceStatus = get-service * | where {$_.name -eq "lanmanserver"}	
if ($smbServerServiceStatus -ne $null)
{
	if ((Get-Service "lanmanserver").Status -eq 'Running')
	{
		RunNet "config server"
		RunNet "session"
		RunNet "files"
		RunNet "share"
	}
	else
	{
		"The `"Server`" service is not running. Not running pscmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
	
CollectFiles -filesToCollect $OutputFile -fileDescription "SMB Server Information (using net.exe)" -SectionDescription $sectionDescription



#----------Check if SMB Server (File and Printer Sharing) is installed, and then run the script
$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\LanManServer"
if (Test-Path $SvcKey) 
{
	#----------Registry
	$OutputFile= $Computername + "_SmbServer_reg_output.TXT"
	$sectionDescription = "SMB Server"
	$CurrentVersionKeys =	"HKLM\SYSTEM\CurrentControlSet\services\LanManServer",
							"HKLM\SYSTEM\CurrentControlSet\services\SRV",
							"HKLM\SYSTEM\CurrentControlSet\services\SRV2",
							"HKLM\SYSTEM\CurrentControlSet\services\SRVNET",
							"HKLM\Software\Microsoft\Windows\Windows Error Reporting\FullLiveKernelReports"

	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "SMB Server registry output" -SectionDescription $sectionDescription
}




#W8/WS2012 and later
if ($bn -gt 9000)
{
	#----------SMBClient / Operational
	$sectionDescription = "SMBServer-Operational EventLogs"
	$EventLogNames = "Microsoft-Windows-SMBServer/Connectivity", "Microsoft-Windows-SMBServer/Operational", "Microsoft-Windows-SMBServer/Security", "Microsoft-Windows-SMBDirect/Operational"
	$Prefix = ""
	$Suffix = "_evt_"
	& "$global:ToolsPath`\TS_GetEvents.ps1" -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}



# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAQ/Exu2DdaHW4s
# SJAWx9+5HMNFT4GIfqQiKeEA2RSVeqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg3Mve+8pf
# 9ZNR179j5PNCsXLgMIHfnD48SskuvUjq4gwwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBABkgPUiUOyjQFMKPc4wUFbRWP+cnsautQhh0++eFyfD8/uTq/9gbRHkN
# ZHjFmUNBDTH62N/Vf/T2mjjXfyuyXGy4/uu+KtI6A3zgJuT6uuOf3KL7GyR2RnqB
# V/gUpCw2SfQKQsJUZ34DL0ihlHwS/Po4a1spnun4KtkDVa8YfIvSXonmRYoUE9nr
# GnZtQns4/3Xuvstfd3RVtKavGOwOXXmYB/Z1SqH4nDPa+V4JAaHXMdjGe0f3rxx3
# ttNitCtUt0Z0ewotLQaaKwT8RUmox/lOqNs4aBc9YfbxDEHEtn3DPiMTM5XR4A35
# Md/9TmfS8x/asnVtx1UGrHlEs8akr8WhghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgK4HPAMoZ6GYe2touMARcyEhbg8f3v5AWNUGsUe4RuxoCBmCKzptW
# ARgTMjAyMTA1MTkyMjIzNTUuMzgyWjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABPIv9ubM/R5f9AAAAAAE8MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyM1oXDTIyMDExMjE3MjgyM1owgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046MTc5RS00
# QkIwLTgyNDYxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCYECrpaQOq9jkOBpC345fQ
# 0IvOpRqK8nEe+jopJc/5XNNqzanq5hrd9wib4RdvpuPj68n5Dm/XZu2vCqnWoxhy
# 3ixrbgS/rg3CS3bqp8Ag1UQg/xAz32TueeTOY1cOelcXRahosIcjlrrkv13AacFX
# m4AbYMCgYM6BzdZKARebc6zEv+4QCy4+1AV8RHQHEOdoj42OJpbFWlHvYKzXuM1A
# H4vmjT9o/fCq2mWD7Ig2/CpaId2gHK6R+S909iK27uVkjVap2/Sb4ATOLJbaVQ+X
# 0+hYbEcCesf93g+tAQXuvA8dH63doK5I5zdZCF5U/3Dibfl7ZCFsU6ks+ph4jJrb
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQU4aFn4soS+jazYT8lGOoYvyZnPEYwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAMvcQjJTdl3luSMzFqRkxRklJ+KWRUUlB
# 3I2KJVWb4Gn6eWdJTiWdC1uxejF2oPX0b+X9QIhi8u1AaV792eEit2lQzqVgPify
# TZGLjzK2Oou4Pj/F58Pp2m6HupGfuNAehln+hSvvIE5ggEnCiv9lVkAJOMlLHF38
# DbPv7pyWs0Lzv2sjZwPHvdhtV8lBtOYsE8Nxznlbsyc80vRnReqm8JQK6Z8xAD4S
# eY8duFFXhciETG2E0bh+/N3mwGnzXJzMbSKAKkzIw6Yxqf+zHzWPFim9DGZwmchq
# +6JBKtb4EGT0EFtfqGCrOPD5O7uPwSdj1apgXqo7Hctx7hcs5qjpwjCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjoxNzlFLTRCQjAtODI0NjElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAHUt0elneaPLba16Ke63RR3B65OaggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPqk8wIhgPMjAyMTA1MTkyMzE2MzFaGA8yMDIxMDUyMDIzMTYzMVowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+qTwIBADAKAgEAAgIYqAIB/zAHAgEAAgIR
# MzAKAgUA5FD7zwIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAI+E73p4h9kk
# SYCzO+rXLK7RK5Ia4XU7rSWLex0xaCG/tD8TBNoGZmVMrG4m9+o4FLmoY6aEzPou
# xTR4PEZU7Qh1EwiNCZblZFkfz+rofE0LgYHWkXw/kJuAVExDxVWBlamtk6kY7p1/
# XyFZKWFBMQMEU6Iu1idtHDCvZZNdvLOxMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE8i/25sz9Hl/0AAAAAATwwDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgBkgcedN0ouitm0+4zpsf2+DZQYraFmUgCpyso7qWot4wgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCCgSQK6TSS/wOc6qbfUfBGv7YhsPfGYhbgV
# IYrhJuhaRjCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABPIv9ubM/R5f9AAAAAAE8MCIEIB+co0f6Uly9BxK096y0E+Z8u4RNWInNiBJi
# 2xgL13agMA0GCSqGSIb3DQEBCwUABIIBAAk/Mc4/Y7VLB+x22oKcAK8ts1s+yn/E
# XyZcRFIaIsaU0JoNNEDOQ87+79tjSjX1gfPXbshD43P89LPGi+9+oYAjJYHTfu4t
# vJ24WNZZ23cqgJnWLNy0EC54PNyjqGTiq8vlQR31rFeAmAb+dGn0fE0ipD7l08HO
# JfNePv1OxWigl0uhul6Ypf27Sy5GPZDL9wJ+GZKgnZ8q+J95IC95IneeIrYl+yBv
# GWCd5NMjZ0MKyESPb9QQ3LxQjw7il06vgfKphwfX+DUVTcohg+7MgZw29v/T/Lnh
# tn6/lEgdzaduNJzSCccC8Yn0r5v+O2vlzapFuNH8EoQJcRocdpKVEAo=
# SIG # End signature block
