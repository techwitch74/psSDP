﻿#************************************************
# DC_SMBServer-Component.ps1
# Version 1.0
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about SMB Server.
# Called from: Networking Diags
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBServer -Status $ScriptVariable.ID_CTSSMBServerDescription

function RunNet ([string]$NetCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBServer -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


$sectionDescription = "SMB Server"


#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = gwmi -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


$OutputFile= $Computername + "_SmbServer_info_pscmdlets.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"SMB Server Powershell Cmdlets"							| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"   1. Get-SmbServerConfiguration"						| Out-File -FilePath $OutputFile -append
"   2. Get-SmbServerNetworkInterface"					| Out-File -FilePath $OutputFile -append
"   3. Get-SmbShare"									| Out-File -FilePath $OutputFile -append
"   4. Get-SmbMultichannelConnection"					| Out-File -FilePath $OutputFile -append
"   5. Get-SmbMultichannelConstraint"					| Out-File -FilePath $OutputFile -append
"   6. Get-SmbOpenFile"									| Out-File -FilePath $OutputFile -append
"   7. Get-SmbSession"									| Out-File -FilePath $OutputFile -append
"   8. Get-SmbWitnessClient"							| Out-File -FilePath $OutputFile -append
"   9. Get-SmbBandWidthLimit"							| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n`n`n`n"	| Out-File -FilePath $OutputFile -append


$smbServerServiceStatus = get-service * | where {$_.name -eq "lanmanserver"}	
if ($smbServerServiceStatus -ne $null)
{
	if ((Get-Service "lanmanserver").Status -eq 'Running')
	{
		if ($bn -ge 9200)
		{
			# Reference:
			#	The basics of SMB PowerShell, a feature of Windows Server 2012 and SMB 3.0
			#   http://blogs.technet.com/b/josebda/archive/2012/06/27/the-basics-of-smb-powershell-a-feature-of-windows-server-2012-and-smb-3-0.aspx

			RunPS "Get-SmbServerConfiguration"			# W8/WS2012, W8.1/WS2012R2	#default fl
			RunPS "Get-SmbServerNetworkInterface"	-ft	# W8/WS2012, W8.1/WS2012R2	#default ft		
			RunPS "Get-SmbShare"					-ft	# W8/WS2012, W8.1/WS2012R2	#default ft
			#RunPS "Get-SmbShare | select Name, ScopeName, FolderEnumerationMode, Path, Description" -ft
			RunPS "Get-SmbShare | select Name, FolderEnumerationMode, Path, ShareState, ScopeName, CachingMode, LeasingMode, ContinuouslyAvailable, CATimeout, AvailabilityType, EncryptData, SecurityDescriptor, Description" -ft
			RunPS "Get-SmbMultichannelConnection"	-ft	# W8/WS2012, W8.1/WS2012R2	#default ft			# run on both client and server
			RunPS "Get-SmbMultichannelConstraint"		# W8/WS2012, W8.1/WS2012R2	#default <unknown>	# run on both client and server
			RunPS "Get-SmbOpenFile"					-ft # W8/WS2012, W8.1/WS2012R2	#default ft	
			RunPS "Get-SmbSession"					-ft	# W8/WS2012, W8.1/WS2012R2	#default ft	
			RunPS "Get-SmbWitnessClient"				# W8/WS2012, W8.1/WS2012R2	#default <unknown>

			# Check if OS is W8.1/WS2012R2 and if the Windows Feature has been installed (FS-SMBBW)
			if ($bn -ge 9600)
			{
				if (Test-path "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SmbBandwidthLimitFilter")
				{
					RunPS "Get-SmbBandWidthLimit"			# W8.1/WS2012R2				#default <unknown>
				}
				else
				{
					"The `"SMB Bandwidth Limit`" feature is not installed."			| Out-File -FilePath $OutputFile -append
				}
			}
			else
			{
				"The `"SMB Bandwidth Limit`" feature and the Get-SmbBandWidthLimit ps cmdlet are only available on WS2012R2."			| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"The powershell cmdlets are only available on W8/WS2012 and later."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The `"Server`" service is not running. Not running pscmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $OutputFile -fileDescription "SMB Server Information from Powershell cmdlets" -SectionDescription $sectionDescription



		<#
		The following cmdlets have not be included:

		Get-SmbDelegation
			This 
			PS C:\windows\system32> Get-SmbDelegation -SmbServer "."
			CheckDelegationPrerequisites : SMB Delegation cmdlets require the installation of the Active Directory module for Windows PowerShell.
			At C:\windows\system32\windowspowershell\v1.0\Modules\SmbShare\SmbScriptModule.psm1:72 char:14
			+     $check = CheckDelegationPrerequisites
			+              ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				+ CategoryInfo          : NotSpecified: (:) [Write-Error], WriteErrorException
				+ FullyQualifiedErrorId : Microsoft.PowerShell.Commands.WriteErrorException,CheckDelegationPrerequisites


		Get-SmbShareAccess
			PS C:\> Get-SmbShareAccess

			cmdlet Get-SmbShareAccess at command pipeline position 1
			Supply values for the following parameters:
			Name[0]: Get-SmbWitnessClient
			Name[1]:
			Get-SmbShareAccess : No MSFT_SMBShare objects found with property 'Name' equal to 'Get-SmbWitnessClient'.  Verify the value of the property and
			retry.
			At line:1 char:1
			+ Get-SmbShareAccess
			+ ~~~~~~~~~~~~~~~~~~
				+ CategoryInfo          : ObjectNotFound: (Get-SmbWitnessClient:String) [Get-SmbShareAccess], CimJobException
				+ FullyQualifiedErrorId : CmdletizationQuery_NotFound_Name,Get-SmbShareAccess
		#>




#----------Net Commands
$OutputFile= $Computername + "_SmbServer_info_net.txt"
"========================================"	| Out-File -FilePath $OutputFile -append
"SMB Server Net Commands"					| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"Overview"									| Out-File -FilePath $OutputFile -append
"----------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. net accounts"						| Out-File -FilePath $OutputFile -append
"   2. net config server"					| Out-File -FilePath $OutputFile -append
"   3. net session"							| Out-File -FilePath $OutputFile -append
"   4. net files"							| Out-File -FilePath $OutputFile -append
"   5. net share"							| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
RunNet "accounts"

$smbServerServiceStatus = get-service * | where {$_.name -eq "lanmanserver"}	
if ($smbServerServiceStatus -ne $null)
{
	if ((Get-Service "lanmanserver").Status -eq 'Running')
	{
		RunNet "config server"
		RunNet "session"
		RunNet "files"
		RunNet "share"
	}
	else
	{
		"The `"Server`" service is not running. Not running pscmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
	
CollectFiles -filesToCollect $OutputFile -fileDescription "SMB Server Information (using net.exe)" -SectionDescription $sectionDescription



#----------Check if SMB Server (File and Printer Sharing) is installed, and then run the script
$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\LanManServer"
if (Test-Path $SvcKey) 
{
	#----------Registry
	$OutputFile= $Computername + "_SmbServer_reg_output.TXT"
	$sectionDescription = "SMB Server"
	$CurrentVersionKeys =	"HKLM\SYSTEM\CurrentControlSet\services\LanManServer",
							"HKLM\SYSTEM\CurrentControlSet\services\SRV",
							"HKLM\SYSTEM\CurrentControlSet\services\SRV2",
							"HKLM\SYSTEM\CurrentControlSet\services\SRVNET",
							"HKLM\Software\Microsoft\Windows\Windows Error Reporting\FullLiveKernelReports"

	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "SMB Server registry output" -SectionDescription $sectionDescription
}




#W8/WS2012 and later
if ($bn -gt 9000)
{
	#----------SMBClient / Operational
	$sectionDescription = "SMBServer-Operational EventLogs"
	$EventLogNames = "Microsoft-Windows-SMBServer/Connectivity", "Microsoft-Windows-SMBServer/Operational", "Microsoft-Windows-SMBServer/Security", "Microsoft-Windows-SMBDirect/Operational"
	$Prefix = ""
	$Suffix = "_evt_"
	& "$global:ToolsPath`\TS_GetEvents.ps1" -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}


