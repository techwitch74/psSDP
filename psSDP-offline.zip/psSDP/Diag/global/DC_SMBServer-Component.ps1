#************************************************
# DC_SMBServer-Component.ps1
# Version 1.0
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about SMB Server.
# Called from: Networking Diags
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBServer -Status $ScriptVariable.ID_CTSSMBServerDescription

function RunNet ([string]$NetCommandToExecute="")
{
	Write-DiagProgress -Activity $ScriptVariable.ID_CTSSMBServer -Status "net $NetCommandToExecute"
	
	$NetCommandToExecuteLength = $NetCommandToExecute.Length + 6
	"`n`n`n" + "=" * ($NetCommandToExecuteLength) + "`r`n" + "net $NetCommandToExecute" + "`r`n" + "=" * ($NetCommandToExecuteLength) | Out-File -FilePath $OutputFile -append
	$CommandToExecute = "cmd.exe /c net.exe " + $NetCommandToExecute + " >> $OutputFile "
	
	RunCmD -commandToRun $CommandToExecute  -CollectFiles $false
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
	"`n" | Out-File -FilePath $OutputFile -append
}


function RunPS ([string]$RunPScmd="", [switch]$ft)
{
	$RunPScmdLength = $RunPScmd.Length
	"-" * ($RunPScmdLength)		| Out-File -FilePath $OutputFile -append
	"$RunPScmd"  				| Out-File -FilePath $OutputFile -append
	"-" * ($RunPScmdLength)  	| Out-File -FilePath $OutputFile -append
	
	if ($ft)
	{
		# This format-table expression is useful to make sure that wide ft output works correctly
		Invoke-Expression $RunPScmd	|format-table -autosize -outvariable $FormatTableTempVar | Out-File -FilePath $outputFile -Width 500 -append
	}
	else
	{
		Invoke-Expression $RunPScmd	| Out-File -FilePath $OutputFile -append
	}
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
	"`n"	| Out-File -FilePath $OutputFile -append
}


$sectionDescription = "SMB Server"


#----------W8/WS2012 powershell cmdlets
# detect OS version and SKU
$wmiOSVersion = Get-CimInstance -Namespace "root\cimv2" -Class Win32_OperatingSystem
[int]$bn = [int]$wmiOSVersion.BuildNumber


$OutputFile= $Computername + "_SmbServer_info_pscmdlets.TXT"
"===================================================="	| Out-File -FilePath $OutputFile -append
"SMB Server Powershell Cmdlets"							| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"   1. Get-SmbServerConfiguration"						| Out-File -FilePath $OutputFile -append
"   2. Get-SmbServerNetworkInterface"					| Out-File -FilePath $OutputFile -append
"   3. Get-SmbShare"									| Out-File -FilePath $OutputFile -append
"   4. Get-SmbMultichannelConnection"					| Out-File -FilePath $OutputFile -append
"   5. Get-SmbMultichannelConstraint"					| Out-File -FilePath $OutputFile -append
"   6. Get-SmbOpenFile"									| Out-File -FilePath $OutputFile -append
"   7. Get-SmbSession"									| Out-File -FilePath $OutputFile -append
"   8. Get-SmbWitnessClient"							| Out-File -FilePath $OutputFile -append
"   9. Get-SmbBandWidthLimit"							| Out-File -FilePath $OutputFile -append
"===================================================="	| Out-File -FilePath $OutputFile -append
"`n`n`n`n"	| Out-File -FilePath $OutputFile -append


$smbServerServiceStatus = get-service * | where {$_.name -eq "lanmanserver"}	
if ($smbServerServiceStatus -ne $null)
{
	if ((Get-Service "lanmanserver").Status -eq 'Running')
	{
		if ($bn -ge 9200)
		{
			# Reference:
			#	The basics of SMB PowerShell, a feature of Windows Server 2012 and SMB 3.0
			#   http://blogs.technet.com/b/josebda/archive/2012/06/27/the-basics-of-smb-powershell-a-feature-of-windows-server-2012-and-smb-3-0.aspx

			RunPS "Get-SmbServerConfiguration"			# W8/WS2012, W8.1/WS2012R2	#default fl
			RunPS "Get-SmbServerNetworkInterface"	-ft	# W8/WS2012, W8.1/WS2012R2	#default ft		
			RunPS "Get-SmbShare"					-ft	# W8/WS2012, W8.1/WS2012R2	#default ft
			#RunPS "Get-SmbShare | select Name, ScopeName, FolderEnumerationMode, Path, Description" -ft
			RunPS "Get-SmbShare | select Name, FolderEnumerationMode, Path, ShareState, ScopeName, CachingMode, LeasingMode, ContinuouslyAvailable, CATimeout, AvailabilityType" -ft
			RunPS "Get-SmbShare | select Name, EncryptData, SecurityDescriptor, Description" -ft
			RunPS "Get-SmbMultichannelConnection"	-ft	# W8/WS2012, W8.1/WS2012R2	#default ft			# run on both client and server
			RunPS "Get-SmbMultichannelConstraint"		# W8/WS2012, W8.1/WS2012R2	#default <unknown>	# run on both client and server
			RunPS "Get-SmbOpenFile"					-ft # W8/WS2012, W8.1/WS2012R2	#default ft	
			RunPS "Get-SmbSession"					-ft	# W8/WS2012, W8.1/WS2012R2	#default ft	
			RunPS "Get-SmbWitnessClient"				# W8/WS2012, W8.1/WS2012R2	#default <unknown>

			# Check if OS is W8.1/WS2012R2 and if the Windows Feature has been installed (FS-SMBBW)
			if ($bn -ge 9600)
			{
				if (Test-path "HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Services\SmbBandwidthLimitFilter")
				{
					RunPS "Get-SmbBandWidthLimit"			# W8.1/WS2012R2				#default <unknown>
				}
				else
				{
					"The `"SMB Bandwidth Limit`" feature is not installed."			| Out-File -FilePath $OutputFile -append
				}
			}
			else
			{
				"The `"SMB Bandwidth Limit`" feature and the Get-SmbBandWidthLimit ps cmdlet are only available on WS2012R2."			| Out-File -FilePath $OutputFile -append
			}
		}
		else
		{
			"The powershell cmdlets are only available on W8/WS2012 and later."	| Out-File -FilePath $OutputFile -append
		}
	}
	else
	{
		"The `"Server`" service is not running. Not running pscmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
CollectFiles -filesToCollect $OutputFile -fileDescription "SMB Server Information from Powershell cmdlets" -SectionDescription $sectionDescription



		<#
		The following cmdlets have not be included:

		Get-SmbDelegation
			This 
			PS C:\windows\system32> Get-SmbDelegation -SmbServer "."
			CheckDelegationPrerequisites : SMB Delegation cmdlets require the installation of the Active Directory module for Windows PowerShell.
			At C:\windows\system32\windowspowershell\v1.0\Modules\SmbShare\SmbScriptModule.psm1:72 char:14
			+     $check = CheckDelegationPrerequisites
			+              ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
				+ CategoryInfo          : NotSpecified: (:) [Write-Error], WriteErrorException
				+ FullyQualifiedErrorId : Microsoft.PowerShell.Commands.WriteErrorException,CheckDelegationPrerequisites


		Get-SmbShareAccess
			PS C:\> Get-SmbShareAccess

			cmdlet Get-SmbShareAccess at command pipeline position 1
			Supply values for the following parameters:
			Name[0]: Get-SmbWitnessClient
			Name[1]:
			Get-SmbShareAccess : No MSFT_SMBShare objects found with property 'Name' equal to 'Get-SmbWitnessClient'.  Verify the value of the property and
			retry.
			At line:1 char:1
			+ Get-SmbShareAccess
			+ ~~~~~~~~~~~~~~~~~~
				+ CategoryInfo          : ObjectNotFound: (Get-SmbWitnessClient:String) [Get-SmbShareAccess], CimJobException
				+ FullyQualifiedErrorId : CmdletizationQuery_NotFound_Name,Get-SmbShareAccess
		#>




#----------Net Commands
$OutputFile= $Computername + "_SmbServer_info_net.txt"
"========================================"	| Out-File -FilePath $OutputFile -append
"SMB Server Net Commands"					| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"Overview"									| Out-File -FilePath $OutputFile -append
"----------------------------------------"	| Out-File -FilePath $OutputFile -append
"   1. net accounts"						| Out-File -FilePath $OutputFile -append
"   2. net config server"					| Out-File -FilePath $OutputFile -append
"   3. net session"							| Out-File -FilePath $OutputFile -append
"   4. net files"							| Out-File -FilePath $OutputFile -append
"   5. net share"							| Out-File -FilePath $OutputFile -append
"========================================"	| Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
"`n" | Out-File -FilePath $OutputFile -append
RunNet "accounts"

$smbServerServiceStatus = get-service * | where {$_.name -eq "lanmanserver"}	
if ($smbServerServiceStatus -ne $null)
{
	if ((Get-Service "lanmanserver").Status -eq 'Running')
	{
		RunNet "config server"
		RunNet "session"
		RunNet "files"
		RunNet "share"
	}
	else
	{
		"The `"Server`" service is not running. Not running pscmdlets."	| Out-File -FilePath $OutputFile -append
	}
}
else
{
	"The `"Server`" service does not exist. Not running ps cmdlets."	| Out-File -FilePath $OutputFile -append
}
	
CollectFiles -filesToCollect $OutputFile -fileDescription "SMB Server Information (using net.exe)" -SectionDescription $sectionDescription



#----------Check if SMB Server (File and Printer Sharing) is installed, and then run the script
$SvcKey = "HKLM:\SYSTEM\CurrentControlSet\services\LanManServer"
if (Test-Path $SvcKey) 
{
	#----------Registry
	$OutputFile= $Computername + "_SmbServer_reg_output.TXT"
	$sectionDescription = "SMB Server"
	$CurrentVersionKeys =	"HKLM\SYSTEM\CurrentControlSet\services\LanManServer",
							"HKLM\SYSTEM\CurrentControlSet\services\SRV",
							"HKLM\SYSTEM\CurrentControlSet\services\SRV2",
							"HKLM\SYSTEM\CurrentControlSet\services\SRVNET",
							"HKLM\Software\Microsoft\Windows\Windows Error Reporting\FullLiveKernelReports"

	RegQuery -RegistryKeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "SMB Server registry output" -SectionDescription $sectionDescription
}




#W8/WS2012 and later
if ($bn -gt 9000)
{
	#----------SMBClient / Operational
	$sectionDescription = "SMBServer-Operational EventLogs"
	$EventLogNames = "Microsoft-Windows-SMBServer/Connectivity", "Microsoft-Windows-SMBServer/Operational", "Microsoft-Windows-SMBServer/Security", "Microsoft-Windows-SMBDirect/Operational"
	$Prefix = ""
	$Suffix = "_evt_"
	& "$global:ToolsPath`\TS_GetEvents.ps1" -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}



# SIG # Begin signature block
# MIIjhwYJKoZIhvcNAQcCoIIjeDCCI3QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBFl8SuceIXEhxX
# 13U92vNF7K1SzYMwGVQiVlJzr4YtR6CCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXDCCFVgCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgYEBPxmMc
# 3MguToaI/JTUd3FDcKvd9EMekkJAd/yykIcwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAEtv5i0W/XyOpA+Y+4Q+WhhNduUIL6wy5zOMQlH9LLtd3Bxp4TxFiEf9
# eX0E+Io+S2NuezG2uOr+p1usfpOA4Pb+LWuYEzPZY/LOCvqQyBM7Eq6RHQjHYIof
# gan6Wa5w8BRlpoqGeldpy2v9rcU3v1YzpHzZbZ8Rkq90neIRcrtwjB1vybcWn9Fa
# j2htm6gqeGQopN9GePZAO33mLtF7b7jTRjZOqas67DR8ci0EVcp0eFdNXZtG/NK/
# l3xagtJD/zxIO+EoCeOOrhivc1zacnqVjIF93hFlfYEcOJLgdyiS/mZ/Xoxxq9s1
# px9R75HGQ4rI5GrfZr+Yg5FjKh7rUZehghLwMIIS7AYKKwYBBAGCNwMDATGCEtww
# ghLYBgkqhkiG9w0BBwKgghLJMIISxQIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVAYL
# KoZIhvcNAQkQAQSgggFDBIIBPzCCATsCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgd0qBG/c+RmhF5kVuJ/KzvX8RoNzSE8XQjkPGTTYqSgYCBmGBshkU
# qhgSMjAyMTExMTExNjUzMzUuMjNaMASAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3Bl
# cmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzRC
# RC1FMzdGLTVGRkMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2Wggg5EMIIE9TCCA92gAwIBAgITMwAAAVdEB2Lcb+i+KgAAAAABVzANBgkqhkiG
# 9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMTAxMTQx
# OTAyMTNaFw0yMjA0MTExOTAyMTNaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVy
# dG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzRCRC1FMzdGLTVGRkMx
# JTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQDebQOnVGb558C/akLV3MDwDYQeHs/uQkK3
# j6f2fEx+DQa+bwHxjKNJVf5YnQWrSk4BxKzrih9dcVQHwXoRybx/U/zoTnPNwibP
# W8w4a5XdCXct3icgtMgXcVXrnEvtmtmQXedMAYP+f9mI0NspXw9HcSiurUC8XTg0
# 7mnUDG3WtOZTxp1hsGd54koCClUYKqglZYR88DbUYdQB/mcW30nu7fM96BCgHUwM
# u0rD/MpIbd7K43YdAcpDxXaWgIKsFgiSSZhpNIAK0rxwvPr17RqNzCYVkEXuSbc3
# Q+ZHWih/bnPYJ0obF8gxIRmY8d/m/HLqhDvGx79Fj1/TERH638b5AgMBAAGjggEb
# MIIBFzAdBgNVHQ4EFgQUXTF7u+g4IZ1P5D0zCnRZEfaAqdkwHwYDVR0jBBgwFoAU
# 1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0w
# Ny0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkq
# hkiG9w0BAQsFAAOCAQEAJXd5AIBul1omcr3Ymy0Zlq+8m+kUsnI1Q4PLXAorUtNb
# E1aeE/AHdkHmHyVnyugzBJO0EQXyoHTe6BPHV7ZkFS/iXMS49KVLsuDQeUXIXLXg
# +XUZ03ypUYvL4ClGsQ3KBSMzRFM9RB6aKXmoA2+P7iPVI+bSLsJYpP6q7/7BwMO5
# DOIBCyzToHXr/Wf+8aNSSMH3tHqEDN8MXAhS7n/EvTp3LbWhQFh7RBEfCL4EQICy
# f1p5bhc+vPoaw30cl/6qlkjyBNL6BOqhcdc/FLy8CqZuuUDcjQ0TKf1ZgqakWa8Q
# daNEWOz/p+I0jRr25Nm0e9JCrf3aIBRUQR1VblMX/jCCBnEwggRZoAMCAQICCmEJ
# gSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18
# aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdN
# uDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NM
# ksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2K
# Qk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZ
# zTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQ
# BgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCB
# jwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAd
# AEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAd
# MA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F
# 4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbM
# QEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mB
# ZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7ti
# X5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S
# 4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3ai
# caoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf
# 5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsb
# iSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJ
# zxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB
# 0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/e
# dIhJEqGCAtIwggI7AgEBMIH8oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQ
# dWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzRCRC1FMzdGLTVG
# RkMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAH
# BgUrDgMCGgMVABEt+Eliew320hv4GyEME684GfDyoIGDMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDlN2UeMCIYDzIw
# MjExMTExMTM0NzEwWhgPMjAyMTExMTIxMzQ3MTBaMHcwPQYKKwYBBAGEWQoEATEv
# MC0wCgIFAOU3ZR4CAQAwCgIBAAICFIECAf8wBwIBAAICEVkwCgIFAOU4tp4CAQAw
# NgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgC
# AQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQBDA/8UuU/RLotpyyr3EbaUHB5lPlF7
# NLMegtOFT7iTZFPdsz4ICYAGg23/qcsc6B4kMdeFuBb3AmNPrQVue89IEgALuNqT
# Jnk53GPCCVgSjiQcmKjujxldnIT0gRYcN5IYIRxC3ZJZhG1ul/stjtGQb14Xs606
# HznWqTb2MaSy4DGCAw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAABV0QHYtxv6L4qAAAAAAFXMA0GCWCGSAFlAwQCAQUAoIIBSjAa
# BgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIHMmBrAB
# e+lzeinLktftBanlSRf9YuKqbQpd9BAijhbJMIH6BgsqhkiG9w0BCRACLzGB6jCB
# 5zCB5DCBvQQgLFqNDUOr87rrqVLGRDEieFLEY7UMNnRcWVpB7akcoBMwgZgwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAAVdEB2Lcb+i+KgAA
# AAABVzAiBCBQ1MvjbNps+jyIR2RILZaI86EOi+hlZRbRUyiwHUBi3TANBgkqhkiG
# 9w0BAQsFAASCAQARn3K/L6CqCsTGyQcxIIQLvtJbU885X1bgxlwAv1njapHTwYUC
# NGc/4rVc13l0qCVVyGaoD2VVuD6VF28bCzkOoqBDcK6V/CDKJYjCOdd2gmCuZyaW
# 2Ki/e2TnQNQhN75E29053jBVGD1k+brPD4wK29T4SVeh2fk0XETd+/XLv7NJwoGJ
# GIMbDlK6ev3o1m1qk8tuXC9DIAyU3ZvQ39dFjs2I+Tmc4TyOm7eBgOOJ8AxFNG1z
# hhob+c2aI1Wo2bRh9VIJ6PRgriqSgFf16brDCQHhMWCSypaX17ECXl1osTorNTLf
# QHeXiKGujW6kWzxaCAaDSOoNiD/Ph7yd4CyY
# SIG # End signature block
