﻿#************************************************
# DC_RDSServerInfo.ps1
# Version 1.0.0
# Date: 21-01-2012
# Author: Daniel Grund - dgrund@microsoft.com
# Description: 
#	This script gets the RDS config and
#   checks vital signs to inform user.
# 1.0.0 Beta release / 2021-03-30 Waltere #_#
#************************************************
PARAM(
	[string] $TargetHost = "localhost",
   	[string] $RootCause = "",
   	[object] $RDSobject = $null,
	[array]  $OutputFileName
)
# globals and function definitions for RDS
$OutputFolder = $PWD.Path 
Import-LocalizedData -BindingVariable RDSSDPStrings -FileName DC_RDSServerInfo -UICulture en-us
$bIsRDSSH = $false
$bIsRDSGW = $false
$bIsRDSCB = $false
$bIsRDSLS = $false
$RCNum = 0

Trap [Exception]  #_#
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
	
. ./DC_RDSHelper.ps1 $RDSHelper $RDSSDPStrings
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSWMIGet
Copy-Item .\RDS.xslt (join-path $pwd.path "result\RDS.xslt")
#[array]$OutputFileName+= $OutputFolder + "\" + "RDS.xslt"

#test for validity of the target end point
$OS = get-WmiObject -Class win32_operatingsystem -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate 
$Computer = get-WmiObject -Class win32_ComputerSystem -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate  
if (($Computer -ne $null) -and (($TargetHost -ne $Computer.DNSHostName) -or ( $TargetHost -eq $Computer.DNSHostName + "." + $Computer.Domain)))
{
    $TargetHost = $Computer.DNSHostName.ToUpper()
}



$RDSobject = FilterWMIObject (get-WmiObject -Class Win32_TerminalServiceSetting -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$RDSGateWay = FilterWMIObject (get-WmiObject -Class Win32_TSGatewayServer -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate -EA SilentlyContinue) #_# -EA
$RDSCB = FilterWMIObject (get-WmiObject -Class Win32_SessionDirectoryServer -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate -EA SilentlyContinue) #_# -EA
$RDSLS = FilterWMIObject (get-WmiObject -Class Win32_TSLicenseServer -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate -EA SilentlyContinue) #_# -EA
$Error.Clear()
if ($OS -eq $null) 
{
	ReportError -RCNum $RCNum -RootCause $RDSSDPStrings.ID_RDSWMIGetError -Solution $RDSSDPStrings.ID_RDSWMIGetSolution
	exit
}

if ($RDSCB -ne $null)
{
	"RDSCB " | WriteTo-StdOut
	$bIsRDSCB = $true
	$OutputFileName = SaveAsXml $RDSCB  ($TargetHost + "_Win32_SessionDirectoryServer.xml") $OutputFileName

	#start multi system
	# skip this for now, enable after further testing
	if($false) # remove for enable
	{		   # remove for enable
	$TargetHost_Temp = $TargetHost  # calling ourself will break targethost, saving it.
    $RDSCBCluster = get-WmiObject -Class Win32_SessionDirectoryCluster -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
    $ConnectionBroker = New-Object RDSHelper+ConnectionBroker
	$ConnectionBroker.ConnectionBrokerName = $TargetHost_Temp
	
	foreach( $Cluster in $RDSCBCluster)
    {
		$Collection = New-Object RDSHelper+Collection
		$Collection.CollectionName = $Cluster.ClusterName
	
        $Query = "Select * from Win32_SessionDirectoryServer where ClusterName='" + $Cluster.ClusterName + "'" 
	    $RDSCBClusterEnum = get-WmiObject -Query $Query -Namespace root\cimv2 -Authentication PacketPrivacy -Impersonation Impersonate
		$Collection.CollectionServers = $RDSCBClusterEnum.ServerName
        $ConnectionBroker.Collections += $Collection
    }
	# Treeview for the server list , don't show if there are no collections
	if($ConnectionBroker.Collections.Count -gt 0)
	{
		$objTreeView = CreateTreeViewUI -ConnectionBroker $ConnectionBroker
		# Get all the servers that were checked in the UI
		$ServersToCollect = GetNodesChecked -objTreeView $objTreeView -ServersToCollect $ServersToCollect
		# Get report logs from each server
		foreach($Server in $ServersToCollect)
		{
			. ./DC_RDSServerInfo.ps1 -TargetHost $Server
		}
	}
	$TargetHost = $TargetHost_Temp # restore targethost when we come back
	} # remove for enable
	#end multi system
	. ./DC_RDSCB.ps1 -TargetHost $TargetHost -RDSobject $RDSobject -OutputFileName $OutputFileName -OS $OS -bIsRDSCB $bIsRDSCB
}
 
if ($RDSobject -ne $null)
{
	
	if($RDSobject.TerminalServerMode -eq "1") {$bIsRDSSH = $true}
	"RDSSH" + $bIsRDSSH| WriteTo-StdOut
    $OutputFileName = SaveAsXml $RDSobject  ($TargetHost + "_Win32_TerminalServiceSetting.xml") $OutputFileName
	. ./DC_RDSSH.ps1 -TargetHost $TargetHost -RDSobject $RDSobject -OutputFileName $OutputFileName -OS $OS -bIsRDSSH $bIsRDSSH
}

if ($RDSGateWay -ne $null)
{
	"RDSGateWay" | WriteTo-StdOut
	$bIsRDSGW = $true
	. ./DC_RDSGW.ps1 $TargetHost $RDSobject $OutputFileName $OS $RDSSDPStrings $bIsRDSGW
}



if ($RDSLS -ne $null)
{
	"RDSLS" | WriteTo-StdOut
	$bIsRDSLS = $true
	$OutputFileName = SaveAsXml $RDSLS  ($TargetHost + "_Win32_TSLicenseServer.xml") $OutputFileName
	. ./DC_RDSLS.ps1 $TargetHost $RDSobject $OutputFileName $OS $RDSSDPStrings $bIsRDSLS
}

#get All RDS eventlogs
. ./DC_RDSEventLog.ps1 $TargetHost $RDSSDPStrings $OutputFolder  #_# . .\

#get IIS information
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSIIS
. ./DC_RDSRDWeb.ps1 $TargetHost $OutputFileName  #_# . .\

#get all the info we can get from RDS powershell plugin !! Only if we have RDS components and if we have powershell V2
#if (($host.version.Major -ge 2) -and (($bIsRDSSH -eq $true) -or ($bIsRDSGW -eq $true) -or ($bIsRDSCB -eq $true) -or ($bIsRDSLS -eq $true)))
#{
#	Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSPowerShell
#	. ./DC_RDSPowerInfo.ps1 $TargetHost $OutputFileName $RDSSDPStrings
#}

# get the RDMSDeploymentUI
$File = $Env:windir + "\Logs\RDMSDeploymentUI.txt"
if(Test-Path $File )
{
	$OutputFileName += $File
}
#get the RDMSUI-trace.log
$File = $Env:temp + "\RDMSUI-trace.log"
if(Test-Path $File )
{
	$OutputFileName += $File
}

#collect our files !!!
$sectionDescription = "RDS specific files"
[array]$RDPFiles = $null
if ($OutputFileName -is [array])
	{
		ForEach ($OutputFile in $OutputFileName)
		{
			$fileDescription = $OutputFile.Substring($OutputFile.LastIndexOf('_')+1, ($OutputFile.LastIndexOf('.')-$OutputFile.LastIndexOf('_')-1))
			if ($OutputFile.Substring($OutputFile.Length -4, 4) -eq ".xml")
			{
				CollectFiles -filesToCollect ([System.IO.Path]::Combine($OutputFolder, $OutputFile)) -fileDescription $fileDescription -sectionDescription $sectionDescription -Verbosity Debug
			}elseif($OutputFile.Substring($OutputFile.Length -4, 4) -eq ".rdp")
			{
				[array]$RDPFiles += $OutputFile
			}
			else
			{
				CollectFiles -filesToCollect ([System.IO.Path]::Combine($OutputFolder, $OutputFile)) -fileDescription $fileDescription -sectionDescription $sectionDescription 
			}
			
			Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status ($RDSSDPStrings.ID_RDSSaved + " " + $OutputFile)
		}
		if($RDPFiles -ne "")
		{
			$RDPFiles = ($RDPFiles | foreach{([System.IO.Path]::Combine( $OutputFolder,$_))})
			CompressCollectFiles -filesToCollect $RDPFiles -DestinationFileName "RDSRdpFiles.zip" -renameOutput $false  -fileDescription "Compressed collected RDP files" -sectionDescription $sectionDescription 
		}
	}
	else
	{
		CollectFiles -filesToCollect ([System.IO.Path]::Combine($OutputFolder, $OutputFileName)) -fileDescription $FileDescription -sectionDescription $sectionDescription
	}

# SIG # Begin signature block
# MIIjlQYJKoZIhvcNAQcCoIIjhjCCI4ICAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDYOOPIxCrlPv9J
# S8adlk6eIRaus3YmqowFTjpMb8mLbaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVajCCFWYCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgOBBdLRL3
# HGgyNPUVMf7/p07+ilnJYf45ROeuEtoBmEowOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAHrtxkAsZ6yuA8H94RpRjTGfNgy8rLtQCHXIDbUUhUPIghFxlqmFsU+6
# 4st5n2NrVZTp7FtW5irEzSDhPEXh9XiO5Oxf/24AWEDhC3CL9IVDArn/LjCSFS3f
# OOK3JblANqD6BAaam9QuelKqWOqZPaUN3LDWNPWQOFBK6GUoqd7bGaim4zkfbYwO
# djTI8UI7bvkj4NaNtTXHxlJUV5i9HkUMl4aPimbjq7cliMYeAlE2LtfBPpP3SU+5
# h5Gs9HxcZ3KHB2WgXqjqP//6pBUqkzyhz3e54KN0PLiSsshZGwYN+6+FR34++QJB
# y0ZsiyULIJC5EpgPeUBgqv+3uKZOmUahghL+MIIS+gYKKwYBBAGCNwMDATGCEuow
# ghLmBgkqhkiG9w0BBwKgghLXMIIS0wIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBWQYL
# KoZIhvcNAQkQAQSgggFIBIIBRDCCAUACAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgQfEFusosaHzFWN72/0zxCedz2fGO7QIcu7sIDS9ldrQCBmCKzjBg
# hxgTMjAyMTA1MTkyMjIyNTQuODQ5WjAEgAIB9KCB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjozQkQ0LTRCODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaCCDk0wggT5MIID4aADAgECAhMzAAABOxIbkiNSAlqlAAAAAAE7MA0G
# CSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMB4XDTIw
# MTAxNTE3MjgyMloXDTIyMDExMjE3MjgyMlowgdIxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xLTArBgNVBAsTJE1pY3Jvc29mdCBJcmVsYW5kIE9w
# ZXJhdGlvbnMgTGltaXRlZDEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046M0JENC00
# QjgwLTY5QzMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Uw
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDjNtaV0NblMBgHAVLzwvdV
# AK2xT9nIXeeq0LD5VErh4bGY1d1AhSFt9wKsmyXt26R6vDy5KKWWn4AfmED2A5Fz
# cgAkL43seVlZdf/mgCQ22tsxpkyFhYOEw8HhOUrDwp3A6nNlkXjGcOBpZZm5uX5C
# dYHaq3a58tlLrioL7ewaMDbwQ6LWftTOVqQf68XqWgIvljoh+re/kJOrsJ7j1kHZ
# kJbBimQfjtxid69EzKbcQCz03T5C8JpeI6iwsjFuGWq+MoArm/0kUJKMRN2lRopK
# BNJWVsNT5Hv3BLO92xaA99NOTQ1uaJuvcDElRTv6AV924jQCjfqbImQlCDXQIUQx
# AgMBAAGjggEbMIIBFzAdBgNVHQ4EFgQUx8+PzeLoV6CKVmQJQUW6vu/miJEwHwYD
# VR0jBBgwFoAU1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZF
# aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGlt
# U3RhUENBXzIwMTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcw
# AoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQ
# Q0FfMjAxMC0wNy0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEF
# BQcDCDANBgkqhkiG9w0BAQsFAAOCAQEAQbDxtOa5Na9VB/sxLUyv3O6QNUQx9acB
# b95j85X95W1tTYddgDCivyJ4Nn6+ZabNLj2zf1Vgb5AEC++jWxVomc1rZmQY1Cj2
# yfsIn6V9qntvzNCNwRXZjXRlk93XLYU+dd0jtpJtV28YiuTwF7DmJZqvphJBnHkr
# jKgkPWqXHn88Xub8oZ6Rym0x+PmH/7gdx4UT0yqdWJGckiNWKeYnObqpc1T5VBGq
# 5rJGGLngD45nShij72GyRix5kWyGUJjofVUMUgMTqAEjf0wPsUbOdSyCpJy4rp5Q
# IcS59fwVoQuPgluwmynqrRyleKRLxcqfnJvS6eZQVBdV7j2u08siFzCCBnEwggRZ
# oAMCAQICCmEJgSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1
# MDcwMTIxNDY1NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ
# 1aUKAIKF++18aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP
# 8WCIhFRDDNdNuDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRh
# Z5FfgVSxz5NMksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39
# dx898Fd1rL2KQk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2
# iAg16HgcsOmZzTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGj
# ggHmMIIB4jAQBgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xG
# G8UzaFqFbVUwGQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGG
# MA8GA1UdEwEB/wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186a
# GMQwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsG
# AQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB
# /wSBlTCBkjCBjwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUF
# BwICMDQeMiAdAEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0A
# ZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFv
# s+umzPUxvs8F4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5
# U4zM9GASinbMQEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFS
# AK84Dxf1L3mBZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1V
# ry/+tuWOM7tiX5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6
# f32WapB4pm3S4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35j
# WSUPei45V3aicaoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHa
# sFAeb73x4QDf5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLN
# HfS4hQEegPsbiSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4
# sanblrKnQqLJzxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHX
# odLFVeNp3lfB0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUe
# CLraNtvTX4/edIhJEqGCAtcwggJAAgEBMIIBAKGB2KSB1TCB0jELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEtMCsGA1UECxMkTWljcm9zb2Z0IEly
# ZWxhbmQgT3BlcmF0aW9ucyBMaW1pdGVkMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVT
# TjozQkQ0LTRCODAtNjlDMzElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAg
# U2VydmljZaIjCgEBMAcGBSsOAwIaAxUAKDPC77kp1J1G63s+RXUk5YJcfeSggYMw
# gYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUF
# AAIFAORPqfAwIhgPMjAyMTA1MTkyMzE0NTZaGA8yMDIxMDUyMDIzMTQ1NlowdzA9
# BgorBgEEAYRZCgQBMS8wLTAKAgUA5E+p8AIBADAKAgEAAgIgcwIB/zAHAgEAAgIR
# ODAKAgUA5FD7cAIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAow
# CAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBABtVnWN1u52S
# 3kVhmono3Nh6OwQ1qouDk2WmLiL5qRMbEh0hE40Fdpl1+7rC8MU4h3kLuzUUXp7U
# W2DB0jBZnEZOChsDjOiHid3CdK+Bq0m/p9n6MONNwz7+qM9cW4nv09WhDnz3Ktzp
# eABhwpsNawa2tz1vfPDonojGzLBDVeqkMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAE7EhuSI1ICWqUAAAAAATswDQYJYIZI
# AWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG
# 9w0BCQQxIgQgVEnNlMHTq1cKbsLe7Vscy5Wi2HQPK4E0gty+j9UHLAwwgfoGCyqG
# SIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAcNuc3ecUm2AJt2Z/vQsVVt1FrWO0AxlG9
# Fjtk4cRAHDCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMz
# AAABOxIbkiNSAlqlAAAAAAE7MCIEIO2Py1yVZQgqJuzfMitYHL/UOHpOwq41csFl
# eItyrj9UMA0GCSqGSIb3DQEBCwUABIIBABkpPOTgOxJr0Sa99YgaFoHWat6X3qNq
# KNE2YgYm51xVQO2o849ZdYHdVbPd+ywJbJeanoD7ot194zzE4ZygZCpcI41htKrD
# 5jA7yLP7K4SI1GWvxZpMR8sCauusDY6m4ASztdLY2bVUIXJqoJOgEHNCLnSTVVjE
# tVrEkZQgQ6su1ATSzOWqA9HpYaUM+jdlZ55Hj+CznMpN+TYjcUs1ttuHY3kSVYQf
# nAdPk6uYXS1ph2vJ6/dl8p8z/Mq3nuW9yc9OVYLX7+cKvam6zWw7pWS5jy2PqFvI
# AkT1e0g1gmxZQlStAehmVgd0IfOFILhHsI1ToJslyvE5i0ke7sbidq4=
# SIG # End signature block
