﻿#************************************************
# DC_RDSServerInfo.ps1
# Version 1.0.0
# Date: 21-01-2012
# Author: Daniel Grund - dgrund@microsoft.com
# Description: 
#	This script gets the RDS config and
#   checks vital signs to inform user.
# 1.0.0 Beta release / 2021-03-30 Waltere #_#
#************************************************
PARAM(
	[string] $TargetHost = "localhost",
   	[string] $RootCause = "",
   	[object] $RDSobject = $null,
	[array]  $OutputFileName
)
# globals and function definitions for RDS
$OutputFolder = $PWD.Path 
Import-LocalizedData -BindingVariable RDSSDPStrings
$bIsRDSSH = $false
$bIsRDSGW = $false
$bIsRDSCB = $false
$bIsRDSLS = $false
$RCNum = 0

Trap [Exception]  #_#
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}
	
. ./DC_RDSHelper.ps1 $RDSHelper $RDSSDPStrings
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSWMIGet
Copy-Item .\RDS.xslt (join-path $pwd.path "result\RDS.xslt")
#[array]$OutputFileName+= $OutputFolder + "\" + "RDS.xslt"

#test for validity of the target end point
$OS = get-WmiObject -Class win32_operatingsystem -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate 
$Computer = get-WmiObject -Class win32_ComputerSystem -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate  
if (($Computer -ne $null) -and (($TargetHost -ne $Computer.DNSHostName) -or ( $TargetHost -eq $Computer.DNSHostName + "." + $Computer.Domain)))
{
    $TargetHost = $Computer.DNSHostName.ToUpper()
}



$RDSobject = FilterWMIObject (get-WmiObject -Class Win32_TerminalServiceSetting -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate)
$RDSGateWay = FilterWMIObject (get-WmiObject -Class Win32_TSGatewayServer -Namespace root\cimv2\TerminalServices -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate -EA SilentlyContinue) #_# -EA
$RDSCB = FilterWMIObject (get-WmiObject -Class Win32_SessionDirectoryServer -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate -EA SilentlyContinue) #_# -EA
$RDSLS = FilterWMIObject (get-WmiObject -Class Win32_TSLicenseServer -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate -EA SilentlyContinue) #_# -EA
$Error.Clear()
if ($OS -eq $null) 
{
	ReportError -RCNum $RCNum -RootCause $RDSSDPStrings.ID_RDSWMIGetError -Solution $RDSSDPStrings.ID_RDSWMIGetSolution
	exit
}

if ($RDSCB -ne $null)
{
	"RDSCB " | WriteTo-StdOut
	$bIsRDSCB = $true
	$OutputFileName = SaveAsXml $RDSCB  ($TargetHost + "_Win32_SessionDirectoryServer.xml") $OutputFileName

	#start multi system
	# skip this for now, enable after further testing
	if($false) # remove for enable
	{		   # remove for enable
	$TargetHost_Temp = $TargetHost  # calling ourself will break targethost, saving it.
    $RDSCBCluster = get-WmiObject -Class Win32_SessionDirectoryCluster -Namespace root\cimv2 -ComputerName $TargetHost -Authentication PacketPrivacy -Impersonation Impersonate
    $ConnectionBroker = New-Object RDSHelper+ConnectionBroker
	$ConnectionBroker.ConnectionBrokerName = $TargetHost_Temp
	
	foreach( $Cluster in $RDSCBCluster)
    {
		$Collection = New-Object RDSHelper+Collection
		$Collection.CollectionName = $Cluster.ClusterName
	
        $Query = "Select * from Win32_SessionDirectoryServer where ClusterName='" + $Cluster.ClusterName + "'" 
	    $RDSCBClusterEnum = get-WmiObject -Query $Query -Namespace root\cimv2 -Authentication PacketPrivacy -Impersonation Impersonate
		$Collection.CollectionServers = $RDSCBClusterEnum.ServerName
        $ConnectionBroker.Collections += $Collection
    }
	# Treeview for the server list , don't show if there are no collections
	if($ConnectionBroker.Collections.Count -gt 0)
	{
		$objTreeView = CreateTreeViewUI -ConnectionBroker $ConnectionBroker
		# Get all the servers that were checked in the UI
		$ServersToCollect = GetNodesChecked -objTreeView $objTreeView -ServersToCollect $ServersToCollect
		# Get report logs from each server
		foreach($Server in $ServersToCollect)
		{
			. ./DC_RDSServerInfo.ps1 -TargetHost $Server
		}
	}
	$TargetHost = $TargetHost_Temp # restore targethost when we come back
	} # remove for enable
	#end multi system
	. ./DC_RDSCB.ps1 -TargetHost $TargetHost -RDSobject $RDSobject -OutputFileName $OutputFileName -OS $OS -bIsRDSCB $bIsRDSCB
}
 
if ($RDSobject -ne $null)
{
	
	if($RDSobject.TerminalServerMode -eq "1") {$bIsRDSSH = $true}
	"RDSSH" + $bIsRDSSH| WriteTo-StdOut
    $OutputFileName = SaveAsXml $RDSobject  ($TargetHost + "_Win32_TerminalServiceSetting.xml") $OutputFileName
	. ./DC_RDSSH.ps1 -TargetHost $TargetHost -RDSobject $RDSobject -OutputFileName $OutputFileName -OS $OS -bIsRDSSH $bIsRDSSH
}

if ($RDSGateWay -ne $null)
{
	"RDSGateWay" | WriteTo-StdOut
	$bIsRDSGW = $true
	. ./DC_RDSGW.ps1 $TargetHost $RDSobject $OutputFileName $OS $RDSSDPStrings $bIsRDSGW
}



if ($RDSLS -ne $null)
{
	"RDSLS" | WriteTo-StdOut
	$bIsRDSLS = $true
	$OutputFileName = SaveAsXml $RDSLS  ($TargetHost + "_Win32_TSLicenseServer.xml") $OutputFileName
	. ./DC_RDSLS.ps1 $TargetHost $RDSobject $OutputFileName $OS $RDSSDPStrings $bIsRDSLS
}

#get All RDS eventlogs
. ./DC_RDSEventLog.ps1 $TargetHost $RDSSDPStrings $OutputFolder  #_# . .\

#get IIS information
Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSIIS
. ./DC_RDSRDWeb.ps1 $TargetHost $OutputFileName  #_# . .\

#get all the info we can get from RDS powershell plugin !! Only if we have RDS components and if we have powershell V2
#if (($host.version.Major -ge 2) -and (($bIsRDSSH -eq $true) -or ($bIsRDSGW -eq $true) -or ($bIsRDSCB -eq $true) -or ($bIsRDSLS -eq $true)))
#{
#	Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status $RDSSDPStrings.ID_RDSPowerShell
#	. ./DC_RDSPowerInfo.ps1 $TargetHost $OutputFileName $RDSSDPStrings
#}

# get the RDMSDeploymentUI
$File = $Env:windir + "\Logs\RDMSDeploymentUI.txt"
if(Test-Path $File )
{
	$OutputFileName += $File
}
#get the RDMSUI-trace.log
$File = $Env:temp + "\RDMSUI-trace.log"
if(Test-Path $File )
{
	$OutputFileName += $File
}

#collect our files !!!
$sectionDescription = "RDS specific files"
[array]$RDPFiles = $null
if ($OutputFileName -is [array])
	{
		ForEach ($OutputFile in $OutputFileName)
		{
			$fileDescription = $OutputFile.Substring($OutputFile.LastIndexOf('_')+1, ($OutputFile.LastIndexOf('.')-$OutputFile.LastIndexOf('_')-1))
			if ($OutputFile.Substring($OutputFile.Length -4, 4) -eq ".xml")
			{
				CollectFiles -filesToCollect ([System.IO.Path]::Combine($OutputFolder, $OutputFile)) -fileDescription $fileDescription -sectionDescription $sectionDescription -Verbosity Debug
			}elseif($OutputFile.Substring($OutputFile.Length -4, 4) -eq ".rdp")
			{
				[array]$RDPFiles += $OutputFile
			}
			else
			{
				CollectFiles -filesToCollect ([System.IO.Path]::Combine($OutputFolder, $OutputFile)) -fileDescription $fileDescription -sectionDescription $sectionDescription 
			}
			
			Write-DiagProgress -Activity $RDSSDPStrings.ID_RDSServerProgress -Status ($RDSSDPStrings.ID_RDSSaved + " " + $OutputFile)
		}
		if($RDPFiles -ne "")
		{
			$RDPFiles = ($RDPFiles | foreach{([System.IO.Path]::Combine( $OutputFolder,$_))})
			CompressCollectFiles -filesToCollect $RDPFiles -DestinationFileName "RDSRdpFiles.zip" -renameOutput $false  -fileDescription "Compressed collected RDP files" -sectionDescription $sectionDescription 
		}
	}
	else
	{
		CollectFiles -filesToCollect ([System.IO.Path]::Combine($OutputFolder, $OutputFileName)) -fileDescription $FileDescription -sectionDescription $sectionDescription
	}
