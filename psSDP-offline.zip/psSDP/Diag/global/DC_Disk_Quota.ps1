﻿###########################################################################
# DC_Disk_Quota
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Collects Disk Quota Data
###########################################################################

Import-LocalizedData -BindingVariable Quota -FileName DC_Disk_Quota -UICulture en-us
Write-DiagProgress -Activity $Quota.ID_Quota

$OutputFile = $ComputerName + "_Diskquota.txt"

logstart

$colItems = get-wmiobject -class "Win32_DiskQuota" -namespace "root\CIMV2" 

foreach ($objItem in $colItems) {
      Add-Content $OutputFile ("Disk Space Used: " + $objItem.DiskSpaceUsed)
      Add-Content $OutputFile ("Limit: " + $objItem.Limit)
      Add-Content $OutputFile ("Quota Volume: " + $objItem.QuotaVolume)
      Add-Content $OutputFile ("Status: " + $objItem.Status)
      Add-Content $OutputFile ("User: " + $objItem.User)
      Add-Content $OutputFile ("Warning Limit: " + $objItem.WarningLimit)
}

CollectFiles -filesToCollect $OutputFile -fileDescription "Disk Quotas"  -sectionDescription "System Information"

logstop