﻿#************************************************
# DC_HyperVBasicInfo.ps1
# Version 1.0
# Date: 4-7-2015
# Author: Ryutaro Hayashi <Ryutaro.Hayashi@microsoft.com>
# Ported to SDP and included in HyperV SDP by Tim Springston <tspring@microsoft.com>
# Description: Data collection for hyperv.
#************************************************
#Output file info
$FileDescription = "Text File containing Hyper-V basic settings and configuration information."
$SectionDescription = "Hyper-V Basic Information"
$Outputfile = Join-Path $Pwd.Path (($env:COMPUTERNAME) + "_Hyper-VBasicInfo.txt")

Get-Date | Out-File $Outputfile -encoding UTF8

Filter Import-CimXml
{
    # Create new XML object from input
    $CimXml = [Xml]$_
    $CimObj = New-Object -TypeName System.Object
    
    # Iterate over the data and pull out just the value name and data for each entry
    ForEach ($CimProperty in $CimXml.SelectNodes("/INSTANCE/PROPERTY[@NAME='Name']"))
    {
        $CimObj | Add-Member -MemberType NoteProperty -Name $CimProperty.NAME -Value $CimProperty.VALUE
    }

    ForEach ($CimProperty in $CimXml.SelectNodes("/INSTANCE/PROPERTY[@NAME='Data']"))
    {
        $CimObj | Add-Member -MemberType NoteProperty -Name $CimProperty.NAME -Value $CimProperty.VALUE
    }

    # Display output
    $CimObj
}

Function showHVGlobalSettings
{
    $VSMgtServiceSettingData = $args[0]

    ("Hyper-V Global Settings") | Out-File $Outputfile  -Append -encoding UTF8
    ("----------------------------------------") | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8

    ("Hyper-V Settings:") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Virtual Hard Disks: " + $VSMgtServiceSettingData.DefaultVirtualHardDiskPath) | Out-File $Outputfile  -Append -encoding UTF8
    ("    Virtual Machines: " + $VSMgtServiceSettingData.DefaultExternalDataRoot) | Out-File $Outputfile  -Append -encoding UTF8
    ("    Physical GPUs: ") | Out-File $Outputfile  -Append -encoding UTF8
    ("    NUMA Spanning: " + $VSMgtServiceSettingData.NumaSpanningEnabled) | Out-File $Outputfile  -Append -encoding UTF8

    ### Live migrations
    $VSMigrationService = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_VirtualSystemMigrationService' 
    $VSMigServiceSettingData = $VSMigrationService.GetRelated('Msvm_VirtualSystemMigrationServiceSettingData') 
    ("    Live Migrations:") | Out-File $Outputfile  -Append -encoding UTF8
    ("        Enable incoming and outgoing live migrations: " + $VSMigServiceSettingData.EnableVirtualSystemMigration) | Out-File $Outputfile  -Append -encoding UTF8

    switch ($VSMigServiceSettingData.AuthenticationType)
    {
        0   {$AuthTypeStr = "CredSSP(0)"}
        1   {$AuthTypeStr = "Kerberos(1)"}
    }
    ("        Authentication protocol: " + $AuthTypeStr) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Simultaneous live migrations: " + $VSMigServiceSettingData.MaximumActiveVirtualSystemMigration) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Incoming live migrations: ") | Out-File $Outputfile  -Append -encoding UTF8

    $MigNetworksSettings = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_VirtualSystemMigrationNetworkSettingData' 
    $NetworksSet = 0

    ForEach($MigNetworksSetting in $MigNetworksSettings)
    {
        For($i=0; $i -lt $MigNetworksSetting.Tags.Count; $i++)
        {
            If($MigNetworksSetting.Tags[$i] -eq "Microsoft:UserManagedAllNetworks")
            {
                $NetworksSet++
            }
        }
    }
    
    If($NetworksSet -gt 0)
    {
        $NetworkOptionStr = "Use any available network for live migration"
    }
    Else
    {
        $NetworkOptionStr = "Use these IP addresses for live migration"
        $IPList = $VSMigrationService.MigrationServiceListenerIPAddressList

        For($y=0; $y -lt $IPLIst.count; $y++)
        {
            $IPListStr = $IPListStr + " " + $IPList[$y]
        }
    }

    ("            Option: " + $NetworkOptionStr) | Out-File $Outputfile  -Append -encoding UTF8

    If($NetworksSet -eq 0)
    {
        ("                Network List: " + $IPListStr) | Out-File $Outputfile  -Append -encoding UTF8
    }

    #### Storage Migrations
    ("    Storage Migrations:") | Out-File $Outputfile  -Append -encoding UTF8
    ("        Simultaneous storage migrations: " + $VSMigServiceSettingData.MaximumActiveStorageMigration) | Out-File $Outputfile  -Append -encoding UTF8

    ### Replication Configuration
    ("    Replication Configuration:") | Out-File $Outputfile  -Append -encoding UTF8
    $HVRServiceSettingData = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_ReplicationServiceSettingData'

    If ($HVRServiceSettingData.RecoveryServerEnabled) 
    {
       switch ($HVRServiceSettingData.AllowedAuthenticationType)
        {
            0   {$AllowedAuthenticationType = "Not defined"}
            1   {$AllowedAuthenticationType = "Use kerberos (HTTP)"}
            2   {$AllowedAuthenticationType = "Use certificate-based Authentication"}
            3   {$AllowedAuthenticationType = "Both certificate based authentication and integrated authentication"}
        }

        ("        Authentication and ports:") | Out-File $Outputfile  -Append -encoding UTF8
        ("            Authentication Type: " + $AllowedAuthenticationType) | Out-File $Outputfile  -Append -encoding UTF8 
        ("            HttpPort(Kerberos) : " + $HVRServiceSettingData.HttpPort) | Out-File $Outputfile  -Append -encoding UTF8
        ("            HttpsPort(Certificate): " + $HVRServiceSettingData.HttpsPort) | Out-File $Outputfile  -Append -encoding UTF8

        $HVRAuthSettingData = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_ReplicationAuthorizationSettingData'
        $AuthEntryCount = ($HVRAuthSettingData | Measure-Object).count

        ("        Authentication and Storage:") | Out-File $Outputfile  -Append -encoding UTF8
 
        If($AuthEntryCount -eq 1 -and $HVRAuthSettingData.AllowedPrimaryHostSystem -eq "*")
        {
            $AuthServerStr = "Type: Allow replication from any authenticated server"
            ("            " + $AuthServerStr) | Out-File $Outputfile  -Append -encoding UTF8
            ("            Storage location: " + $HVRAuthSettingData.ReplicaStorageLocation) | Out-File $Outputfile  -Append -encoding UTF8
        }
        Else
        {
            $AuthServerStr = "Type: Allow replication from specifed servers"
            ("            " + $AuthServerStr) | Out-File $Outputfile  -Append -encoding UTF8
            ForEach($HVRAuthSetting in $HVRAuthSettingData)
            {
                ("                Primary server: " + $HVRAuthSetting.AllowedPrimaryHostSystem + " | Storage location: "  + $HVRAuthSetting.ReplicaStorageLocation + " | TrustGroup: " + $HVRAuthSetting.TrustGroup) | Out-File $Outputfile  -Append -encoding UTF8
            }
        }
    }
    Else
    {
         ("        Hyper-V Replica is not configured as replica server.") | Out-File $Outputfile  -Append -encoding UTF8
    }

    ### Enhanced Session Mode Policy (WS2012R2 or later)
    If($VSMgtServiceSettingData.EnhancedSessionModeEnabled -eq $null)
    {
        $EnhancedSessionMode = "N/A (Enhanced session mode is supported from Windows Server 2012 R2)"
    } 
    Else
    {
        $EnhancedSessionMode = $VSMgtServiceSettingData.EnhancedSessionModeEnabled     
    }

    ("    Enhanced session mode policy: " + $EnhancedSessionMode) | Out-File $Outputfile  -Append -encoding UTF8

    ### Memory reserve
    $memReserveRegKey = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\"
    $memReserveReg = Get-ItemProperty $memReserveRegKey
    $memoryReserve = $memReserveReg."MemoryReserve"

    If($memoryReserve -ne $null)
    {
        ("    Memory Reserve: " + $memoryReserve + " MB(WARNING: Memory reserve is set)") | Out-File $Outputfile  -Append -encoding UTF8
    }

    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showNUMAinfo()
{

    ("NUMA Information") | Out-File $Outputfile  -Append -encoding UTF8
    ("----------------------------------------") | Out-File $Outputfile  -Append -encoding UTF8

    $hostName = hostname
    $hostComputer = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_ComputerSystem' | Where-Object { $_.ElementName -eq $hostname}
    $numaNodes = $hostComputer.GetRelated("Msvm_NumaNode")
    
    Foreach($numaNode in $numaNodes) {
        ("") | Out-File $Outputfile  -Append -encoding UTF8 
        ($numaNode.ElementName + ":") | Out-File $Outputfile  -Append -encoding UTF8
        ("    EnabledState                   : " + $numaNode.EnabledState) | Out-File $Outputfile  -Append -encoding UTF8
        ("    HealthState                    : " + $numaNode.HealthState) | Out-File $Outputfile  -Append -encoding UTF8
        ("    NumberOfLogicalProcessors      : " + $numaNode.NumberOfLogicalProcessors) | Out-File $Outputfile  -Append -encoding UTF8
        ("    NumberOfProcessorCores         : " + $numaNode.NumberOfProcessorCores) | Out-File $Outputfile  -Append -encoding UTF8
        ("    CurrentlyConsumableMemoryBlocks: " + $numaNode.CurrentlyConsumableMemoryBlocks) | Out-File $Outputfile  -Append -encoding UTF8
        ("") | Out-File $Outputfile  -Append -encoding UTF8
        
        $Memory = $numaNode.GetRelated("Msvm_Memory") | Where-Object { $_.SystemName -eq $hostName}
        $MemSizeGB = ($Memory.ConsumableBlocks * $Memory.BlockSize / 1024 / 1024 / 1024)
        $MemSizeGB2 = [math]::round($MemSizeGB, 2)
        $MemSizeMB = ($Memory.ConsumableBlocks * $Memory.BlockSize / 1024 / 1024)

        ("    ==== " + $Memory.ElementName + " ====") | Out-File $Outputfile  -Append -encoding UTF8
        ("    BlockSize                      : " + $Memory.BlockSize) | Out-File $Outputfile  -Append -encoding UTF8
        ("    ConsumableBlocks               : " + $Memory.ConsumableBlocks) | Out-File $Outputfile  -Append -encoding UTF8
        ("    Size                           : " + $MemSizeMB + "MB / " + $MemSizeGB2 + "GB") | Out-File $Outputfile  -Append -encoding UTF8
        ("    EnabledState                   : " + $Memory.EnabledState) | Out-File $Outputfile  -Append -encoding UTF8
        ("    HealthState                    : " + $Memory.HealthState) | Out-File $Outputfile  -Append -encoding UTF8
        ("") | Out-File $Outputfile  -Append -encoding UTF8
    }
}

Function showVMBasicinfo()
{
    $VM = $args[0]
    $VSSettingData = $args[1]
    ("Basic information:") | Out-File $Outputfile  -Append -encoding UTF8
    ("    GUID: " + $VM.Name) | Out-File $Outputfile  -Append -encoding UTF8

    If($VM.ProcessID -eq $null)
    {
        $procId = "N/A => Virtual Machine is not running."
    }
    Else
    {
        $procId = $VM.ProcessID
    }

    ("    PID: " + $procId) | Out-File $Outputfile  -Append -encoding UTF8

    ### VM Version
    ("    Version: " + $VSSettingData.Version) | Out-File $Outputfile  -Append -encoding UTF8

    ### VM Generation
    $vmGgeneration = getVmGeneration $VSSettingData  
    ("    Generation: " + $vmGgeneration) | Out-File $Outputfile  -Append -encoding UTF8

    ### Enabled state
    $vmStatus = getVMEnabledState $VM.EnabledState
    ("    State: " + $vmStatus) | Out-File $Outputfile  -Append -encoding UTF8

    ### Heartbeat
    $heartbeatComponent = Get-WmiObject  -namespace 'root\virtualization\v2' -query "associators of {$VM} where ResultClass = Msvm_HeartbeatComponent"

    If($heartbeatComponent -eq $null)
    {
        $heartbeartStr = "N/A(Virtual Machine is not running)"
    }
    ElseIf($heartbeatComponent.EnabledState -eq 3) 
    {
        $heartbeartStr = "N/A(Heartbeat service is not enabled)"
    }
    Else
    {
        $hbStatusStr1 = getHBOperationalStatus $heartbeatComponent.OperationalStatus[0]
        $hbStatusStr2 = getHBSecondaryStatus $heartbeatComponent.OperationalStatus[1]
        $heartbeartStr = $hbStatusStr1 + "(Application state - " + $hbStatusStr2 + ")"
    }

    ("    Heartbeat: " + $heartbeartStr) | Out-File $Outputfile  -Append -encoding UTF8

    ### Health state
    switch ($VM.HealthState)
    {
        # https://msdn.microsoft.com/en-us/library/hh850116(v=vs.85).aspx
        5   {$healthState = "OK" + "(" + $VM.HealthState + ")"}
       20   {$healthState = "Major Failure" + "(" + $VM.HealthState + ")"}
       25   {$healthState = "Critical failure)" + "(" + $VM.HealthState + ")"}                               
    }

    ("    Health state: " + $healthState) | Out-File $Outputfile  -Append -encoding UTF8

    ### Uptime
    $uptimeSeconds = $VM.OnTimeInMilliseconds / 1000
    $uptimeMinutes = $uptimeSeconds / 60
    $seconds = [math]::Truncate($uptimeSeconds % 60)
    $minutes = [math]::Truncate($uptimeMinutes % 60)
    $hours = [math]::Truncate($uptimeSeconds / 3600)

    ("    Uptime: " + $hours + ":" + $minutes +  ":" + $seconds) | Out-File $Outputfile  -Append -encoding UTF8
 
    ### IC version
    If($VM.EnabledState -eq 2)
    {
        $KvpExchangeComponent = $VM.GetRelated("Msvm_KvpExchangeComponent")

        If($KvpExchangeComponent.count -eq 0)
        {
            $versionString = "Unable to retrieve IC version. VM would not be started."
        }
        ElseIf($KvpExchangeComponent.GuestIntrinsicExchangeItems -ne $null)
        {
            $IntrinsicItems = $KvpExchangeComponent.GuestIntrinsicExchangeItems | Import-CimXml 
            $icVersionItem = $IntrinsicItems | Where {$_.Name -eq "IntegrationServicesVersion"}

            If($icVersionItem.Data -ne $null)
            {
                $versionString = $icVersionItem.Data
                $icVersionExist = $True
            }
            Else
            {
                $versionString = "Unable to retrieve IC version. Key exchange service would not be running in guest."
            }
        }
        Else
        {
            $versionString = "Unable to retrieve IC version. Key exchange service would not be running in guest."
        }
    }
    Else
    {
        $versionString = "N/A(VM is not running)"
    }

    $icRegistryKey = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Virtualization\GuestInstaller\Version\"
	$icReg = Get-ItemProperty $icRegistryKey -EA SilentlyContinue
	if ($icReg) {	$hostICVersion =  $icReg."Microsoft-Hyper-V-Guest-Installer-Win6x-Package" }
    If($hostICVersion -eq $icVersionItem.Data)
    {
        ("    Integration Service Version: " + $versionString + " => IC version is same with host version.") | Out-File $Outputfile  -Append -encoding UTF8
    }
    ElseIf($icVersionExist)
    {
        ("    Integration Service Version: " + $versionString + " => WARNING: IC version is not same with host version(" + $hostICVersion + ").") | Out-File $Outputfile  -Append -encoding UTF8
    }
    Else
    {
        ("    Integration Service Version: " + $versionString) | Out-File $Outputfile  -Append -encoding UTF8
    }

    If($VM.EnhancedSessionModeState -ne $null)
    {
        switch ($VM.EnhancedSessionModeState)
        {
            2   {$EnhancedSessionModeState = "Enhanced mode is allowed and available on the virtual machine(2)"}
            3   {$EnhancedSessionModeState = "Enhanced mode is not allowed on the virtual machine(3)"}
            6   {$EnhancedSessionModeState = "Enhanced mode is allowed and but not currently available on the virtual machine(6)"}
            default {$EnhancedSessionModeState = "Unknown"}
        }
        ("    EnhancedSession Mode:  " + $EnhancedSessionModeState) | Out-File $Outputfile  -Append -encoding UTF8
    }

    ("    Number of NUMA nodes: " + $VM.NumberOfNumaNodes) | Out-File $Outputfile  -Append -encoding UTF8

    ### Configuration file
    $configPath = $VSSettingData.ConfigurationDataRoot + "\" + $VSSettingData.ConfigurationFile
    ("    Configuration File: " + $configPath) | Out-File $Outputfile  -Append -encoding UTF8



    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showKVPItems()
{
    $VM = $args[0]
    $VSSettingData = $args[1]

    $KvpExchangeComponent = $VM.GetRelated("Msvm_KvpExchangeComponent")
    $KvpExchangeComponentSettingData = $VSSettingData.GetRelated("Msvm_KvpExchangeComponentSettingData")

    ("KVP Items:") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Guest intrinsic items:") | Out-File $Outputfile  -Append -encoding UTF8

    If($KvpExchangeComponent.count -eq 0)
    {
        ("        Unable to retrieve guest items. VM would not be started.") | Out-File $Outputfile  -Append -encoding UTF8
    }
    ElseIf($KvpExchangeComponent.GuestIntrinsicExchangeItems -ne $null)
    {
        $IntrinsicItems = $KvpExchangeComponent.GuestIntrinsicExchangeItems | Import-CimXml 

        ForEach($IntrinsicItem in $IntrinsicItems)
        {
            ("        " + $IntrinsicItem.Name + ": " + $IntrinsicItem.Data) | Out-File $Outputfile  -Append -encoding UTF8
        }
        ("") | Out-File $Outputfile  -Append -encoding UTF8
    }
    Else
    {
        ("        Unable to retrieve guest items. Key exchange service would not be running in guest.") | Out-File $Outputfile  -Append -encoding UTF8
    }

    ("") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Host only items:") | Out-File $Outputfile  -Append -encoding UTF8

    If($KvpExchangeComponentSettingData.HostOnlyItem -eq $null)
    {
        ("        No host only items.") | Out-File $Outputfile  -Append -encoding UTF8
    }
    Else
    {
        $HostItems = $KvpExchangeComponentSettingData.HostOnlyItems | Import-CimXml 
    
        If($HostItems.count -eq 0)
        {
            ("        No host only items are registerd.") | Out-File $Outputfile  -Append -encoding UTF8
        }
        Else
        {
            ForEach($HostItem in $HostItems)
            {
                ("        " + $HostItem.Name + ": " + $HostItem.Data) | Out-File $Outputfile  -Append -encoding UTF8
            }
        }
    }
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showBIOSinfo
{
    $VSSettingData = $args[0]

    ("BIOS:") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Num Lock: " + $VSSettingData.BIOSNumLock) | Out-File $Outputfile  -Append -encoding UTF8

    For($i=0; $i -lt $VSSettingData.BootOrder.length; $i++)
    {
        switch ($VSSettingData.BootOrder[$i])
        {
            0   {$deviceStr = "Floppy"}
            1   {$deviceStr = "CD-ROM"}
            2   {$deviceStr = "Hard Drive"}
            3   {$deviceStr = "PXE Boot"}
        }

        $BootOrderStr = $BootOrderStr + $deviceStr

        If($i -lt ($VSSettingData.BootOrder.length-1)) {
            $BootOrderStr = $BootOrderStr + " -> "
        }
    }

    ("    Startup order: " + $BootOrderStr) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showMeminfo 
{
    $VSSettingData = $args[0]
    $MemSettingData = $VSSettingData.GetRelated('Msvm_MemorySettingData')
    ("Memory:") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Startup RAM: " + $MemSettingData.VirtualQuantity + "MB") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Enable Dynamic Memory: " + $MemSettingData.DynamicMemoryEnabled) | Out-File $Outputfile  -Append -encoding UTF8

    If($MemSettingData.DynamicMemoryEnabled)
    {
        ("        Minimum RAM: " + $MemSettingData.Reservation + "MB") | Out-File $Outputfile  -Append -encoding UTF8
        ("        Maximum RAM: " + $MemSettingData.Limit + "MB") | Out-File $Outputfile  -Append -encoding UTF8
        ("        Memory Buffer: " + $MemSettingData.TargetMemoryBuffer) | Out-File $Outputfile  -Append -encoding UTF8
    }

    ("    Memory Weight: " + $MemSettingData.Weight) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showCPUinfo 
{
    $VSSettingData = $args[0]
    $ProcSettingData = $VSSettingData.GetRelated('Msvm_ProcessorSettingData')
    ("Processor:") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Number of Virtual Processors: " + $ProcSettingData.VirtualQuantity) | Out-File $Outputfile  -Append -encoding UTF8
    ("    Resource control: ") | Out-File $Outputfile  -Append -encoding UTF8
    ("        Virtual machine reserve: " + $ProcSettingData.Reservation / 1000) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Virtual machine limit  : " + $ProcSettingData.Limit / 1000) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Relative weight        : " + $ProcSettingData.Weight) | Out-File $Outputfile  -Append -encoding UTF8
    ("    Compatibility: ") | Out-File $Outputfile  -Append -encoding UTF8
    ("        Migrate to physical computer with a differnet processor version: " + $ProcSettingData.LimitProcessorFeatures) | Out-File $Outputfile  -Append -encoding UTF8
    ("    NUMA: ") | Out-File $Outputfile  -Append -encoding UTF8
    ("        Maximum number of virtual processors  : " + $ProcSettingData.MaxProcessorsPerNumaNode) | Out-File $Outputfile  -Append -encoding UTF8

    $MemSettingData = $VSSettingData.GetRelated('Msvm_MemorySettingData')
    ("        MaxMemoryBlocksPerNumaNode            : " + $MemSettingData.MaxMemoryBlocksPerNumaNode + " MB") | Out-File $Outputfile  -Append -encoding UTF8
    ("        Maximum NUMA nodes allowed on a socket: " + $ProcSettingData.MaxNumaNodesPerSocket) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showIDEHardDriveinfo 
{
    $VM = $args[0]

    ("IDE Controller :") | Out-File $Outputfile  -Append -encoding UTF8

    $hardDrives = Get-VMHardDiskDrive -VMName $VM.ElementName | Where-Object {$_.ControllerType -eq "IDE" }

	If($hardDrives.count -eq 0)
       {
           ("    No IDE drive attached.") | Out-File $Outputfile  -Append -encoding UTF8
           ("") | Out-File $Outputfile  -Append -encoding UTF8
           return
       }

	ForEach($hardDrive in $hardDrives)
    {
        If($hardDrive.ControllerType -eq "IDE")
        {
            ("    Virtual Hard Disks: ") | Out-File $Outputfile  -Append -encoding UTF8

            If( $hardDrive.Path -eq $null)
            {
                ("        WARNING: Disk path is null. Probably the disk is removed or deleted.")  | Out-File $Outputfile  -Append -encoding UTF8
                continue
            }
            Else
            {
                ("        - " + $hardDrive.Path) | Out-File $Outputfile  -Append -encoding UTF8
                ("            Location: " + $hardDrive.Name) | Out-File $Outputfile  -Append -encoding UTF8
            }

            If(!(Test-Path $hardDrive.Path))
            {
                ("        WARNING: the file does not exist.") | Out-File $Outputfile  -Append -encoding UTF8
                continue
            }

            $vhdInfo = Get-VHD -Path $hardDrive.Path
            $property = Get-ChildItem $hardDrive.Path
            $fileSize = [math]::round($property.Length / 1GB , 3)
            $maxFileSize = [math]::round($vhdInfo.Size / 1GB , 3)
            $ACL = Get-ACL $hardDrive.Path

            ("            VhdType: " + $vhdInfo.VhdType) | Out-File $Outputfile  -Append -encoding UTF8
            ("            Creation time: " + $property.CreationTime + "    " + "Last write time: " + $property.LastWriteTime) | Out-File $Outputfile  -Append -encoding UTF8
            ("            Current size: " + $fileSize + " GB" + "  /  Max file size: " + $maxFileSize + " GB") | Out-File $Outputfile  -Append -encoding UTF8
            ("            LogicalSectorSize: " + $vhdInfo.LogicalSectorSize + " bytes  /  PhysicalSectorSize: " + $vhdInfo.PhysicalSectorSize + " bytes") | Out-File $Outputfile  -Append -encoding UTF8
            ("            Owner: " + $ACL.Owner) | Out-File $Outputfile  -Append -encoding UTF8
            ("            ACL: ") | Out-File $Outputfile  -Append -encoding UTF8

            $AccessRules = $ACL.GetAccessRules($true,$true, [System.Security.Principal.NTAccount])

            ForEach($AccessRule in $AccessRules)
            {
                ("                " + $AccessRule.IdentityReference + " => " + $AccessRule.FileSystemRights) | Out-File $Outputfile  -Append -encoding UTF8
            }
            ("            ID: " + $hardDrive.ID) | Out-File $Outputfile  -Append -encoding UTF8
            ("") | Out-File $Outputfile  -Append -encoding UTF8

            ### Advanced Features(Windows Server 2012 R2 or later)
            ("    Advanced Features:") | Out-File $Outputfile  -Append -encoding UTF8

            $StorageAllocationSettingData = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_StorageAllocationSettingData' | Where-Object { $_.HostResource  -eq $hardDrive.Path}
            
            If($StorageAllocationSettingData.IOPSLimit -eq $null)
            {
                $isStorageQoSEnabled = $false
                $StorageQoSStr = "This feature is supported from Windows Server 2012 R2."
            }
            ElseIf($StorageAllocationSettingData.IOPSLimit -eq 0)
            {
                $isStorageQoSEnabled = $false
                $StorageQoSStr = "Disabled"
            }
            Else
            {
                $isStorageQoSEnabled = $true
                $StorageQoSStr = "Enabled"
            }

            ("        Enable Quality of Service management: " + $StorageQoSStr)  | Out-File $Outputfile  -Append -encoding UTF8
  
            If($isStorageQoSEnabled)
            {
                ("            Minimum: " + $StorageAllocationSettingData.IOPSReservation) | Out-File $Outputfile  -Append -encoding UTF8
                ("            Maximum: " + $StorageAllocationSettingData.IOPSLimit) | Out-File $Outputfile  -Append -encoding UTF8
            }
        }
        ("") | Out-File $Outputfile  -Append -encoding UTF8
    }
}

Function showSCSIHardDriveinfo 
{
    $VM = $args[0]
    ("SCSI Controller :") | Out-File $Outputfile  -Append -encoding UTF8

    $hardDrives = Get-VMHardDiskDrive -VMName $VM.ElementName | Where-Object {$_.ControllerType -eq "SCSI" }
    If($hardDrives.count -eq 0)
    {
        ("    No SCSI drive attached.") | Out-File $Outputfile  -Append -encoding UTF8
        ("") | Out-File $Outputfile  -Append -encoding UTF8
        return
    }

    ForEach($hardDrive in $hardDrives)
    {
        If($hardDrive.ControllerType -eq "SCSI")
        {
            ("    Virtual Hard Disks: ") | Out-File $Outputfile  -Append -encoding UTF8

            If( $hardDrive.Path -eq $null)
            {
                ("        WARNING: Disk path is null. Probably the disk is detached or deleted.")  | Out-File $Outputfile  -Append -encoding UTF8
                continue  
            }
            Else
            {  
                ("        - " + $hardDrive.Path) | Out-File $Outputfile  -Append -encoding UTF8
                ("            Location: " + $hardDrive.Name) | Out-File $Outputfile  -Append -encoding UTF8
            }

            If(!(Test-Path $hardDrive.Path))
            {
               ("            WARNING: above file does not exist.") | Out-File $Outputfile  -Append -encoding UTF8
                continue
            }

            $vhdInfo = Get-VHD -Path $hardDrive.Path 
            $property = Get-ChildItem $hardDrive.Path
            $fileSize = [math]::round($property.Length / 1GB , 3)
            $maxFileSize = [math]::round($vhdInfo.Size / 1GB , 3)
            $ACL = Get-ACL $hardDrive.Path            

            ("            VhdType: " + $vhdInfo.VhdType) | Out-File $Outputfile  -Append -encoding UTF8
            ("            Creation time: " + $property.CreationTime + "    " + "Last write time: " + $property.LastWriteTime) | Out-File $Outputfile  -Append -encoding UTF8
            ("            Current size: " + $fileSize + " GB" + "  /  Max file size: " + $maxFileSize + " GB") | Out-File $Outputfile  -Append -encoding UTF8
            ("            LogicalSectorSize: " + $vhdInfo.LogicalSectorSize + " bytes  /  PhysicalSectorSize: " + $vhdInfo.PhysicalSectorSize + " bytes") | Out-File $Outputfile  -Append -encoding UTF8
            ("            Owner: " + $ACL.Owner) | Out-File $Outputfile  -Append -encoding UTF8
            ("            ACL: ") | Out-File $Outputfile  -Append -encoding UTF8

            $AccessRules = $ACL.GetAccessRules($true,$true, [System.Security.Principal.NTAccount])

            ForEach($AccessRule in $AccessRules)
            {
                ("                " + $AccessRule.IdentityReference + " => " + $AccessRule.FileSystemRights) | Out-File $Outputfile  -Append -encoding UTF8
            }
            ("            ID: " + $hardDrive.ID) | Out-File $Outputfile  -Append -encoding UTF8
            ("") | Out-File $Outputfile  -Append -encoding UTF8

            ### Advanced Features(Windows Server 2012 R2 or later)
            ("    Advanced Features:") | Out-File $Outputfile  -Append -encoding UTF8

            $StorageAllocationSettingData = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_StorageAllocationSettingData' | Where-Object { $_.HostResource  -eq $hardDrive.Path}
            
            # Storage Qos
            If($StorageAllocationSettingData.IOPSLimit -eq $null)
            {
                $isStorageQoSEnabled = $false
                $StorageQoSStr = "This feature is supported from Windows Server 2012 R2."
            }
            ElseIf($StorageAllocationSettingData.IOPSLimit -eq 0)
            {
                $isStorageQoSEnabled = $false
                $StorageQoSStr = "Disabled"
            }
            Else
            {
                $isStorageQoSEnabled = $true
                $StorageQoSStr = "Enabled"
            }

            ("        Enable Quality of Service management: " + $StorageQoSStr) | Out-File $Outputfile  -Append -encoding UTF8
  
            If($isStorageQoSEnabled)
            {
                ("            Minimum: " + $StorageAllocationSettingData.IOPSReservation) | Out-File $Outputfile  -Append -encoding UTF8
                ("            Maximum: " + $StorageAllocationSettingData.IOPSLimit) | Out-File $Outputfile  -Append -encoding UTF8
                ("") | Out-File $Outputfile  -Append -encoding UTF8
            }

            # Shared disk support
            If($StorageAllocationSettingData.PersistentReservationsSupported -eq $null)
            {
                $sharedDiskStr = "This feature is supported from Windows Server 2012 R2."
            }
            ElseIf($StorageAllocationSettingData.PersistentReservationsSupported)
            {
                $sharedDiskStr = "Enabled"
            }
            Else
            {
                $sharedDiskStr = "Disabled"
            }
            ("        Enable virtual hard disk sharing: " + $sharedDiskStr) | Out-File $Outputfile  -Append -encoding UTF8
        }
        ("") | Out-File $Outputfile  -Append -encoding UTF8
    }
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showNetworkAdapterinfo 
{
    $VSSettingData = $args[0]
    $EthernetPortAllocationSettings = $VSSettingData.GetRelated('Msvm_EthernetPortAllocationSettingData')

    ForEach($EthernetPortAllocationSetting in $EthernetPortAllocationSettings)
    {
        ### Get GUID for vSwitch
        $VirtualEthernetSwitch = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_VirtualEthernetSwitch' | Where-Object { $_.__PATH -eq $EthernetPortAllocationSetting.HostResource}

        ("Network Adapter :") | Out-File $Outputfile  -Append -encoding UTF8

        If ($VirtualEthernetSwitch -ne $null)
        {
            $switchName = $VirtualEthernetSwitch.ElementName
        }
        Else
        {
            $switchName = "Not Connected"
        }
        ("    Virtual Switch: " + $switchName) | Out-File $Outputfile  -Append -encoding UTF8

        ### VLAN Info
        $EthernetSwitchPortVlanSettingData = $EthernetPortAllocationSetting.GetRelated('Msvm_EthernetSwitchPortVlanSettingData')

        If($EthernetSwitchPortVlanSettingData -ne $NULL)
        {
            switch ($EthernetSwitchPortVlanSettingData.OperationMode)
            {
                0   {$VlanMode = "None(0)"}
                1   {$VlanMode = "Access(1)"}
                2   {$VlanMode = "Trunk(2)"}
                3   {$VlanMode = "Private(3)"}
                default {$VlanMode = "Disabled"}
            }
            ("    Enable virtual LAN identification: " + $VlanMode) | Out-File $Outputfile  -Append -encoding UTF8
            ("    VLAN ID: " + $EthernetSwitchPortVlanSettingData.AccessVlanId) | Out-File $Outputfile  -Append -encoding UTF8
        }
        Else
        {
            ("    Enable virtual LAN identification: Disabled") | Out-File $Outputfile  -Append -encoding UTF8
        }
        ("") | Out-File $Outputfile  -Append -encoding UTF8

        ### Bandwidth Management Info
        $EthernetSwitchPortBandwidthSettingData = $EthernetPortAllocationSetting.GetRelated('Msvm_EthernetSwitchPortBandwidthSettingData')

        ("    Bandwitdth Management:") | Out-File $Outputfile  -Append -encoding UTF8

        If($EthernetSwitchPortBandwidthSettingData -ne $NULL)
        {
            ("        Enable bandwidth management: True") | Out-File $Outputfile  -Append -encoding UTF8
            ("        Minimum bandwidth          : " + $EthernetSwitchPortBandwidthSettingData.Reservation / 1000000.0 + " Mbps") | Out-File $Outputfile  -Append -encoding UTF8
            ("        Maximum bandwidth          : " + $EthernetSwitchPortBandwidthSettingData.Limit / 1000000.0 + " Mbps") | Out-File $Outputfile  -Append -encoding UTF8
        }
        Else
        {
            ("        Enable bandwidth management: False") | Out-File $Outputfile  -Append -encoding UTF8
        }
        ("") | Out-File $Outputfile  -Append -encoding UTF8

        ### Hardware Acceleration
        $EthernetSwitchPortOffloadSettingData = $EthernetPortAllocationSetting.GetRelated('Msvm_EthernetSwitchPortOffloadSettingData')

        ("    Hardware Acceleration:") | Out-File $Outputfile  -Append -encoding UTF8

        If($EthernetSwitchPortOffloadSettingData.VMQOffloadWeight -ne 0)
        {
            $VMQEnabled = "True(VMQOffloadWeight=" + $EthernetSwitchPortOffloadSettingData.VMQOffloadWeight +")"
        }
        Else
        {
            $VMQEnabled = "False"
        }

        ("        Enable virtual machine queue: " +$VMQEnabled) | Out-File $Outputfile  -Append -encoding UTF8

        If($EthernetSwitchPortOffloadSettingData.IPSecOffloadLimit -ne 0)
        {
            $IPSecEnabled = "True(Maximum Number = " + $EthernetSwitchPortOffloadSettingData.IPSecOffloadLimit +" Offloaded SA)"
        }
        Else
        {
            $IPSecEnabled = "False"
        }

        ("        IPSec task offloading: " +$IPSecEnabled) | Out-File $Outputfile  -Append -encoding UTF8

        If($EthernetSwitchPortOffloadSettingData.IOVOffloadWeight -ne 0)
        {
            $SRIOVEnabled = "True(IOVOffloadWeight = " + $EthernetSwitchPortOffloadSettingData.IOVOffloadWeight + ")"
        }
        Else
        {
            $SRIOVEnabled = "False"
        }

        ("        Enable SR-IOV: " +$SRIOVEnabled) | Out-File $Outputfile  -Append -encoding UTF8
        ("") | Out-File $Outputfile  -Append -encoding UTF8

        ### Failover TCP/IP
        $SyntheticEthernetPortSettings = $VSSettingData.GetRelated('Msvm_SyntheticEthernetPortSettingData')

        # Get Msvm_SyntheticEthernetPortSettingData corresponding to the current Msvm_EthernetPortAllocationSetting
        ForEach($SyntheticEthernetPortSetting in $SyntheticEthernetPortSettings)
        {
            If($EthernetPortAllocationSetting.InstanceID.Contains($SyntheticEthernetPortSetting.InstanceID))
            {
                $SyntheticPort = $SyntheticEthernetPortSetting
                break
            }
        }

        If($SyntheticPort -eq $null)
        {
            ("    WARNING: Failed to retrieve Msvm_SyntheticEthernetPortSettingData.") | Out-File $Outputfile  -Append -encoding UTF8
            ("") | Out-File $Outputfile  -Append -encoding UTF8 

            ### As Msvm_SyntheticEthernetPortSettingData is not found, we cannot show any info on vNIC.
            return 
        }

        ("    Failover TCP/IP: ") | Out-File $Outputfile  -Append -encoding UTF8

        $FailoverNetworkAdapterSettingData = $SyntheticPort.GetRelated('Msvm_FailoverNetworkAdapterSettingData')

        If($FailoverNetworkAdapterSettingData -ne $null)
        {
            If($FailoverNetworkAdapterSettingData.DHCPEnabled)
            {
                ("        IPv4/IPv6 TCP/IP Settings: DHCP(No static IP address is specified)") | Out-File $Outputfile  -Append -encoding UTF8
            }
            Else
            {
                ("        IPv4 TCP/IP Settings:") | Out-File $Outputfile  -Append -encoding UTF8
                ("            IPv4 Address   : " + $FailoverNetworkAdapterSettingData.IPAddresses[0]) | Out-File $Outputfile  -Append -encoding UTF8
                ("            Subnet mask    : " + $FailoverNetworkAdapterSettingData.Subnets[0]) | Out-File $Outputfile  -Append -encoding UTF8
                ("            Default gateway: " + $FailoverNetworkAdapterSettingData.DefaultGateways[0]) | Out-File $Outputfile  -Append -encoding UTF8
                ("            Prefferred DNS server: " + $FailoverNetworkAdapterSettingData.DNSServers[0]) | Out-File $Outputfile  -Append -encoding UTF8
                ("            Alternate DNS server : " + $FailoverNetworkAdapterSettingData.DNSServers[1]) | Out-File $Outputfile  -Append -encoding UTF8
                ("") | Out-File $Outputfile  -Append -encoding UTF8

                If($FailoverNetworkAdapterSettingData.IPAddresses.length -eq 2)
                {
                    ("        IPv6 TCP/IP Settings:") | Out-File $Outputfile  -Append -encoding UTF8
                    ("            IPv4 Address   : " + $FailoverNetworkAdapterSettingData.IPAddresses[1]) | Out-File $Outputfile  -Append -encoding UTF8
                    ("            Subnet mask    : " + $FailoverNetworkAdapterSettingData.Subnets[1]) | Out-File $Outputfile  -Append -encoding UTF8
                    ("            Default gateway: " + $FailoverNetworkAdapterSettingData.DefaultGateways[1]) | Out-File $Outputfile  -Append -encoding UTF8
                    ("            Prefferred DNS server: " + $FailoverNetworkAdapterSettingData.DNSServers[2]) | Out-File $Outputfile  -Append -encoding UTF8
                    ("            Alternate DNS server : " + $FailoverNetworkAdapterSettingData.DNSServers[3]) | Out-File $Outputfile  -Append -encoding UTF8
                }
            }
        }
        Else 
        {
            ("        Hyper-V replica is not configured.") | Out-File $Outputfile  -Append -encoding UTF8
        }

        ("") | Out-File $Outputfile  -Append -encoding UTF8

        ### Advanced Feature
        ("    Advanced Features:") | Out-File $Outputfile  -Append -encoding UTF8

        If($SyntheticPort.StaticMacAddress)
        {
			$MACAddr = "Static (" + $SyntheticPort.address + ")" 
        }
        Else
        {
            $MACAddr = "Dynamic (" + $SyntheticPort.address + ")" 

        }

        ("        MAC Address: " + $MACAddr) | Out-File $Outputfile  -Append -encoding UTF8

        $EthernetSwitchPortSecuritySettingData = $EthernetPortAllocationSetting.GetRelated('Msvm_EthernetSwitchPortSecuritySettingData')
        
        If($EthernetSwitchPortSecuritySettingData.AllowMacSpoofing -ne $null)
        {
            $MACAddressSpoofing = $EthernetSwitchPortSecuritySettingData.AllowMacSpoofing
        }
        Else
        {
            $MACAddressSpoofing = "False"
        }

        ("        Enable MAC address spoofing: " + $MACAddressSpoofing) | Out-File $Outputfile  -Append -encoding UTF8

        ### DHCP guard
        If($EthernetSwitchPortSecuritySettingData.EnableDhcpGuard -ne $null)
        {
            $DHCPGuard = $EthernetSwitchPortSecuritySettingData.EnableDhcpGuard
        }
        Else
        {
            $DHCPGuard = "False"
        }

        ("        Enable DHCP guard: " + $DHCPGuard) | Out-File $Outputfile  -Append -encoding UTF8

        ### Router guard
        If($EthernetSwitchPortSecuritySettingData.EnableRouterGuard -ne $null)
        {
            $RouterGuard = $EthernetSwitchPortSecuritySettingData.EnableRouterGuard
        }
        Else
        {
            $RouterGuard = "False"
        }

        ("        Enable router advertisement guard: " + $RouterGuard) | Out-File $Outputfile  -Append -encoding UTF8

        ### Port mirroring
        If($EthernetSwitchPortSecuritySettingData.MonitorMode -ne $null)
        {
            switch ($EthernetSwitchPortSecuritySettingData.MonitorMode)
            {
                0   {$MonitorMode = "None (0)"}
                1   {$MonitorMode = "Destination (1)"}
                2   {$MonitorMode = "Source (2)"}
                default {$MonitorMode = "False"}
            }
        }
        Else
        {
            $MonitorMode = "False"
        }
        ("        Mirrorring mode: " + $MonitorMode) | Out-File $Outputfile  -Append -encoding UTF8

        ### Proctected Netowrk(WS2012R2 or later)
        If($SyntheticPort.ClusterMonitored -ne $null)
        {
            ("        Protected network: " + $SyntheticPort.ClusterMonitored) | Out-File $Outputfile  -Append -encoding UTF8
        }

        ### NIC Teaming
        If($EthernetSwitchPortSecuritySettingData.AllowTeaming -ne $null)
        {
            $AllowTeaming = $EthernetSwitchPortSecuritySettingData.AllowTeaming
        }
        Else
        {
            $AllowTeaming = "False"
        }

        ("        Enable this network adapter to be partof a team in the guest operating system: " + $AllowTeaming) | Out-File $Outputfile  -Append -encoding UTF8
        ("") | Out-File $Outputfile  -Append -encoding UTF8
    }
}

Function showComPortinfo 
{
    $VM = $args[0]

    $ComPorts = Get-VMComPort -VMName $VM.ElementName

    ("COM Port:") | Out-File $Outputfile  -Append -encoding UTF8

    Foreach ($ComPort in $ComPorts)
    {
        ("    " + $ComPort.Name + ": " + $ComPort.Path) | Out-File $Outputfile  -Append -encoding UTF8
    }
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showFloppyDriveinfo 
{
    $VM = $args[0]

    $loppyDrive = Get-VMFloppyDiskDrive -VMName $VM.ElementName

    ("Diskette Drive:") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Path: " + $floppyDrive.Path) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showICinfo 
{
    $VSSettingData = $args[0]

    ("Integration Services:") | Out-File $Outputfile  -Append -encoding UTF8

    $ShutdownComponentSettingData = $VSSettingData.GetRelated('Msvm_ShutdownComponentSettingData')
    $enabledState = getStateString($ShutdownComponentSettingData.EnabledState)
    ("    Operating system shutdown: " + $enabledState) | Out-File $Outputfile  -Append -encoding UTF8

    $TimeSyncComponentSettingData = $VSSettingData.GetRelated('Msvm_TimeSyncComponentSettingData')
    $enabledState = getStateString($TimeSyncComponentSettingData.EnabledState)
    ("    Time synchronization     : " + $enabledState) | Out-File $Outputfile  -Append -encoding UTF8

    $KvpExchangeComponentSettingData = $VSSettingData.GetRelated('Msvm_KvpExchangeComponentSettingData')
    $enabledState = getStateString($KvpExchangeComponentSettingData.EnabledState)
    ("    Data Exchange            : " + $enabledState) | Out-File $Outputfile  -Append -encoding UTF8

    $HeartbeatComponentSettingData = $VSSettingData.GetRelated('Msvm_HeartbeatComponentSettingData')
    $enabledState = getStateString($HeartbeatComponentSettingData.EnabledState)
    ("    Heartbeat                : " + $enabledState) | Out-File $Outputfile  -Append -encoding UTF8

    ### Show heartbeat interval if it is enabled.
    If($HeartbeatComponentSettingData.EnabledState -eq 2)
    {
        ("        Interval      : " + $HeartbeatComponentSettingData.Interval + " ms") | Out-File $Outputfile  -Append -encoding UTF8
        ("        Latency       : " + $HeartbeatComponentSettingData.Latency + " ms") | Out-File $Outputfile  -Append -encoding UTF8
        ("        ErrorThreshold: " + $HeartbeatComponentSettingData.ErrorThreshold + " times") | Out-File $Outputfile  -Append -encoding UTF8
    }

    $VssComponentSettingData = $VSSettingData.GetRelated('Msvm_VssComponentSettingData')
    $enabledState = getStateString($VssComponentSettingData.EnabledState)
    ("    Backup (volume snapshot) : " + $enabledState) | Out-File $Outputfile  -Append -encoding UTF8

    ### Guest service(Windows server 2012 R2 or later)
    $GuestServiceInterfaceComponentSettingData = $VSSettingData.GetRelated('Msvm_GuestServiceInterfaceComponentSettingData')
    $enabledState = getStateString($GuestServiceInterfaceComponentSettingData.EnabledState)
    ("    Guest service            : " + $enabledState) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function getStateString 
{
    $enabledState = $args[0]

    switch ($enabledState)
    {
        2   {$enabledStateStr = "Enabled(2)"}
        3   {$enabledStateStr = "Disabled(3)"}
        default {$enabledStateStr = "Unknown"}
    }
    return $enabledStateStr
}

Function showSnapshotFileinfo
{
    $VSSettingData = $args[0]

    ("Snapshot File Location(File Location for xml):") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Path: " + $VSSettingData.SnapshotDataRoot) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showSmartPagingFileinfo
{
    $VSSettingData = $args[0]

    ("Smart Paging File Location:") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Path: " + $VSSettingData.SwapFileDataRoot) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showAutomaticActioninfo
{
    $VSSettingData = $args[0]
    ("Automatic Start Action:") | Out-File $Outputfile  -Append -encoding UTF8
    switch ($VSSettingData.AutomaticStartupAction)
    {
        2   {$startActionStr = "Nothing(2)"}
        3   {$startActionStr = "Automatically start if it was running when the service stopped(3)"}
        4   {$startActionStr = "Always start this virtual machine automatically(4)"}
        default {$startActionStr = "Unknown"}
    }
    ("    Action: " + $startActionStr) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8

    ("Automatic Stop Action:") | Out-File $Outputfile  -Append -encoding UTF8
    switch ($VSSettingData.AutomaticShutdownAction)
    {
        2   {$shutdownActionStr = "Turn off the virtual machine(2)"}
        3   {$shutdownActionStr = "Save the virtual machine state(3)"}
        4   {$shutdownActionStr = "Shut down the guest operating system(4)"}
        default {$shutdownActionStr = "Unknown"}
    }
    ("    Action: " + $shutdownActionStr) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showSnapshotInfo
{
    $VM = $args[0]
    ("Snapshot: ") | Out-File $Outputfile  -Append -encoding UTF8

    $Snapshots =  Get-VMSnapshot -VMName $VM.ElementName

    If($Snapshots.length -eq 0)
    {
        ("    No snapshots in this VM.") | Out-File $Outputfile  -Append -encoding UTF8
        ("") | Out-File $Outputfile  -Append -encoding UTF8
        return
    }

    ("    -----------------------------------------------------") | Out-File $Outputfile  -Append -encoding UTF8

    ForEach($Snapshot in $Snapshots)
    { 
        $VirtualSystemSettingData = $VM.GetRelated('Msvm_VirtualSystemSettingData') | Where-Object { $_.ElementName -eq $Snapshot.Name }

        If($VirtualSystemSettingData.count -gt 1) 
        {
            ### Sometimes there are two same Msvm_StorageAllocationSettingData. So we get first one. Probably this is a bug...
            $HardDrives = $VirtualSystemSettingData[0].GetRelated('Msvm_StorageAllocationSettingData') 
        } 
        Else
        {
            $HardDrives = $VirtualSystemSettingData.GetRelated('Msvm_StorageAllocationSettingData') 
        }

        ("    Name         : " + $Snapshot.Name) | Out-File $Outputfile  -Append -encoding UTF8
        ("    Type         : " + $Snapshot.SnapshotType) | Out-File $Outputfile  -Append -encoding UTF8
        ("    Creation Time: " + $Snapshot.CreationTime) | Out-File $Outputfile  -Append -encoding UTF8
        ("    Parent       : " + $Snapshot.ParentSnapshotName) | Out-File $Outputfile  -Append -encoding UTF8
        ("    File List    : ") | Out-File $Outputfile  -Append -encoding UTF8

        If($HardDrives -eq $null)
        {
            continue  # No drives attached to this snapshot.
        }

        # Get ACL and file property.
        ForEach($HardDrive in $HardDrives)
        {
            If(($HardDrive.HostResource[0]).Contains("vhd"))
            {
                ("        - " + $HardDrive.HostResource) | Out-File $Outputfile  -Append -encoding UTF8
            }
            Else
            {
                continue  ### Probably physical drive or ISO file
            }

            If(!(Test-Path $HardDrive.HostResource))
            {
                ("            !!! WARNING: above file does not exist !!!") | Out-File $Outputfile  -Append -encoding UTF8
                continue
            }


            $vhdInfo = Get-VHD -Path $HardDrive.HostResource[0] 
            $property = Get-ChildItem $HardDrive.HostResource[0]
            $fileSize = [math]::round($property.Length / 1GB , 3)
            $maxFileSize = [math]::round($vhdInfo.Size / 1GB , 3)
            $ACL = Get-ACL $HardDrive.HostResource[0]            

            ("            VhdType: " + $vhdInfo.VhdType) | Out-File $Outputfile  -Append -encoding UTF8
            ("            Creation time: " + $property.CreationTime + "    " + "Last write time: " + $property.LastWriteTime) | Out-File $Outputfile  -Append -encoding UTF8
            ("            Current size: " + $fileSize + " GB" + "  /  Max file size: " + $maxFileSize + " GB") | Out-File $Outputfile  -Append -encoding UTF8
            ("            LogicalSectorSize: " + $vhdInfo.LogicalSectorSize + " bytes  /  PhysicalSectorSize: " + $vhdInfo.PhysicalSectorSize + " bytes") | Out-File $Outputfile  -Append -encoding UTF8
            ("            Owner: " + $ACL.Owner) | Out-File $Outputfile  -Append -encoding UTF8
            ("            ACL: ") | Out-File $Outputfile  -Append -encoding UTF8

            $AccessRules = $ACL.GetAccessRules($true,$true, [System.Security.Principal.NTAccount])

            ForEach($AccessRule in $AccessRules)
            {
                ("                " + $AccessRule.IdentityReference + " => " + $AccessRule.FileSystemRights) | Out-File $Outputfile  -Append -encoding UTF8
            }
        }
        ("    -----------------------------------------------------") | Out-File $Outputfile  -Append -encoding UTF8
    }
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function showReplicationinfo
{
    $VM = $args[0]
    $VirtualSystemSettingData = $VM.GetRelated('Msvm_VirtualSystemSettingData') | Where-Object { $_.VirtualSystemType -eq 'Microsoft:Hyper-V:System:Realized' }

    switch ($VM.ReplicationState)
    {
        0   {$ReplicationState = "Disabled"}
        1   {$ReplicationState = "Ready for replication"}
        2   {$ReplicationState = "Waiting to complete initial replication"}
        3   {$ReplicationState = "Replicating"}
        4   {$ReplicationState = "Synced replication complete"}
        5   {$ReplicationState = "Recovered"}
        6   {$ReplicationState = "Committed"}
        7   {$ReplicationState = "Suspended"}
        8   {$ReplicationState = "Critical"}
        9   {$ReplicationState = "Waiting to start resynchronization"}
       10   {$ReplicationState = "Resynchronizing"}
       11   {$ReplicationState = "Resynchronization suspended"}
       12   {$ReplicationState = "Failover in progress"}
       13   {$ReplicationState = "Failback in progress"}
       14   {$ReplicationState = "Failback complete"}
    }

    switch ($VM.FailedOverReplicationType)
    {
        0   {$FailedOverReplicationType = "None"}
        1   {$FailedOverReplicationType = "Regular"}
        2   {$FailedOverReplicationType = "Application consistent"}
        3   {$FailedOverReplicationType = "Planned"}
    }

    switch ($VM.ReplicationHealth)
    {
        0   {$ReplicationHealth = "Not applicable"}
        1   {$ReplicationHealth = "Ok"}
        2   {$ReplicationHealth = "Warning"}
        3   {$ReplicationHealth = "Critical"}
    }

    switch ($VM.ReplicationMode)
    {
        0   {$ReplicationMode = "None"}
        1   {$ReplicationMode = "Primary"}
        2   {$ReplicationMode = "Recovery"}
        3   {$ReplicationMode = "Replica"}
        4   {$ReplicationMode = "Extended Replica"}
    }

    ### Sometimes there are two same Msvm_ReplicationSettingData. So we get first one. 
    $ReplicationSettingData = $VM.GetRelated('Msvm_ReplicationSettingData') | Select-Object -first 1

    switch ($ReplicationSettingData.AuthenticationType)
    {
        1   {$AuthenticationType = "Kerberos authentication"}
        2   {$AuthenticationType = "Certificate based authentication"}
    }

    $HVRConfiRoot = $VirtualSystemSettingData.ConfigurationDataRoot.ToString()
    $HVRConfigFile = $VirtualSystemSettingData.ConfigurationFile.ToString()
    $VHD = get-vhd -vmid $VM.Name

    If($ReplicationSettingData.ReplicationInterval -eq $null)
    {
        $ReplicationInterval = 300
    }
    Else
    {
        $ReplicationInterval = $ReplicationSettingData.ReplicationInterval
    }

    ("Replication:") | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Replication:") | Out-File $Outputfile  -Append -encoding UTF8
    ("        This virtual machinge is configured as " + $ReplicationMode + " virtual machine.") | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
    ("        Port on the Replica server  : " + $ReplicationSettingData.RecoveryServerPortNumber) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Authentication Type         : " + $AuthenticationType) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Compression the data that is transmitted over the network: " + $ReplicationSettingData.CompressionEnabled) | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Recovery Points:") | Out-File $Outputfile  -Append -encoding UTF8

    If($ReplicationSettingData.RecoveryHistory -eq 0)
    {
        ("        Only the latest point for recovery") | Out-File $Outputfile  -Append -encoding UTF8
    }
    Else
    {
        ("        Additional recovery points") | Out-File $Outputfile  -Append -encoding UTF8
        ("            Number of recovery point: " + $ReplicationSettingData.RecoveryHistory) | Out-File $Outputfile  -Append -encoding UTF8

        $isVssReplicaEnabled = $True
        If($ReplicationSettingData.ApplicationConsistentSnapshotInterval -eq 0)
        {
            $isVssReplicaEnabled = $False
        }

        ("        Application consistent replication: " + $isVssReplicaEnabled) | Out-File $Outputfile  -Append -encoding UTF8

        If($isVssReplicaEnabled)
        {
            ("        Replicate incremental VSS copy every: "  + $ReplicationSettingData.ApplicationConsistentSnapshotInterval + " hour(s)") | Out-File $Outputfile  -Append -encoding UTF8
        }
    }

    ### Windows Server 2012 R2 or later
    ### We don't show resync setting if it is RecoveryVM as it is not available.
    If($VM.ReplicationMode -eq 1)
    {
        ("") | Out-File $Outputfile  -Append -encoding UTF8
        ("    Resynchronization:") | Out-File $Outputfile  -Append -encoding UTF8

        $resyncIntervalEnd = [System.Management.ManagementDateTimeConverter]::Totimespan($ReplicationSettingData.AutoResynchronizeIntervalEnd)
        $resyncIntervalStart = [System.Management.ManagementDateTimeConverter]::Totimespan($ReplicationSettingData.AutoResynchronizeIntervalStart)
        $oneSecond = New-TimeSpan -Seconds 1
        $endPlusOneSec = $resyncIntervalEnd + $oneSecond

        If($ReplicationSettingData.AutoResynchronizeEnabled)
        {
            If(($resyncIntervalStart.Hours -eq $endPlusOneSec.Hours) -and ($resyncIntervalStart.Minutes -eq $endPlusOneSec.Minutes) -and ($resyncIntervalStart.Seconds -eq $endPlusOneSec.Seconds))
            {
                ("        Automatically start resynchronization") | Out-File $Outputfile  -Append -encoding UTF8
            }
            Else
            {
                ("        Automatically start resynchronization only during the follwing hours:") | Out-File $Outputfile  -Append -encoding UTF8
                ("            From: " + $resyncIntervalStart.Hours.ToString("00") + $resyncIntervalStart.Minutes.ToString("\:00")) | Out-File $Outputfile  -Append -encoding UTF8
                ("              To: " + $resyncIntervalEnd.Hours.ToString("00") + $resyncIntervalEnd.Minutes.ToString("\:00")) | Out-File $Outputfile  -Append -encoding UTF8
            }
        }
        Else
        {
            ("        Manually") | Out-File $Outputfile  -Append -encoding UTF8
        }
    }

    ("") | Out-File $Outputfile  -Append -encoding UTF8
    ("    Other replication info: ") | Out-File $Outputfile  -Append -encoding UTF8
    ("        VM GUID                     : " + $VM.Name) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Configuration file          : " + $HVRConfiRoot + "\" + $HVRConfigFile) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Included VHD files          : ") | Out-File $Outputfile  -Append -encoding UTF8

    ForEach($includedDisk in $ReplicationSettingData.IncludedDisks)
    {
        ("            - " + $includedDisk) | Out-File $Outputfile  -Append -encoding UTF8
    }

    ("        Primary server              : " + $ReplicationSettingData.PrimaryHostSystem) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Primary connection point    : " + $ReplicationSettingData.PrimaryConnectionPoint) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Replica server              : " + $ReplicationSettingData.RecoveryHostSystem) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Replication interval        : " + $ReplicationInterval + " seconds") | Out-File $Outputfile  -Append -encoding UTF8
    ("        ReplicationHealth           : " + $ReplicationHealth) | Out-File $Outputfile  -Append -encoding UTF8
    ("        ReplicationMode             : " + $ReplicationMode) | Out-File $Outputfile  -Append -encoding UTF8
    ("        ReplicationState            : " + $ReplicationState) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Last update time            : " + $VM.LastReplicationTime) | Out-File $Outputfile  -Append -encoding UTF8
    ("        Last update time(VSS)       : " + $VM.LastApplicationConsistentReplicationTime) | Out-File $Outputfile  -Append -encoding UTF8
}

Function showHVFileVersion
{
    $system32Files = dir "C:\Windows\System32\vm*"
    $hypervisorFiles = dir "C:\Windows\System32\hv*"
    $driversFiles = dir "C:\Windows\System32\drivers\vm*"
    $fileArray = ($system32Files, $driversFiles, $hypervisorFiles)
    
    ("File version:") | Out-File $Outputfile  -Append -encoding UTF8

    ForEach($files in $fileArray)
    {
        ForEach($file in $files)
        {
            $ext = (Get-ChildItem $File).get_Extension()

            If($ext -ne ".dll" -and $ext -ne ".sys" -and $ext -ne ".exe")
            {
               continue
            }

            ("    " + $file.Name + "    " + $file.VersionInfo.FileVersion) | Out-File $Outputfile  -Append -encoding UTF8
        }
    }
    ("") | Out-File $Outputfile  -Append -encoding UTF8
}

Function getVmGeneration
{
    $VSSettingData = $args[0]

    If($VSSettingData.VirtualSystemSubType -eq $null) ### WS2012
    {
        $vmGgeneration = "1"
    }
    Else ### WS2012R2 or later
    {
        $subType = $VSSettingData.VirtualSystemSubType.split(":")
        $vmGgeneration = $subType[3]
    }

    return $vmGgeneration
}

Function getHeartBeatInfo
{
    $heartbeatComponent = $args[0]

    If ( $heartbeatComponent.StatusDescriptions -ne $null )
    {
        $heartbeat = $HeartbeatComponent.OperationalStatus[0]
        $strhbPrimaryStatus = getHBOperationalStatus($heartbeat)
    }
}

Function getVMEnabledState
{
    $vmStatus = $args[0]

    # http://msdn.microsoft.com/en-us/library/hh850116(v=vs.85).aspx
    switch ($vmStatus)
    {
        0   {$EnabledState = "Unknown"}
        1   {$EnabledState = "Other"}
        2   {$EnabledState = "Running(Enabled - 2)"}
        3   {$EnabledState = "Off(Disabled - 3)"}
        4   {$EnabledState = "Shutting down(4)"}
        5   {$EnabledState = "Not Applicable(5)"}
        6   {$EnabledState = "Saved(Enabled but Offline - 6)"}
        7   {$EnabledState = "In Test(7)"}
        8   {$EnabledState = "Deferred(8)"}
        9   {$EnabledState = "Quiesce(9)"}
       10   {$EnabledState = "Starting(10)"}
    }

    return $EnabledState
}

Function getHBOperationalStatus
{
    $hbStatus = $args[0]

    # http://msdn.microsoft.com/en-us/library/hh850157(v=vs.85).aspx
    switch ($hbStatus)
    {
        2   {$hbPrimaryStatus = "OK"}
        3   {$hbPrimaryStatus = "Degraded"}
        7   {$hbPrimaryStatus = "Non-Recoverable Error"}
       12   {$hbPrimaryStatus = "No Contact"}
       13   {$hbPrimaryStatus = "Lost Communication"}
       15   {$hbPrimaryStatus = "Paused"}
       default {$hbPrimaryStatus = "N/A"}
    }
    return $hbPrimaryStatus
}

Function getHBSecondaryStatus
{
    $hbStatus2 = $args[0]

    # http://msdn.microsoft.com/en-us/library/hh850157(v=vs.85).aspx
    switch ($hbStatus2)
    {
            2   {$hbSecondaryStatus = "OK"}
        32775   {$hbSecondaryStatus = "Protocol Mismatch"}
        32782   {$hbSecondaryStatus = "Application Critical State"}
        32783   {$hbSecondaryStatus = "Communication Timed Out"}
        32784   {$hbSecondaryStatus = "Communication Failed"}
        default {$hbSecondaryStatus = "N/A"}
    }
    return $hbSecondaryStatus
}

###
### MAIN
###
$osVersion = [environment]::OSVersion.Version
$TestPath = Test-Path "C:\Windows\System32\vmms.exe"
If (($TestPath -eq $False) -or ($osVersion.Build -lt 9200))
{
    "Hyper-V basic information cannot be collected on this system."  | WriteTo-StdOut
    "Hyper-V is installed: $TestPath"  | WriteTo-StdOut
    "OS version is build $OSVersion"  | WriteTo-StdOut
}
Else
{
    $hostName = hostname
    $VMs = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_ComputerSystem' | Where-Object { $_.ElementName -ne $hostName}
    $VSMgtServiceSettingData = Get-WmiObject -Namespace 'root\virtualization\v2' -Class 'Msvm_VirtualSystemManagementServiceSettingData'

    showHVGlobalSettings $VSMgtServiceSettingData
    showNUMAinfo
    
    ("Virtual Machine Settings") | Out-File $Outputfile  -Append -encoding UTF8
    ("----------------------------------------") | Out-File $Outputfile  -Append -encoding UTF8
    ("") | Out-File $Outputfile  -Append -encoding UTF8 
    
    ForEach ($VM in $VMs)
    {
        
        $VirtualSystemSettingData = $VM.GetRelated('Msvm_VirtualSystemSettingData') | Where-Object { $_.VirtualSystemType -eq 'Microsoft:Hyper-V:System:Realized' }
        
        ("<<<<<<<<<< " + $VM.elementName + " >>>>>>>>>>") | Out-File $Outputfile  -Append -encoding UTF8
        ("") | Out-File $Outputfile  -Append -encoding UTF8
        
        showVMBasicinfo $VM $VirtualSystemSettingData
        
        ### Hyper-V UI settings
        showBIOSinfo $VirtualSystemSettingData
        showMeminfo $VirtualSystemSettingData
        showCPUinfo $VirtualSystemSettingData
        
        # We don't get IDE info in case of Gen2VM as IDE does not exist.
        $vmGeneration = getVmGeneration $VirtualSystemSettingData
        If($vmGeneration -eq "1")
        {
            showIDEHardDriveinfo $VM
        }

        showSCSIHardDriveinfo $VM
        showNetworkAdapterinfo $VirtualSystemSettingData
        showComPortinfo $VM 

        If($vmGeneration -eq "1")
        {
            showFloppyDriveinfo $VM
        }

        showICinfo $VirtualSystemSettingData
        showSnapshotFileinfo $VirtualSystemSettingData
        showSmartPagingFileinfo $VirtualSystemSettingData
        showAutomaticActioninfo $VirtualSystemSettingData

        ### Additional info
        showSnapshotInfo $VM
        showKVPItems $VM $VirtualSystemSettingData

        # Get replication info if it is enabled
        if ($VM.ReplicationState -ne 0)
        {
            ("Detected Hyper-V replica enabled...") | Out-File $Outputfile  -Append -encoding UTF8
            ("") | Out-File $Outputfile  -Append -encoding UTF8
            showReplicationinfo $VM
        }

        ("") | Out-File $Outputfile  -Append -encoding UTF8
        ("================================================================================") | Out-File $Outputfile  -Append -encoding UTF8
        ("") | Out-File $Outputfile  -Append -encoding UTF8

    }
    
    showHVFileVersion
    CollectFiles -filesToCollect $OutputFile  -fileDescription $FileDescription  -sectionDescription $SectionDescription  -renameOutput $false
}
