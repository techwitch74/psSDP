﻿#************************************************
# DC_RegistrySetupPerf.ps1
# Version 1.1
# Date: 2009-2019
# Author:  +WalterE
# Description: Collects Registry information
# Called from: all TS_AutoAddCommands_*
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}
Import-LocalizedData -BindingVariable UtilsRegistrySetupPerf

$OutputFile= $Computername + "_reg_CurrentVersion.TXT"
$CurrentVersionKeys = "HKLM\Software\Microsoft\Windows NT\CurrentVersion", 
                      "HKLM\Software\Microsoft\Windows\CurrentVersion"   
RegQuery -RegistryKeys $CurrentVersionKeys -OutputFile $OutputFile -fileDescription "CurrentVersion"

$OutputFile= $Computername + "_reg_Uninstall.TXT"
$UninstallKeys = "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall", 
                 "HKLM\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
RegQuery -RegistryKeys $UninstallKeys -OutputFile $OutputFile -fileDescription "Uninstall" -Recursive $true

#$OutputFile= $Computername + "_reg_ProductOptions.TXT"
#RegqueryValue -RegistryKeys "HKLM\SYSTEM\CurrentControlSet\Control\ProductOptions" -RegistryValues 'ProductSuite' -OutputFile $OutputFile -fileDescription "Product Options"


$OutputFile= $Computername + "_reg_Recovery.TXT"
$RecoveryKeys = "HKLM\System\CurrentControlSet\Control\CrashControl", 
			"HKLM\System\CurrentControlSet\Control\Session Manager",
			"HKLM\System\CurrentControlSet\Control\Session Manager\Memory Management",
			"HKLM\Software\Microsoft\Windows NT\CurrentVersion\AeDebug"	
RegQuery -RegistryKeys $RecoveryKeys -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfRecoveryDebugInfo -AddFileToReport $false

$RecoveryKeys = "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options",
			"HKLM\Software\Microsoft\Windows\Windows Error Reporting",
			"HKLM\Software\Policies\Microsoft\Windows\Windows Error Reporting"
RegQuery -RegistryKeys $RecoveryKeys -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfRecoveryDebugInfo -AddFileToReport $true -Recursive $true

$OutputFile= $Computername + "_reg_Startup.TXT"
$StartupKeys = "HKCU\Software\Microsoft\Windows\CurrentVersion\Run", 
         "HKCU\Software\Microsoft\Windows\CurrentVersion\Runonce", 
         "HKCU\Software\Microsoft\Windows\CurrentVersion\RunonceEx", 
         "HKCU\Software\Microsoft\Windows\CurrentVersion\RunServices", 
         "HKCU\Software\Microsoft\Windows\CurrentVersion\RunServicesOnce", 
         "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\Explorer\Run", 
         "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run", 
         "HKLM\Software\Microsoft\Windows\CurrentVersion\Runonce", 
         "HKLM\Software\Microsoft\Windows\CurrentVersion\RunonceEx", 
         "HKLM\Software\Microsoft\Windows\CurrentVersion\RunServices", 
         "HKLM\Software\Microsoft\Windows\CurrentVersion\RunServicesOnce", 
         "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\ShellServiceObjectDelayLoad"
RegQuery -RegistryKeys $StartupKeys -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfIStartupInfo -AddFileToReport $false

$StartupKeys = "HKCU\Software\Microsoft\Windows NT\CurrentVersion",
				"HKCU\Software\Microsoft\Windows NT\CurrentVersion\Windows",
				"HKCU\Software\Microsoft\Windows\CurrentVersion\Policies\Explorer",
				"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
$StartupKeysValues = "Load", 
					 "Run", 
					 "Run", 
					 "UserInit"
RegQueryValue -RegistryKeys $StartupKeys -RegistryValues $StartupKeysValues -OutputFile $OutputFile -fileDescription "Startup Info" -CollectResultingFile $true

$OutputFile= $Computername + "_reg_Print.HIV"
RegSave -RegistryKey "HKLM\SYSTEM\CurrentControlSet\Control\Print" -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfILocalPrintKey

$OutputFile= $Computername + "_reg_Policies.txt"
$PoliciesKeys =  "HKCU\Software\Policies",
				"HKLM\Software\Policies",
				"HKCU\Software\Microsoft\Windows\CurrentVersion\Policies",
				"HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies"
RegQuery -RegistryKeys $PoliciesKeys  -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfIPolicies -Recursive $true

$OutputFile= $Computername + "_reg_TimeZone.txt"
$TimezoneKeys =  "HKLM\SYSTEM\CurrentControlSet\Control\TimeZoneInformation",
				"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Time Zones"
RegQuery -RegistryKeys $TimezoneKeys  -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfRegTimeZoneInfo -Recursive $true

$OutputFile= $Computername + "_reg_TermServices.txt"
$TSKeys =  "HKLM\SYSTEM\CurrentControlSet\Control\Terminal Server",
			"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server",
			"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Terminal Server Web Access",
			"HKLM\SYSTEM\CurrentControlSet\Services\TermService",
			"HKLM\SYSTEM\CurrentControlSet\Services\TermDD"
RegQuery -RegistryKeys $TSKeys -OutputFile $OutputFile -fileDescription $UtilsRegistrySetupPerf.ID_RegSetupPerfRegTS -Recursive $true

