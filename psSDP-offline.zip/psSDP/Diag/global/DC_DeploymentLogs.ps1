﻿# Copyright ?2008, Microsoft Corporation. All rights reserved.

# You may use this code and information and create derivative works of it,
# provided that the following conditions are met:
# 1. This code and information and any derivative works may only be used for
# troubleshooting a) Windows and b) products for Windows, in either case using
# the Windows Troubleshooting Platform
# 2. Any copies of this code and information
# and any derivative works must retain the above copyright notice, this list of
# conditions and the following disclaimer.
# 3. THIS CODE AND INFORMATION IS PROVIDED ``AS IS'' WITHOUT WARRANTY OF ANY KIND,
# WHETHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES
# OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. IF THIS CODE AND
# INFORMATION IS USED OR MODIFIED, THE ENTIRE RISK OF USE OR RESULTS IN CONNECTION
# WITH THE USE OF THIS CODE AND INFORMATION REMAINS WITH THE USER.

PARAM([string]$MachineName = $ComputerName,[string]$Path= $null)

if($debug -eq $true){[void]$shell.popup("Run DC_DeploymentLogsLogs.ps1")}

Import-LocalizedData -BindingVariable DeploymentLogsStrings

Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogs -Status $DeploymentLogsStrings.ID_DeploymentLogsObtaining

Function CopyDeploymentFile ($sourceFileName, $destinationFileName, $fileDescription) 
{

	Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status $sourceFileName

	$sectionDescription = "Deployment Logs"
	
	if (test-path $sourceFileName) {
		$sourceFile = Get-Item $sourceFileName
		#copy the file only if it is not a 0KB file.
		if ($sourceFile.Length -gt 0) 
		{
			$CommandLineToExecute = "cmd.exe /c copy `"$sourceFileName`" `"$destinationFileName`""
			RunCmD -commandToRun $CommandLineToExecute -sectionDescription $sectionDescription -filesToCollect $destinationFileName -fileDescription $fileDescription
		}
	}
}

$PathNotPresent = [string]::IsNullOrEmpty($Path)
 
if($PathNotPresent)
{ 
	$LogPath = $Env:windir
}
else
{
	$LogPath = $Path
}

Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status (join-path $LogPath "System32\sysprep")
$arrSysprepFiles = get-childitem -force -path (join-path $LogPath "System32\sysprep") -recurse -exclude *.exe,*.mui,*.dll | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrSysprepFiles -fileDescription "Sysprep Folder" -sectionDescription "Sysprep Folder" -DestinationFileName ($MachineName + "_sysprep.zip") -renameoutput $false -recursive

Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status (join-path $LogPath "Panther")
$arrPantherFiles = get-childitem -force -path (join-path $LogPath "Panther") -recurse -exclude *.exe,*.mui,*.dll,*.png,*.ttf | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrPantherFiles -fileDescription "Panther Folder" -sectionDescription "Panther Folder" -DestinationFileName ($MachineName + "_panther.zip") -renameoutput $false -recursive 

#CompressCollectFiles -filesToCollect (join-path $LogPath "System32\sysprep") -recursive -fileDescription "Sysprep Folder" -sectionDescription "Sysprep Folder" -DestinationFileName ($MachineName + "_sysprep.zip") -renameoutput $false

#CompressCollectFiles -filesToCollect (join-path $LogPath "Panther") -recursive -fileDescription "Panther Folder" -sectionDescription "Panther Folder" -DestinationFileName ($MachineName + "_panther.zip") -renameoutput $false

$sourceFileName = "$LogPath\setupact.log"
$destinationFileName = $MachineName + "_setupact-windows.log"
$fileDescription = "Setupact.log on Windows folder"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$LogPath\setuperr.log"
$destinationFileName = $MachineName + "_setuperr-windows.log"
$fileDescription = "Setuperr.log on Windows folder"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$LogPath\logs\dism\DISM.log"
$destinationFileName = $MachineName + "_DISM-Windows-Logs.log"
$fileDescription = "DISM.log on Windows\logs\DISM"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

$sourceFileName = "$LogPath\ccm\smsts.log"
$destinationFileName = $MachineName + "_smsts_ccm_logs.log"
$fileDescription = "Task Sequencer Log on System32\ccm\logs"
CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription

#_# ----- added: 2019-07-15 #_#
if (test-path "$LogPath\logs\mosetup\bluebox.log")
	{
	$sourceFileName = "$LogPath\logs\mosetup\bluebox.log"
	$destinationFileName = $MachineName + "_bluebox.log"
	$fileDescription = "bluebox.log on on Windows\logs\mosetup folder"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	}
if (test-path "$Env:systemdrive\windows.old\windows\logs\mosetup\bluebox.log")
	{
	$sourceFileName = "$Env:systemdrive\windows.old\windows\logs\mosetup\bluebox.log"
	$destinationFileName = $MachineName + "_bluebox_windowsold.log"
	$fileDescription = "bluebox.log on on Windows.old\windows\logs\mosetup folder"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	}

$BT_folder = (join-path $Env:systemdrive '\$Windows.~BT')
if  (-not (test-path $BT_folder)) {$BT_folder = 'D:\$Windows.~BT'}
if (test-path $BT_folder)
	{
	if (test-path (join-path $BT_folder "Sources\Panther")){
		Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status (join-path $BT_folder "Sources\Panther")
		$arrBTPantherFiles = get-childitem -force -path (join-path $BT_folder "Sources\Panther") -recurse -exclude *.exe,*.mui,*.dll,*.png,*.ttf | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrBTPantherFiles -fileDescription "~BT Panther Folder" -sectionDescription "~BT Panther Folder" -DestinationFileName ($MachineName + "_~bt_Panther.zip") -renameoutput $false -recursive
	}
	if (test-path (join-path $BT_folder "Sources\Rollback")){
		Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status (join-path $BT_folder "Sources\Rollback")
		$arrBTPantherFiles = get-childitem -force -path (join-path $BT_folder "Sources\Rollback") -recurse -exclude *.exe,*.mui,*.dll,*.png,*.ttf | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrBTPantherFiles -fileDescription "~BT Rollback Folder" -sectionDescription "~BT Rollback Folder" -DestinationFileName ($MachineName + "_~bt_Rollback.zip") -renameoutput $false -recursive
	}
	$sectionDescription = "Dir $BT_folder"
	$OutputFile = Join-Path $pwd.path ($MachineName + "_Dir_WindowsBT.txt")
	Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status "Get $sectiondescription"
	$CommandToExecute = 'dir /a /s "$BT_folder" '
	RunCmD -commandToRun ("cmd.exe /c $CommandToExecute  >> `"$OutputFile`"") -collectFiles $false
	collectfiles -filesToCollect $OutputFile -fileDescription "WinDeploy: $sectionDescription output" -sectionDescription $sectionDescription
}

$WebSetupPantherFolder = (join-path $Env:userprofile "Local Settings\Application Data\Microsoft\WebSetup\Panther")
if (test-path $WebSetupPantherFolder)
	{
		Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status "$WebSetupPantherFolder"
		$arrWebPantherFiles = get-childitem -force -path $WebSetupPantherFolder -recurse -exclude *.exe,*.tmp,*.js,*.png | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
		CompressCollectFiles -filesToCollect $arrWebPantherFiles -fileDescription "UpgradeSetup\WebSetup-Panther Folder" -sectionDescription "UpgradeSetup\WebSetup-Panther Folder" -DestinationFileName ($MachineName + "_WebSetup-Panther.zip") -renameoutput $false -recursive
	}
if (test-path "$Env:localappdata\Microsoft\Windows\PurchaseWindowsLicense")
{
	$sourceFileName = "$Env:localappdata\Microsoft\Windows\PurchaseWindowsLicense\PurchaseWindowsLicense.log"
	$destinationFileName = $MachineName + "_PurchaseWindowsLicense.log"
	$fileDescription = "Log on Microsoft\Windows\PurchaseWindowsLicense"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	}
if (test-path "$Env:localappdata\Microsoft\Windows\Windows Anytime Upgrade")
{
	$sourceFileName = "$Env:localappdata\Microsoft\Windows\Windows Anytime Upgrade\PurchaseWindowsLicense.log"
	$destinationFileName = $MachineName + "_Windows-Anytime-Upgrade.log"
	$fileDescription = "Log on Microsoft\Windows\Windows Anytime Upgrade"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	}

Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status "$Env:WinDir\Setup\"
$arrSetupFiles = get-childitem -force -path (join-path $Env:WinDir "Setup") -recurse | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $arrSetupFiles -fileDescription "$Env:WinDir\Setup Folder" -sectionDescription "$Env:WinDir\Setup Folder" -DestinationFileName ($MachineName + "_Win_Setup.zip") -renameoutput $false -recursive

if (test-path "$LogPath\setupact.log")
	{
	$sourceFileName = "$LogPath\setupact.log"
	$destinationFileName = $MachineName + "_setupact.log"
	$fileDescription = "setupact.log on Windows folder"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	}
if (test-path "$LogPath\System32\LogFiles\setupcln\setupact.log")
	{
	$sourceFileName = "$LogPath\System32\LogFiles\setupcln\setupact.log"
	$destinationFileName = $MachineName + "_setupact-setupcln.log"
	$fileDescription = "setupact.log on Windows\System32\LogFiles\setupcln folder"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	}

Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status "CCM Logs"
$CCMlogFiles = get-childitem -force -path $Env:WinDir\ccm\logs -recurse -include execmgr.log,scheduler.log,StatusAgent.log,ccmnotificationagent.log,ccmexec.log,rebootcoordinator.log,wua*.*,updates*.*,deltaDownload.log | Where {$_.psIsContainer -eq $false} | foreach {$_.fullname}
CompressCollectFiles -filesToCollect $CCMlogFiles -fileDescription "$Env:WinDir\ccm\logs" -sectionDescription "$Env:WinDir\ccm\logs" -DestinationFileName ($MachineName + "_SCCM-Logs.zip") -renameoutput $false -recursive

$OutputFile = $MachineName + "_SCCM_SoftwareUpdatesClientConfig.txt"
Get-WmiObject -Namespace ROOT\ccm\Policy\Machine\ActualConfig -Class CCM_SoftwareUpdatesClientConfig |out-file $OutputFile
$fileDescription = "SoftwareUpdatesClientConfig"
$sectionDescription = "SoftwareUpdatesClientConfig"
CollectFiles -filesToCollect $outfile -fileDescription $fileDescription -sectionDescription $sectionDescription


if($PathNotPresent)
{
	$sourceFileName = "$Env:TEMP\smsts.log"
	$destinationFileName = $MachineName + "_smsts_temp.log"
	$fileDescription = "Task Sequencer Log on Temp folder"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	
	$sourceFileName = "$Env:SystemDrive\_SMSTaskSequence\smsts.log"
	$destinationFileName = $MachineName + "_smsts_SMSTaskSequence.log"
	$fileDescription = "Task Sequencer Log on C:\_SMSTaskSequence"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	
	$sourceFileName = "$Env:SystemDrive\SMSTSLog\smsts.log"
	$destinationFileName = $MachineName + "_smsts_SMSTSLog.log"
	$fileDescription = "Task Sequencer Log on C:\SMSTSLog"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
	
	$sourceFileName = "$Env:systemdrive\minint\*"
	$destinationFileName = $MachineName + "_Minint_SystemDrive.zip"
	$fileDescription = "Deployment Logs on SystemDrive\Minint"
	CompressCollectFiles -fileDescription $fileDescription -DestinationFileName $destinationFileName -filesToCollect $sourceFileName -sectionDescription "Logs"

	if (test-path "$Env:SystemDrive\users\administrator\appdata\local\temp\smstslog\smsts.log") {
		$sourceFileName = "$Env:SystemDrive\users\administrator\appdata\local\temp\smstslog\smsts.log"
		$destinationFileName = $MachineName + "_smsts_Admin_temp.log"
		$fileDescription = "Task Sequencer Log on C:\SMSTSLog"
		CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
		}

}

$sourceFileName = "$LogPath\temp\deploymentlogs\*"
$destinationFileName = $MachineName + "_DeploymentLogs_Windows_Temp.zip"
$fileDescription = "Deployment Logs on \windows\temp"
Write-DiagProgress -Activity $DeploymentLogsStrings.ID_DeploymentLogsObtaining -Status $sourceFileName
CompressCollectFiles -fileDescription $fileDescription -DestinationFileName $destinationFileName -filesToCollect $sourceFileName -sectionDescription "deployment Logs"

if ((!$PathNotPresent) -or ($OSVersion.Major -lt 6))
{
	$sourceFileName = join-path $LogPath "SVCPack.Log"
	$destinationFileName = $MachineName + "_SVCPack.Log"
	$fileDescription = "Service Pack Installation Log"
	CopyDeploymentFile -sourceFileName $sourceFileName -destinationFileName $destinationFileName -fileDescription $fileDescription
}
