﻿trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

TraceOut "Started"
$sectionDescription = "System Information"

Import-LocalizedData -BindingVariable ScriptStrings

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_OSInfo

# Header for Client Summary File
$OSInfoFile = Join-Path $Pwd.Path ($ComputerName + "__OS_Summary.txt")
"=====================================" | Out-File $OSInfoFile
"Operating System Information Summary:" | Out-File $OSInfoFile -Append
"=====================================" | Out-File $OSInfoFile -Append

# PSObject to store Client information
$OSInfo = New-Object PSObject

TraceOut "    Getting OS information..."

# -------------
# Computer Name
# -------------
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Computer Name" -Value $ComputerName

# ----------------------
# OS information:
# ----------------------
$Temp = Get-WmiObject -Namespace root\cimv2 -Class Win32_OperatingSystem -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Operating System" -Value $Temp.Caption
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Service Pack" -Value $Temp.CSDVersion
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Version" -Value $Temp.Version
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Architecture" -Value $OSArchitecture
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Last Boot Up Time" -Value ($Temp.ConvertToDateTime($Temp.LastBootUpTime))
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Current Time" -Value ($Temp.ConvertToDateTime($Temp.LocalDateTime))
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Total Physical Memory" -Value  ([string]([math]::round($($Temp.TotalVisibleMemorySize/1MB), 2)) + " GB")
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Free Physical Memory" -Value  ([string]([math]::round($($Temp.FreePhysicalMemory/1MB), 2)) + " GB")
}
else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "OS Details" -Value "Error obtaining data from Win32_OperatingSystem WMI Class" }

# ----------------------
# Computer System Information:
# ----------------------
$Temp = Get-WmiObject -Namespace root\cimv2 -Class Win32_TimeZone -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Time Zone" -Value $Temp.Description }
else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Time Zone" -Value "Error obtaining value from Win32_TimeZone WMI Class" }

$Temp = Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Daylight In Effect" -Value $Temp.DaylightInEffect
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Domain" -Value $Temp.Domain
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Model" -Value $Temp.Model
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Number of Processors" -Value $Temp.NumberOfProcessors
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Number of Logical Processors" -Value $Temp.NumberOfLogicalProcessors
}
else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Computer System Details" -Value "Error obtaining value from Win32_ComputerSystem WMI Class" }

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_SysInfo

# --------------------------
# Get SystemInfo.exe output
# --------------------------
$TempFileName = $ComputerName + "_OS_SysInfo.txt"
$SysInfoFile = Join-Path $Pwd.Path $TempFileName
$CmdToRun = "cmd.exe /c SystemInfo.exe /S $ComputerName > $SysInfoFile"
RunCmd -commandToRun $CmdToRun -filesToCollect $SysInfoFile -fileDescription "SysInfo Output"  -sectionDescription $sectionDescription -BackgroundExecution -noFileExtensionsOnDescription
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "SysInfo Output" -Value "Review $TempFileName"

TraceOut "    Getting Processes and Services..."

# -----------------------
# Get Running Tasks List
# -----------------------
$TempFileName = $ComputerName + "_OS_TaskList.txt"
$TaskListFile = Join-Path $Pwd.Path $TempFileName
$CmdToRun = "cmd.exe /c TaskList.exe /v /FO TABLE /S $ComputerName > $TaskListFile"
RunCmd -commandToRun $CmdToRun -filesToCollect $TaskListFile -fileDescription "Running Tasks List"  -sectionDescription $sectionDescription -noFileExtensionsOnDescription
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Running Tasks List" -Value "Review $TempFileName"

# ----------------
# Services Status
#-----------------
$TempFileName = $ComputerName + "_OS_Services.txt"
$ServicesFile = Join-Path $Pwd.Path $TempFileName
$Temp = Get-WmiObject Win32_Service -ErrorVariable WMIError -ErrorAction SilentlyContinue  | Select DisplayName, Name, State, @{name="Log on As";expression={$_.StartName}}, StartMode | `
			Sort-Object DisplayName | `
			Format-Table -AutoSize
If ($WMIError.Count -eq 0) {
	$Temp | Out-File $ServicesFile -Width 1000
	CollectFiles -filesToCollect $ServicesFile -fileDescription "Services Status" -sectionDescription $sectionDescription -noFileExtensionsOnDescription
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Services Status" -Value "Review $TempFileName"
}
Else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Services Status" -Value "Error obtaining Services Status: $WMIError[0].Exception.Message"
	$WMIError.Clear()
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_MSInfo

# ------------------
# Get MSInfo output
# ------------------
$TempFileName = $ComputerName + "_OS_MSInfo.NFO"
$MSInfoFile = Join-Path $Pwd.Path $TempFileName
$CmdToRun = "cmd.exe /c start /wait MSInfo32.exe /nfo $MSInfoFile /computer $ComputerName"
RunCmd -commandToRun $CmdToRun -filesToCollect $MSInfoFile -fileDescription "MSInfo Output"  -sectionDescription $sectionDescription -BackgroundExecution
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "MSInfo Output" -Value "Review $TempFileName"

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_RSoP

# --------------------
# Get GPResult Output
# --------------------
TraceOut "    Getting GPResult..."
$CommandToExecute = "$Env:windir\system32\cmd.exe"

$OutputFileZ = $ComputerName + "_OS_GPResult.txt"
$Arg =  "/c $Env:windir\system32\gpresult.exe /Z > `"" + $PWD.Path + "\$OutputFileZ`""
Runcmd -fileDescription "GPResult /Z output" -commandToRun ($CommandToExecute + " " + $Arg) -filesToCollect $OutputFileZ -sectionDescription $sectionDescription -noFileExtensionsOnDescription
Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "GPResult /Z Output" -Value "Review $OutputFileZ"

If ($OSVersion.Major -ge 6) {
	$OutputFileH = $ComputerName + "_OS_GPResult.htm"
	$Arg =  "/c $Env:windir\system32\gpresult.exe /H `"" + $PWD.Path + "\$OutputFileH`" /F"
	Runcmd -fileDescription "GPResult /H output" -commandToRun ($CommandToExecute + " " + $Arg) -filesToCollect $OutputFileH -sectionDescription $sectionDescription -noFileExtensionsOnDescription
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "GPResult /H Output" -Value "Review $OutputFileH"
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status $ScriptStrings.ID_SCCM_GenericInfo_EnvVar

# ----------------------
# Environment Variables
# ----------------------
TraceOut "    Getting environment variables..."
$TempFileName = $ComputerName + "_OS_EnvironmentVariables.txt"
$OutputFile = join-path $pwd.path $TempFileName
"-----------------" | Out-File $OutputFile
"SYSTEM VARIABLES" | Out-File $OutputFile -Append
"-----------------" | Out-File $OutputFile -Append
 [environment]::GetEnvironmentVariables("Machine") | Out-File $OutputFile -Append -Width 250
"" | Out-File $OutputFile -Append
"-----------------" | Out-File $OutputFile -Append
"USER VARIABLES" | Out-File $OutputFile -Append
"-----------------" | Out-File $OutputFile -Append
 [environment]::GetEnvironmentVariables("User") | Out-File $OutputFile -Append -Width 250
 CollectFiles -filesToCollect $OutputFile -fileDescription "Environment Variables"  -sectionDescription $sectionDescription -noFileExtensionsOnDescription
 Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Environment Variables" -Value "Review $TempFileName"

# ----------------------
# Pending Reboot
# ----------------------
TraceOut "    Determining if reboot is pending..."
$TempFileName = $ComputerName + "_OS_RebootPending.txt"
$OutputFile = join-path $pwd.path $TempFileName
Get-PendingReboot -ComputerName $ComputerName | Out-File $OutputFile
CollectFiles -filesToCollect $OutputFile -fileDescription "Reboot Pending"  -sectionDescription $sectionDescription -noFileExtensionsOnDescription
Add-Member -InputObject $OSInfoFile -MemberType NoteProperty -Name "Reboot Pending" -Value "Review $TempFileName"

# ---------------------------------
# Get event logs
# ---------------------------------
TraceOut "    Getting Event Logs..."
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_GenericInfo -Status ($ScriptStrings.ID_SCCM_GenericInfo_EventLog)

$ZipName = $ComputerName + "_OS_EventLogs.zip"
$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_OS_EventLogs")
$fileDescription = "Event Logs"

If (Test-Path $Destination) {
	Remove-Item -Path $Destination -Recurse -Force
}
New-Item -ItemType "Directory" $Destination

# Copy files directly, it's much much faster this way. User can convert to TXT or CSV offline, as needed.
$TempLogPath = Join-Path $Env:windir "system32\winevt\logs"
Copy-Files -Source $TempLogPath -Destination $Destination -Filter Application.evtx
Copy-Files -Source $TempLogPath -Destination $Destination -Filter System.evtx
Copy-Files -Source $TempLogPath -Destination $Destination -Filter Security.evtx
Copy-Files -Source $TempLogPath -Destination $Destination -Filter Setup.evtx

compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription $fileDescription -Recursive -ForegroundProcess -noFileExtensionsOnDescription
Remove-Item -Path $Destination -Recurse -Force

# --------------------------------
# Get WMI Provider Configuration
# --------------------------------
TraceOut "    Getting WMI Configuration..."
$TempFileName = $ComputerName + "_OS_WMIProviderConfig.txt"
$OutputFile = join-path $pwd.path $TempFileName
$Temp1 = Get-WmiObject -Namespace root -Class __ProviderHostQuotaConfiguration -ErrorAction SilentlyContinue
If ($Temp1 -is [WMI]) {
	TraceOut "      Connected to __ProviderHostQuotaConfiguration..."
	"------------------------" | Out-File $OutputFile
	"WMI Quota Configuration " | Out-File $OutputFile -Append
	"------------------------" | Out-File $OutputFile -Append
	$Temp1 | Select MemoryPerHost, MemoryAllHosts, ThreadsPerHost, HandlesPerHost, ProcessLimitAllHosts | Out-File $OutputFile -Append
}

$Temp2 = Get-WmiObject -Namespace root\cimv2 -Class MSFT_Providers -ErrorAction SilentlyContinue
if (($Temp2 | Measure-Object).Count -gt 0) {
	TraceOut "      Connected to MSFT_Providers..."
	"------------------------" | Out-File $OutputFile -Append
	"WMI Providers " | Out-File $OutputFile -Append
	"------------------------`r`n" | Out-File $OutputFile -Append
	foreach($provider in $Temp2) {
		"Process ID $($provider.HostProcessIdentifier)" | Out-File $OutputFile -Append
		"  - Used by Provider $($provider.provider)" | Out-File $OutputFile -Append
		"  - Associated with Namespace $($provider.Namespace)" | Out-File $OutputFile -Append

		if (-not [string]::IsNullOrEmpty($provider.User)) {
			"  - By User $($provider.User)" | Out-File $OutputFile -Append
		}

		if (-not [string]::IsNullOrEmpty($provider.HostingGroup)) {
			"  - Under Hosting Group $($provider.HostingGroup)" | Out-File $OutputFile -Append
		}

		"" | Out-File $OutputFile -Append
	}
}

if ($Temp1 -is [wmi] -or $Temp2 -is [wmi]) {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "WMI Provider Config" -Value "Review $TempFileName"
	CollectFiles -filesToCollect $OutputFile -fileDescription "WMI Provider Config" -sectionDescription $sectiondescription -noFileExtensionsOnDescription }
else {
	Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "WMI Provider Config" -Value "Error obtaining data from WMI" }

# --------------------------------
# Collect Certificate Information
# --------------------------------
TraceOut "    Getting Certificates..."
$TempFileName = ($ComputerName + "_OS_Certificates.txt")
$OutputFile = join-path $pwd.path $TempFileName

"##############" | Out-File $OutputFile
"## COMPUTER ##" | Out-File $OutputFile -Append
"##############`r`n`r`n" | Out-File $OutputFile -Append

"MY" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\My | Out-File $OutputFile -Append

"SMS" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\SMS | Out-File $OutputFile -Append

"Trusted People" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\TrustedPeople | Out-File $OutputFile -Append

"Trusted Publishers" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\TrustedPublisher | Out-File $OutputFile -Append

"Trusted Root CA's" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\LocalMachine\Root | Out-File $OutputFile -Append

"##############" | Out-File $OutputFile -Append
"##   USER   ##" | Out-File $OutputFile -Append
"##############`r`n`r`n" | Out-File $OutputFile -Append

"MY" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\CurrentUser\My | Out-File $OutputFile -Append

"Trusted People" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\CurrentUser\TrustedPeople | Out-File $OutputFile -Append

"Trusted Publishers" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\CurrentUser\TrustedPublisher | Out-File $OutputFile -Append

"Trusted Root CA's" | Out-File $OutputFile -Append
"==================" | Out-File $OutputFile -Append
Get-CertInfo Cert:\CurrentUser\Root | Out-File $OutputFile -Append

Add-Member -InputObject $OSInfo -MemberType NoteProperty -Name "Certificates" -Value "Review $TempFileName"
CollectFiles -filesToCollect $OutputFile -fileDescription "Certificates" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ---------------------------
# Collect OS Information
# ---------------------------
$OSInfo | Out-File $OSInfoFile -Append -Width 500
CollectFiles -filesToCollect $OSInfoFile -fileDescription "OS Summary"  -sectionDescription $global:SummarySectionDescription -noFileExtensionsOnDescription

TraceOut "Completed"
# SIG # Begin signature block
# MIIa5QYJKoZIhvcNAQcCoIIa1jCCGtICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUS8nYRZIkgGQ7VNjaiXfS0M00
# PMOgghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTMMIIE
# yAIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHlMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBTh
# MLQeXZNPz0YftQrzqhS9SFZy8DCBhAYKKwYBBAGCNwIBDDF2MHSgWoBYAEQASQBB
# AEcAXwBDAFQAUwBfAFMAQwBDAE0AXwAyADAAMQAyAF8AZwBsAG8AYgBhAGwAXwBE
# AEMAXwBHAGUAbgBlAHIAaQBjAEkAbgBmAG8ALgBwAHMAMaEWgBRodHRwOi8vbWlj
# cm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQBbtBTyNP0Nu17kSrskc9S5ymUP
# pZDwLCNLlbME3orjs/lIFwlzE9zDYxXsnB5bMwZrdgOBXGz+X6l+2yweObAQV5lW
# MQdwatc9N+04K0786I0X97WmtPGHbrlFh5H2VAeVS53WXVxmd9lscXVvvDuCutK+
# D69idnmKUKRt4ITPJmBHStbL1SkdohgTrg+MFzEVTZ6PaWmVq1jbB51+zG9aXYFC
# sqzha+A0KID8sNRKw7XY7xugowo7Uim3aHWQ3wj9Pa1EJp2kYJ7n1uCpEVZC2Uq3
# nAUkIhW+PLB+FfZiKhPgkCbkoC5LqEyDjDWpMNEaZGZBRfu6GGSPx+0KB9Q6oYIC
# KDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQQITMwAAAMZ4gDYBdRppcgAAAAAAxjAJBgUrDgMCGgUAoF0wGAYJKoZI
# hvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcwNDI3MTQyMzI5
# WjAjBgkqhkiG9w0BCQQxFgQUbkFbGxLFNzhMGcHEWFMD39VasDUwDQYJKoZIhvcN
# AQEFBQAEggEALRhmyfw1cPpHGTU5YUBVeJF6HDBXBPxRo26s4V4yX2eMzxW+Pz48
# 0Jt53oYG/ItDfbehNLRpS303cM8Yz58iaF8cQHgyU6njou2vI7eCgz2XdlCEXVix
# bQrn7KAQm588k4MywbFAAvdbw9G4jzQGFM3YVZ1VBUMD3Cr0WeoHJIqMm5Ro99b0
# fKEE0+q6dFa5eoS3e+khnvvWFKI2HGgJrR4U1JxbZqqL2FpTSjNCo5jlJufsHiee
# FEs/7Q09CLksgzo+F4M2UXotHZJWRZGGVvjKkof8mSEqbfGZq0h77ge44u1GorMm
# koTBsNDoZUo5iFgdxPZ8xtlOaDD9yI/8JA==
# SIG # End signature block
