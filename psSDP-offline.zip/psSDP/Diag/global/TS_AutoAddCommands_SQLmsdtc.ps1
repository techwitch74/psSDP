# 2019-03-20 WalterE added Trap #_#

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
	}

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Collect Phase module: Common ---"
	# version of the psSDP Diagnostic
	Run-DiagExpression .\DC_NetworkingDiagnostic.ps1

	# Basic System Information
	Run-DiagExpression .\DC_BasicSystemInformation.ps1
	
	# MSInfo
	Run-DiagExpression .\DC_MSInfo.ps1
	
	# Obtain pstat output
	Run-DiagExpression .\DC_PStat.ps1
	
	# CheckSym - in Main
	#_#Run-DiagExpression .\DC_ChkSym.ps1

	# AutoRuns Information
	Run-DiagExpression .\DC_Autoruns.ps1

	# Collects System and Application Event Logs 
	Run-DiagExpression .\DC_SystemAppEventLogs.ps1
	
	# PoolMon
	Run-DiagExpression .\DC_PoolMon.ps1
	
	# Collect summary report 
	Run-DiagExpression .\DC_SummaryReliability.ps1

if ($Global:skipTS -ne $true) {
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object " --- $(Get-Date -Format 'HH:mm:ss') $Global:SDPtech - Diag Phase module: TS_SQL_msdtc ---"

	"[Running Action] : CollectRegistryDebugInformation" | WriteTo-Stdout
	Run-DiagExpression .\SQL_Debug_Registry.ps1
	
	"[Running Action] : CollectDRWatson" | WriteTo-Stdout
	Run-DiagExpression .\TS_DumpCollector.ps1 -CopyWERMinidumps -CopyMachineMiniDumps
	
	# Root Cause / Known Issue Detection ( Rules Implementations )
	  Run-DiagExpression .\TS_DCOMEnabled.ps1
	  Run-DiagExpression .\TS_NetworkDTCEnabled.ps1
}

Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "*** $(Get-Date -UFormat "%R:%S") DONE TS_AutoAddCommands_SQLsetup.ps1 SkipTS: $Global:skipTS - SkipBPA: $Global:skipBPA"