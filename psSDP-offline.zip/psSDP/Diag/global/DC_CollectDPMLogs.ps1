﻿#************************************************
# CollectDPMLogs.ps1
# Version 2.0.0
# Date: 09-27-2011
# Author: Patrick Lewis   - patlewis@microsoft.com
# Co-author: Wilson Souza - wsouza@microsoft.com
# Description: This script collects the .errlog and .Crash logs from the DPM\Temp directory
#************************************************
Import-LocalizedData -BindingVariable LocalsCollectDPMLogs -FileName DC_CollectDPMLogs -UICulture en-us

#Main

$DPMFolder= GetDPMInstallFolder # GetDPMInstallFolder is a function from Functions.ps1
If ($DPMFolder -ne $null)
{
	$DPMRAVersion = DPMRAVersion ($DPMFolder)
}
else 
{
	$LocalsCollectDPMLogs.ID_DPM_NotInstalled | WriteTo-StdOut -ShortFormat
}

if($DPMRAVersion -ne $null)
{
	Write-DiagProgress -Activity $LocalsCollectDPMLogs.ID_DPM_COLLECT_LOGS 
	if ($DPMRAVersion -ne 2)
	{
		$DPMFolderTemp = Join-Path $DPMFolder "temp\"
	}
	else
	{
		$DPMFolderTemp = $DPMFolder
	}
	$OutputBase= "$ComputerName$Prefix" + "_DPM_Error_Logs" + ".zip"	
	CompressCollectFilesForTimePeriod -filesToCollect ($DPMFolderTemp + "*.errlog") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 7
	
	$DPMFolderConfig = Join-Path $DPMFolder "config\"
	$OutputBase = "$ComputerName$Prefix" + "_DPM_config_xml"
	CompressCollectFilesForTimePeriod -filesToCollect ($DPMFolderConfig + "*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_CONFIG_FILES -Recursive -NumberOfDays 3650

	# Collecting DPMLogs folder (this folder contains DPM Setup log, rollup update logs)
	$OutputBase = "$ComputerName$Prefix" + "_DPM_Install_Logs" 
	$DPMInstallLogs = "empty"
	if ($DPMRAVersion -eq 4)
	{
		$DPMInstallLogs = ($DPMFolder | split-path -parent) + "\DPMLogs"
	}

	if ($DPMRAVersion -eq 2 -or $DPMRAVersion -eq 3)
	{
			$DPMInstallLogs = $env:SystemDrive + "\DPMLogs"
			if (!(test-path $DPMInstallLogs))
			{
				$DPMInstallLogs = $env:ALLUSERSPROFILE + "\DPMLogs"
			}
			
	}
	if (test-path $DPMInstallLogs)
	{
		CompressCollectFilesForTimePeriod -filesToCollect ($DPMInstallLogs + "\*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	else
	{
		$OutputBase += ".txt"
		"DPMLogs folder wasn't found on this system" | out-file $OutputBase
	}

	# Collecting DPM Agent installation files
	$OutputBase = "$ComputerName$Prefix" + "_DPM_Agent_Install_Logs" 
	$temp = $env:windir + "\Temp"
	if (test-path ($temp + '\MSDPM*'))
	{
		CompressCollectFilesForTimePeriod -filesToCollect ($Temp + "\MSDPM*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	else
	{
		$OutputBase += ".txt"
		"DPM Agent installation Logs weren't found on this system" | out-file $OutputBase
	}

	# Collect DPMUI logs from DPM 2010/2012 which resides on the user profile
	$MSDPMVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo(($DPMFolder + 'bin\msdpm.exe')).filemajorpart.ToString() + "." + [System.Diagnostics.FileVersionInfo]::GetVersionInfo(($DPMFolder + 'bin\msdpm.exe')).FileMinorPart.ToString()
	switch ($MSDPMVersion)
	{

		'3.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center Data Protection Manager 2010'
		       }

		'4.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 Data Protection Manager' 
		       }

		'4.1'  {
				    $ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 Service Pack 1 Data Protection Manager'
			   }

		'4.2'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2012 R2 Data Protection Manager'
		 	   }

		'5.0'  {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft System Center 2016 Technical Preview 4 Data Protection Manager'
		 	   }

		'11.0' {
					$ProfileRelativePath = '\AppData\Roaming\Microsoft\Microsoft Azure Backup'
			   }
	}

	$ProfileFolders = @(dir ((Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList").ProfilesDirectory) | ? { $_.Attributes -match 'Directory' -and ($_.pschildname -notmatch 'Public' -or $_.pschildname -notmatch 'Default')})

	foreach ($Profile in $Profilefolders)
	{
		$ProfileFullPath = $Profile.FullName + $ProfileRelativePath
		If ($ProfileFullPath)
		{
			$OutputBase = $ComputerName + "_DPM_UI_CLI_Settings_" + $Profile.basename + ".Logs" 
			CompressCollectFilesForTimePeriod -filesToCollect ($ProfileFullPath + "\*.errlog") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
		}
	}


	# Collect DPM Active Owner
	if ($DPMRAVersion -eq 3 -or $DPMRAVersion -eq 4)
	{
		$DPMActiveOwner = Join-Path $DPMFolder "ActiveOwner\"
		$OutputBase = $ComputerName + "_ActiveOwner" 
		CompressCollectFilesForTimePeriod -filesToCollect ($DPMActiveOwner + "\*.*") -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650	
	}
	
	# Collect Last queries executed against DPMDB
	if ((Test-Path "HKLM:SOFTWARE\Microsoft\Microsoft Data Protection Manager\DB") -eq $true)
	{		
		add-pssnapin sqlservercmdletsnapin100 -ErrorAction SilentlyContinue
		Push-Location; Import-Module SQLPS; Pop-Location
		$OutputBase = $ComputerName + "_Last_Updated_Tables" 
		$SQLServer   = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).SqlServer
		$SQLInstance = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).InstanceName
		$SQLDPMDB    = (get-itemproperty HKLM:\SOFTWARE\Microsoft\"Microsoft Data Protection Manager"\DB).DatabaseName
		$Query = "SELECT OBJECT_NAME(OBJECT_ID) AS DatabaseName, last_user_update
				  FROM sys.dm_db_index_usage_stats
		          WHERE database_id = DB_ID( '" + $SQLDPMDB + "')
		          ORDER BY last_user_update desc"
		invoke-sqlcmd -serverinstance ($SQLServer + "\"+ $SQLInstance) -query $Query -database $SQLDPMDB ! out-file $OutputBase 
		CompressCollectFilesForTimePeriod -filesToCollect $OutputBase -DestinationFileName ($OutputBase) -sectionDescription $LocalsCollectDPMLogs.ID_DPM_INFORMATION -fileDescription $LocalsCollectDPMLogs.ID_DPM_ErrorLogs_Files -Recursive -NumberOfDays 3650			
	}
}
		
	




# SIG # Begin signature block
# MIIjfAYJKoZIhvcNAQcCoIIjbTCCI2kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCD7v6fS+1YGg9qI
# /FgIaHS+JPWkCCfhH4+Yl96cdQ5CMaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVUTCCFU0CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgUKr8xEYg
# JmHk42iMOksRaUxoay17oSPWm2xgfLSMsKgwOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAG/RXKuKz7CcQAsmlhxoSk46UUFFvipQnYp0zBM5BAoJ4hh9teni65x4
# FYEZgTuZyn5DCdr/soYbv2WTCJakAUOQNLpTdVTUFvXvhzdPthdWZLVRG9M8BHZH
# cT3T4Lbm/A/agH2r65/G7Ml3NulV9PMs5QYG6xSxFUfRnlYPZmq1sMYp3bM5qzcV
# AcZ0zo5vPyijqSP5YSEBOmqvcUuRgZHeyXdWQ/4tx7koNAwVahyCIcB+krm99Kt2
# 71HtqO8xSpPRVyu8hyTRzNLufOz99EVbp9/iV6WLbfk8asX+yb433QANucbIGwqN
# 8DkeDFNHy3O4k0fOp1fUYMfHzmVgs7ShghLlMIIS4QYKKwYBBAGCNwMDATGCEtEw
# ghLNBgkqhkiG9w0BBwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYL
# KoZIhvcNAQkQAQSgggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQguRewUnMU4x8r69Bu5iDhPZWHEDB/DkrSPaGYMzZVrDYCBmCJ1nt4
# IhgTMjAyMTA1MTkyMjIzNTMuNDkxWjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046N0JGMS1F
# M0VBLUI4MDgxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# gg48MIIE8TCCA9mgAwIBAgITMwAAAVHDUOdZbKrGpwAAAAABUTANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMDExMTIxODI2
# MDRaFw0yMjAyMTExODI2MDRaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo3QkYxLUUzRUEtQjgwODElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ/Sh++qhK477ziJI1mx6bTJGA45hviRJs4Lsq/1cY2Y
# Gf4oPDJOO46kiT+UcR/7A8qoWLu4z0jvOrImYfLuwwV/S/CPgAfvHzz7w+LqCyg9
# tgaaBZeAfBcOSu0rom728Rje2nS9f81vrFl5Vb6Q4RDyCgyArxHTYxky4ZLX37Y3
# n4PZbpgTFASdhuP4OGndHQ70TZiojGV13vy5eEIP6D0s1wlBGKEkqmuQ/uTEYplX
# uf2Ey49I1a/IheOVdIU+1R/DiTuGCJnJ2Yaug8NRvsOgAkRnjxZjlqlvLRGdd0jJ
# jqria05MMsvM8jbVbbSQF+3YhS20dErzJWyWVitCh3cCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBTFd//jaFBikzRoOjjMhOnzdUTqbTAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQAr/fXAFYOZ8dEqo7y30M5roDI+XCfTROtHbkh9S6cR2IpvS7N1H4mH
# e7dCb8hMP60UxCh2851eixS5V/vpRyTBis2Zx7U3tjiOmRxZzYhYbYMlrmAya5uy
# kMpDYtRtS27lYnvTHoZqCvoQYmZ563H2UpwUqJK7ztkBFhwtcZ2ecDPNlBI6axWD
# pHIVPukXKAo45iBRn4EszY9TCG3+JXCeRaFdTIOhcBeOQoozlx1V685IrDGfabg6
# RY4xFekwGOiDYDJIS3r/wFaMNLBfDH0M7SSJRWHRRJGeTRfyMs6AtmG/YsOGwinQ
# a3Q9wLOpr6BkjYwgupTnc+hHqyStzYRYMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIC
# zjCCAjcCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjdCRjEtRTNFQS1CODA4MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQCg
# oq9z8T+kQgslTCUgFaDFetcjXqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5FADyzAiGA8yMDIxMDUyMDA1Mzgx
# OVoYDzIwMjEwNTIxMDUzODE5WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDkUAPL
# AgEAMAoCAQACAhkVAgH/MAcCAQACAhFVMAoCBQDkUVVLAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQEFBQADgYEAqk9uNflrwqOMR91pqaK5YS+20j2ZqAr343jcYYMTjaiV
# t9AL4BD4Hu2zpaj4oIYavwyQh2usAaRU8THj4ncLUxHGdYr1OG2f/VmcqcwJVr4i
# ysmAWBEo2miC/4rGquA3WPRddZCclbmpEHUnAMwhTHZv6WodDEMC9Op5c3uVjGIx
# ggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AVHDUOdZbKrGpwAAAAABUTANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCDWb4bta2yXl1rUCQ0XyfE6
# CWbGJao5A4l7rrHAN7CmxTCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIC7N
# XJmI+NbBWQcAphb7/UnD+bbrlIcbL/7dAfVxeuVBMIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFRw1DnWWyqxqcAAAAAAVEwIgQgXh3x
# EtLo7ZLQMxY+WmSph22uhPsBj8WTjk5JOpzZdUkwDQYJKoZIhvcNAQELBQAEggEA
# gLy5tEl/CEBu4GGju9f9ZPG9ZvD9GddFs/KzYVCW0prQpjLIJQxB7/yUNr6/uF8b
# xU2d1gEoNdhf7w5VayWlZG9Quvp/zdsqSxiQg1vbRPuEKRRD3OvWfRc7cUBNVBir
# 7ua6JMwAYbYcAyC2RiZyMJBwu1a3r7+Ihg6XTY7KLBsj4sHVE9bYlIs17y6GX2W0
# 2iATY5J6gv5Ire5GEGi1vzDNH7FYcHa2KDzYNvgVHvlMK90pVd1QclIFxqMv2CyK
# YaBqZVdFXQV6Eei7iamMlAkeJScA4f5lAxQSyMYYH0UFE8ZhpHRtwNQ6r1z83Dor
# n4kFvPcKEIfkYgLou5pYrg==
# SIG # End signature block
