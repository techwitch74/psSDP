﻿param([switch]$Full,[switch]$Force)
"Begin DC_ROIScan.ps1" | Trace -NoShortFormat

if((-not $Force) -and ($global:ROIScanHasBeenRun -ne $null))
{
	"DC_RoiScan has already run. Exiting DC_RoiScan" | WriteTo-StdOut
	return
}

if($null -eq $global:ROIScanHasBeenRun)
{
	$global:ROIScanHasBeenRun = New-Object psobject
	$global:ROIScanHasBeenRun | Add-Member -MemberType NoteProperty -Name "When Run" -Value ([DateTime]::Now)
}

Import-LocalizedData -BindingVariable ROIScanString   -FileName DC_ROIScan

Write-DiagProgress -Activity $ROIScanString.ID_ROIScan -Status $ROIScanString.ID_ROIScanObtaining

$OutputFile = $ComputerName + "_ROIScan.*"
#_# $CommandLineToExecute = "${Env:Windir}\system32\cscript.exe ROIScan.VBS //E:VBScript /quiet /logfolder '${Env:Temp}'"
$CommandLineToExecute = "${Env:Windir}\system32\cscript.exe ROIScan.VBS //E:VBScript /quiet /logfolder '${global:savePathTmp}'"

if($Full)
{
	$CommandLineToExecute += " /Full"
}
"Executing Command: $CommandLineToExecute" | Trace
"On thread $([System.Threading.Thread]::CurrentThread.ManagedThreadId.ToString())" | Trace
$PostProcCmd = {
	$roiscanXmlFileName = "$($Env:Temp)\$($ComputerName)_Roiscan.xml"
	if(Test-Path $roiscanXmlFileName)
	{
		Set-Variable -Scope Global -Name RoiScanXml -Value ([xml](Get-Content $roiscanXmlFileName))
	}


}
RunCmD -commandToRun $CommandLineToExecute -sectionDescription "Robust Office Inventory Scan" -filesToCollect "$Env:Temp\$OutputFile" -fileDescription "ROIScan Log" -BackgroundExecution  -PostProcessingScriptBlock $PostProcCmd
"End DC_ROIScan.ps1" | Trace -NoShortFormat
