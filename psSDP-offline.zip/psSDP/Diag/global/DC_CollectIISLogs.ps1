﻿# **********************************************************************************************************************************************************
# Version 1.0
# Date: 03/22/2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description: 
#		Base Script taken from DSI\Shared. Modified to exclude non-required logs to overcome some errors encountered if Advanced Logging is not installed.
# 		Collects IIS Logs for the last 5 days
#		Log Collection flags are pre-set in utils_ConfigMgr07.ps1
#		1. Collects IIS Logs.
#		2. Collects IIS Configuration by executing DC_IIS_Collect_Configuration.ps1 from DSI\Scripts\IIS\IIS_CORE
# **********************************************************************************************************************************************************

trap [Exception] 
{ 
	WriteTo-ErrorDebugReport -ErrorRecord $_ 
	continue 
}

TraceOut "Started"
Import-LocalizedData -BindingVariable IISStrings

If ($Is_IIS) {
	Set-Variable -Name sites -Value @()
	$NumOfDays = 5
	$sites += "Default Web Site"
	
	If ($Is_WSUS) {
		$siteID = Get-RegValue ($Reg_WSUS + "\Server\Setup") "IISTargetWebSiteIndex"
		If ($siteID -ne 1) {
			$sites += "WSUS Administration"
		}
	}	
	
	$DaysToCollect = 0 - $NumOfDays
	TraceOut "OS Build - $($OSVersion.Build)"
	TraceOut "Sites - $sites"
	
	
	if($OSVersion.Build -ge 6000)
	{
		# IIS 7.0 and Higher
		[System.Reflection.Assembly]::LoadFrom( "C:\windows\system32\inetsrv\Microsoft.Web.Administration.dll" )
		$serverManager = (New-Object Microsoft.Web.Administration.ServerManager)

		# Set Up Directory Structure
		$LogFiles = (Join-Path $PWD.Path "\Logs_IIS\LogFiles")
	    $FailedReqLogFiles = (Join-Path $PWD.Path "\Logs_IIS\FailedReqLogFiles")
		
		# Delete temporary directories if they already exist.
		If (Test-Path $LogFiles) {
			Remove-Item -Path $LogFiles -Recurse
		}
		
		If (Test-Path $FailedReqLogFiles) {
			Remove-Item -Path $FailedReqLogFiles -Recurse
		}
		
		New-Item $LogFiles -type Directory
		New-Item $FailedReqLogFiles -type Directory

		$sites | ForEach-Object `
		{
		
			# Write Progress
			Write-DiagProgress -Activity $IISStrings.ID_SCCM_ACTIVITY_CollectIISLogs -Status ($IISStrings.ID_SCCM_CollectIISLogs_IISLogs + ": " + $_)
			
			# Build Filename in this format  SITE_APP_VDIR_Web.config
			$currentSiteName = $_
			TraceOut "Site Found: $currentSiteName"
			$currentSite = $serverManager.Sites[$currentSiteName]
			$siteId = $currentSite.Id
			$path = $currentSite.ChildElements["logFile"].Attributes["directory"].value
			$LogFilePath = [environment]::ExpandEnvironmentVariables($path)
			$LogFilePath = Join-Path $LogFilePath ("W3SVC" + $siteId)
			TraceOut "LogPath: $LogFilePath"
			$path = $currentSite.ChildElements["traceFailedRequestsLogging"].Attributes["directory"].value
			$FREBPath = [environment]::ExpandEnvironmentVariables($path)
			$FREBPath = Join-Path $FREBPath ("W3SVC" + $siteId)
			TraceOut "FREB Log Path: $FREBPath"
			
			$dateStart = (Get-Date).AddDays($DaysToCollect)
			if(Test-Path $LogFilePath)
			{
				New-Item (Join-Path $LogFiles $currentSiteName) -type Directory
				
				Dir $LogFilePath | Where-Object {$_.lastwritetime -gt $dateStart} | ForEach-Object `
				{ 
					TraceOut "Copying Log: $_"
					Copy-Item $_.FullName (Join-Path $LogFiles $currentSiteName)
				}
			}
			
			# Failed Request Logging
			if(Test-Path $FREBPath)
			{
				New-Item (Join-Path $FailedReqLogFiles $currentSiteName) -type Directory
				Dir $FrebPath | Where-Object {$_.lastwritetime -gt $dateStart} | ForEach-Object `
				{ 
					TraceOut "Copying FREB Log: " + $_.FullName
					Copy-Item $_.FullName (Join-Path $FailedReqLogFiles $currentSiteName)
				}
			}
			
		}
	}
	else
	{
		# IIS 6.0
		
		# Set Up Directory Structure
		$LogFiles = (Join-Path $PWD.Path "\Logs_IIS\LogFiles")
		New-Item $LogFiles -type Directory

		$sites | ForEach-Object `
		{
			# Write Progress
			Write-DiagProgress -Activity $IISStrings.ID_SCCM_ACTIVITY_CollectIISLogs -Status ($IISStrings.ID_SCCM_CollectIISLogs_IISLogs + ": " + $_)
			
			$currentSiteName = $_
			TraceOut "Site Found: $currentSiteName"
			$siteQuery = "Select * From IIsWebServerSetting Where ServerComment = '{0}'" -f $currentSiteName
			Get-WMIObject -Namespace "root/MicrosoftIISv2" -Query $siteQuery | ForEach-Object `
			{
				$siteIdPath = $_.Name.Replace("/","")
				$path = $_.LogFileDirectory
				$LogFilePath = [environment]::ExpandEnvironmentVariables($path)
				$LogFilePath = Join-Path $LogFilePath $siteIdPath
				TraceOut "LogPath: $LogFilePath"

				$dateStart = (Get-Date).AddDays($DaysToCollect)
				if(Test-Path $LogFilePath)
				{
					New-Item (Join-Path $LogFiles $currentSiteName) -type Directory
					Dir $LogFilePath | Where-Object {$_.lastwritetime -gt $dateStart} | ForEach-Object `
					{ 
						TraceOut "Copying Log: $_"
						Copy-Item $_.FullName (Join-Path $LogFiles $currentSiteName)
					}
				}
			}
		}
	}

	CompressCollectFiles -filesToCollect (Join-Path $PWD.Path "Logs_IIS\*.*") -Recursive -fileDescription "IIS Logs" -DestinationFileName "Logs_IIS.zip" -sectionDescription "IIS Configuration" -noFileExtensionsOnDescription
	
	.\DC_IIS_Collect_Configuration.ps1 -sites $sites
}

TraceOut "Completed"
# SIG # Begin signature block
# MIIa6wYJKoZIhvcNAQcCoIIa3DCCGtgCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUlDmZYc6xpLbvCi4HfA+1unCh
# Ne6gghWDMIIEwzCCA6ugAwIBAgITMwAAAMhHIp2jDcrAWAAAAAAAyDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODU0
# WhcNMTgwOTA3MTc1ODU0WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# Ojk4RkQtQzYxRS1FNjQxMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAoUNNyknhIcQy
# V4oQO4+cu9wdeLc624e9W0bwCDnHpdxJqtEGkv7f+0kYpyYk8rpfCe+H2aCuA5F0
# XoFWLSkOsajE1n/MRVAH24slLYPyZ/XO7WgMGvbSROL97ewSRZIEkFm2dCB1DRDO
# ef7ZVw6DMhrl5h8s299eDxEyhxrY4i0vQZKKwDD38xlMXdhc2UJGA0GZ16ByJMGQ
# zBqsuRyvxAGrLNS5mjCpogEtJK5CCm7C6O84ZWSVN8Oe+w6/igKbq9vEJ8i8Q4Vo
# hAcQP0VpW+Yg3qmoGMCvb4DVRSQMeJsrezoY7bNJjpicVeo962vQyf09b3STF+cq
# pj6AXzGVVwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFA/hZf3YjcOWpijw0t+ejT2q
# fV7MMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJqUDyiyB97jA9U9vp7HOq8LzCIfYVtQfJi5PUzJrpwzv6B7
# aoTC+iCr8QdiMG7Gayd8eWrC0BxmKylTO/lSrPZ0/3EZf4bzVEaUfAtChk4Ojv7i
# KCPrI0RBgZ0+tQPYGTjiqduQo2u4xm0GbN9RKRiNNb1ICadJ1hkf2uzBPj7IVLth
# V5Fqfq9KmtjWDeqey2QBCAG9MxAqMo6Epe0IDbwVUbSG2PzM+rLSJ7s8p+/rxCbP
# GLixWlAtuY2qFn01/2fXtSaxhS4vNzpFhO/z/+m5fHm/j/88yzRvQfWptlQlSRdv
# wO72Vc+Nbvr29nNNw662GxDbHDuGN3S65rjPsAkwggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTSMIIE
# zgIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHrMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBRL
# 4Jqh3lc19NOLMuKuSJpfZTyAIjCBigYKKwYBBAGCNwIBDDF8MHqgYIBeAEQASQBB
# AEcAXwBDAFQAUwBfAFMAQwBDAE0AXwAyADAAMQAyAF8AZwBsAG8AYgBhAGwAXwBE
# AEMAXwBDAG8AbABsAGUAYwB0AEkASQBTAEwAbwBnAHMALgBwAHMAMaEWgBRodHRw
# Oi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQBzhNEADFo26twXQ8JT
# 5NkGRHjv21dT4dm7xdQWLeNB59mh0YIZ5FZqU/wR/DLfssIw30c1Mh0Bscfrwhi0
# +ukj/kltthQIqPxomVnkQ3TrYWSHvhO+cspIYtvkj10REO76do5v9HNJPRo3M1Ql
# rZDnkniIULeQcRl1BbEqWPACyAA8oIHHEAMTevbqEBvq1ehYvOzfUlMm2ztHtTOu
# Wa2RKv2ND0kduAQ+eUNG05PpnrOBKjLk/wSSfTFjC4jW2qFnJ+Gm8KkQ7gLx132f
# wvcvYBpV8ICLfu3GH7TqlTAtGdu1ItQ4TGEgG/nYgmAZK5pQOhkKNs+Ca3bcU7AW
# iEEVoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQQITMwAAAMhHIp2jDcrAWAAAAAAAyDAJBgUrDgMCGgUAoF0w
# GAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcwNDI3
# MTQyMzM0WjAjBgkqhkiG9w0BCQQxFgQUPC1yDwyamk3VWge8CPcVkNEOtikwDQYJ
# KoZIhvcNAQEFBQAEggEAhnC1fhRRS4pqyK5B/5r3TgqHu9yJ1AXdTsdfOUGBM+7d
# wCnRMbVn1xh8HzSjZHeE12qP/uDsqE5zPTvoWpzLCj9u+qABGhnIPRx5alUV/kJF
# 7jPRF1Jm6MHdewSIB8KU+p94LgmrD0elHN7TWnOFwFd8v+8A8G6yBX9/cgSBbhPZ
# ic/Pof8n3c2ZUUYSVVv/rNBXfJwdKfK6Dv/iZ2oRTqYhGnQw2K68pPcgwBih30zh
# oWpYDkteJNLv4SLCAFrkfgo6nu4mHGCVagirkKhXdR0f8FMOiTqQAzQ5cq1pZIve
# m/gzkAT8q11jtkOH01boUKYhZJ/b9KxMdDedsYMFdQ==
# SIG # End signature block
