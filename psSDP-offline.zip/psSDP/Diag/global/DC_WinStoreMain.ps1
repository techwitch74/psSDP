﻿#************************************************
# DC_WinStoreMain.ps1
# Version 1.0
# Date: 2009-2019
# Author: Walter Eder (waltere@microsoft.com)
# Description: Collects additional AppCompat information.
# Called from: TS_AutoAddCommands_Apps.ps1
# see  https://support.microsoft.com/en-gb/help/2777618/sdp-3-fb1bd57c-43b4-4236-973b-cb4fdbc0f3e8-windows-store-in-box-applic
#_# -> moved content to to TS_AutoAddCommands_Apps.ps1
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}

Write-verbose "$(Get-Date -UFormat "%R:%S") : Start of script DC_WinStoreMain.ps1"

"Starting DC_WinStoreMain.ps1 script" | WriteTo-StdOut
#Import-LocalizedData -BindingVariable ScriptVariable

#$zipLogsFiles = "$env:LOCALAPPDATA\Temp\WinStoreManifest"

#_# colllect all data - no ask for Basic|Advanced
"Getting MSInfo Files" | WriteTo-StdOut
				Run-DiagExpression .\DC_MSInfo.ps1
	Run-DiagExpression .\DC_WinStoreCollect.ps1
	Run-DiagExpression .\DC_WinUpdateCollect.ps1
	Run-DiagExpression .\DC_AppxCollect.ps1
	Run-DiagExpression .\DC_UEXCollect.ps1
	.\DC_NgenCollect.ps1
	Run-DiagExpression .\DC_COMCollect.ps1
	.\DC_SystemCollect.ps1

<#
$Results = Get-DiagInput -Id "WinStoreChoice"

If ($Results -eq "Basic")
  {

#	$ResultsBDialog1 = Get-DiagInput -Id "WinStore_BasicStartLogging"	#pauseinteraction

	#.\DC_WinStoreCollect.ps1
	#.\DC_WinUpdateCollect.ps1
	#.\DC_AppxCollect.ps1
	#.\DC_UEXCollect.ps1
	#.\DC_NgenCollect.ps1
	#.\DC_COMCollect.ps1
	.\DC_SystemCollect.ps1

  }

If ($Results -eq "Advanced")
  {
		$ResultsAdvD1 = Get-DiagInput -Id "WinStoreAdvD1"
			if($ResultsAdvD1 -eq "Opt1-MSInfo32")
			{
				# MS Info
				"Getting MSInfo Files" | WriteTo-StdOut
				Run-DiagExpression .\DC_MSInfo.ps1
			}
		
		 .\DC_WinStoreCollect.ps1
		 .\DC_WinUpdateCollect.ps1
		 .\DC_AppxCollect.ps1
		 .\DC_UEXCollect.ps1
		 .\DC_NgenCollect.ps1
		 .\DC_COMCollect.ps1
		 .\DC_SystemCollect.ps1
  }
#>

# The following is the framework for sdp dialog....
# for when we decide to add it later

Write-verbose "$(Get-Date -UFormat "%R:%S") :   end of script DC_WinStoreMain.ps1"
