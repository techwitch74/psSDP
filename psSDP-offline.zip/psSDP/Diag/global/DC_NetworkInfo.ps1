﻿# ***********************************************************************************************************************************
# Version 1.0
# Date: 03-25-2012, 2021
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects basic Networking Information.
#		Base script taken from SharedComponents\Scripts\NetworkBasicInfo.
#		1. Gets IP Details.
#		2. Gets Proxy Information
#		3. Gets Active BITS Jobs
#		4. Gets Enabled Firewall Rules
#		5. Gets TCP/IP Information
#		6. Gets SMB Information
#		7. Summarizes all data to a text file for better readability.
# ***********************************************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

Function RunCommand ([string]$cmdToRun="", [string]$OutputFile, [string]$FileDescription="", [string]$CollectFile=$false)
{
	"`r`n" + "-" * ($cmdToRun.Length + 2) + "`r`n[" + $cmdToRun + "]`r`n" + "-" * ($cmdToRun.Length + 2) + "`r`n" | Out-File -FilePath $OutputFile -Append
	$CommandLineToExecute = "cmd.exe /c $cmdToRun >> `"$OutputFile`""

	if ($CollectFile -ne $true)
	{
		$X = RunCmD -commandToRun $CommandLineToExecute -filesToCollect $OutputFile -CollectFiles $false
	} else {
		$x = RunCmD -commandToRun $CommandLineToExecute -sectionDescription $NetBasicInfoStrings.ID_NetBasicInfo -filesToCollect $OutputFile -fileDescription $FileDescription -noFileExtensionsOnDescription
	}
}

TraceOut "Started"

Import-LocalizedData -BindingVariable NetBasicInfoStrings
$sectiondescription = "Networking Information"
$NetInfoFile = Join-Path $Pwd.Path ($ComputerName + "__NET_Summary.txt")

# -----------
# IP Address
# -----------
"------------" | Out-File $NetInfoFile
"IP Details:" | Out-File $NetInfoFile -Append
"------------" | Out-File $NetInfoFile -Append
Get-WmiObject -namespace root\cimv2 -class Win32_NetworkAdapterConfiguration | Where { $_.IPAddress -ne $null } | `
	Select-Object DNSHostName,IpAddress,DefaultIPGateway,IPSubnet,MACAddress,DHCPEnabled -Unique | `
	Out-File $NetInfoFile -Append

# -----------------
# Proxy Information
# -----------------
$TempFileName = $ComputerName + "_OS_ProxyInfo.txt"
$ProxyFile = Join-Path $Pwd.Path $TempFileName
"-----------------------------------" | Out-File $NetInfoFile -Append
"Proxy Information (System and User)" | Out-File $NetInfoFile -Append
"-----------------------------------" | Out-File $NetInfoFile -Append
"    Review $TempFileName" | Out-File $NetInfoFile -Append

# System Proxy
"==========================" | Out-File $ProxyFile -Append
"Proxy Information (System)" | Out-File $ProxyFile -Append
"==========================" | Out-File $ProxyFile -Append
if ($OSVersion.Major -ge 6)
{
	RunCmD -commandToRun "psexec.exe /accepteula -s netsh winhttp show proxy >> $ProxyFile" -collectFiles $false
}
else
{
	RunCmD -commandToRun "psexec.exe /accepteula -s proxycfg >> $ProxyFile" -collectFiles $false
}

# User Proxy
"========================" | Out-File $ProxyFile -Append
"Proxy Information (User)" | Out-File $ProxyFile -Append
"========================" | Out-File $ProxyFile -Append
if ($OSVersion.Major -ge 6)
{
	RunCmd -commandToRun "netsh winhttp show proxy >> $ProxyFile" -collectFiles $false
}
else
{
	RunCmd -commandToRun "proxycfg >> $ProxyFile" -collectFiles $false
}

"=================================" | Out-File $ProxyFile -Append
"Proxy Information (Registry Keys)" | Out-File $ProxyFile -Append
"=================================" | Out-File $ProxyFile -Append
$ProxyRegKey = "HKLM\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
Export-RegKey -RegKey $ProxyRegKey -outFile $ProxyFile -collectFiles $false -Recurse $false -UpdateDiagReport $false

$ProxyRegKey = "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
Export-RegKey -RegKey $ProxyRegKey -outFile $ProxyFile -collectFiles $false -Recurse $false -UpdateDiagReport $false

$ProxyRegKey = "HKU\.DEFAULT\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
Export-RegKey -RegKey $ProxyRegKey -outFile $ProxyFile -collectFiles $false -Recurse $false -UpdateDiagReport $false

CollectFiles -filesToCollect $ProxyFile -fileDescription "Proxy Configuration" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $NetBasicInfoStrings.ID_SCCM_ACTIVITY_NetworkInfo -Status $NetBasicInfoStrings.ID_SCCM_NetworkInfo_BITS

# -------------------
# Get Bits Transfers
# -------------------
"" | Out-File $NetInfoFile -Append
"-----------------" | Out-File $NetInfoFile -Append
"Active BITS Jobs" | Out-File $NetInfoFile -Append
"-----------------" | Out-File $NetInfoFile -Append
$TempFileName = $ComputerName + "_OS_BITSTransfers.txt"
$BitsFile = Join-Path $Pwd.Path $TempFileName
$CmdToRun = "psexec.exe /accepteula -s bitsadmin.exe /RAWRETURN /list /allusers /verbose >> $BitsFile"
$RetVal = RunCmd -commandToRun $CmdToRun -collectFiles $false -useSystemDiagnosticsObject
If ($RetVal -eq 0) {
	If ((Get-Content $BitsFile) -ne $null) {
		# BitsAdmin.exe executed succesfully, and output file was not empty
		CollectFiles -filesToCollect $BitsFile -fileDescription "Active BITS Jobs" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
		"    Review $TempFileName" | Out-File $NetInfoFile -Append
	}
	Else {
		# BitsAdmin.exe executed succesfully, but output file was empty
		"    No Active Bits Jobs Found" | Out-File $NetInfoFile -Append
	}
}
Else {
	"    Failed to run bitsadmin command. Error $RetVal" | Out-File $NetInfoFile -Append
}

# ---------------
# Firewall Rules
# ---------------
"" | Out-File $NetInfoFile -Append
"-----------------------" | Out-File $NetInfoFile -Append
"Enabled Firewall Rules" | Out-File $NetInfoFile -Append
"-----------------------" | Out-File $NetInfoFile -Append
$TempFileName = $ComputerName + "_OS_EnabledFirewallRules.txt"
$fwFile = Join-Path $Pwd.Path $TempFileName
"===================================" | Out-File $fwFile -Append -Width 1000
$Temp = (Get-Service | Where {$_.DisplayName -match 'Windows Firewall'} | Select-Object Status)
"Firewall Service Status = " + $Temp.Status | Out-File $fwFile -Append -Width 1000
"===================================" | Out-File $fwFile -Append -Width 1000

If ($OSVersion.Major -ge 6) {
	trap [Exception]
	{
		"    ERROR: " + ($_.Exception.Message) | Out-File $NetInfoFile -Append
	}
	$fw = New-Object -ComObject hnetcfg.fwpolicy2 -ErrorAction SilentlyContinue -ErrorVariable FWError
	If ($FWError.Count -eq 0) {
		$fw.Rules | Where-Object {$_.Enabled} | Sort-Object Name | `
			Format-Table -Property Name,Direction,Protocol,LocalPorts,RemotePorts,LocalAddresses,RemoteAddresses,ServiceName,ApplicationName -AutoSize | `
			Out-File $fwFile -Append -Width 1000
		CollectFiles -filesToCollect $fwFile -fileDescription "Enabled Firewall Rules" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
		"    Review $TempFileName" | Out-File $NetInfoFile -Append
	}
}
Else {
	$CmdToRun = "netsh firewall show config >> " + $fwFile
	RunCmd -commandToRun $CmdToRun -filesToCollect $fwFile -fileDescription "Enabled Firewall Rules" -sectionDescription "Networking Information" -noFileExtensionsOnDescription
	"    Review $TempFileName" | Out-File $NetInfoFile -Append
}

# ---------------------------
# TCP/IP and SMB Information
# ---------------------------
$OutputFile = $ComputerName + "_OS_TCPIP-Info.txt"
"" | Out-File $NetInfoFile -Append
"-------------------" | Out-File $NetInfoFile -Append
"TCP/IP Information" | Out-File $NetInfoFile -Append
"-------------------" | Out-File $NetInfoFile -Append
"    Review $OutputFile" | Out-File $NetInfoFile -Append

RunCommand -cmdToRun "hostname" -OutputFile $OutputFile
RunCommand -cmdToRun "ipconfig /all" -OutputFile $OutputFile
RunCommand -cmdToRun "arp -a" -OutputFile $OutputFile
RunCommand -cmdToRun "nbtstat -n" -OutputFile $OutputFile
RunCommand -cmdToRun "netstat -ano" -OutputFile $OutputFile
RunCommand -cmdToRun "netstat -anob" -OutputFile $OutputFile
RunCommand -cmdToRun "reg.exe query HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters" -OutputFile $OutputFile
if ($OSVersion.Major -ge 6)
{
	RunCommand -cmdToRun "netsh int tcp show global" -OutputFile $OutputFile
	RunCommand -cmdToRun "netsh int ipv4 show offload" -OutputFile $OutputFile
	RunCommand -cmdToRun "netstat -nato -p tcp" -FileDescription "TCP/IP Information" -OutputFile $OutputFile -CollectFile $true
}
else
{
	RunCommand -cmdToRun "netstat -ano -p tcp" -FileDescription "TCP/IP Information" -OutputFile $OutputFile -CollectFile $true
}

$OutputFile = $ComputerName + "_OS_SMB-Info.txt"
"" | Out-File $NetInfoFile -Append
"----------------" | Out-File $NetInfoFile -Append
"SMB Information" | Out-File $NetInfoFile -Append
"----------------" | Out-File $NetInfoFile -Append
"    Review $OutputFile" | Out-File $NetInfoFile -Append

if ((Get-TSRemote) -lt 2)
{
	RunCommand -cmdToRun "net config workstation" -OutputFile $OutputFile
}

if ((Get-Service "lanmanserver").Status -eq 'Running')
{
	RunCommand -cmdToRun "net config server" -OutputFile $OutputFile
	RunCommand -cmdToRun "net share" -OutputFile $OutputFile
	RunCommand -cmdToRun "net statistics server" -OutputFile $OutputFile
}

RunCommand -cmdToRun "net sessions" -OutputFile $OutputFile
RunCommand -cmdToRun "net use" -OutputFile $OutputFile
RunCommand -cmdToRun "net accounts" -OutputFile $OutputFile
RunCommand -cmdToRun "net statistics workstation" -OutputFile $OutputFile -FileDescription "SMB Information" -CollectFile $true

# .\DC_NetBasicInfo.ps1

CollectFiles -filesToCollect $NetInfoFile -fileDescription "Network Information"  -sectionDescription $global:SummarySectionDescription -noFileExtensionsOnDescription

TraceOut "Completed"
