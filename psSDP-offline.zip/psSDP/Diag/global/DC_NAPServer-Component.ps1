﻿#************************************************
# DC_NAPServer-Component.ps1
# Version 1.0
# Date: 2009-2014
# Author: Boyd Benson (bbenson@microsoft.com)
# Description: Collects information about the NAP Server.
# Called from: Main Networking Diag
#*******************************************************

Trap [Exception]
	{
	 # Handle exception and throw it to the stdout log file. Then continue with function and script.
		 $Script:ExceptionMessage = $_
		 "[info]: Exception occurred."  | WriteTo-StdOut
		 "[info]: Exception.Message $ExceptionMessage."  | WriteTo-StdOut 
		 $Error.Clear()
		 continue
		 # later use return to return the exception message to an object:   return $Script:ExceptionMessage
	}


Import-LocalizedData -BindingVariable ScriptVariable
Write-DiagProgress -Activity $ScriptVariable.ID_CTSNAPServer -Status $ScriptVariable.ID_CTSNAPServerDescription


#----------Check if DNS Server is installed, and then run the script
$SvcKey = "HKLM:\SOFTWARE\Microsoft\NapServer"
if (Test-Path $SvcKey) 
{
	#----------Registry
	$OutputFile= $Computername + "_NapServer_reg_.TXT"
	$sectionDescription = "NAP Server"
	$CurrentVersionKeys = "HKLM\SOFTWARE\Microsoft\NapServer"
	RegQuery -Registrykeys $CurrentVersionKeys -Recursive $true -OutputFile $OutputFile -fileDescription "NAP Server Registry Keys" -SectionDescription $sectionDescription

	#----------MSSHAV-SHV EventLog
	$EventLogNames = "Microsoft-Windows-MSSHAV-SHV/Operational"
	$Prefix = ""
	$Suffix = "_evt_"
	.\TS_GetEvents.ps1 -EventLogNames $EventLogNames -SectionDescription $sectionDescription -Prefix $Prefix -Suffix $Suffix
}
