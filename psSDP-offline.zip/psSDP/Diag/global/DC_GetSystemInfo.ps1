﻿#************************************************
# DC_GetSystemInfo.ps1
# Version 2.0.0
# Date: 09-27-2011
# Author: Patrick Lewis - patlewis@microsoft.com
# Description: This script gathers info on filter drivers installed
#************************************************
#TODO:  Get VSSADMIN List Writers and also Mountvol output
#VSSADMIN LIST PROVIDERS
# Use same textfile for above except for mountvol in separate folder

Import-LocalizedData -BindingVariable LocalizedGetFilterInfo -FileName DC_GetSystemInfo -UICulture en-us

Write-DiagProgress -Activity $LocalizedGetFilterInfo.ID_DPM_GETSYSINFO_ACTIVITY -Status $LocalizedGetFilterInfo.ID_DPM_STATUS_GETSYSINFO

#Gathering filter driver info
$OutputBase= "$ComputerName$Prefix" +  "_Filter_Drivers.txt"
"------------------------------------------------------------------" | Out-File $OutputBase
"Filters drivers installed" | Out-File $OutputBase -append
"------------------------------------------------------------------" | Out-File $OutputBase  -append
fltmc filters | Out-File $OutputBase -append
"" | Out-File $OutputBase -append
"" | Out-File $OutputBase -append
"------------------------------------------------------------------" | Out-File $OutputBase  -append
"Volumes using filter drivers:" | Out-File $OutputBase -append
"------------------------------------------------------------------" | Out-File $OutputBase  -append
"" | Out-File $OutputBase -append
fltmc instances | Out-File $OutputBase -append
CollectFiles -filesToCollect $OutputBase -fileDescription "Filter drivers"  -sectionDescription "System Information"

#Gathering VSS info 
$OutputBase = "$ComputerName$Prefix" + "_VSS_Info.txt"
"------------------------------------------------------------------" | Out-File $OutputBase
"VSS Providers" | Out-File $OutputBase -append
"------------------------------------------------------------------" | Out-File $OutputBase  -append
VSSADMIN LIST PROVIDERS | Out-File $OutputBase -Append
"" | Out-File $OutputBase -append
"" | Out-File $OutputBase -append
"------------------------------------------------------------------" | Out-File $OutputBase -Append
"VSS List Writers output" | Out-File $OutputBase -append
"------------------------------------------------------------------" | Out-File $OutputBase  -Append
VSSADMIN LIST WRITERS | Out-File $OutputBase -Append
"" | Out-File $OutputBase -append
"" | Out-File $OutputBase -append
"------------------------------------------------------------------" | Out-File $OutputBase -Append
"VShadow/DiskShadow Metadata Writers output" | Out-File $OutputBase -append
"------------------------------------------------------------------" | Out-File $OutputBase  -Append
if ((Get-WmiObject Win32_OperatingSystem -comp $ComputerName).Version -like '5.2*')
{	
	.\vshadow.exe -wm2 | Out-File $OutputBase -append
}
else
{
	"list writers" | out-file "script.txt" -encoding ASCII
	diskshadow.exe /s script.txt | Out-File $OutputBase -append
	remove-item script.txt -Confirm:$false
}
CollectFiles -filesToCollect $OutputBase -fileDescription "VSS Info"  -sectionDescription "System Information"

#Gathering USN info 
$OutputBase = "$ComputerName$Prefix" + "_USN_Info.txt"
$drive = @(mountvol | Select-String ":\\")
foreach ($driveUSN in $drive)
{
	"------------------------------------------------------------------" | Out-File $OutputBase -Append
	$DriveUSN = $DriveUSN.ToString()
	$DriveUSN = $driveUSN.Substring(8,$driveUSN.Length -9)
	$DriveUSN | Out-File $OutputBase -Append
	$DriveUSN = 'fsutil.exe usn queryjournal "' + $DriveUSN + '"'
	$DriveUSN
	"" | Out-File $OutputBase -append
	invoke-expression $DriveUSN  |out-file $OutputBase -Append
}
CollectFiles -filesToCollect $OutputBase -fileDescription "USN Journal Info"  -sectionDescription "System Information"

# Grab output from MSINFO32 (NFO format).
$msinfo32 = $env:programfiles + "\Common Files\Microsoft Shared\MSInfo\msinfo32.exe"
$OutputBase = "$ComputerName$Prefix" + "_MSINFO32.nfo"
&$msinfo32 /nfo $OutputBase | out-null
CollectFiles -filesToCollect $OutputBase -fileDescription "MSInfo"  -sectionDescription "System Information"

# Grab pfirewall.log if Windows Firewall is enabled (Windows 2008/2008R2)
$OutputBase = "$ComputerName$Prefix" + "_pfirewall.log"
if ((Get-WmiObject Win32_OperatingSystem -comp $ComputerName).Version -notlike '5.2*')
{
	if ((get-service -name MpsSvc).status -eq 'Running')
	{
		if (test-path ($env:windir + "\system32\logfiles\firewall\pfirewall.log"))
		{
			if ((gci ($env:windir + "\system32\logfiles\firewall\pfirewall.log")).length -ne 0 )
			{
				copy-item  ($env:windir + "\system32\logfiles\firewall\pfirewall.log")
				rename-item pfirewall.log $OutputBase 
			}
			else
			{
				"pfirewall.log file exists but it has 0 bytes in size" | Out-File $OutputBase
			}
		}
		else
		{
			"Windows Firewall service is running but pfirewall.log file doesn't exist" | Out-File $OutputBase
		}
	}
	else
	{
		"Firewall Service not running" | Out-File $OutputBase
	}
}
else
{
	"pFirewall log is not collected on Windows 2003 systems" | Out-File $OutputBase
}
CollectFiles -filesToCollect $OutputBase -fileDescription "Windows Firewall"  -sectionDescription "System Information"


#Running VSSPSS
$OutputBase = "$ComputerName$Prefix" + "_VSSPSS_Info.txt"
cscript.exe VSSPSS.vbs  | Out-File $OutputBase
CollectFiles -filesToCollect $OutputBase -fileDescription "VSSPSS Info"  -sectionDescription "System Information"

# Grab registry keys for OLE and RPC
$OutputBase= "$ComputerName$Prefix" +  "_Registry_OLE.txt"
RegQuery -RegistryKeys "HKLM\Software\Microsoft\Ole" -OutputFile $OutputBase -fileDescription "Registry OLE keys" -sectionDescription "System Information" -Recursive $true

$OutputBase= "$ComputerName$Prefix" +  "_Registry_RPC.txt"
RegQuery -RegistryKeys "HKLM\Software\Microsoft\RPC" -OutputFile $OutputBase -fileDescription "Registry RPC keys" -sectionDescription "System Information" -Recursive $true

# Grab registry keys for DPM
$OutputBase= "$ComputerName$Prefix" +  "_Registry_DPM.txt"
RegQuery -RegistryKeys "HKLM\Software\Microsoft\Microsoft Data Protection Manager" -OutputFile $OutputBase -fileDescription "Registry DPM keys" -sectionDescription "System Information" -Recursive $true

# Grab registry keys for Microsoft Azure Recovery Services Agent
$OutputBase= "$ComputerName$Prefix" +  "_CBENGINE_Registry.txt"
RegQuery -RegistryKeys "HKLM\Software\Microsoft\Windows Azure Backup" -OutputFile $OutputBase -fileDescription "Registry Windows Azure Backup keys" -sectionDescription "System Information" -Recursive $true
          
# Query signed and unsigned drivers using : driverquery /si /FO TABLE
$OutputBase= "$ComputerName$Prefix" +  "_DriverQuery.txt"
$CommandToRun = "cmd.exe /c driverquery /si /FO TABLE >> " + $OutputBase
RunCMD -commandToRun $CommandToRun -filesToCollect $OutputBase -fileDescription "Driverquery Output" -sectionDescription "System Information" 

# Grab installed applications on local computer
$OutputBase= "$ComputerName$Prefix" +  "_Installed_Programs.txt"
Get-WmiObject -Class Win32_Product | sort-object name | ft Name, Vendor, Version -AutoSize | Out-File $OutputBase
CollectFiles -filesToCollect $OutputBase -fileDescription "Installed Applications"  -sectionDescription "System Information"

# Grab installed hotfiex on local computer
$OutputBase= "$ComputerName$Prefix" +  "_Installed_hotfixes.txt"
get-hotfix | Sort-Object installedon -Descending | Out-File $OutputBase
CollectFiles -filesToCollect $OutputBase -fileDescription "Installed Hotfixes"  -sectionDescription "System Information"
# SIG # Begin signature block
# MIIa6wYJKoZIhvcNAQcCoIIa3DCCGtgCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU1d6RB/0a4Ouuxd0EvgsU3q1f
# 5aigghWDMIIEwzCCA6ugAwIBAgITMwAAAK7sP622i7kt0gAAAAAArjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwNTAzMTcxMzI1
# WhcNMTcwODAzMTcxMzI1WjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkI4RUMtMzBBNC03MTQ0MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAxTU0qRx3sqZg
# 8GN4YCrqA1CzmYPp8+U/MG7axHXPZGdMvNbRSPl29ba88jCYRut/6p5OjvCGNcRI
# MPWKFMqKVeY8zUoQNp46jYsXenl4vTAgJ2cUCeaGy9vxLYTGuXtaChn+jIpPuR6x
# UQ60Y44M2jypsbcQZYc6Oukw4co+CIw8fKqxPcDjdm1c/gyzVnhSYTXsv8S0NBwl
# iuhNCNE4D8b0LNj7Exj5zfVYGvP6Z+JtGY7LT+7caUCT0uItKlE0D/iDvlY5zLrb
# luUb4WLUBpglMw7bU0BSAcvcNx0XyV7+AdcmhiFQGt4pZjbVzOsXs3POWHTq4/KX
# RmtGHKfvMwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFBw4ctJakrpBibpB9TJkYJsJ
# gGBUMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAAAZsVbJVNFZUNMcXRxKeelc1DgiQHLC60Sika98OwDFXomY
# akk6yvE+fJ3DICnDUK9kmf83sYTOQ5Y7h3QzwHcPdyhLPHSBBmuPklj6jcWGuvHK
# pUuP9PTjyKBw0CPZ1PTO1Jc5RjsQYvxqu01+G5UvZolnM6Ww7QpmBoDEyze5J+dg
# GwrWMhIKDzKLV9do6R5ouZQvLvV7bjH50AX2tK2n3zpZYvAl/LayLHFNIO7A2DQ1
# VzWa3n2yyYvameaX1NkSLA32PqjAXykmkDfHQ6DFVuDV4nqrNI+s14EJgMQy8DzU
# 9X7+KIkCzLFNq/bc2WDo15qsQiACPVSKY1IOGiIwggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTSMIIE
# zgIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHrMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBQw
# xKE8yScGJb2qrS4Sllk0a4f9oDCBigYKKwYBBAGCNwIBDDF8MHqgYIBeAFMAeQBz
# AHQAZQBtAEMAZQBuAHQAZQByAEQAUABNAF8ATQBBAEIAXwBnAGwAbwBiAGEAbABf
# AEQAQwBfAEcAZQB0AFMAeQBzAHQAZQBtAEkAbgBmAG8ALgBwAHMAMaEWgBRodHRw
# Oi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQDMEFvFskptCc6BpFew
# jA/tK+g4XVsuM8/0iLe1kUr89Kb2WWfJW1gZBboNMKUDt3BRDDUN6rTQAV/daZ3M
# Vq2MzmfPYNDSLh/w4uuJfg7SZYN1rAuRSYmXrGfaKUlyixRnGxf2eFxzuPhBsPA/
# VK0aI3P2FDwLC8kvI9uOMI/9kySmFQV/BDR6eruu03QNx1rtvVPBjIQIGQk8y5EL
# +379DIwm1mTrnN3XX9oeMnqf1ZNrQgss5TCyyQ96bAZ8xHOa9bOdL1Shg2BR0Avk
# mq4MsRiYRW8VUjzOlBfIkt6PXm10BpPmwWYC99jj8h4CVmrHrG0GbKIeDkOvlbxA
# YwjeoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQQITMwAAAK7sP622i7kt0gAAAAAArjAJBgUrDgMCGgUAoF0w
# GAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTYwODMw
# MjEzMTUwWjAjBgkqhkiG9w0BCQQxFgQUCdHTQWmbHTw5MnWF9Aeg/9PFo0UwDQYJ
# KoZIhvcNAQEFBQAEggEAGMetySC/RJkWDIonLSkxgRW6bHvdolTO5u0MCDfLn6q6
# M7JcmJ8BjYrHGFS7M90kxjiRa30CgwY9cC1PruAXs4m4MtDI1IGXj0kXVSBO9hKQ
# 1omQACeX2vV6tjxqhoZe9ZwtfjPShpqMMxkfiJuADnJZEyDi5OKd69C61Enw2Tmx
# uRli+Ow2kenqrYXMPNxR7o1iqbnCzwosJwqgUYH22Pe2tmqAWEKcUyt+Z2fMxNas
# GeDcgsdnNKggzseOhcO8yGuQLLshBszi6rsOpuZwH9/dKWvHoBdpFdpKCt0cMkcw
# tjo+9emyC8E3u9rMP5SOHrnqpLwKP1xU0s1kyTo71Q==
# SIG # End signature block
