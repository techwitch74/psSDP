# *********************************************************************************************************************
# Version 1.0
# Date: 02-29-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects Configuration Manager Client Information
#		1. Gets CCMExec service Status, Start time, Install Directory, Assigned Site, MP, Client Version and GUID.
# 		2. Gets Software Distribution Execution History.
#		3. Gets Cache Size, Location and Elements.
#		4. Gets Inventory Timestamps
#		5. Gets Update Installation Status
#		6. Gets State Message Data
#		7. Gets File Versions from Client Install Directory
#		8. Summarizes all data in a PSObject, then dumps to a text file for better readability.
# *********************************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

If (!$Is_Client) {
	TraceOut "ConfigMgr Client not detected. This script gathers data only from a Client. Exiting."
	exit 0
}

function Get-WmiOutput {
	Param(
		[Parameter(Mandatory=$true)]
	    [string]$Namespace,
		[Parameter(Mandatory=$false)]
	    [string]$ClassName,
		[Parameter(Mandatory=$false)]
	    [string]$Query,
		[Parameter(Mandatory=$false)]
	    [string]$DisplayName,
		[Parameter(Mandatory=$false)]
		[switch]$FormatList,
		[Parameter(Mandatory=$false)]
		[switch]$FormatTable
	)

	if ($DisplayName) {
		$DisplayText = $DisplayName
	}
	else {
		$DisplayText = $ClassName
	}

	$results =  "`r`n=================================`r`n"
	$results += " $DisplayText `r`n"
	$results += "=================================`r`n`r`n"

	if ($ClassName) {
		$Temp = Get-WmiData -Namespace $Namespace -ClassName $ClassName
	}

	if ($Query) {
		$Temp = Get-WmiData -Namespace $Namespace -Query $Query
	}

	if ($Temp) {
		if ($FormatList) {
			$results += ($Temp | Format-List | Out-String -Width 500).Trim()
		}

		if ($FormatTable) {
			$results += ($Temp | Format-Table -AutoSize | Out-String -Width 500).Trim()
		}

		$results += "`r`n"
	}
	else {
		$results += "    No Instances.`r`n"
	}

	return $results
}

function Get-WmiData{
	Param(
		[Parameter(Mandatory=$true)]
	    [string]$Namespace,
	    [Parameter(Mandatory=$false)]
	    [string]$ClassName,
		[Parameter(Mandatory=$false)]
	    [string]$Query
	)

	if ($ClassName) {
		$Temp = Get-CimInstance -Namespace $Namespace -Class $ClassName -ErrorVariable WMIError -ErrorAction SilentlyContinue
	}

	if ($Query) {
		$Temp = Get-CimInstance -Namespace $Namespace -Query $Query -ErrorVariable WMIError -ErrorAction SilentlyContinue
	}

	if ($WMIError.Count -ne 0) {
		if ($WMIError[0].Exception.Message -eq "") {
			$results = $WMIError[0].Exception.ToString()
		}
		else {
			$results = $WMIError[0].Exception.Message
		}
		$WMIError.Clear()
		return $results
	}

	if (($Temp | Measure-Object).Count -gt 0) {
		$results = $Temp | Select * -ExcludeProperty __GENUS, __CLASS, __SUPERCLASS, __DYNASTY, __RELPATH, __PROPERTY_COUNT, __DERIVATION, __SERVER, __NAMESPACE, __PATH, PSComputerName, Scope, Path, Options, ClassPath, Properties, SystemProperties, Qualifiers, Site, Container
	}
	else {
		$results = $null
	}

	return $results
}

TraceOut "Started"

Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "Configuration Manager Client Information"

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_ClientInfo

TraceOut "    Getting Client Information"

# ----------------------
# Current Time:
# ----------------------
AddTo-CMClientSummary -Name "Current Time" -Value $CurrentTime

# -------------
# Computer Name
# -------------
AddTo-CMClientSummary -Name "Client Name" -Value $ComputerName

# ------------------
# Assigned Site Code
# ------------------
$Temp = Get-RegValue ($Reg_SMS + "\Mobile Client") "AssignedSiteCode"
If ($Temp -ne $null) {
	AddTo-CMClientSummary -Name "Assigned Site Code" -Value $Temp}
else {
	AddTo-CMClientSummary -Name "Assigned Site Code" -Value "Error obtaining value from Registry"}

# ------------------------
# Current Management Point
# ------------------------
$Temp = Get-CimInstance -Namespace root\CCM -Class SMS_Authority -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	AddTo-CMClientSummary -Name "Current MP" -Value $Temp.CurrentManagementPoint }
else {
	AddTo-CMClientSummary -Name "Current MP" -Value "Error obtaining value from SMS_Authority WMI Class" }

# --------------
# Client Version
# --------------
$Temp = Get-CimInstance -Namespace root\CCM -Class SMS_Client -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	AddTo-CMClientSummary -Name "Client Version" -Value $Temp.ClientVersion }
else {
	AddTo-CMClientSummary -Name "Client Version" -Value "Error obtaining value from SMS_Client WMI Class" }

# ----------------------------------------------------------
# Installation Directory - defined in utils_ConfigMgr07.ps1
# ----------------------------------------------------------
If ($CCMInstallDir -ne $null) {
	AddTo-CMClientSummary -Name "Installation Directory" -Value $CCMInstallDir }
else {
	AddTo-CMClientSummary -Name "Installation Directory" -Value "Error obtaining value" }

# ------------
# Client GUID
# ------------
$Temp = Get-CimInstance -Namespace root\CCM -Class CCM_Client -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	AddTo-CMClientSummary -Name "Client ID" -Value $Temp.ClientId
	AddTo-CMClientSummary -Name "Previous Client ID (if any)" -Value $Temp.PreviousClientId
	AddTo-CMClientSummary -Name "Client ID Change Date" -Value $Temp.ClientIdChangeDate }
else {
	AddTo-CMClientSummary -Name "Client ID Information" -Value "Error Obtaining value from CCM_Client WMI Class" }

# -----------------------
# CCMExec Service Status
# -----------------------
$Temp = Get-Service | Where-Object {$_.Name -eq 'CCMExec'} | Select-Object Status
If ($Temp -ne $null) {
	if ($Temp.Status -eq 'Running') {
		$Temp2 = Get-Process | Where-Object {$_.ProcessName -eq 'CCMExec'} | Select-Object StartTime
		AddTo-CMClientSummary -Name "CCMExec Status" -Value "Running. StartTime = $($Temp2.StartTime)"
	}
	else {
		AddTo-CMClientSummary -Name "CCMExec Status" -Value $Temp.Status
	}
}
Else {
	AddTo-CMClientSummary -Name "CCMExec Service Status" -Value "ERROR: Service Not found"
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_History

TraceOut "    Getting Software Distribution and Application Execution History"

# -----------------------------------------------------
# Software Distribution Execution History from Registry
# -----------------------------------------------------
$Temp = ($Reg_SMS -replace "HKLM\\", "HKLM:\") + "\Mobile Client\Software Distribution\Execution History"
If (Check-RegKeyExists $Temp) {
	$TempFileName = ($ComputerName + "_CMClient_ExecutionHistory.txt")
	$ExecHistory = Join-Path $Pwd.Path $TempFileName
	Get-ChildItem $Temp -Recurse `
	| ForEach-Object {Get-ItemProperty $_.PSPath} `
	| Select @{name="Path";exp={$_.PSPath.Substring($_.PSPath.LastIndexOf("History\") + 8)}}, _ProgramID, _State, _RunStartTime, SuccessOrFailureCode, SuccessOrFailureReason `
	| Out-File $ExecHistory -Append -Width 500
	AddTo-CMClientSummary -Name "ExecMgr History" -Value ("Review $TempFileName") -NoToSummaryReport
	CollectFiles -filesToCollect $ExecHistory -fileDescription "ExecMgr History"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
}
else {
	AddTo-CMClientSummary -Name "ExecMgr History" -Value "Execution History not found" -NoToSummaryReport
}

# -----------------------------------------------------
# Application Enforce Status from WMI
# -----------------------------------------------------
$Temp = Get-CimInstance -Namespace root\CCM\CIModels -Class CCM_AppEnforceStatus -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$TempFileName = ($ComputerName + "_CMClient_AppHistory.txt")
		$AppHist = Join-Path $Pwd.Path $TempFileName
		$Temp | Select-Object AppDeliveryTypeId, ExecutionStatus, ExitCode, Revision, ReconnectData `
		| Out-File $AppHist -Append -Width 250
		AddTo-CMClientSummary -Name "App Execution History" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $AppHist -fileDescription "Application History"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	else {
		AddTo-CMClientSummary -Name "App Execution History" -Value ("Error obtaining data or no data in WMI") -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "App Execution History" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

# -----------------
# Cache Information
# -----------------
$Temp = Get-CimInstance -Namespace root\ccm\softmgmtagent -Class CacheConfig -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$TempFileName = ($ComputerName + "_CMClient_CacheInfo.txt")
		$CacheInfo = Join-Path $Pwd.Path $TempFileName
		"Cache Config:" | Out-File $CacheInfo
		"==================" | Out-File $CacheInfo -Append
		$Temp | Select-Object Location, Size, NextAvailableId | Format-List * | Out-File $CacheInfo -Append -Width 500
		"Cache Elements:" | Out-File $CacheInfo -Append
		"===============" | Out-File $CacheInfo -Append
		$Temp = Get-CimInstance -Namespace root\ccm\softmgmtagent -Class CacheInfoEx -ErrorAction SilentlyContinue
		$Temp | Select-Object Location, ContentId, CacheID, ContentVer, ContentSize, LastReferenced, PeerCaching, ContentType, ReferenceCount, PersistInCache `
			| Sort-Object -Property Location | Format-Table -AutoSize | Out-File $CacheInfo -Append -Width 500
		AddTo-CMClientSummary -Name "Cache Information" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $CacheInfo -fileDescription "Cache Information"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	Else {
		AddTo-CMClientSummary -Name "Cache Information" -Value "No data found in WMI." -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "Cache Information" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

# -----------------------------------------------
# Inventory Timestamps from InventoryActionStatus
# -----------------------------------------------
$Temp = Get-CimInstance -Namespace root\ccm\invagt -Class InventoryActionStatus -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$TempFileName = ($ComputerName + "_CMClient_InventoryVersions.txt")
		$InvVersion = Join-Path $Pwd.Path $TempFileName
		$Temp | Select-Object InventoryActionID, @{name="LastCycleStartedDate(LocalTime)";expression={$_.ConvertToDateTime($_.LastCycleStartedDate)}}, LastMajorReportversion, LastMinorReportVersion, @{name="LastReportDate(LocalTime)";expression={$_.ConvertToDateTime($_.LastReportDate)}} `
		| Out-File $InvVersion -Append
		AddTo-CMClientSummary -Name "Inventory Versions" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $InvVersion -fileDescription "Inventory Versions"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	else {
		AddTo-CMClientSummary -Name "Inventory Versions" -Value "No data found in WMI." -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "Inventory Versions" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_Updates

TraceOut "    Getting Software Update Status and State Messages"

# -----------------------------------
# Update Status from CCM_UpdateStatus
# -----------------------------------
$TempFileName = ($ComputerName + "_CMClient_CCM-UpdateStatus.txt")
$UpdStatus = Join-Path $Pwd.Path $TempFileName
"=================================" | Out-File $UpdStatus
" CCM_UpdateStatus" | Out-File $UpdStatus -Append
"=================================" | Out-File $UpdStatus -Append
$Temp = Get-CimInstance -Namespace root\CCM\SoftwareUpdates\UpdatesStore -Class CCM_UpdateStatus -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$Temp | Select-Object UniqueID, Article, Bulletin, RevisionNumber, Status, @{name="ScanTime(LocalTime)";expression={$_.ConvertToDateTime($_.ScanTime)}}, ExcludeForStateReporting, Title, SourceUniqueId `
		  | Sort-Object -Property Article, UniqueID -Descending | Format-Table -AutoSize | Out-File $UpdStatus -Append -Width 500
		AddTo-CMClientSummary -Name "CCM Update Status" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $UpdStatus -fileDescription "CCM Update Status"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	else {
		AddTo-CMClientSummary -Name "CCM Update Status" -Value ("No data in WMI") -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "CCM Update Status" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

# --------------------------------
# State Messages from CCM_StateMsg
# --------------------------------
$TempFileName = ($ComputerName + "_CMClient_CCM-StateMsg.txt")
$StateMsg = Join-Path $Pwd.Path $TempFileName
"=================================" | Out-File $StateMsg
" CCM_StateMsg " | Out-File $StateMsg -Append
"=================================" | Out-File $StateMsg -Append
$Temp = Get-CimInstance -Namespace root\CCM\StateMsg -Class CCM_StateMsg -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$Temp | Select-Object TopicID, TopicType, TopicIDType, StateID, Priority, MessageSent, @{name="MessageTime(LocalTime)";expression={$_.ConvertToDateTime($_.MessageTime)}} `
		 | Sort-Object -Property TopicType, TopicID | Format-Table -AutoSize | Out-File $StateMsg -Append -Width 500
		AddTo-CMClientSummary -Name "CCM State Messages" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $StateMsg -fileDescription "State Messages"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	else {
		AddTo-CMClientSummary -Name "CCM State Messages" -Value ("No data in WMI") -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "CCM State Messages" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

TraceOut "    Getting WMI Data from Client"
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_WMIData

# --------------------------------
# Deployments
# --------------------------------
$TempFileName = ($ComputerName + "_CMClient_CCM-MachineDeployments.TXT")
$OutputFile = join-path $pwd.path $TempFileName
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "Update Deployments" -Query "SELECT AssignmentID, AssignmentAction, AssignmentName, StartTime, EnforcementDeadline, SuppressReboot, NotifyUser, OverrideServiceWindows, RebootOutsideOfServiceWindows, UseGMTTimes, WoLEnabled FROM CCM_UpdateCIAssignment" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "Application Deployments (Machine only)" -Query "SELECT AssignmentID, AssignmentAction, AssignmentName, StartTime, EnforcementDeadline, SuppressReboot, NotifyUser, OverrideServiceWindows, RebootOutsideOfServiceWindows, UseGMTTimes, WoLEnabled FROM CCM_ApplicationCIAssignment" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "DCM Deployments (Machine only)" -Query "SELECT AssignmentID, AssignmentAction, AssignmentName, StartTime, EnforcementDeadline, SuppressReboot, NotifyUser, OverrideServiceWindows, RebootOutsideOfServiceWindows, UseGMTTimes, WoLEnabled FROM CCM_DCMCIAssignment" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "Package Deployments (Machine only)" -Query "SELECT PKG_PackageID, ADV_AdvertisementID, PRG_ProgramName, PKG_Name, PRG_CommandLine, ADV_MandatoryAssignments, ADV_ActiveTime, ADV_ActiveTimeIsGMT, ADV_RCF_InstallFromLocalDPOptions, ADV_RCF_InstallFromRemoteDPOptions, ADV_RepeatRunBehavior, PRG_MaxDuration, PRG_PRF_RunWithAdminRights, PRG_PRF_AfterRunning FROM CCM_SoftwareDistribution" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "Task Sequence Deployments" -Query "SELECT PKG_PackageID, ADV_AdvertisementID, PRG_ProgramName, PKG_Name, TS_BootImageID, TS_Type, ADV_MandatoryAssignments, ADV_ActiveTime, ADV_ActiveTimeIsGMT, ADV_RCF_InstallFromLocalDPOptions, ADV_RCF_InstallFromRemoteDPOptions, ADV_RepeatRunBehavior, PRG_MaxDuration FROM CCM_TaskSequence" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_ServiceWindow -FormatTable | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_RebootSettings -FormatTable | Out-File $OutputFile -Append

AddTo-CMClientSummary -Name "Machine Deployments" -Value ("Review $TempFileName") -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Machine Deployments" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# --------------------------------
# Client Agent Configs
# --------------------------------
$TempFileName = ($ComputerName + "_CMClient_CCM-ClientAgentConfig.TXT")
$OutputFile = join-path $pwd.path $TempFileName

Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_ClientAgentConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_SoftwareUpdatesClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_ApplicationManagementClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_SoftwareDistributionClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_Logging_GlobalConfiguration -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_PolicyAgent_Configuration -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_Service_ResourceProfileConfiguration -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_ConfigurationManagementClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_HardwareInventoryClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_SoftwareInventoryClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_SuperPeerClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_EndpointProtectionClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_AntiMalwarePolicyClientConfig -FormatList | Out-File $OutputFile -Append

AddTo-CMClientSummary -Name "Client Agent Configs" -Value ("Review $TempFileName") -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Client Agent Configs" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# --------------------------------
# Various WMI classes
# --------------------------------

$TempFileName = ($ComputerName + "_CMClient_CCM-ClientMPInfo.TXT")
$OutputFile = join-path $pwd.path $TempFileName

Get-WmiOutput -Namespace root\CCM -ClassName SMS_Authority -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName CCM_Authority -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_LocalMP -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_LookupMP -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_MPProxyInformation -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName CCM_ClientSiteMode -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_Client -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName ClientInfo -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_PendingReRegistrationOnSiteReAssignment -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_PendingSiteAssignment -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\LocationServices -ClassName SMS_ActiveMPCandidate -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\LocationServices -DisplayName "SMS_MPInformation" -Query "SELECT MP, MPLastRequestTime, MPLastUpdateTime, SiteCode, Reserved2 FROM SMS_MPInformation" -FormatList | Out-File $OutputFile -Append

AddTo-CMClientSummary -Name "MP Information" -Value ("Review $TempFileName") -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "MP Information" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_FileVer
TraceOut "    Getting File Versions"

# ---------------------
# Binary Versions List
# ---------------------
$TempFileName = ($ComputerName + "_CMClient_FileVersions.TXT")
$OutputFile = join-path $pwd.path $TempFileName
Get-ChildItem ($CCMInstallDir) -recurse -include *.dll,*.exe -ErrorVariable DirError -ErrorAction SilentlyContinue | `
	ForEach-Object {[System.Diagnostics.FileVersionInfo]::GetVersionInfo($_)} | `
	Select-Object FileName, FileVersion, ProductVersion | Format-Table -AutoSize | `
	Out-File $OutputFile -Width 1000
If ($DirError.Count -eq 0) {
	CollectFiles -filesToCollect $OutputFile -fileDescription "Client File Versions" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	AddTo-CMClientSummary -Name "File Versions" -Value ("Review $TempFileName") -NoToSummaryReport
}
else {
	AddTo-CMClientSummary -Name "File Versions" -Value ("ERROR: " + $DirError[0].Exception.Message) -NoToSummaryReport
	$DirError.Clear()
}

# ---------------------------
# Collect Client Information
# ---------------------------
# Moved to DC_FinishExecution

Traceout "Completed"
# SIG # Begin signature block
# MIIjiAYJKoZIhvcNAQcCoIIjeTCCI3UCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDzsG1I+Evq5c7i
# eqo9tDr2nFmJoaLNfsVwm+syuD8slqCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVXTCCFVkCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgYA8L3Dhc
# W7uMdIGmrJbYgGtn6VL6iu3oMPnXmpH7nAowOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAKZjyvfnXITLAAkNIvC+nOB37Rlg3Ll9VDuY5N1FHHDNDEEfJuTSnZJ5
# F2U/ejVvtgAa876SQaumgSRRXOnXaD5o7W4KF8q3Fau8iEwXSyB/v75ZCTFA1lyH
# We103rDHWGrsyI3js8boIa6z6AyAPmW6XJz9uXrBm+1+yxcyz2Jx0skC6+SEvvt8
# sU1cklWRsxRO4mjDMhgQ9eV1ypcIqvweDw0+RkG2oFG5kCwMBEv5T5bE61QSIQrz
# yEGMHkb/UR5Flb1kx8UgeTOesQJx2+klr53urYD2RRAH7RA2HJeBBUfFy14aY3+C
# S+8VynKjAvSzA6o/kg0zr3Dt5BMkFdehghLxMIIS7QYKKwYBBAGCNwMDATGCEt0w
# ghLZBgkqhkiG9w0BBwKgghLKMIISxgIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBVQYL
# KoZIhvcNAQkQAQSgggFEBIIBQDCCATwCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQgtC0aHRMM90DXBtndWCluK/0GjcWNublV3B3KiowJ7IYCBmGCCja6
# lBgTMjAyMTExMTExNjUzMzUuNzc4WjAEgAIB9KCB1KSB0TCBzjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9w
# ZXJhdGlvbnMgUHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY4
# N0EtRTM3NC1EN0I5MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2
# aWNloIIORDCCBPUwggPdoAMCAQICEzMAAAFji2TGyYWWZXYAAAAAAWMwDQYJKoZI
# hvcNAQELBQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAO
# BgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEm
# MCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjEwMTE0
# MTkwMjIzWhcNMjIwNDExMTkwMjIzWjCBzjELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMgUHVl
# cnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY4N0EtRTM3NC1EN0I5
# MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNlMIIBIjANBgkq
# hkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArXEX9hKdyXRikv+o3YWd/CN/SLxr4LgQ
# vPlRnLck5Tnhcf6se/XLcuApga7fCu01IRjgfPnPo9GUQm+/tora2bta8VJ6zuIs
# WFDTwNXiFXHnMXqWXm43a2LZ8k1nokOMxJVi5j/Bph00Wjs3iXzHzv/VJMihvc8O
# JqoCgRnWERua5GvjgQo//dEOCj8BjSjTXMAXiTke/Kt/PTcZokhnoQgiBthsToTY
# tfZwln3rdo1g9kthVs2dO+I7unZ4Ye1oCSfTxCvNb2nPVoYJNSUMtFQucyJBUs2K
# BpTW/w5PO/tqUAidOVF8Uu88hXQknZI+r7BUvE8aGJWzAStf3z+zNQIDAQABo4IB
# GzCCARcwHQYDVR0OBBYEFAk1yvF2cmfuPzFan0bHkD7X3z0pMB8GA1UdIwQYMBaA
# FNVjOlyKMZDzQ3t8RhvFM2hahW1VMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1RpbVN0YVBDQV8y
# MDEwLTA3LTAxLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljVGltU3RhUENBXzIwMTAt
# MDctMDEuY3J0MAwGA1UdEwEB/wQCMAAwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJ
# KoZIhvcNAQELBQADggEBAAKIQYIH147iU86OMgJh+xOpqb0ip1G0yPbRQEFUuG5+
# 8/3G+Wgjwtn3A4+riwKglJ2EwtrBRZl3ru8WUz+IE/7teSrXT1Np5BITg1z254zX
# l+US9qjhm3MahZNzGkL5qVhjSRUYiPpLEFLGcKShl6xPjhZUhMFAv/jc+YfFUAUP
# QLVwPPNrme/UJKIO+dnio3Gk/pp/0hh8pskHhsnEGrnYVlVCpHh0Do1rsfixOGHU
# Bj+phzqTOZKmFS8TMKrnE9nz5OWyg01ljPpMBHqqd59PYP/cOyfteY77A2MiLoAR
# ZAkdqrAHtHk5Y7tAnunTtGX/hO+Q0zO9mXwEFJ9ftiMwggZxMIIEWaADAgECAgph
# CYEqAAAAAAACMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkgMjAxMDAeFw0xMDA3MDEyMTM2NTVaFw0yNTA3MDEyMTQ2
# NTVaMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNV
# BAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwMIIBIjANBgkqhkiG9w0B
# AQEFAAOCAQ8AMIIBCgKCAQEAqR0NvHcRijog7PwTl/X6f2mUa3RUENWlCgCChfvt
# fGhLLF/Fw+Vhwna3PmYrW/AVUycEMR9BGxqVHc4JE458YTBZsTBED/FgiIRUQwzX
# Tbg4CLNC3ZOs1nMwVyaCo0UN0Or1R4HNvyRgMlhgRvJYR4YyhB50YWeRX4FUsc+T
# TJLBxKZd0WETbijGGvmGgLvfYfxGwScdJGcSchohiq9LZIlQYrFd/XcfPfBXday9
# ikJNQFHRD5wGPmd/9WbAA5ZEfu/QS/1u5ZrKsajyeioKMfDaTgaRtogINeh4HLDp
# mc085y9Euqf03GS9pAHBIAmTeM38vMDJRF1eFpwBBU8iTQIDAQABo4IB5jCCAeIw
# EAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFNVjOlyKMZDzQ3t8RhvFM2hahW1V
# MBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1UdDwQEAwIBhjAPBgNVHRMB
# Af8EBTADAQH/MB8GA1UdIwQYMBaAFNX2VsuP6KJcYmjRPZSQW9fOmhjEMFYGA1Ud
# HwRPME0wS6BJoEeGRWh0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3By
# b2R1Y3RzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNybDBaBggrBgEFBQcBAQRO
# MEwwSgYIKwYBBQUHMAKGPmh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2Vy
# dHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3J0MIGgBgNVHSABAf8EgZUwgZIw
# gY8GCSsGAQQBgjcuAzCBgTA9BggrBgEFBQcCARYxaHR0cDovL3d3dy5taWNyb3Nv
# ZnQuY29tL1BLSS9kb2NzL0NQUy9kZWZhdWx0Lmh0bTBABggrBgEFBQcCAjA0HjIg
# HQBMAGUAZwBhAGwAXwBQAG8AbABpAGMAeQBfAFMAdABhAHQAZQBtAGUAbgB0AC4g
# HTANBgkqhkiG9w0BAQsFAAOCAgEAB+aIUQ3ixuCYP4FxAz2do6Ehb7Prpsz1Mb7P
# BeKp/vpXbRkws8LFZslq3/Xn8Hi9x6ieJeP5vO1rVFcIK1GCRBL7uVOMzPRgEop2
# zEBAQZvcXBf/XPleFzWYJFZLdO9CEMivv3/Gf/I3fVo/HPKZeUqRUgCvOA8X9S95
# gWXZqbVr5MfO9sp6AG9LMEQkIjzP7QOllo9ZKby2/QThcJ8ySif9Va8v/rbljjO7
# Yl+a21dA6fHOmWaQjP9qYn/dxUoLkSbiOewZSnFjnXshbcOco6I8+n99lmqQeKZt
# 0uGc+R38ONiU9MalCpaGpL2eGq4EQoO4tYCbIjggtSXlZOz39L9+Y1klD3ouOVd2
# onGqBooPiRa6YacRy5rYDkeagMXQzafQ732D8OE7cQnfXXSYIghh2rBQHm+98eEA
# 3+cxB6STOvdlR3jo+KhIq/fecn5ha293qYHLpwmsObvsxsvYgrRyzR30uIUBHoD7
# G4kqVDmyW9rIDVWZeodzOwjmmC3qjeAzLhIp9cAvVCch98isTtoouLGp25ayp0Ki
# yc8ZQU3ghvkqmqMRZjDTu3QyS99je/WZii8bxyGvWbWu3EQ8l1Bx16HSxVXjad5X
# wdHeMMD9zOZN+w2/XU/pnR4ZOC+8z1gFLu8NoFA12u8JJxzVs341Hgi62jbb01+P
# 3nSISRKhggLSMIICOwIBATCB/KGB1KSB0TCBzjELMAkGA1UEBhMCVVMxEzARBgNV
# BAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jv
# c29mdCBDb3Jwb3JhdGlvbjEpMCcGA1UECxMgTWljcm9zb2Z0IE9wZXJhdGlvbnMg
# UHVlcnRvIFJpY28xJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkY4N0EtRTM3NC1E
# N0I5MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEw
# BwYFKw4DAhoDFQDtLGAe3UndKpNNKrMtyswZlAFh76CBgzCBgKR+MHwxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5Te9IjAiGA8y
# MDIxMTExMTIwMDI0MloYDzIwMjExMTEyMjAwMjQyWjB3MD0GCisGAQQBhFkKBAEx
# LzAtMAoCBQDlN70iAgEAMAoCAQACAiM0AgH/MAcCAQACAhEGMAoCBQDlOQ6iAgEA
# MDYGCisGAQQBhFkKBAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAI
# AgEAAgMBhqAwDQYJKoZIhvcNAQEFBQADgYEAnqYD8yPvoiw8hILRb1Xu8zXfsM4e
# 3InjK8rlmfNaeQX9PwDsxr7NiWWL1U0ZnZ+7q5hatTb3oyNjyp6aZq2W2oROpP3N
# yfbZMJxTAfvc0u/SLBDAYBRO/K7HBM+bAo3fFFjAugLR3WbsGfb1nyWHzbR+T3Jq
# uGHNhABU8vz1cWExggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMAITMwAAAWOLZMbJhZZldgAAAAABYzANBglghkgBZQMEAgEFAKCCAUow
# GgYJKoZIhvcNAQkDMQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCC4ibLD
# IgsVc7CyjF1PJLA7Shr8R8sLL7l8dcdPtSIRKzCB+gYLKoZIhvcNAQkQAi8xgeow
# gecwgeQwgb0EIJxZ3ZcdoWOhKKQpuLjL0BgEiksHL1FvXqezUasR9CNqMIGYMIGA
# pH4wfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFji2TGyYWWZXYA
# AAAAAWMwIgQgbNyOcP0hXvI1cKvMuGogRKjNurAH+Ok0yUHzs1p6YT0wDQYJKoZI
# hvcNAQELBQAEggEAF56YP524CNB6Y+GQzZLnWEPKU1K5L9pCoZEM+zIGVLAhit0z
# FGaUGfyT8Mm8fR3jf/NbKamuEP+wbLVbfcQPcT0n0yxnCfoyw/5UNoB4wsHezMz7
# qD9tGofo7KuVeCSKnMqa+N21by8UfU3NSIcbEQIHa3GoRptFy2cfsaZncoXm++7l
# 1I4cF10/gthJBErs7gmloeVxSyLazqRKGjnNtwsx5ER4EeB7+EckvHJ1b5Sy8ITO
# AlrE0LMoDKQlZcgjMpy4eTiRswViu4vOZ572OomPU6BfivF240YKu/4g92PaGUat
# Hq525PmfMXeY2EioaXNUuare0a6hHTevuUATcA==
# SIG # End signature block
