﻿# *********************************************************************************************************************
# Version 1.0
# Date: 02-29-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects Configuration Manager Client Information
#		1. Gets CCMExec service Status, Start time, Install Directory, Assigned Site, MP, Client Version and GUID.
# 		2. Gets Software Distribution Execution History.
#		3. Gets Cache Size, Location and Elements.
#		4. Gets Inventory Timestamps
#		5. Gets Update Installation Status
#		6. Gets State Message Data
#		7. Gets File Versions from Client Install Directory
#		8. Summarizes all data in a PSObject, then dumps to a text file for better readability.
# *********************************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

If (!$Is_Client) {
	TraceOut "ConfigMgr Client not detected. This script gathers data only from a Client. Exiting."
	exit 0
}

function Get-WmiOutput {
	Param(
		[Parameter(Mandatory=$true)]
	    [string]$Namespace,
		[Parameter(Mandatory=$false)]
	    [string]$ClassName,
		[Parameter(Mandatory=$false)]
	    [string]$Query,
		[Parameter(Mandatory=$false)]
	    [string]$DisplayName,
		[Parameter(Mandatory=$false)]
		[switch]$FormatList,
		[Parameter(Mandatory=$false)]
		[switch]$FormatTable
	)

	if ($DisplayName) {
		$DisplayText = $DisplayName
	}
	else {
		$DisplayText = $ClassName
	}

	$results =  "`r`n=================================`r`n"
	$results += " $DisplayText `r`n"
	$results += "=================================`r`n`r`n"

	if ($ClassName) {
		$Temp = Get-WmiData -Namespace $Namespace -ClassName $ClassName
	}

	if ($Query) {
		$Temp = Get-WmiData -Namespace $Namespace -Query $Query
	}

	if ($Temp) {
		if ($FormatList) {
			$results += ($Temp | Format-List | Out-String -Width 500).Trim()
		}

		if ($FormatTable) {
			$results += ($Temp | Format-Table -AutoSize | Out-String -Width 500).Trim()
		}

		$results += "`r`n"
	}
	else {
		$results += "    No Instances.`r`n"
	}

	return $results
}

function Get-WmiData{
	Param(
		[Parameter(Mandatory=$true)]
	    [string]$Namespace,
	    [Parameter(Mandatory=$false)]
	    [string]$ClassName,
		[Parameter(Mandatory=$false)]
	    [string]$Query
	)

	if ($ClassName) {
		$Temp = Get-WmiObject -Namespace $Namespace -Class $ClassName -ErrorVariable WMIError -ErrorAction SilentlyContinue
	}

	if ($Query) {
		$Temp = Get-WmiObject -Namespace $Namespace -Query $Query -ErrorVariable WMIError -ErrorAction SilentlyContinue
	}

	if ($WMIError.Count -ne 0) {
		if ($WMIError[0].Exception.Message -eq "") {
			$results = $WMIError[0].Exception.ToString()
		}
		else {
			$results = $WMIError[0].Exception.Message
		}
		$WMIError.Clear()
		return $results
	}

	if (($Temp | Measure-Object).Count -gt 0) {
		$results = $Temp | Select * -ExcludeProperty __GENUS, __CLASS, __SUPERCLASS, __DYNASTY, __RELPATH, __PROPERTY_COUNT, __DERIVATION, __SERVER, __NAMESPACE, __PATH, PSComputerName, Scope, Path, Options, ClassPath, Properties, SystemProperties, Qualifiers, Site, Container
	}
	else {
		$results = $null
	}

	return $results
}

TraceOut "Started"

Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "Configuration Manager Client Information"

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_ClientInfo

TraceOut "    Getting Client Information"

# ----------------------
# Current Time:
# ----------------------
AddTo-CMClientSummary -Name "Current Time" -Value $CurrentTime

# -------------
# Computer Name
# -------------
AddTo-CMClientSummary -Name "Client Name" -Value $ComputerName

# ------------------
# Assigned Site Code
# ------------------
$Temp = Get-RegValue ($Reg_SMS + "\Mobile Client") "AssignedSiteCode"
If ($Temp -ne $null) {
	AddTo-CMClientSummary -Name "Assigned Site Code" -Value $Temp}
else {
	AddTo-CMClientSummary -Name "Assigned Site Code" -Value "Error obtaining value from Registry"}

# ------------------------
# Current Management Point
# ------------------------
$Temp = Get-WmiObject -Namespace root\CCM -Class SMS_Authority -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	AddTo-CMClientSummary -Name "Current MP" -Value $Temp.CurrentManagementPoint }
else {
	AddTo-CMClientSummary -Name "Current MP" -Value "Error obtaining value from SMS_Authority WMI Class" }

# --------------
# Client Version
# --------------
$Temp = Get-WmiObject -Namespace root\CCM -Class SMS_Client -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	AddTo-CMClientSummary -Name "Client Version" -Value $Temp.ClientVersion }
else {
	AddTo-CMClientSummary -Name "Client Version" -Value "Error obtaining value from SMS_Client WMI Class" }

# ----------------------------------------------------------
# Installation Directory - defined in utils_ConfigMgr07.ps1
# ----------------------------------------------------------
If ($CCMInstallDir -ne $null) {
	AddTo-CMClientSummary -Name "Installation Directory" -Value $CCMInstallDir }
else {
	AddTo-CMClientSummary -Name "Installation Directory" -Value "Error obtaining value" }

# ------------
# Client GUID
# ------------
$Temp = Get-WmiObject -Namespace root\CCM -Class CCM_Client -ErrorAction SilentlyContinue
If ($Temp -is [WMI]) {
	AddTo-CMClientSummary -Name "Client ID" -Value $Temp.ClientId
	AddTo-CMClientSummary -Name "Previous Client ID (if any)" -Value $Temp.PreviousClientId
	AddTo-CMClientSummary -Name "Client ID Change Date" -Value $Temp.ClientIdChangeDate }
else {
	AddTo-CMClientSummary -Name "Client ID Information" -Value "Error Obtaining value from CCM_Client WMI Class" }

# -----------------------
# CCMExec Service Status
# -----------------------
$Temp = Get-Service | Where-Object {$_.Name -eq 'CCMExec'} | Select-Object Status
If ($Temp -ne $null) {
	if ($Temp.Status -eq 'Running') {
		$Temp2 = Get-Process | Where-Object {$_.ProcessName -eq 'CCMExec'} | Select-Object StartTime
		AddTo-CMClientSummary -Name "CCMExec Status" -Value "Running. StartTime = $($Temp2.StartTime)"
	}
	else {
		AddTo-CMClientSummary -Name "CCMExec Status" -Value $Temp.Status
	}
}
Else {
	AddTo-CMClientSummary -Name "CCMExec Service Status" -Value "ERROR: Service Not found"
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_History

TraceOut "    Getting Software Distribution and Application Execution History"

# -----------------------------------------------------
# Software Distribution Execution History from Registry
# -----------------------------------------------------
$Temp = ($Reg_SMS -replace "HKLM\\", "HKLM:\") + "\Mobile Client\Software Distribution\Execution History"
If (Check-RegKeyExists $Temp) {
	$TempFileName = ($ComputerName + "_CMClient_ExecutionHistory.txt")
	$ExecHistory = Join-Path $Pwd.Path $TempFileName
	Get-ChildItem $Temp -Recurse `
	| ForEach-Object {Get-ItemProperty $_.PSPath} `
	| Select @{name="Path";exp={$_.PSPath.Substring($_.PSPath.LastIndexOf("History\") + 8)}}, _ProgramID, _State, _RunStartTime, SuccessOrFailureCode, SuccessOrFailureReason `
	| Out-File $ExecHistory -Append -Width 500
	AddTo-CMClientSummary -Name "ExecMgr History" -Value ("Review $TempFileName") -NoToSummaryReport
	CollectFiles -filesToCollect $ExecHistory -fileDescription "ExecMgr History"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
}
else {
	AddTo-CMClientSummary -Name "ExecMgr History" -Value "Execution History not found" -NoToSummaryReport
}

# -----------------------------------------------------
# Application Enforce Status from WMI
# -----------------------------------------------------
$Temp = Get-WmiObject -Namespace root\CCM\CIModels -Class CCM_AppEnforceStatus -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$TempFileName = ($ComputerName + "_CMClient_AppHistory.txt")
		$AppHist = Join-Path $Pwd.Path $TempFileName
		$Temp | Select-Object AppDeliveryTypeId, ExecutionStatus, ExitCode, Revision, ReconnectData `
		| Out-File $AppHist -Append -Width 250
		AddTo-CMClientSummary -Name "App Execution History" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $AppHist -fileDescription "Application History"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	else {
		AddTo-CMClientSummary -Name "App Execution History" -Value ("Error obtaining data or no data in WMI") -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "App Execution History" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

# -----------------
# Cache Information
# -----------------
$Temp = Get-WmiObject -Namespace root\ccm\softmgmtagent -Class CacheConfig -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$TempFileName = ($ComputerName + "_CMClient_CacheInfo.txt")
		$CacheInfo = Join-Path $Pwd.Path $TempFileName
		"Cache Config:" | Out-File $CacheInfo
		"==================" | Out-File $CacheInfo -Append
		$Temp | Select-Object Location, Size, NextAvailableId | Format-List * | Out-File $CacheInfo -Append -Width 500
		"Cache Elements:" | Out-File $CacheInfo -Append
		"===============" | Out-File $CacheInfo -Append
		$Temp = Get-WmiObject -Namespace root\ccm\softmgmtagent -Class CacheInfoEx -ErrorAction SilentlyContinue
		$Temp | Select-Object Location, ContentId, CacheID, ContentVer, ContentSize, LastReferenced, PeerCaching, ContentType, ReferenceCount, PersistInCache `
			| Sort-Object -Property Location | Format-Table -AutoSize | Out-File $CacheInfo -Append -Width 500
		AddTo-CMClientSummary -Name "Cache Information" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $CacheInfo -fileDescription "Cache Information"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	Else {
		AddTo-CMClientSummary -Name "Cache Information" -Value "No data found in WMI." -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "Cache Information" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

# -----------------------------------------------
# Inventory Timestamps from InventoryActionStatus
# -----------------------------------------------
$Temp = Get-WmiObject -Namespace root\ccm\invagt -Class InventoryActionStatus -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$TempFileName = ($ComputerName + "_CMClient_InventoryVersions.txt")
		$InvVersion = Join-Path $Pwd.Path $TempFileName
		$Temp | Select-Object InventoryActionID, @{name="LastCycleStartedDate(LocalTime)";expression={$_.ConvertToDateTime($_.LastCycleStartedDate)}}, LastMajorReportversion, LastMinorReportVersion, @{name="LastReportDate(LocalTime)";expression={$_.ConvertToDateTime($_.LastReportDate)}} `
		| Out-File $InvVersion -Append
		AddTo-CMClientSummary -Name "Inventory Versions" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $InvVersion -fileDescription "Inventory Versions"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	else {
		AddTo-CMClientSummary -Name "Inventory Versions" -Value "No data found in WMI." -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "Inventory Versions" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_Updates

TraceOut "    Getting Software Update Status and State Messages"

# -----------------------------------
# Update Status from CCM_UpdateStatus
# -----------------------------------
$TempFileName = ($ComputerName + "_CMClient_CCM-UpdateStatus.txt")
$UpdStatus = Join-Path $Pwd.Path $TempFileName
"=================================" | Out-File $UpdStatus
" CCM_UpdateStatus" | Out-File $UpdStatus -Append
"=================================" | Out-File $UpdStatus -Append
$Temp = Get-WmiObject -Namespace root\CCM\SoftwareUpdates\UpdatesStore -Class CCM_UpdateStatus -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$Temp | Select-Object UniqueID, Article, Bulletin, RevisionNumber, Status, @{name="ScanTime(LocalTime)";expression={$_.ConvertToDateTime($_.ScanTime)}}, ExcludeForStateReporting, Title, SourceUniqueId `
		  | Sort-Object -Property Article, UniqueID -Descending | Format-Table -AutoSize | Out-File $UpdStatus -Append -Width 500
		AddTo-CMClientSummary -Name "CCM Update Status" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $UpdStatus -fileDescription "CCM Update Status"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	else {
		AddTo-CMClientSummary -Name "CCM Update Status" -Value ("No data in WMI") -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "CCM Update Status" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

# --------------------------------
# State Messages from CCM_StateMsg
# --------------------------------
$TempFileName = ($ComputerName + "_CMClient_CCM-StateMsg.txt")
$StateMsg = Join-Path $Pwd.Path $TempFileName
"=================================" | Out-File $StateMsg
" CCM_StateMsg " | Out-File $StateMsg -Append
"=================================" | Out-File $StateMsg -Append
$Temp = Get-WmiObject -Namespace root\CCM\StateMsg -Class CCM_StateMsg -ErrorVariable WMIError -ErrorAction SilentlyContinue
If ($WMIError.Count -eq 0)
{
	If ($Temp -ne $null) {
		$Temp | Select-Object TopicID, TopicType, TopicIDType, StateID, Priority, MessageSent, @{name="MessageTime(LocalTime)";expression={$_.ConvertToDateTime($_.MessageTime)}} `
		 | Sort-Object -Property TopicType, TopicID | Format-Table -AutoSize | Out-File $StateMsg -Append -Width 500
		AddTo-CMClientSummary -Name "CCM State Messages" -Value ("Review $TempFileName") -NoToSummaryReport
		CollectFiles -filesToCollect $StateMsg -fileDescription "State Messages"  -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	}
	else {
		AddTo-CMClientSummary -Name "CCM State Messages" -Value ("No data in WMI") -NoToSummaryReport
	}
}
Else {
	AddTo-CMClientSummary -Name "CCM State Messages" -Value ("ERROR: " + $WMIError[0].Exception.Message) -NoToSummaryReport
	$WMIError.Clear()
}

TraceOut "    Getting WMI Data from Client"
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_WMIData

# --------------------------------
# Deployments
# --------------------------------
$TempFileName = ($ComputerName + "_CMClient_CCM-MachineDeployments.TXT")
$OutputFile = join-path $pwd.path $TempFileName
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "Update Deployments" -Query "SELECT AssignmentID, AssignmentAction, AssignmentName, StartTime, EnforcementDeadline, SuppressReboot, NotifyUser, OverrideServiceWindows, RebootOutsideOfServiceWindows, UseGMTTimes, WoLEnabled FROM CCM_UpdateCIAssignment" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "Application Deployments (Machine only)" -Query "SELECT AssignmentID, AssignmentAction, AssignmentName, StartTime, EnforcementDeadline, SuppressReboot, NotifyUser, OverrideServiceWindows, RebootOutsideOfServiceWindows, UseGMTTimes, WoLEnabled FROM CCM_ApplicationCIAssignment" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "DCM Deployments (Machine only)" -Query "SELECT AssignmentID, AssignmentAction, AssignmentName, StartTime, EnforcementDeadline, SuppressReboot, NotifyUser, OverrideServiceWindows, RebootOutsideOfServiceWindows, UseGMTTimes, WoLEnabled FROM CCM_DCMCIAssignment" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "Package Deployments (Machine only)" -Query "SELECT PKG_PackageID, ADV_AdvertisementID, PRG_ProgramName, PKG_Name, PRG_CommandLine, ADV_MandatoryAssignments, ADV_ActiveTime, ADV_ActiveTimeIsGMT, ADV_RCF_InstallFromLocalDPOptions, ADV_RCF_InstallFromRemoteDPOptions, ADV_RepeatRunBehavior, PRG_MaxDuration, PRG_PRF_RunWithAdminRights, PRG_PRF_AfterRunning FROM CCM_SoftwareDistribution" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -DisplayName "Task Sequence Deployments" -Query "SELECT PKG_PackageID, ADV_AdvertisementID, PRG_ProgramName, PKG_Name, TS_BootImageID, TS_Type, ADV_MandatoryAssignments, ADV_ActiveTime, ADV_ActiveTimeIsGMT, ADV_RCF_InstallFromLocalDPOptions, ADV_RCF_InstallFromRemoteDPOptions, ADV_RepeatRunBehavior, PRG_MaxDuration FROM CCM_TaskSequence" `
  -FormatTable | Sort-Object -Property AssignmentID | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_ServiceWindow -FormatTable | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_RebootSettings -FormatTable | Out-File $OutputFile -Append

AddTo-CMClientSummary -Name "Machine Deployments" -Value ("Review $TempFileName") -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Machine Deployments" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# --------------------------------
# Client Agent Configs
# --------------------------------
$TempFileName = ($ComputerName + "_CMClient_CCM-ClientAgentConfig.TXT")
$OutputFile = join-path $pwd.path $TempFileName

Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_ClientAgentConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_SoftwareUpdatesClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_ApplicationManagementClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_SoftwareDistributionClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_Logging_GlobalConfiguration -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_PolicyAgent_Configuration -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_Service_ResourceProfileConfiguration -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_ConfigurationManagementClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_HardwareInventoryClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_SoftwareInventoryClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_SuperPeerClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_EndpointProtectionClientConfig -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\Policy\Machine\ActualConfig -ClassName CCM_AntiMalwarePolicyClientConfig -FormatList | Out-File $OutputFile -Append

AddTo-CMClientSummary -Name "Client Agent Configs" -Value ("Review $TempFileName") -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "Client Agent Configs" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# --------------------------------
# Various WMI classes
# --------------------------------

$TempFileName = ($ComputerName + "_CMClient_CCM-ClientMPInfo.TXT")
$OutputFile = join-path $pwd.path $TempFileName

Get-WmiOutput -Namespace root\CCM -ClassName SMS_Authority -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName CCM_Authority -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_LocalMP -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_LookupMP -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_MPProxyInformation -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName CCM_ClientSiteMode -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_Client -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName ClientInfo -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_PendingReRegistrationOnSiteReAssignment -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM -ClassName SMS_PendingSiteAssignment -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\LocationServices -ClassName SMS_ActiveMPCandidate -FormatList | Out-File $OutputFile -Append
Get-WmiOutput -Namespace root\CCM\LocationServices -DisplayName "SMS_MPInformation" -Query "SELECT MP, MPLastRequestTime, MPLastUpdateTime, SiteCode, Reserved2 FROM SMS_MPInformation" -FormatList | Out-File $OutputFile -Append

AddTo-CMClientSummary -Name "MP Information" -Value ("Review $TempFileName") -NoToSummaryReport
CollectFiles -filesToCollect $OutputFile -fileDescription "MP Information" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------
# Write Progress
# ----------------
Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM07ClientInfo -Status $ScriptStrings.ID_SCCM_CM07ClientInfo_FileVer
TraceOut "    Getting File Versions"

# ---------------------
# Binary Versions List
# ---------------------
$TempFileName = ($ComputerName + "_CMClient_FileVersions.TXT")
$OutputFile = join-path $pwd.path $TempFileName
Get-ChildItem ($CCMInstallDir) -recurse -include *.dll,*.exe -ErrorVariable DirError -ErrorAction SilentlyContinue | `
	ForEach-Object {[System.Diagnostics.FileVersionInfo]::GetVersionInfo($_)} | `
	Select-Object FileName, FileVersion, ProductVersion | Format-Table -AutoSize | `
	Out-File $OutputFile -Width 1000
If ($DirError.Count -eq 0) {
	CollectFiles -filesToCollect $OutputFile -fileDescription "Client File Versions" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
	AddTo-CMClientSummary -Name "File Versions" -Value ("Review $TempFileName") -NoToSummaryReport
}
else {
	AddTo-CMClientSummary -Name "File Versions" -Value ("ERROR: " + $DirError[0].Exception.Message) -NoToSummaryReport
	$DirError.Clear()
}

# ---------------------------
# Collect Client Information
# ---------------------------
# Moved to DC_FinishExecution

Traceout "Completed"
# SIG # Begin signature block
# MIIa6wYJKoZIhvcNAQcCoIIa3DCCGtgCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUCiez4fa2V8qhiDClD8xMBlqc
# X9egghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTSMIIE
# zgIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHrMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBT8
# J37tATJO1spwVAf1dL5snzuynzCBigYKKwYBBAGCNwIBDDF8MHqgYIBeAEQASQBB
# AEcAXwBDAFQAUwBfAFMAQwBDAE0AXwAyADAAMQAyAF8AZwBsAG8AYgBhAGwAXwBE
# AEMAXwBDAE0AMQAyAEMAbABpAGUAbgB0AEkAbgBmAG8ALgBwAHMAMaEWgBRodHRw
# Oi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQCaVqH0V/8r7lb3Zhxm
# oks0iVE1Qbfg7QxE42fFwyjoSXGLsegdD5H7cAdXkcDzm8Vm+DdFGpWFaBlT4i0j
# j82WqeCxeMi+dExttwXXWOfZKLg2gaTxbozUFmc+PfTWAyNFt7fml2ArJHK8zdL9
# aylQZbhYtfuTFg9o61Fj5VGTFplU25QhFQMhny9FnRrA1kyCKasmJGAOIusCj5KB
# NcdEk4y5VaEOgezq4CipJp6blVblr1xQ4/J3P62xwhfVSmXfvZKpIM1VBJIJoAyJ
# paOf4bYvuJxsQ/JIQK8AxkiPFED0RFjBgfwUScEGGOExh3OwnT+pOQZVUw66mfm8
# jw4toYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQQITMwAAAMZ4gDYBdRppcgAAAAAAxjAJBgUrDgMCGgUAoF0w
# GAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcwNDI3
# MTQyMzMxWjAjBgkqhkiG9w0BCQQxFgQUJCiAieodSuGCW6VCY8rADMMGwVcwDQYJ
# KoZIhvcNAQEFBQAEggEAUVWkUJg9vsbYJsXmKcrVdfCDNRhaIoXSgH0S0+IQLx4y
# mKuTRm7tUbHvbsEEofRvyVV4sC5mjkyxaKMp7cbqwE8KrxXLTWZEzuZ90s/qED2j
# 7daZ2IgVi8M2U2LAfzjpBCHjmDjwfwr2+lMu2OWuPu+LjkZv+GkcjRVvK6AhI77a
# 1FzeZ629bFmEDKw//oB3bIPBy7LKPZTT0nk8u1ufPWM0w6EQr4pw3Jk6xKrYgniS
# 0JcjMnndxiNYQsFMYn6k1fpR5rLhbKQSH9j7v6VcldJHkF9OVJbe6SI+WtgkOcuX
# /yXuqHdSKnWJYIrJN/2J5DlhOedgp7lUd1tgUn2KsQ==
# SIG # End signature block
