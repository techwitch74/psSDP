﻿# ***********************************************************************************************************
# Version 1.0
# Date: 11-12-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
#
# ***********************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

TraceOut "Started"

Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "WSUS Server Information"

If ($Is_WSUS)
{
	# ----------------
	# Write Progress
	# ----------------
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WSUSInfo -Status $ScriptStrings.ID_SCCM_WSUSInfo_WSUS

	$WSUSInfo = New-Object PSObject

	# Summary File Header
	$WSUSFile = Join-Path $Pwd.Path ($ComputerName + "__WSUS_Summary.txt")
	"======================" | Out-File $WSUSFile
	"Update Server Summary:" | Out-File $WSUSFile -Append
	"======================" | Out-File $WSUSFile -Append

	# -------------
	# Computer Name
	# -------------
	Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Computer Name" -Value $ComputerName
	Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Logged On User" -Value ($Env:USERDOMAIN + "\" + $Env:USERNAME)

	# ----------------------
	# Time zone information:
	# ----------------------
	$Temp = Get-WmiObject -Namespace root\cimv2 -Class Win32_TimeZone -ErrorAction SilentlyContinue
	If ($Temp -is [WMI]) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Time Zone" -Value $Temp.Description }
	else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Time Zone" -Value "Error obtaining value from Win32_TimeZone WMI Class" }

	$Temp = Get-WmiObject -Namespace root\cimv2 -Class Win32_ComputerSystem -ErrorAction SilentlyContinue
	If ($Temp -is [WMI]) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Daylight In Effect" -Value $Temp.DaylightInEffect }
	else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Daylight In Effect" -Value "Error obtaining value from Win32_ComputerSystem WMI Class" }

	# -----------------------
	# WUA Service Status
	# -----------------------
	$Temp = Get-Service | Where-Object {$_.Name -eq 'WsusService'} | Select-Object Status
	If ($Temp -ne $null) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Update Services Service Status" -Value $Temp.Status
	}
	Else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Update Services Service Status" -Value "ERROR: Service Not found"
	}

	# --------------------------
	# WUA Service StartTime
	# --------------------------
	$Temp = Get-Process | Where-Object {($_.ProcessName -eq 'WsusService')} | Select-Object StartTime
	If ($Temp -ne $null) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Update Services Service StartTime" -Value $Temp.StartTime
	}
	Else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Update Services Service StartTime" -Value "ERROR: Service Not running"
	}

	# --------------------------
	# WSUS Registry Settings
	# --------------------------
	$Version = Get-RegValue ($Reg_WSUS + "\Server\Setup") "VersionString"
	If ($Version -ne $null) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Version" -Value $Version }
	else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Version" -Value "Error obtaining value from Registry" }

	$Temp = Get-RegValue ($Reg_WSUS + "\Server\Setup") "ContentDir"
	If ($Temp -ne $null) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Content Directory" -Value $Temp }
	else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Content Directory" -Value "Error obtaining value from Registry" }

	$Temp = Get-RegValue ($Reg_WSUS + "\Server\Setup") "PortNumber"
	If ($Temp -ne $null) {
		$Port = $Temp
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Port Number" -Value $Temp }
	else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Port Number" -Value "Error obtaining value from Registry" }

	$Temp = Get-RegValue ($Reg_WSUS + "\Server\Setup") "SqlServerName"
	If ($Temp -ne $null) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "SQL Server Name" -Value $Temp }
	else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "SQL Server Name" -Value "Error obtaining value from Registry" }

	$Temp = Get-RegValue ($Reg_WSUS + "\Server\Setup") "SqlDatabaseName"
	If ($Temp -ne $null) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "SQLDatabaseName" -Value $Temp }
	else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "SQLDatabaseName" -Value "Error obtaining value from Registry" }

	$Temp = Get-RegValue ($Reg_WSUS + "\Server\Setup") "SqlAuthenticationMode"
	If ($Temp -ne $null) {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "SQL Authentication Mode" -Value $Temp }
	else {
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "SQL Authentication Mode" -Value "Error obtaining value from Registry" }

	$Temp = Get-RegValue ($Reg_WSUS + "\Server\Setup") "UsingSSL"
	If ($Temp -eq 1) {
		$SSL = $true
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "SSL Enabled" -Value $Temp
		$Temp = Get-RegValue ($Reg_WSUS + "\Server\Setup") "ServerCertificateName"
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "ServerCertificateName" -Value $Temp }
	else {
		$SSL = $false
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "SSL Enabled" -Value 0 }

	# --------------------------
	# Instantiate WSUS Object
	# --------------------------
	try {
		[void][reflection.assembly]::LoadWithPartialName("Microsoft.UpdateServices.Administration")
		$wsus = [Microsoft.UpdateServices.Administration.AdminProxy]::GetUpdateServer($ComputerName,$SSL,$Port)
	}
	catch [System.Exception]
	{
		TraceOut "Failed to connect to the WSUS Server."
		TraceOut "  Error:" $_.Exception.Message
		$wsus = $null
	}

	If ($ManifestName -eq "WSUS") {
		# ----------------
		# Write Progress
		# ----------------
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WSUSInfo -Status $ScriptStrings.ID_SCCM_WSUSInfo_FileListContent

		# ------------------------------------
		# File List from WSUS ContentDirectory
		# ------------------------------------
		if ($wsus -ne $null) {
			$ContentPath = $wsus.GetConfiguration().LocalContentCachePath
			$TempFileName = ($ComputerName + "_WSUS_FileList_ContentDir.TXT")
			$OutputFile = join-path $pwd.path $TempFileName
			Get-ChildItem ($ContentPath) -Recurse -ErrorVariable DirError -ErrorAction SilentlyContinue | `
				Select-Object LastAccessTime, FullName, Length, Mode | Sort-Object FullName | Format-Table -AutoSize | `
				Out-File $OutputFile -Width 1000
			If ($DirError.Count -eq 0) {
				CollectFiles -filesToCollect $OutputFile -fileDescription "WSUS Content File List" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
				Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "WSUS Content File List" -Value ("Review $TempFileName")
			}
			else {
				Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "WSUS Content File List" -Value ("ERROR: " + $DirError[0].Exception.Message)
				$DirError.Clear()
			}
		}
		else {
			Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "WSUS Content File List" -Value ("ERROR: Unable to connect to WSUS Server.")
		}

		# ----------------
		# Write Progress
		# ----------------
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WSUSInfo -Status $ScriptStrings.ID_SCCM_WSUSInfo_FileListInstall

		# --------------------------------
		# File List from Install Directory
		# --------------------------------
		$TempFileName = ($ComputerName + "_WSUS_FileList_InstallDir.TXT")
		$OutputFile = join-path $pwd.path $TempFileName
		Get-ChildItem ($WSUSInstallDir) -Recurse -ErrorVariable DirError -ErrorAction SilentlyContinue | `
			Select-Object LastAccessTime, FullName, Length, Mode | Sort-Object FullName | Format-Table -AutoSize | `
			Out-File $OutputFile -Width 1000
		If ($DirError.Count -eq 0) {
			CollectFiles -filesToCollect $OutputFile -fileDescription "Server File List" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
			Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Server File List" -Value ("Review $TempFileName")
		}
		else {
			Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Server File List" -Value ("ERROR: " + $DirError[0].Exception.Message)
			$DirError.Clear()
		}

		# ----------------
		# Write Progress
		# ----------------
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WSUSInfo -Status $ScriptStrings.ID_SCCM_WSUSInfo_FileVer

		# ---------------------
		# Binary Versions List
		# ---------------------
		$TempFileName = ($ComputerName + "_WSUS_FileVersions.TXT")
		$OutputFile = join-path $pwd.path $TempFileName
		Get-ChildItem ($WSUSInstallDir) -recurse -include *.dll,*.exe -ErrorVariable DirError -ErrorAction SilentlyContinue | `
			ForEach-Object {[System.Diagnostics.FileVersionInfo]::GetVersionInfo($_)} | `
			Select-Object FileName, FileVersion, ProductVersion | Format-Table -AutoSize | `
			Out-File $OutputFile -Width 1000
		If ($DirError.Count -eq 0) {
			CollectFiles -filesToCollect $OutputFile -fileDescription "Server File Versions" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
			Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Server File Versions" -Value ("Review $TempFileName")
		}
		else {
			Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "Server File Versions" -Value ("ERROR: " + $DirError[0].Exception.Message)
			$DirError.Clear()
		}
	}

	# ----------------
	# Write Progress
	# ----------------
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WSUSInfo -Status $ScriptStrings.ID_SCCM_WSUSInfo_Logs

	# ------------------
	# Collect WSUS Logs
	# ------------------
	$filesDescription = "WSUS Logs"
	$WSUSLogPath = $WSUSInstallDir + "LogFiles"
	$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_Logs_WSUS")
	$ZipName = "Logs_WSUS.zip"
	TraceOut "WSUS Logs Directory: $WSUSLogPath"

	# Remove temp destination directory if it exists
	If (Test-Path $Destination)	{
		Remove-Item -Path $Destination -Recurse
	}

	# Copy Logs, if they exist.
	If (Test-Path $WSUSLogPath) {
		# ----------------
		# Write Progress
		# ----------------
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WSUSInfo -Status $ScriptStrings.ID_SCCM_WSUSInfo_Compress

		New-Item -ItemType "Directory" $Destination
		Copy-Item ($WSUSLogPath + "\*.log") ($Destination) -Force -ErrorAction SilentlyContinue

		# --------------------------
		# Compress and Collect Logs
		# --------------------------
		compressCollectFiles -DestinationFileName $ZipName -filesToCollect $Destination -sectionDescription $sectionDescription -fileDescription $filesDescription -ForegroundProcess -noFileExtensionsOnDescription
		Remove-Item -Path $Destination -Recurse
	}

	# ----------------
	# Write Progress
	# ----------------
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_WSUSInfo -Status $ScriptStrings.ID_SCCM_WSUSInfo_BasicInfo

	# --------------------------
	# Get WSUS Basic Info
	# --------------------------
	$TempFileName = ($ComputerName + "_WSUS_BasicInfo.txt")
	$TempFileName2 = ($ComputerName + "_WSUS_UpdateApprovals.txt")
	$WSUSBasicInfoFile = Join-Path $PWD.Path $TempFileName
	$ApprovalsFile = Join-Path $Pwd.Path $TempFileName2

	try {
		.\Get-WSUSBasicInfo.ps1 -GetApprovedUpdates -OutputDirectory $PWD.Path -SilentExecution
		CollectFiles -filesToCollect $WSUSBasicInfoFile -fileDescription "WSUS Basic Info" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
		CollectFiles -filesToCollect $ApprovalsFile -fileDescription "WSUS Approved Updates" -sectionDescription $sectiondescription -noFileExtensionsOnDescription
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "WSUS Basic Info" -Value "Review $TempFileName"
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "WSUS Approved Updates" -Value "Review $TempFileName2"
	}
	catch [System.Exception]
	{
		$errMessage = $_.Exception.Message
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "WSUS Basic Info" -Value $errMessage
		Add-Member -InputObject $WSUSInfo -MemberType NoteProperty -Name "WSUS Approved Updates" -Value $errMessage
	}

	# --------------------------
	# Collect WSUS Summary File
	# --------------------------
	# Output WSUSInfo PSObject to Summary File
	$WSUSInfo | Out-File $WSUSFile -Append -Width 500
	CollectFiles -filesToCollect $WSUSFile -fileDescription "WSUS Summary" -sectionDescription $global:SummarySectionDescription -noFileExtensionsOnDescription
}

# ---------------------------------------------------
# Collect WSUS Setup Logs (If not older than 30 days)
# ---------------------------------------------------
$filesDescription = "WSUS Setup Logs"
$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_Logs_WSUSSetup")
$ZipName = "Logs_WSUSSetup.zip"

# Remove temp destination directory if it exists
If (Test-Path $Destination)
{
	Remove-Item -Path $Destination -Recurse
}

# Copy Logs, if they exist and are not older than 30 days
New-Item -ItemType "Directory" $Destination
$dateStart = (Get-Date).AddDays(0-30)
Get-ChildItem $Env:Temp -Recurse -Include "WSUS*.log" | ForEach-Object {
	Copy-Item $_.FullName $Destination
}
compressCollectFiles -DestinationFileName $ZipName -filesToCollect $Destination -sectionDescription $sectionDescription -fileDescription $filesDescription -ForegroundProcess -noFileExtensionsOnDescription
Remove-Item -Path $Destination -Recurse

TraceOut "Completed"
# SIG # Begin signature block
# MIIa6wYJKoZIhvcNAQcCoIIa3DCCGtgCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU4/sDThnfuP69v23qKxgj4dtg
# XgygghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTSMIIE
# zgIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHrMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBSl
# H490J/w+lEnO6yGV+H7vSZ2KczCBigYKKwYBBAGCNwIBDDF8MHqgYIBeAEQASQBB
# AEcAXwBDAFQAUwBfAFMAQwBDAE0AXwAyADAAMQAyAF8AZwBsAG8AYgBhAGwAXwBE
# AEMAXwBXAFMAVQBTAFMAZQByAHYAZQByAEkAbgBmAG8ALgBwAHMAMaEWgBRodHRw
# Oi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQBJttiyJuys3GiEJLV6
# 2XH2XzFf+wNUw7ElKtB+0eUB2d5Fu/eDfuOWzR3CGSIUNejhL+BPPkeU2t3HDBb7
# 6z2izO+HnQ/JCvXdeGV1iL1AWMu4/PATtlqu+jNlKgWo2VAf5Uo4fe2e8KQcQ97Z
# or+VnAIyZHdhJWgDYaZY1JUahUstbptgwmzbBrnuae1sdHh30aBkxeeZZjCfP79J
# VuwuEMLv7Il5PzHDFF4Uelctx8IHm4T42VIhZu9oN8CzZDyYZAyY6u0aNTwXj43p
# pIuOS8VjtOn54R9fRIhrdqLctF5ItnZS7jDt8RyL1gftAemgJJeUneSPaGCjFNNK
# 3fmAoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQQITMwAAAMZ4gDYBdRppcgAAAAAAxjAJBgUrDgMCGgUAoF0w
# GAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcwNDI3
# MTQyMzMwWjAjBgkqhkiG9w0BCQQxFgQUt3LRjLzWU7FmOJ3HZYUCCV0yPI0wDQYJ
# KoZIhvcNAQEFBQAEggEAWqD7lK+R53Yd9BogPmT7a1xeWjiFcFMHUwAwAfKGAIZk
# qf52Jn7ZbRWfsjZ6VRSn6TPd3NOpiVym5Jx6VR8jl0VPc32QxA+2f49XpEH0EYyZ
# vwJADKq6FV5Z3igF1MwD7/qGexRYPZMDeVvd4toQVAT/9Q2u8m70uDUDqX+OHcMh
# 6AO7BbR/jAT5uFqUr8Q7mndscuJdZDob5A0Vsju1eQM2qdn6/sgk8mGMMpXJwwff
# 0FIkxp16KTtJpbbeR5OcNY4OjbkRV8+Km8tSD6LNnDtnTdTQfWOhxdvzNHY3hIMf
# 3JU6IupDzbw3i2BpDrl3jdo+/xkXGwTVX3kEYeWXQA==
# SIG # End signature block
