﻿###########################################################################
# DC_File_ACLs
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Collects File ACL Data
###########################################################################

Import-LocalizedData -BindingVariable FileACL -FileName DC_File_ACLs -UICulture en-us
Write-DiagProgress -Activity $FileACL.ID_FileACL

$ComputerName = $Env:COMPUTERNAME
$SystemRoot = $Env:SystemRoot + "\"
$Drive = $Env:SystemDrive + "\"
$OutputFile = $ComputerName + "_Cacls_Client.txt"

#"Start collecting " + $OutputFile | write-toStdout 
logStart

Set-Content -Encoding unknown $OutputFile "NTFS File Permissions: `n------------------------------------------------------------------`n"

function listACL ([string]$ACL)
{
	Add-Content -Encoding Unknown $OutputFile $ACL
	Get-Acl $ACL | Format-List | Out-File $OutputFile -append
	Add-Content -Encoding Unknown $OutputFile "------------------------------------------------------------------"
}


#$DriveAll = $Drive + "*.*"
$SystemRootAll = $SystemRoot + "*.*"
$DotNetAll = $SystemRoot + "Microsoft.NET\Framework\*.*"
$DotNet1 = $SystemRoot + "Microsoft.NET\Framework\v1.1.4322\*.*"
$DotNet2 = $SystemRoot + "Microsoft.NET\Framework\v2.0.50727\*.*"
$SD = $SystemRoot + "SoftwareDistribution"
$SDAll = $SD + "\*.*"
$Tasks = $SystemRoot + "Tasks"
$TasksAll = $Tasks + "\*.*"


listACL $Drive
listACL $SystemRootAll
listACL $DotNetAll
listACL $DotNet1
listACL $DotNet2
listACL $SD
listACL $SDAll
listACL $Tasks
listACL $TasksAll

CollectFiles -filesToCollect $OutputFile -fileDescription "Cacls Client" -sectionDescription "System Information"

#"Finished collecting " + $OutputFile | write-toStdout  
logStop
