﻿# ***********************************************************************************************************
# Version 1.0
# Date: 03-01-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects Configuration Manager SQL Server Information.
# ***********************************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	$_ | Out-File -FilePath $OutputBase -Append
	continue
}

# ===============================================================
# Function Definitions
# Taken from DC_CollectSQL.ps1 from OpsMgr
# ===============================================================

function WriteConnectionEvents($currentEventID) {
     Get-Event | % {
        if ($_.SourceIdentifier -eq $currentEventID) {
             $CurrentEventIdentifier = $_.EventIdentifier;
            $info = $_.SourceEventArgs
            Remove-Event -EventIdentifier $CurrentEventIdentifier
             $info.Message
         }
     }
}

function Run-SQLCommandtoFile
{
    param (
		$SqlQuery,
		$outFile,
		$DisplayText,
		$collectFiles=$false,
		$fileDescription="",
		$ZipFile="",
		$OutputWidth = 1024,
		[switch]$HideSqlQuery,
		[switch]$NoSecondary
		)
	process
	{
		# Reset DisplayText to SqlQuery if it's not provided
		if ($DisplayText -eq $null) {
			$DisplayText = $SqlQuery
		}

		# Skip secondary site
		if ($NoSecondary -and ($SiteType -eq 2)) {
			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "Not available on a Secondary Site"
			return
		}

		# Standardize text added to summary file "Review $outFileName"
		if ($ZipFile -eq "") {
			$outFileName = $outFile
		}
		else {
			$outFileName = $ZipFile + $outFile.Substring($outFile.LastIndexOf("\"))
		}

		# Hide SQL Query from output if specified
		if ($HideSqlQuery) {
			"=" * ($DisplayText.Length + 4) + "`r`n-- " + $DisplayText + "`r`n" + "=" * ($DisplayText.Length + 4) + "`r`n" | Out-File -FilePath $outFile -Append
			TraceOut "  Current Query = $DisplayText"
		}
		else {
			"=" * ($SqlQuery.Length + 2) + "`r`n-- " + $DisplayText + "`r`n" + $SqlQuery + "`r`n" + "=" * ($SqlQuery.Length + 2) + "`r`n" | Out-File -FilePath $outFile -Append
			TraceOut "  Current Query = $SqlQuery"
		}

		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM12SQL -Status $DisplayText

		$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
		$SqlCmd.CommandText = $SqlQuery
		$SqlCmd.Connection = $global:DatabaseConnection

		$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
		$SqlAdapter.SelectCommand = $SqlCmd

		$SqlTable = New-Object System.Data.DataTable
		try {
			$SqlAdapter.Fill($SqlTable) | out-null

			$results = ($SqlTable | Select * -ExcludeProperty RowError, RowState, HasErrors, Table, ItemArray | Format-Table -AutoSize -Wrap -Property * `
				| Out-String -Width $OutputWidth).Trim()
			$results += "`r`n`r`n"
			$results | Out-File -FilePath $outFile -Append

			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "Review $outFileName"

			If ($collectFiles -eq $true) {
				CollectFiles -filesToCollect $outFile -fileDescription $fileDescription -sectionDescription $sectiondescription -noFileExtensionsOnDescription
			}
		}
		catch [Exception] {
			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "ERROR: $_"
		}
	}
}

function Run-SQLCommandtoFileWithInfo
{
    param (
		$SqlQuery,
		$outFile,
		$DisplayText,
		$collectFiles=$false,
		$ZipFile="",
		[switch]$HideSqlQuery,
		[switch]$SkipEvents
		)
	process
	{
		# Reset DisplayText to SqlQuery if it's not provided
		if ($DisplayText -eq $null) {
			$DisplayText = $SqlQuery
		}

		# Standardize text added to summary file "Review $outFileName"
		if ($ZipFile -eq "") {
			$outFileName = $outFile
		}
		else {
			$outFileName = $ZipFile + $outFile.Substring($outFile.LastIndexOf("\"))
		}

		# Hide SQL Query from output if specified
		if ($HideSqlQuery) {
			"=" * ($DisplayText.Length + 4) + "`r`n-- " + $DisplayText + "`r`n" + "=" * ($DisplayText.Length + 4) + "`r`n" | Out-File -FilePath $outFile -Append
			TraceOut "  Current Query = $DisplayText"
		}
		else {
			"=" * ($SqlQuery.Length + 2) + "`r`n-- " + $DisplayText + "`r`n" + $SqlQuery + "`r`n" + "=" * ($SqlQuery.Length + 2) + "`r`n" | Out-File -FilePath $outFile -Append
			TraceOut "  Current Query = $SqlQuery"
		}

		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM12SQL -Status $DisplayText

		If (-not $SkipEvents) {
			$eventID = $outFile
			Register-ObjectEvent -inputObject $global:DatabaseConnection -eventName InfoMessage -sourceIdentifier $eventID
		}

		$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
		$SqlCmd.Connection = $global:DatabaseConnection
		$SqlCmd.CommandText = $SqlQuery
		$SqlCmd.CommandTimeout = 0

		$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
		$SqlAdapter.SelectCommand = $SqlCmd

		$DataSet = New-Object System.Data.DataSet

		try {
			$SqlAdapter.Fill($DataSet)

			If ($DataSet.Tables.Count -gt 0) {
				foreach ($table in $DataSet.Tables)
				{
					$table | Format-Table -AutoSize | Out-String -width 2048 | Out-File -FilePath $outFile -Append
				}
			}

			If (-not $SkipEvents) {
				If (($RemoteStatus -eq 0) -or ($RemoteStatus -eq 1)) {
					WriteConnectionEvents $eventID | Out-String -width 2048 | Out-File -FilePath $outFile -Append
				}
				Else {
					"Message Information Events cannot be obtained Remotely. Run Diagnostics locally on a Primary or Central Site to obtain this data." | Out-File -FilePath $outFile -Append
				}
			}

			If ($collectFiles -eq $true) {
				CollectFiles -filesToCollect $outFile -fileDescription "$DisplayText" -sectionDescription $sectionDescription -noFileExtensionsOnDescription
			}

			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "Review $outFileName"
		}
		catch [Exception] {
			AddTo-CMDatabaseSummary -NoToSummaryReport -NoToSummaryFile -Name $DisplayText -Value "ERROR: $_"
		}
	}
}

function Get-SQLValue
{
	Param(
		[string]$SqlQuery,
	    [string]$ColumnName,
		[string]$DisplayText
	)

	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM12SQL -Status $DisplayText

	$Result = New-Object -TypeName PSObject

	$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
	$SqlCmd.CommandText = $SqlQuery
	$SqlCmd.Connection = $global:DatabaseConnection

	$SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
	$SqlAdapter.SelectCommand = $SqlCmd

	TraceOut "Current Query = $SqlQuery"
	$SqlTable = New-Object System.Data.DataTable
	try {
		$SqlAdapter.Fill($SqlTable) | out-null
		$ActualValue = $SqlTable | Select -ExpandProperty $ColumnName -ErrorAction SilentlyContinue
		$Result | Add-Member -MemberType NoteProperty -Name "Value" -Value $ActualValue
		$Result | Add-Member -MemberType NoteProperty -Name "Error" -Value $null
	}
	catch [Exception] {
		$Result | Add-Member -MemberType NoteProperty -Name "Value" -Value $null
		$Result | Add-Member -MemberType NoteProperty -Name "Error" -Value $_
	}

	# Return column value
	return $Result
}

function Get-SQLValueWithError
{
	Param(
		[string]$SqlQuery,
	    [string]$ColumnName,
		[string]$DisplayText
	)

	$ResultValue = Get-SQLValue -SqlQuery $SqlQuery -ColumnName $ColumnName -DisplayText $DisplayText
	if ($ResultValue.Error -eq $null) {
		return $ResultValue.Value
	}
	else {
		return $ResultValue.Error
	}
}

function Format-XML ([xml]$xml, $indent=2)
{
    $StringWriter = New-Object System.IO.StringWriter
    $XmlWriter = New-Object System.XMl.XmlTextWriter $StringWriter
    $xmlWriter.Formatting = "indented"
    $xmlWriter.Indentation = $Indent
    $xml.WriteContentTo($XmlWriter)
    $XmlWriter.Flush()
    $StringWriter.Flush()
    return $StringWriter.ToString()
}

#function RunSQLCommandtoCSV
#{
#    param (
#		$cmd,
#		$outfile
#		)
#	process
#	{
#		$out = $ComputerName + "_SQL_" + $outfile + ".csv"

#		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CM12SQL -Status $cmd
#		$da = new-object System.Data.SqlClient.SqlDataAdapter ($cmd, $connnectionstring)
#		$dt = new-object System.Data.DataTable
#		$da.fill($dt) | out-null

#		$dt | Export-CSV -Path $out
#		CollectFiles -filesToCollect $out -fileDescription "$cmd" -sectionDescription $sectiondescription

#	}
#}

# ===========================
# Script Execution
# ===========================

If (!$Is_SiteServer) {
	TraceOut "ConfigMgr Site Server not detected. This script gathers data only from a Site Server. Exiting."
	exit 0
}

TraceOut "Started"
Import-LocalizedData -BindingVariable ScriptStrings
$sectiondescription = "Configuration Manager SQL Data"

TraceOut "ConfigMgr SQL Server: $ConfigMgrDBServer"
TraceOut "ConfigMgr SQL Database: $ConfigMgrDBName"

if ($global:DatabaseConnectionError -ne $null) {
	TraceOut "SQL Connection Failed With Error: $global:DatabaseConnectionError"
	return
}

$Temp = Get-SQLValueWithError -SqlQuery "SELECT name, value_in_use FROM sys.configurations WHERE name = 'max server memory (MB)'" -ColumnName "value_in_use" -DisplayText "Max Server Memory (MB)"
AddTo-CMDatabaseSummary -Name "Max Memory (MB)" -Value $Temp -NoToSummaryQueries

$Temp = Get-SQLValueWithError -SqlQuery "SELECT name, value_in_use FROM sys.configurations WHERE name = 'max degree of parallelism'" -ColumnName "value_in_use" -DisplayText "MDOP"
AddTo-CMDatabaseSummary -Name "MDOP" -Value $Temp -NoToSummaryQueries

# ------------------
# Basic SQL Queries
# ------------------
$OutFile= $ComputerName +  "_SQL_Basic.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT @@SERVERNAME AS [Server Name], @@VERSION AS [SQL Version]" -outFile $OutFile -DisplayText "SQL Version"
Run-SQLCommandtoFile -SqlQuery "SELECT servicename, process_id, startup_type_desc, status_desc,
last_startup_time, service_account, is_clustered, cluster_nodename, [filename]
FROM sys.dm_server_services WITH (NOLOCK) OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "SQL Services" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT cpu_count AS [Logical CPU Count], scheduler_count, hyperthread_ratio AS [Hyperthread Ratio],
cpu_count/hyperthread_ratio AS [Physical CPU Count],
physical_memory_kb/1024 AS [Physical Memory (MB)], committed_kb/1024 AS [Committed Memory (MB)],
committed_target_kb/1024 AS [Committed Target Memory (MB)],
max_workers_count AS [Max Workers Count], affinity_type_desc AS [Affinity Type],
sqlserver_start_time AS [SQL Server Start Time], virtual_machine_type_desc AS [Virtual Machine Type]
FROM sys.dm_os_sys_info WITH (NOLOCK) OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "SQL Server Hardware Info" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "EXEC sp_helpdb" -outFile $OutFile -DisplayText "Databases"
Run-SQLCommandtoFile -SqlQuery "EXEC sp_helprolemember" -outFile $OutFile -DisplayText "Role Members"
Run-SQLCommandtoFile -SqlQuery "SELECT uid, status, name, createdate, islogin, hasdbaccess, updatedate FROM sys.sysusers" -outFile $OutFile -DisplayText "Sys Users"
Run-SQLCommandtoFile -SqlQuery "SELECT status, name, loginname, createdate, updatedate, accdate, dbname, denylogin, hasaccess, sysadmin, securityadmin, serveradmin, setupadmin, processadmin, diskadmin, dbcreator, bulkadmin, isntname, isntgroup, isntuser FROM [master].sys.syslogins" `
	-outFile $OutFile -DisplayText "Sys Logins ([master].sys.syslogins)" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT certificate_id, principal_id, name, subject, pvt_key_encryption_type_desc, expiry_date, start_date, is_active_for_begin_dialog, issuer_name, string_sid, thumbprint, attested_by  FROM [master].sys.certificates" `
	-outFile $OutFile -DisplayText "Certificates ([master].sys.certificates)" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.dm_os_loaded_modules WHERE company <> 'Microsoft Corporation' OR company IS NULL"	`
	-outFile $OutFile -DisplayText "Loaded Modules"

CollectFiles -filesToCollect $OutFile -fileDescription "Basic SQL Information" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ------------------------------------
# Top SP's by CPU, Elapsed Time, etc.
# ------------------------------------
#$OutFile= $ComputerName +  "_SQL_TopQueries.txt"
#Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) DB_NAME(t.[dbid]) AS [Database Name], qs.creation_time AS [Creation Time],
#qs.total_worker_time AS [Total Worker Time], qs.min_worker_time AS [Min Worker Time],
#qs.total_worker_time/qs.execution_count AS [Avg Worker Time],
#qs.max_worker_time AS [Max Worker Time],
#qs.total_elapsed_time/qs.execution_count AS [Avg Elapsed Time],
# qs.execution_count AS [Execution Count],
#qs.total_logical_reads/qs.execution_count AS [Avg Logical Reads],
#qs.total_physical_reads/qs.execution_count AS [Avg Physical Reads],
#rtrim(t.[text]) AS [Query Text]
#FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
#CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS t
#ORDER BY qs.total_worker_time DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 Queries by CPU" -HideSqlQuery
#Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) DB_NAME(t.[dbid]) AS [Database Name], qs.creation_time AS [Creation Time],
#qs.total_elapsed_time  AS [Total Elapsed Time],
#qs.total_elapsed_time/qs.execution_count AS [Avg Elapsed Time],
#qs.total_worker_time AS [Total Worker Time],
#qs.total_worker_time/qs.execution_count AS [Avg Worker Time],
#qs.execution_count AS [Execution Count],
#qs.total_logical_reads/qs.execution_count AS [Avg Logical Reads],
#qs.total_physical_reads/qs.execution_count AS [Avg Physical Reads],
#rtrim(t.[text]) AS [Query Text]
#FROM sys.dm_exec_query_stats AS qs WITH (NOLOCK)
#CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS t
#ORDER BY qs.total_elapsed_time/qs.execution_count DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 Queries by Average Elapsed Time" -HideSqlQuery

$OutFile= $ComputerName +  "_SQL_TopQueries.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) p.name AS [SP Name], qs.total_worker_time AS [TotalWorkerTime],
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime],
qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time, GETDATE()), 0) AS [Calls/Minute],
qs.total_elapsed_time,
qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID() AND qs.execution_count > 0
ORDER BY qs.total_worker_time DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 SPs by CPU" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) p.name AS [SP Name], qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.total_elapsed_time, qs.execution_count, ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time,
GETDATE()), 0) AS [Calls/Minute], qs.total_worker_time/qs.execution_count AS [AvgWorkerTime],
qs.total_worker_time AS [TotalWorkerTime], qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID() AND qs.execution_count > 0
ORDER BY avg_elapsed_time DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 SPs by Average Elapsed Time" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) p.name AS [SP Name], qs.execution_count,
ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time, GETDATE()), 0) AS [Calls/Minute],
qs.total_worker_time/qs.execution_count AS [AvgWorkerTime], qs.total_worker_time AS [TotalWorkerTime],
qs.total_elapsed_time, qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID() AND qs.execution_count > 0
ORDER BY qs.execution_count DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 SPs by Execution Count" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT TOP(50) p.name AS [SP Name], ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time, GETDATE()), 0) AS [Calls/Minute],
qs.total_elapsed_time/qs.execution_count AS [avg_elapsed_time],
qs.total_elapsed_time, qs.total_worker_time/qs.execution_count AS [AvgWorkerTime],
qs.total_worker_time AS [TotalWorkerTime], qs.execution_count, qs.cached_time
FROM sys.procedures AS p WITH (NOLOCK)
INNER JOIN sys.dm_exec_procedure_stats AS qs WITH (NOLOCK)
ON p.[object_id] = qs.[object_id]
WHERE qs.database_id = DB_ID() AND ISNULL(qs.execution_count/DATEDIFF(Minute, qs.cached_time, GETDATE()), 0) > 0  AND qs.execution_count > 0
ORDER BY [Calls/Minute] DESC OPTION (RECOMPILE)" -outFile $OutFile -DisplayText "Top 50 SPs by Calls Per Minute" -HideSqlQuery

CollectFiles -filesToCollect $OutFile -fileDescription "Top Queries" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ------------------
# SQL Transactions
# ------------------
$OutFile= $ComputerName +  "_SQL_Transactions.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT sp.spid, rtrim(sp.status) [status], rtrim(sp.loginame) [Login], rtrim(sp.hostname) [hostname],
sp.blocked BlkBy, sd.name DBName, rtrim(sp.cmd) Command, sp.open_tran, sp.cpu CPUTime, sp.physical_io DiskIO, sp.last_batch LastBatch, rtrim(sp.program_name) [ProgramName], rtrim(qt.text) [Text]
FROM master.dbo.sysprocesses sp
JOIN master.dbo.sysdatabases sd ON sp.dbid = sd.dbid
OUTER APPLY sys.dm_exec_sql_text(sp.sql_handle) AS qt
WHERE sp.blocked <> 0
ORDER BY sp.spid" -outFile $OutFile -DisplayText "Blocked SPIDs" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT sp.spid, rtrim(sp.status) [status], rtrim(sp.loginame) [Login], rtrim(sp.hostname) [hostname],
sp.blocked BlkBy, sd.name DBName, rtrim(sp.cmd) Command, sp.open_tran, sp.cpu CPUTime, sp.physical_io DiskIO, sp.last_batch LastBatch, rtrim(sp.program_name) [ProgramName], rtrim(qt.text) [Text]
FROM master.dbo.sysprocesses sp
JOIN master.dbo.sysdatabases sd ON sp.dbid = sd.dbid
OUTER APPLY sys.dm_exec_sql_text(sp.sql_handle) AS qt
WHERE sp.spid IN (SELECT blocked FROM master.dbo.sysprocesses) AND sp.blocked = 0
ORDER BY sp.spid" -outFile $OutFile -DisplayText "Head Blockers" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT T.*, S.blocked, rtrim(E.text) [Text]
	FROM sys.dm_tran_active_snapshot_database_transactions T
	JOIN sys.dm_exec_requests R ON T.Session_ID = R.Session_ID
	INNER JOIN sys.sysprocesses S on S.spid = T.Session_ID
	OUTER APPLY sys.dm_exec_sql_text(R.sql_handle) AS E
	ORDER BY elapsed_time_seconds DESC" -outFile $OutFile -DisplayText "Active Snapshot Database Transactions" -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "EXEC sp_who2" -outFile $OutFile -DisplayText "sp_who2"
CollectFiles -filesToCollect $OutFile -fileDescription "SQL Transactions" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------------
# List of Site Systems
# ----------------------
$OutFile = $ComputerName + "_SQL_SiteSystems.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT SMSSiteCode, COUNT(1) AS [Number Of DPs] FROM DistributionPoints GROUP BY SMSSiteCode UNION SELECT 'Total' AS SMSSiteCode, COUNT(1) AS [Number Of DPs] FROM DistributionPoints" `
	-outFile $OutFile -DisplayText "Count of All Available Distribution Points by Site"
Run-SQLCommandtoFile -SqlQuery "SELECT SiteCode, ServerName, COUNT(ServerName) AS [Number Of Site System Roles] FROM SysResList GROUP BY SiteCode, ServerName" `
	-outFile $OutFile -DisplayText "Count of All Available Site Systems by Server Name"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM DistributionPoints ORDER BY SMSSiteCode, ServerName" `
	-outFile $OutFile -DisplayText "List of Distribution Points"
Run-SQLCommandtoFile -SqlQuery "SELECT SiteCode, RoleName, ServerName, ServerRemoteName, PublicDNSName, InternetEnabled, Shared, SslState, DomainFQDN, ForestFQDN, IISPreferredPort, IISSslPreferredPort, IsAvailable FROM SysResList ORDER BY SiteCode, ServerName, RoleName" `
	-outFile $OutFile -DisplayText "List of Site Systems"

CollectFiles -filesToCollect $OutFile -fileDescription "List of Site Systems" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ------------------------
# CM Database Information
# ------------------------
$OutFile = $ComputerName + "_SQL_CMDBInfo.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT SiteNumber, SiteCode, TaskName, TaskType, IsEnabled, NumRefreshDays, DaysOfWeek, BeginTime, LatestBeginTime, BackupLocation, DeleteOlderThan FROM vSMS_SC_SQL_Task ORDER BY SiteCode" `
	-outFile $OutFile -DisplayText "ConfigMgr Maintenance Tasks Configuration"
Run-SQLCommandtoFile -SqlQuery "SELECT *, DATEDIFF(S, LastStartTime, LastCompletionTime) As TimeTakenInSeconds, DATEDIFF(MI, LastStartTime, LastCompletionTime) As TimeTakenInMinutes FROM SQLTaskStatus ORDER BY TimeTakenInMinutes DESC" `
	-outFile $OutFile -DisplayText "ConfigMgr Maintenance Tasks Status ($global:SMSSiteCode)"
Run-SQLCommandtoFile -SqlQuery "SELECT *, DATEDIFF(S, LastStartTime, LastSuccessfulCompletionTime) As TimeTakenInSeconds, DATEDIFF(MI, LastStartTime, LastSuccessfulCompletionTime) As TimeTakenInMinutes FROM vSR_SummaryTasks ORDER BY TimeTakenInMinutes DESC" `
	-outFile $OutFile -DisplayText "State System Summary Tasks ($global:SMSSiteCode)" -NoSecondary

Run-SQLCommandtoFile -SqlQuery "SELECT BoundaryType, CASE WHEN BoundaryType = 0 THEN 'IPSUBNET' WHEN BoundaryType = 1 THEN 'ADSITE' WHEN BoundaryType = 2 THEN 'IPV6PREFIX' WHEN BoundaryType = 3 THEN 'IPRANGE' END AS [Type], COUNT(BoundaryType) AS [Count] FROM BoundaryEx GROUP BY BoundaryType" `
	-outFile $OutFile -DisplayText "Boundary Counts"

CollectFiles -filesToCollect $OutFile -fileDescription "ConfigMgr DB Info" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ------------------------
# Site Control File
# ------------------------
$OutFile = $ComputerName + "_SQL_SiteControlFile.xml.txt"
$ResultValue = Get-SQLValue -SqlQuery "SELECT * FROM vSMS_SC_SiteControlXML WHERE SiteCode = '$SMSSiteCode'" -ColumnName "SiteControl" -DisplayText "Site Control File (XML)"

if ($ResultValue.Error -eq $null) {
	try {
		$ScfXml = Format-XML -xml $ResultValue.Value
		$ScfXml | Out-String -Width 4096 | Out-File -FilePath $OutFile -Force
	}
	catch [Exception] {
		$_ | Out-File -FilePath $OutFile -Force
	}
}
else {
	$ResultValue.Error | Out-File -FilePath $OutFile -Force
}

CollectFiles -filesToCollect $OutFile -fileDescription "Site Control File" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ---------------------
# SUP Sync information
# ---------------------
$OutFile = $ComputerName + "_SQL_SUPSync.txt"

Run-SQLCommandtoFile -SqlQuery "SELECT CI.CategoryInstance_UniqueID, CI.CategoryTypeName, LCI.CategoryInstanceName FROM CI_CategoryInstances CI
JOIN CI_LocalizedCategoryInstances LCI ON CI.CategoryInstanceID = LCI.CategoryInstanceID
JOIN CI_UpdateCategorySubscription UCS ON CI.CategoryInstanceID = UCS.CategoryInstanceID
WHERE UCS.IsSubscribed = 1
ORDER BY CI.CategoryTypeName, LCI.CategoryInstanceName" -outFile $OutFile -DisplayText "SUM Products/Classifications" -NoSecondary -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM  vSMS_SUPSyncStatus"-outFile $OutFile -DisplayText "SUP Sync Status" -NoSecondary
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM WSUSServerLocations" -outFile $OutFile -DisplayText "WSUSServerLocations"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM Update_SyncStatus" -outFile $OutFile -DisplayText "Update_SyncStatus"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CI_UpdateSources" -outFile $OutFile -DisplayText "CI_UpdateSources"

CollectFiles -filesToCollect $OutFile -fileDescription "SUP Sync Status" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ---------------------
# OSD Information
# ---------------------
$OutFile = $ComputerName + "_SQL_BootImages.txt"

Run-SQLCommandtoFile -SqlQuery "SELECT * FROM vSMS_OSDeploymentKitInstalled"-outFile $OutFile -DisplayText "ADK Version from Database" -NoSecondary -HideSqlQuery
"========================================" | Out-File $OutFile -Append
"-- ADK Version from Add/Remove Programs " | Out-File $OutFile -Append
"========================================" | Out-File $OutFile -Append
"" | Out-File $OutFile -Append
($global:ADKVersion).Trim() | Out-File $OutFile -Append
"`r`n" | Out-File $OutFile -Append
Run-SQLCommandtoFile -SqlQuery "SELECT PkgID, Name, ImageOSVersion, Version, Architecture, DefaultImage, SourceSite, SourceVersion, LastRefresh, SourceDate, SourceSize, Action, Source, ImagePath FROM vSMS_BootImagePackage_List"-outFile $OutFile -DisplayText "Boot Images" -NoSecondary
Run-SQLCommandtoFile -SqlQuery "SELECT ImageId, Architecture, Name, MsiComponentID, Size, IsRequired, IsManageable FROM vSMS_WinPEOptionalComponentInBootImage ORDER BY ImageId, Architecture"-outFile $OutFile -DisplayText "Optional Components" -NoSecondary
CollectFiles -filesToCollect $OutFile -fileDescription "Boot Images" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------
# DRS Data
# ----------
$ZipName = $ComputerName + "_SQL_DRSData.zip"
$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_SQL_DRSData")
If (Test-Path $Destination) {
	Remove-Item -Path $Destination -Recurse -Force
}
New-Item -ItemType "Directory" $Destination

$OutFile = Join-Path $Destination "spDiagDRS.txt"
Run-SQLCommandtoFileWithInfo -SqlQuery "EXEC spDiagDRS" -outFile $OutFile -DisplayText "spDiagDRS" -ZipFile $ZipName

# Removed spDiagGetSpaceUsed as it takes a long time, and is not absolutely necessary
# $OutFile = Join-Path $Destination "spDiagGetSpaceUsed.txt"
# Run-SQLCommandtoFileWithInfo -SqlQuery "EXEC spDiagGetSpaceUsed" -outFile $OutFile -DisplayText "spDiagGetSpaceUsed" -ZipFile $ZipName

$OutFile = Join-Path $Destination "Sites.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT SiteKey, SiteCode, SiteName, ReportToSite, Status, DetailedStatus, SiteType, BuildNumber, Version, SiteServer, InstallDir, ReplicatesReservedRanges FROM Sites" -outFile $OutFile -DisplayText "Sites Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM ServerData" -outFile $OutFile -DisplayText "ServerData Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT SiteKey, SiteCode, ReportToSite, SiteServer, Settings FROM Sites" -OutputWidth 2048 -outFile $OutFile -DisplayText "Client Operational Settings" -ZipFile $ZipName

$OutFile = Join-Path $Destination "RCM_Tables.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM RCM_ReplicationLinkStatus" -outFile $OutFile -DisplayText "RCM_ReplicationLinkStatus Table Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM RCM_DrsInitializationTracking" -outFile $OutFile -DisplayText "RCM_DrsInitializationTracking Table Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM RCM_RecoveryTracking" -outFile $OutFile -DisplayText "RCM_RecoveryTracking" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM RCM_RecoveryPostAction" -outFile $OutFile -DisplayText "RCM_RecoveryPostAction" -ZipFile $ZipName

$OutFile = Join-Path $Destination "vReplicationLinkStatus.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM vReplicationLinkStatus" -outFile $OutFile -DisplayText "vReplicationLinkStatus Output" -ZipFile $ZipName

$OutFile = Join-Path $Destination "DRS_Tables.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT COUNT (ConflictType) [Count], TableName, ConflictType, ConflictLoserSiteCode FROM DrsConflictInfo GROUP BY TableName, ConflictType, ConflictLoserSiteCode ORDER BY [Count] DESC" -outFile $OutFile -DisplayText "DRS Conflicts Summary (All time)" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT COUNT (ConflictType) [Count], TableName, ConflictType, ConflictLoserSiteCode FROM DrsConflictInfo WHERE ConflictTime > DATEAdd(dd,-5,GETDate()) GROUP BY TableName, ConflictType, ConflictLoserSiteCode ORDER BY [Count] DESC" -outFile $OutFile -DisplayText "DRS Conflicts Summary (Past 5 days)" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM DrsConflictInfo WHERE ConflictTime > DATEAdd(dd,-5,GETDate()) ORDER BY ConflictTime DESC" -outFile $OutFile -DisplayText "DRS Conflicts (Past 5 days)" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM DRSReceiveHistory WHERE ProcessedTime IS NULL" -outFile $OutFile -DisplayText "DRSReceiveHistory Table Output" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM DRSSendHistory WHERE ProcessedTime IS NULL" -outFile $OutFile -DisplayText "DRSSendHistory Table Output" -ZipFile $ZipName

$OutFile = Join-Path $Destination "vLogs.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT TOP 1000 * FROM vLogs WHERE LogText NOT LIKE 'INFO:%' AND LogText NOT LIKE 'Not sending changes to sites%' AND LogText <> 'Web Service heartbeat' AND LogText NOT LIKE 'SYNC%'ORDER BY LogLine DESC" -outFile $OutFile -DisplayText "vLogs Output" -ZipFile $ZipName

$OutFile = Join-Path $Destination "TransmissionQueue.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT COUNT (to_service_name) [Count], to_service_name FROM sys.transmission_queue GROUP BY to_service_name" -outFile $OutFile -DisplayText "Transmission Queue Summary" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.transmission_queue WHERE conversation_handle NOT IN (SELECT handle FROM SSB_DialogPool)" -outFile $OutFile -DisplayText "Orphaned Messages" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.transmission_queue" -outFile $OutFile -DisplayText "Transmission Queue" -ZipFile $ZipName

$OutFile = Join-Path $Destination "EndPointsAndQueues.txt"
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.tcp_endpoints" -outFile $OutFile -DisplayText "TCP Endpoints" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.service_broker_endpoints" -outFile $OutFile -DisplayText "Service Broker Endpoints" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.service_queues" -outFile $OutFile -DisplayText "Service Queues" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM sys.conversation_endpoints" -outFile $OutFile -DisplayText "Conversation Endpoints" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT * FROM SSB_DialogPool" -outFile $OutFile -DisplayText "SSB Dialog Pool" -ZipFile $ZipName

$OutFile = Join-Path $Destination "DRS_Config.txt"
# Run-SQLCommandtoFile -SqlQuery "SELECT * FROM ServerData" -outFile $OutFile -DisplayText "Server Data Table" -ZipFile $ZipName
Run-SQLCommandtoFile -SqlQuery "SELECT SD.SiteCode,
MAX(CASE WHEN vRSCP.Name = 'Degraded' THEN vRSCP.Value END) AS Degraded,
MAX(CASE WHEN vRSCP.Name = 'Failed' THEN vRSCP.Value END) AS Failed,
MAX(CASE WHEN vRSCP.Name = 'DviewForHINV' THEN vRSCP.Value END) AS DviewForHINV,
MAX(CASE WHEN vRSCP.Name = 'DviewForSINV' THEN vRSCP.Value END) AS DviewForSINV,
MAX(CASE WHEN vRSCP.Name = 'DviewForStatusMessages' THEN vRSCP.Value END) AS DviewForStatusMessages,
MAX(CASE WHEN vRSCP.Name = 'SQL Server Service Broker Port' THEN vRSCP.Value END) AS BrokerPort,
MAX(CASE WHEN vRSCP.Name = 'Send History Summarize Interval' THEN vRSCP.Value END) AS SendHistorySummarizeInterval,
MAX(CASE WHEN vRSCP.Name = 'SQL Server Service Broker Port' THEN vRSCP.Value END) AS SSBPort,
MAX(CASE WHEN vRSCP.Name = 'Retention Period' THEN vRSCP.Value END) AS RetentionPeriod,
MAX(CASE WHEN vRSCP.Name = 'IsCompression' THEN vRSCP.Value END) AS IsCompression
FROM vRcmSqlControlProperties vRSCP
JOIN RCMSQlControl RSC ON vRSCP.ID = RSC.ID
JOIN ServerData SD ON RSC.SiteNumber = SD.ID
GROUP BY SD.SiteCode" -outFile $OutFile -DisplayText "RCM Control Properties" -ZipFile $ZipName -HideSqlQuery
Run-SQLCommandtoFile -SqlQuery "SELECT D.name, CTD.* FROM sys.change_tracking_databases AS CTD JOIN sys.databases AS D ON D.database_id = CTD.database_id WHERE D.name = '$ConfigMgrDBNameNoInstance'" -outFile $OutFile -DisplayText "DRS Data Retention Settings" -ZipFile $ZipName

# Compress and Collect
compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription "DRS Data" -Recursive -ForegroundProcess -noFileExtensionsOnDescription
Remove-Item -Path $Destination -Recurse -Force
# CollectFiles -filesToCollect $OutFile -fileDescription "DRS Troubleshooting Data" -sectionDescription $sectiondescription -noFileExtensionsOnDescription

# ----------------------
# Update Servicing Data
# ----------------------
$ZipName = $ComputerName + "_SQL_UpdateServicing.zip"
$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_SQL_UpdateServicing")
If (Test-Path $Destination) {
	Remove-Item -Path $Destination -Recurse -Force
}
New-Item -ItemType "Directory" $Destination

if ($global:SiteBuildNumber -gt 8325) {
	# CM_UpdatePackages
	$OutFile = Join-Path $Destination "CM_UpdatePackages.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackages" -outFile $OutFile -DisplayText "CM_UpdatePackages" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackages_Hist ORDER BY RecordTime DESC" -outFile $OutFile -DisplayText "CM_UpdatePackages_Hist" -ZipFile $ZipName

	# CM_UpdatePackageSiteStatus
	$OutFile = Join-Path $Destination "CM_UpdatePackageSiteStatus.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackageSiteStatus" -outFile $OutFile -DisplayText "CM_UpdatePackageSiteStatus" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackageSiteStatus_HIST ORDER BY RecordTime DESC" -outFile $OutFile -DisplayText "CM_UpdatePackageSiteStatus_HIST" -ZipFile $ZipName

	# CM_UpdatePackageInstallationStatus
	$OutFile = Join-Path $Destination "CM_UpdatePackageInstallationStatus.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackageInstallationStatus ORDER BY MessageTime DESC" -outFile $OutFile -DisplayText "CM_UpdatePackageInstallationStatus" -ZipFile $ZipName

	# CM_UpdateReadiness
	$OutFile = Join-Path $Destination "CM_UpdateReadiness.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdateReadiness" -outFile $OutFile -DisplayText "CM_UpdateReadiness" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdateReadinessSite ORDER BY LastUpdateTime DESC" -outFile $OutFile -DisplayText "CM_UpdateReadinessSite" -ZipFile $ZipName

	# CM_UpdatePackagePrereqStatus
	$OutFile = Join-Path $Destination "CM_UpdatePackagePrereqStatus.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM CM_UpdatePackagePrereqStatus" -outFile $OutFile -DisplayText "CM_UpdatePackagePrereqStatus" -ZipFile $ZipName

	# EasySetupSettings
	$OutFile = Join-Path $Destination "EasySetupSettings.txt"
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM EasySetupSettings" -outFile $OutFile -DisplayText "EasySetupSettings" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT PkgID, Name, SourceVersion, StoredPkgVersion, SourceSite, SourceSize, UpdateMask, Action, Source, StoredPkgPath, StorePkgFlag, ShareType, LastRefresh, PkgFlags, SourceDate, HashVersion FROM SMSPackages WHERE PkgID = (SELECT PackageID FROM EasySetupSettings)" -outFile $OutFile -DisplayText "EasySetup Package" -ZipFile $ZipName
	Run-SQLCommandtoFile -SqlQuery "SELECT * FROM PkgStatus WHERE Type = 1 AND ID = (SELECT PackageID FROM EasySetupSettings)" -outFile $OutFile -DisplayText "EasySetup Package Status" -ZipFile $ZipName

	# Compress and Collect
	compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription "Update Servicing Data" -Recursive -ForegroundProcess -noFileExtensionsOnDescription
	Remove-Item -Path $Destination -Recurse -Force
}
else {
	TraceOut "    Update Servicing Data not collected because Site Build Number $global:SiteBuildNumber is less than 8325."
}

# ---------------------------
# Collect Server Information
# ---------------------------
# Moved to DC_FinishExecution

TraceOut "Completed"
# SIG # Begin signature block
# MIIa5QYJKoZIhvcNAQcCoIIa1jCCGtICAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUhrxMyltCkCOrth9vl7+XnlqE
# 21mgghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTMMIIE
# yAIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIHlMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBRw
# F3l5vlpfj7M+2ASq5nT9f/sywDCBhAYKKwYBBAGCNwIBDDF2MHSgWoBYAEQASQBB
# AEcAXwBDAFQAUwBfAFMAQwBDAE0AXwAyADAAMQAyAF8AZwBsAG8AYgBhAGwAXwBE
# AEMAXwBDAE0AMQAyAFMAUQBMAEkAbgBmAG8ALgBwAHMAMaEWgBRodHRwOi8vbWlj
# cm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQAjq57WYXNbYTaARmDk9cOGnrY6
# 1RVqEJZ0KAbzGnlyhnYJ38n8bAadol32nkqu22QzwHzFHibGGZhm+NDDGeDi1Pek
# WXw3iZG2kLv/cBg1KEE38XGP7vtRKnOWNFH2lkeE3kpavh9QwzkNBn1IjVoNotRk
# qae7aSUhFrXTE2Yy2ahssg82Xwp5+PLItDHWtg4ky2oOaNfa9AlyBqmKQdWROMRo
# dG/9T2srgAiOM/TF2iG1KQoLdU+NQhoL9f+or7ClQq+Mm4Wg7q959TP5AjxWR3YB
# SY4wUezDZDrzi/mZI2jVLlPaofID3aGLsoiG6kQeYa9TFs/y2y1cmk3Sz/AHoYIC
# KDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0
# YW1wIFBDQQITMwAAAMZ4gDYBdRppcgAAAAAAxjAJBgUrDgMCGgUAoF0wGAYJKoZI
# hvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTcwNDI3MTQyMzMx
# WjAjBgkqhkiG9w0BCQQxFgQU1fV3G4AcnXAieGZA0Kd1rwie4r0wDQYJKoZIhvcN
# AQEFBQAEggEAa6OA4igwPtkadB5kgFA0al1kGzdhMeXqVdl8Ehf78YhXOqnkMfDQ
# 44JyW8UNTuK8hx/zf1ZuEy3cKwsJWABz2mZkNeutWFlCDxsIneTzhAg0+emC5HSu
# Xmvhy+fL9c32BCgAHpO/5rub58aWvjlCzi/psYt6Jb59JfgZW6DL647ximLqSEGH
# An9JBpkLDcBMdgeFFlFE9hG1XZ2Yj312S5t75gy9NetMegYq1JoBc6GWfQQbA8FZ
# 9inW96xD5COwDawOiiPwCkUnIbJBYNoR2lNawUgJnMOK0gHT4DPYEJucfJzm4XPn
# Yo7No/ERgLquZGTGHUFpWo4DiFWJuds8pw==
# SIG # End signature block
