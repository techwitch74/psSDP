﻿# *****************************************************************************************
# Version 1.0
# Date: 02-23-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects all Configuration Manager Logs
#		Log Collection flags are pre-set in appropriate utils script.
#		1. Collects CCM Logs.
#		2. Collects SMS Logs.
#		3. Collects most recent copy of CrashDumps and Crash.log for previous 9 crashes.
#		4. Collects Admin Console Logs.
#		5. Collects Site Setup Logs.
#		6. Collects CCMSetup Logs.
#		7. Collects WSUS Logs.
#		8. Collects logs for new CM12 Roles
#		9. Collects Lantern Logs for CM12 Client
#		10. Compresses all logs to ConfigMgrLogs.zip
# *****************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

TraceOut "Started"

TraceOut "GetCCMLogs: $GetCCMLogs"
TraceOut "GetSMSLogs: $GetSMSLogs"
TraceOut "CCMSetup Logs Directory = $CCMSetupLogPath"
TraceOut "AdminUI Logs Directory: $AdminUILogPath"

Import-LocalizedData -BindingVariable ScriptStrings

$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_Logs_ConfigMgr")
$ZipName = "Logs_ConfigMgr.zip"
$Compress = $false
$fileDescription = "ConfigMgr Logs"
$sectionDescription = "Configuration Manager Logs"

# Remove temp destination directory if it exists
If (Test-Path $Destination)
{
	Remove-Item -Path $Destination -Recurse
}

# ---------
# CCM Logs
# ---------

TraceOut "    Getting CCM Logs"
If ($CCMLogPath -ne $null)
{
	# CCM Logs
	If (Test-Path ($CCMLogPath))
	{
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CCM_CollectConfigMgrLogs
		$TempDestination = Join-Path $Destination "CCM_Logs"
		New-Item -ItemType "Directory" $TempDestination

		# Copy-Item ($CCMLogPath + "\*.lo*") ($TempDestination) -ErrorAction SilentlyContinue -Force
		Copy-FilesWithStructure -Source $CCMLogPath -Destination $TempDestination -Include *.lo*

		if (Test-Path (Join-Path $Env:windir "\WindowsUpdate.log")) {
			Copy-Item ($Env:windir + "\WindowsUpdate.log") ($TempDestination) -ErrorAction SilentlyContinue
		}
		$Compress = $true
	}
	Else
	{
		TraceOut "      $CCMLogPath does not exist. CCM Logs not collected. Check Logging\@Global\LogDirectory Registry Key Value."
	}

	if ($GetCCMLogs) {
		# Software Catalog Logs
		TraceOut "    Getting Software Catalog Logs for all users"
		$TempDestination = Join-Path $Destination "CCM_SoftwareCatalog_Logs"
		New-Item -ItemType "Directory" $TempDestination
		if ($OSVersion.Major -lt 6) {
			$ProfilePath = Join-Path $env:systemdrive "Documents and Settings"
			$SLPath = "\Local Settings\Application Data\Microsoft\Silverlight\is"
		}
		else {
			$ProfilePath = Join-Path $env:systemdrive "Users"
			$SLPath = "\AppData\LocalLow\Microsoft\Silverlight\is"
		}

		Get-ChildItem $ProfilePath | `
			foreach {
				if (!$_.Name.Contains("All Users") -and !$_.Name.Contains("Default") -and !$_.Name.Contains("Public") -and !$_.Name.Contains("LocalService") -and !$_.Name.Contains("NetworkService") -and !$_.Name.Contains("Classic .NET AppPool")) {
					$currentUserName = $_.Name
					TraceOut "      Checking user $currentUserName"
					Get-ChildItem -Path (Join-Path $_.FullName $SLpath) -Recurse -Filter *ConfigMgr*.lo* -ErrorAction SilentlyContinue | `
						foreach {
							TraceOut "        Copying ConfigMgr Silverlight logs for $currentUserName"
							Copy-Item -Path $_.FullName -Destination "$TempDestination\$($currentUserName)_$($_)" -Force
							$Compress = $true
						}
				}
			}
	}
}
Else
{
	TraceOut "    Client detected but CCMLogPath is set to null. CCM Logs not collected. Check Logging\@Global\LogDirectory Registry Key Value."
}

# ----------
# SMS Logs
# ----------
TraceOut "    Getting SMS Logs"
If ($SMSLogPath -ne $null)
{
	If (Test-Path ($SMSLogPath))
	{
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_SMS_CollectConfigMgrLogs

		# SMS Logs
		$SubDestination =Join-Path $Destination "SMS_Logs"
		New-Item -ItemType "Directory" $SubDestination
		# Copy-Item ($SMSLogPath + "\*.lo*") $SubDestination
		Copy-Files -Source $SMSLogPath -Destination $SubDestination -Filter *.lo*

		# CrashDumps
		If (Test-Path ($SMSLogPath + "\CrashDumps"))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CrashDumps_CollectConfigMgrLogs
			$CrashDumps = Get-ChildItem ($SMSLogPath + "\CrashDumps") | Sort-Object CreationTime -Descending | Select -first 10
			$i = 0
			for ($i = 0 ; $i -lt $CrashDumps.Length ; $i++)
			{
				if ($i -eq 0)
				{
					Copy-Item $CrashDumps[$i].PSPath ($Destination + "\CrashDumps\" + $CrashDumps[$i] + "_Full") -Recurse
				}
				else
				{
					New-Item -ItemType "Directory" ($Destination + "\CrashDumps\" + $CrashDumps[$i]) -Force
					Copy-Item ($CrashDumps[$i].PSPath + "\crash.log") ($Destination + "\CrashDumps\" + $CrashDumps[$i] + "\crash.log") -ErrorAction SilentlyContinue
				}
			}
		}

		$Compress = $true
	}
	Else
	{
		TraceOut "      $SMSLogPath does not exist. SMS Logs not collected. Check $Reg_SMS\Identification\Installation Directory Registry Key Value."
	}
}
Else
{
	TraceOut "      SMSLogPath is set to null. SMS Logs not collected. Check $Reg_SMS\Identification\Installation Directory Registry Key Value."
}

# Collect SQL Backup Logs. Not implemented for CM07.
If ($Is_SiteServer)
{
	TraceOut "    Getting SQLBackup Logs"
	if ($SQLBackupLogPathUNC -ne $null) {
		if (Test-Path $SQLBackupLogPathUNC) {
			$SubDestination = Join-Path $Destination ("SMSSqlBackup_" + $ConfigMgrDBServer + "_Logs")
			New-Item -ItemType "Directory" $SubDestination

			TraceOut "SubDestination = $SubDestination"
			#Copy-Item ($SQLBackupLogPathUNC + "\*.lo*") $SubDestination
			Copy-Files -Source $SQLBackupLogPathUNC -Destination $SubDestination -Filter *.lo*
			$Compress = $true
		}
		else {
			TraceOut "      $SQLBackupLogPathUNC does not exist or Access Denied. SMS SQL Backup Logs not collected."
		}
	}
	else {
		TraceOut "      SQLBackupLogPathUNC is set to null. SMS SQL Backup Logs not collected."
	}
}

# Collect DP Logs. For CM07, DPLogPath should be null.
TraceOut "    Getting DP Logs"
If ($DPLogPath -ne $null)
{
	If (Test-Path ($DPLogPath))
	{
		New-Item -ItemType "Directory" ($Destination + "\DP_Logs")
		# Copy-Item ($DPLogPath + "\*.lo*") ($Destination + "\DP_Logs")
		Copy-Files -Source $DPLogPath -Destination ($Destination + "\DP_Logs") -Filter *.lo*
		$Compress = $true
	}
	Else
	{
		TraceOut "      $DPLogPath does not exist. DP Logs not collected."
	}
}
Else
{
	TraceOut "      DPLogPath is set to null. DP Logs not collected."
}

# Collect SMSProv Log(s) if SMS Provider is installed on Remote Server.
If ($Is_SMSProv)
{
	If ($Is_SiteServer -eq $false)
	{
		TraceOut "    Getting SMSProv Logs"
		If (Test-Path ($SMSProvLogPath))
		{
			New-Item -ItemType "Directory" ($Destination + "\SMSProv_Logs")
			# Copy-Item ($SMSProvLogPath + "\*.lo*") ($Destination + "\SMSProv_Logs")
			Copy-Files -Source $SMSProvLogPath -Destination ($Destination + "\SMSProv_Logs") -Filter *.lo*

			$Compress = $true
		}
		Else
		{
			TraceOut "      $SMSProvLogPath does not exist. SMS Provider Logs not collected."
		}
	}
}

# Collect AdminUI Logs
If ($Is_AdminUI -and ($RemoteStatus -ne 2))
{
	If ($AdminUILogPath -ne $null)
	{
		TraceOut "    Getting AdminUI Logs"
		If (Test-Path ($AdminUILogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AdminUI_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AdminUI_Logs")
			#$FilesToCopy = Get-ChildItem ($AdminUILogPath + "\*.log") | Where-Object -FilterScript {$_.Name -notlike "*-*"}
			#Copy-Item $FilesToCopy ($Destination + "\AdminUI_Logs")
			Copy-Files -Source $AdminUILogPath -Destination ($Destination + "\AdminUI_Logs") -Filter *.lo*
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AdminUILogPath does not exist. AdminUI Logs not collected."
		}
	}
	Else
	{
		TraceOut "      AdminUI detected but AdminUILogPath is set to null. AdminUI Logs not collected."
	}
}

# Collect Setup logs
If (Test-Path ("$Env:SystemDrive\ConfigMgr*.log"))
{
	If ($RemoteStatus -ne 2) {
		TraceOut "    Getting ConfigMgr Setup Logs"
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Setup_CollectConfigMgrLogs
		New-Item -ItemType "Directory" ($Destination + "\ConfigMgrSetup_Logs")
		Copy-Item ($Env:SystemDrive + "\Config*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		Copy-Item ($Env:SystemDrive + "\Comp*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		Copy-Item ($Env:SystemDrive + "\Ext*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		$Compress = $true
	}
}

# Collect CCM Setup Logs
If (Test-Path ($CCMSetupLogPath))
{
	TraceOut "    Getting CCMSetup Logs"
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CCMSetup_CollectConfigMgrLogs
	New-Item -ItemType "Directory" ($Destination + "\CCMSetupRTM_Logs")
	New-Item -ItemType "Directory" ($Destination + "\CCMSetup_Logs")
	Copy-Item ($CCMSetupLogPath + "\*.log") ($Destination + "\CCMSetupRTM_Logs") -Recurse -Force -ErrorAction SilentlyContinue
	Copy-Item ($CCMSetupLogPath + "\Logs\*.log") ($Destination + "\CCMSetup_Logs") -Recurse -Force -ErrorAction SilentlyContinue

	$Compress = $true
}

# Collect WSUS Logs
#If ($Is_WSUS -and ($RemoteStatus -ne 2))
#{
#	$WSUSLogPath = $WSUSInstallDir + "LogFiles"
#	TraceOut "WSUS Logs Directory: $WSUSLogPath"
#	New-Item -ItemType "Directory" ($Destination + "\WSUS_Logs")
#	Copy-Item ($WSUSLogPath + "\*.log") ($Destination + "\WSUS_Logs") -Force -ErrorAction SilentlyContinue
#	$Compress = $true
#}

# Collect App Catalog Service Logs
If ($Is_AWEBSVC -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting AppCatalogSvc Logs"
	If ($AppCatalogSvcLogPath -ne $null)
	{
		If (Test-Path ($AppCatalogSvcLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AppCat_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AppCatalogSvc_Logs")
			$FilesToCopy = Get-ChildItem ($AppCatalogSvcLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\AppCatalogSvc_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AppCatalogSvcLogPath does not exist. App Catalog Service Logs not collected."
		}
	}
	Else
	{
		TraceOut "      App Catalog Service Role detected but App Catalog Service Log Path is set to null. Logs not collected."
	}
}

# Collect App Catalog Website Logs
If ($Is_PORTALWEB -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting App Catalog Logs"
	If ($AppCatalogLogPath -ne $null)
	{
		If (Test-Path ($AppCatalogLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AppCatSvc_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AppCatalog_Logs")
			$FilesToCopy = Get-ChildItem ($AppCatalogLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\AppCatalog_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AppCatalogLogPath does not exist. App Catalog Logs not collected."
		}
	}
	Else
	{
		TraceOut "      App Catalog Role detected but App Catalog Log Path is set to null. Logs not collected."
	}
}

# Collect Enrollment Point Logs
If ($Is_ENROLLSRV -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Enrollment Point Logs"
	If ($EnrollPointLogPath -ne $null)
	{
		If (Test-Path ($EnrollPointLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollPoint_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\EnrollPoint_Logs")
			$FilesToCopy = Get-ChildItem ($EnrollPointLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\EnrollPoint_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $EnrollPointLogPath does not exist. Enrollment Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Enrollment Point Role detected but Enrollment Point Log Path is set to null. Logs not collected."
	}
}

# Collect Enrollment Proxy Point Logs
If ($Is_ENROLLWEB -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Enrollment Proxy Point Logs"
	If ($EnrollProxyPointLogPath -ne $null)
	{
		If (Test-Path ($EnrollProxyPointLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollProxy_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\EnrollProxyPoint_Logs")
			$FilesToCopy = Get-ChildItem ($EnrollProxyPointLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\EnrollProxyPoint_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $EnrollProxyPointLogPath does not exist. Enrollment Proxy Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Enrollment Proxy Point Role detected but Enrollment Proxy Point Log Path is set to null. Logs not collected."
	}
}

# Collect Certificate Registration Point Logs
If ($Is_CRP -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Certificate Registration Point Logs"
	If ($CRPLogPath -ne $null)
	{
		If (Test-Path ($CRPLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CRP_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\CRP_Logs")
			$FilesToCopy = Get-ChildItem ($CRPLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\CRP_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $CRPLogPath does not exist. Certificate Registration Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Certificate Registration Point Role detected but Certificate Registration Point Log Path is set to null. Logs not collected."
	}
}

If ($Is_Lantern) {
	TraceOut "    Getting Policy Platform Logs"
	If ($LanternLogPath -ne $null)
	{
		If (Test-Path ($LanternLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Lantern_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\PolicyPlatform_Logs")
			Copy-Item $LanternLogPath ($Destination + "\PolicyPlatform_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $LanternLogPath does not exist. Microsoft Policy Platform Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Microsoft Policy Platform is Installed but Log Path is set to null. Logs not collected."
	}
}

If ($Is_PXE) {
	TraceOut "    Getting WDS Logs"
	New-Item -ItemType "Directory" ($Destination + "\WDS_Logs")
	Copy-Item ("$Env:windir\tracing\wds*.log") ($Destination + "\WDS_Logs") -Recurse -Force -ErrorAction SilentlyContinue
	$Compress = $true
}

# Collect System Health Validator Point Logs
If ($Is_SMSSHV -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting System Health Validator Point Logs"
	If ($SMSSHVLogPath -ne $null)
	{
		If (Test-Path ($SMSSHVLogPath))
		{
			#Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollProxy_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\SMSSHV_Logs")
			$FilesToCopy = Get-ChildItem ($SMSSHVLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\SMSSHV_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $SMSSHVLogPath does not exist. System Health Validator Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      System Health Validator Point Role detected but System Health Validator Point Log Path is set to null. Logs not collected."
	}
}

# Compress and Collect Logs if something was copied
If ($Compress)
{
	TraceOut "    Compressing and collecting logs"
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Compress_CollectConfigMgrLogs
	compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription $fileDescription -Recursive -ForegroundProcess -noFileExtensionsOnDescription
	Remove-Item -Path $Destination -Recurse
}

Traceout "Completed"
# SIG # Begin signature block
# MIIjfAYJKoZIhvcNAQcCoIIjbTCCI2kCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDWdpZ41UptdV9F
# 6LDeayJWtwXWzxXMgiDXyKLeeOxpgaCCDYEwggX/MIID56ADAgECAhMzAAAB32vw
# LpKnSrTQAAAAAAHfMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ1WhcNMjExMjAyMjEzMTQ1WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC2uxlZEACjqfHkuFyoCwfL25ofI9DZWKt4wEj3JBQ48GPt1UsDv834CcoUUPMn
# s/6CtPoaQ4Thy/kbOOg/zJAnrJeiMQqRe2Lsdb/NSI2gXXX9lad1/yPUDOXo4GNw
# PjXq1JZi+HZV91bUr6ZjzePj1g+bepsqd/HC1XScj0fT3aAxLRykJSzExEBmU9eS
# yuOwUuq+CriudQtWGMdJU650v/KmzfM46Y6lo/MCnnpvz3zEL7PMdUdwqj/nYhGG
# 3UVILxX7tAdMbz7LN+6WOIpT1A41rwaoOVnv+8Ua94HwhjZmu1S73yeV7RZZNxoh
# EegJi9YYssXa7UZUUkCCA+KnAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUOPbML8IdkNGtCfMmVPtvI6VZ8+Mw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDYzMDA5MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAnnqH
# tDyYUFaVAkvAK0eqq6nhoL95SZQu3RnpZ7tdQ89QR3++7A+4hrr7V4xxmkB5BObS
# 0YK+MALE02atjwWgPdpYQ68WdLGroJZHkbZdgERG+7tETFl3aKF4KpoSaGOskZXp
# TPnCaMo2PXoAMVMGpsQEQswimZq3IQ3nRQfBlJ0PoMMcN/+Pks8ZTL1BoPYsJpok
# t6cql59q6CypZYIwgyJ892HpttybHKg1ZtQLUlSXccRMlugPgEcNZJagPEgPYni4
# b11snjRAgf0dyQ0zI9aLXqTxWUU5pCIFiPT0b2wsxzRqCtyGqpkGM8P9GazO8eao
# mVItCYBcJSByBx/pS0cSYwBBHAZxJODUqxSXoSGDvmTfqUJXntnWkL4okok1FiCD
# Z4jpyXOQunb6egIXvkgQ7jb2uO26Ow0m8RwleDvhOMrnHsupiOPbozKroSa6paFt
# VSh89abUSooR8QdZciemmoFhcWkEwFg4spzvYNP4nIs193261WyTaRMZoceGun7G
# CT2Rl653uUj+F+g94c63AhzSq4khdL4HlFIP2ePv29smfUnHtGq6yYFDLnT0q/Y+
# Di3jwloF8EWkkHRtSuXlFUbTmwr/lDDgbpZiKhLS7CBTDj32I0L5i532+uHczw82
# oZDmYmYmIUSMbZOgS65h797rj5JJ6OkeEUJoAVwwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVUTCCFU0CAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAd9r8C6Sp0q00AAAAAAB3zAN
# BglghkgBZQMEAgEFAKCBpDAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQg72K8GvaX
# hsLfSt4rctDZft34vlBB9Q6szN3dKoFn2AswOAYKKwYBBAGCNwIBDDEqMCigCIAG
# AFQAUwBToRyAGmh0dHBzOi8vd3d3Lm1pY3Jvc29mdC5jb20gMA0GCSqGSIb3DQEB
# AQUABIIBAF5xZDYEjJqjj7/523bQNbmYxPrXLDnO9K70bXPWcI+655XfSG3NbSwf
# weQRxXgdHEdJpqEqactgJKRxQ7joL8WGACDc9lMaOA6FdS1Io38xX+UE4fR/u2yi
# gXXnwL+Gpg1L8oEFLEboAckNFQdOnOVwKkBTmeObGQPol1lX5jVUn1AIK2mxp4Xe
# 6HelXLsucO7c0r2pxYD8XYa31IVP5+N4LTVi3t1T2uEtqQGMjSjNzx3x6nj49x12
# UpHKB3UmPxPG1C8vT6jv4v3h0eTF17ZnwJKMu+RA6nwqKfvVaybyr/Mi3IGto02m
# HO7kAWRKU7Au0uyRfa3qhbQ/nwSx87ihghLlMIIS4QYKKwYBBAGCNwMDATGCEtEw
# ghLNBgkqhkiG9w0BBwKgghK+MIISugIBAzEPMA0GCWCGSAFlAwQCAQUAMIIBUQYL
# KoZIhvcNAQkQAQSgggFABIIBPDCCATgCAQEGCisGAQQBhFkKAwEwMTANBglghkgB
# ZQMEAgEFAAQg9SlZ0PSZhhWKt6WULJgFTgUZ/ssK9d0V5Qk9ZMqmxVECBmCJ1lRL
# wxgTMjAyMTA1MTkyMjIzNTMuNzI3WjAEgAIB9KCB0KSBzTCByjELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFt
# ZXJpY2EgT3BlcmF0aW9uczEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046RDZCRC1F
# M0U3LTE2ODUxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2Wg
# gg48MIIE8TCCA9mgAwIBAgITMwAAAVBYotSnmwsw6wAAAAABUDANBgkqhkiG9w0B
# AQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UE
# BxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYD
# VQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0yMDExMTIxODI2
# MDNaFw0yMjAyMTExODI2MDNaMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2Fz
# aGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENv
# cnBvcmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25z
# MSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpENkJELUUzRTctMTY4NTElMCMGA1UE
# AxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAOd6f5R7KlnDJxtWmg3zM1ICqdmXjT5GNFPHXuCw+9Vg
# 3G897o/Ou5L8nlfaY43oFG35dokBMkm+QKAe9WImqtTtDf1PSpN/TZ85NPOQFHXO
# EHaKEvddJoSlET8vbBJru+AvyOE8WLR1nyeepyP3ptUtpG8+zsA1d4MXfGlk2BRI
# ovYR6AFyZFSx773a5aT81iyPxjcQK/ao+dII0RKp1D3slLgrdHk/MdIIbbFi9FEu
# n5v3QVUjYkJCvUgCP3ZQ2R7bAodtCzlV3IkT7++CDq3Jl1rFbsBWiMirkpx8zf5B
# qE0qmx04ebfsjBiYPUt9OxvS1WFcuNuHujhPpwIqJZsCAwEAAaOCARswggEXMB0G
# A1UdDgQWBBSCVRkfGUXbrWQvQ8EAQzu3659FfjAfBgNVHSMEGDAWgBTVYzpcijGQ
# 80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0w
# MS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0YVBDQV8yMDEwLTA3LTAxLmNy
# dDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# CwUAA4IBAQBRP2h0co7+4+PTwB4vk/YeLEw6ocreg+T0kB2aWB/Ze3zEXtj0EeIV
# A1Zgwp38cjavJg67dIACze3FlpGlqW9jRHXpZYhDML0b2ipIPtA03REzGyKIIwzr
# n+er3FI8iuZiHppNcWAgy6HgYs2TuAxAXJtRuDZmUtmyf2vlHPFf/HxorXuCARYq
# aKKPWWBv/oAT5sA9S4TLLnS5rpT1mzT5uLz8e+dmzo+IzAaG1fP+xGtloBiNsu9o
# Jc6T4NtG8cGhgdBCbflCs9Qh+I1zDfSCIgxHLvFgeOKaX8jFqQwVQnnqYsTdK+dt
# IbForCmk+WQizDkeF6Z1IYezlKWtBNteMIIGcTCCBFmgAwIBAgIKYQmBKgAAAAAA
# AjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0
# aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcNMjUwNzAxMjE0NjU1WjB8MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNy
# b3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIwDQYJKoZIhvcNAQEBBQADggEP
# ADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0VBDVpQoAgoX77XxoSyxfxcPl
# YcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEwRA/xYIiEVEMM1024OAizQt2T
# rNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQedGFnkV+BVLHPk0ySwcSmXdFh
# E24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKxXf13Hz3wV3WsvYpCTUBR0Q+c
# Bj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4GkbaICDXoeByw6ZnNPOcvRLqn
# 9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEAAaOCAeYwggHiMBAGCSsGAQQB
# gjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7fEYbxTNoWoVtVTAZBgkrBgEE
# AYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB
# /zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvXzpoYxDBWBgNVHR8ETzBNMEug
# SaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9N
# aWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsG
# AQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jv
# b0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0gAQH/BIGVMIGSMIGPBgkrBgEE
# AYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9Q
# S0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcA
# YQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZI
# hvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOhIW+z66bM9TG+zwXiqf76V20Z
# MLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS+7lTjMz0YBKKdsxAQEGb3FwX
# /1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlKkVIArzgPF/UveYFl2am1a+TH
# zvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon/VWvL/625Y4zu2JfmttXQOnx
# zplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOiPPp/fZZqkHimbdLhnPkd/DjY
# lPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/fmNZJQ96LjlXdqJxqgaKD4kW
# umGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCIIYdqwUB5vvfHhAN/nMQekkzr3
# ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0cs0d9LiFAR6A+xuJKlQ5slva
# yA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7aKLixqduWsqdCosnPGUFN4Ib5
# KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQcdeh0sVV42neV8HR3jDA/czm
# TfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+NR4Iuto229Nfj950iEkSoYIC
# zjCCAjcCAQEwgfihgdCkgc0wgcoxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVyaWNhIE9wZXJhdGlvbnMx
# JjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOkQ2QkQtRTNFNy0xNjg1MSUwIwYDVQQD
# ExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloiMKAQEwBwYFKw4DAhoDFQAj
# DXufcvE1a0YRm1qWWaQxlh6gEqCBgzCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1w
# IFBDQSAyMDEwMA0GCSqGSIb3DQEBBQUAAgUA5FAD0zAiGA8yMDIxMDUyMDA1Mzgy
# N1oYDzIwMjEwNTIxMDUzODI3WjB3MD0GCisGAQQBhFkKBAExLzAtMAoCBQDkUAPT
# AgEAMAoCAQACAgL9AgH/MAcCAQACAhGRMAoCBQDkUVVTAgEAMDYGCisGAQQBhFkK
# BAIxKDAmMAwGCisGAQQBhFkKAwKgCjAIAgEAAgMHoSChCjAIAgEAAgMBhqAwDQYJ
# KoZIhvcNAQEFBQADgYEALTmnU76RtsG8Unlnx/v8fRLyBzh+He9c/X0FweNr/+Bl
# tXbxCms8acKVMEa2U7omSlueu4YdkZlGw1oABMm+BUXbR1O0NZW3GG7GssrxrOAi
# +OOhvjojogSBeS66anXYRxjM0sTeqdIRt+f4IaD2Gt6NQuhJMXzNwCaCZ6IVxwAx
# ggMNMIIDCQIBATCBkzB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAA
# AVBYotSnmwsw6wAAAAABUDANBglghkgBZQMEAgEFAKCCAUowGgYJKoZIhvcNAQkD
# MQ0GCyqGSIb3DQEJEAEEMC8GCSqGSIb3DQEJBDEiBCCpGEkyY9Ln62LQ2G6CiCdS
# 85hkrr3alsPxWpR1xNJcvjCB+gYLKoZIhvcNAQkQAi8xgeowgecwgeQwgb0EIGz0
# Pp8vmsJOGBcmYYiF1dLohjVmDqinjt2Qonwv8qP2MIGYMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFQWKLUp5sLMOsAAAAAAVAwIgQgJwJq
# 7Kv4gM4ttoOd4Smr9j+BpNnlYaQytX0aRRx3H/0wDQYJKoZIhvcNAQELBQAEggEA
# 208S5S2DsMD9qLejWe2b8KFUUJvwAps5Qxxfs7UyI5XEUdSz1yED3u2vnNm6XI9c
# 5OFDDl8ULuvPZnAhHwA9j9GeoMY1Pmqk+0f2i59gdFiN1ICMRrfbcQxOjoHpqdct
# Yz7YB6vLZ3UQ8j2vIn/NM4rLT1rd3qA21Vt+ljldv30sLX1KS1e2mN7w1awvAX1z
# Z+E6W3bsp+rLno+ByZz6iuOJQtjYBtUgjJ/7FSjC9kac7Noo8gPxBOnxKGQQQpH2
# p78rQHXZwWdDTUTVPjzZA7EezyRZMFRta64ERWrqRlpr4Bh8hCWt130rlQZOHxyY
# grqteMoO4NwJBlmbAAzgdA==
# SIG # End signature block
