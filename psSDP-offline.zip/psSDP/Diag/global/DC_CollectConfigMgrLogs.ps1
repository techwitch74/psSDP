﻿# *****************************************************************************************
# Version 1.0
# Date: 02-23-2012
# Author: Vinay Pamnani - vinpa@microsoft.com
# Description:
# 		Collects all Configuration Manager Logs
#		Log Collection flags are pre-set in appropriate utils script.
#		1. Collects CCM Logs.
#		2. Collects SMS Logs.
#		3. Collects most recent copy of CrashDumps and Crash.log for previous 9 crashes.
#		4. Collects Admin Console Logs.
#		5. Collects Site Setup Logs.
#		6. Collects CCMSetup Logs.
#		7. Collects WSUS Logs.
#		8. Collects logs for new CM12 Roles
#		9. Collects Lantern Logs for CM12 Client
#		10. Compresses all logs to ConfigMgrLogs.zip
# *****************************************************************************************

trap [Exception]
{
	WriteTo-ErrorDebugReport -ErrorRecord $_
	continue
}

TraceOut "Started"

TraceOut "GetCCMLogs: $GetCCMLogs"
TraceOut "GetSMSLogs: $GetSMSLogs"
TraceOut "CCMSetup Logs Directory = $CCMSetupLogPath"
TraceOut "AdminUI Logs Directory: $AdminUILogPath"

Import-LocalizedData -BindingVariable ScriptStrings

$Destination = Join-Path $Env:windir ("\Temp\" + $ComputerName + "_Logs_ConfigMgr")
$ZipName = "Logs_ConfigMgr.zip"
$Compress = $false
$fileDescription = "ConfigMgr Logs"
$sectionDescription = "Configuration Manager Logs"

# Remove temp destination directory if it exists
If (Test-Path $Destination)
{
	Remove-Item -Path $Destination -Recurse
}

# ---------
# CCM Logs
# ---------

TraceOut "    Getting CCM Logs"
If ($CCMLogPath -ne $null)
{
	# CCM Logs
	If (Test-Path ($CCMLogPath))
	{
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CCM_CollectConfigMgrLogs
		$TempDestination = Join-Path $Destination "CCM_Logs"
		New-Item -ItemType "Directory" $TempDestination

		# Copy-Item ($CCMLogPath + "\*.lo*") ($TempDestination) -ErrorAction SilentlyContinue -Force
		Copy-FilesWithStructure -Source $CCMLogPath -Destination $TempDestination -Include *.lo*

		if (Test-Path (Join-Path $Env:windir "\WindowsUpdate.log")) {
			Copy-Item ($Env:windir + "\WindowsUpdate.log") ($TempDestination) -ErrorAction SilentlyContinue
		}
		$Compress = $true
	}
	Else
	{
		TraceOut "      $CCMLogPath does not exist. CCM Logs not collected. Check Logging\@Global\LogDirectory Registry Key Value."
	}

	if ($GetCCMLogs) {
		# Software Catalog Logs
		TraceOut "    Getting Software Catalog Logs for all users"
		$TempDestination = Join-Path $Destination "CCM_SoftwareCatalog_Logs"
		New-Item -ItemType "Directory" $TempDestination
		if ($OSVersion.Major -lt 6) {
			$ProfilePath = Join-Path $env:systemdrive "Documents and Settings"
			$SLPath = "\Local Settings\Application Data\Microsoft\Silverlight\is"
		}
		else {
			$ProfilePath = Join-Path $env:systemdrive "Users"
			$SLPath = "\AppData\LocalLow\Microsoft\Silverlight\is"
		}

		Get-ChildItem $ProfilePath | `
			foreach {
				if (!$_.Name.Contains("All Users") -and !$_.Name.Contains("Default") -and !$_.Name.Contains("Public") -and !$_.Name.Contains("LocalService") -and !$_.Name.Contains("NetworkService") -and !$_.Name.Contains("Classic .NET AppPool")) {
					$currentUserName = $_.Name
					TraceOut "      Checking user $currentUserName"
					Get-ChildItem -Path (Join-Path $_.FullName $SLpath) -Recurse -Filter *ConfigMgr*.lo* -ErrorAction SilentlyContinue | `
						foreach {
							TraceOut "        Copying ConfigMgr Silverlight logs for $currentUserName"
							Copy-Item -Path $_.FullName -Destination "$TempDestination\$($currentUserName)_$($_)" -Force
							$Compress = $true
						}
				}
			}
	}
}
Else
{
	TraceOut "    Client detected but CCMLogPath is set to null. CCM Logs not collected. Check Logging\@Global\LogDirectory Registry Key Value."
}

# ----------
# SMS Logs
# ----------
TraceOut "    Getting SMS Logs"
If ($SMSLogPath -ne $null)
{
	If (Test-Path ($SMSLogPath))
	{
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_SMS_CollectConfigMgrLogs

		# SMS Logs
		$SubDestination =Join-Path $Destination "SMS_Logs"
		New-Item -ItemType "Directory" $SubDestination
		# Copy-Item ($SMSLogPath + "\*.lo*") $SubDestination
		Copy-Files -Source $SMSLogPath -Destination $SubDestination -Filter *.lo*

		# CrashDumps
		If (Test-Path ($SMSLogPath + "\CrashDumps"))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CrashDumps_CollectConfigMgrLogs
			$CrashDumps = Get-ChildItem ($SMSLogPath + "\CrashDumps") | Sort-Object CreationTime -Descending | Select -first 10
			$i = 0
			for ($i = 0 ; $i -lt $CrashDumps.Length ; $i++)
			{
				if ($i -eq 0)
				{
					Copy-Item $CrashDumps[$i].PSPath ($Destination + "\CrashDumps\" + $CrashDumps[$i] + "_Full") -Recurse
				}
				else
				{
					New-Item -ItemType "Directory" ($Destination + "\CrashDumps\" + $CrashDumps[$i]) -Force
					Copy-Item ($CrashDumps[$i].PSPath + "\crash.log") ($Destination + "\CrashDumps\" + $CrashDumps[$i] + "\crash.log") -ErrorAction SilentlyContinue
				}
			}
		}

		$Compress = $true
	}
	Else
	{
		TraceOut "      $SMSLogPath does not exist. SMS Logs not collected. Check $Reg_SMS\Identification\Installation Directory Registry Key Value."
	}
}
Else
{
	TraceOut "      SMSLogPath is set to null. SMS Logs not collected. Check $Reg_SMS\Identification\Installation Directory Registry Key Value."
}

# Collect SQL Backup Logs. Not implemented for CM07.
If ($Is_SiteServer)
{
	TraceOut "    Getting SQLBackup Logs"
	if ($SQLBackupLogPathUNC -ne $null) {
		if (Test-Path $SQLBackupLogPathUNC) {
			$SubDestination = Join-Path $Destination ("SMSSqlBackup_" + $ConfigMgrDBServer + "_Logs")
			New-Item -ItemType "Directory" $SubDestination

			TraceOut "SubDestination = $SubDestination"
			#Copy-Item ($SQLBackupLogPathUNC + "\*.lo*") $SubDestination
			Copy-Files -Source $SQLBackupLogPathUNC -Destination $SubDestination -Filter *.lo*
			$Compress = $true
		}
		else {
			TraceOut "      $SQLBackupLogPathUNC does not exist or Access Denied. SMS SQL Backup Logs not collected."
		}
	}
	else {
		TraceOut "      SQLBackupLogPathUNC is set to null. SMS SQL Backup Logs not collected."
	}
}

# Collect DP Logs. For CM07, DPLogPath should be null.
TraceOut "    Getting DP Logs"
If ($DPLogPath -ne $null)
{
	If (Test-Path ($DPLogPath))
	{
		New-Item -ItemType "Directory" ($Destination + "\DP_Logs")
		# Copy-Item ($DPLogPath + "\*.lo*") ($Destination + "\DP_Logs")
		Copy-Files -Source $DPLogPath -Destination ($Destination + "\DP_Logs") -Filter *.lo*
		$Compress = $true
	}
	Else
	{
		TraceOut "      $DPLogPath does not exist. DP Logs not collected."
	}
}
Else
{
	TraceOut "      DPLogPath is set to null. DP Logs not collected."
}

# Collect SMSProv Log(s) if SMS Provider is installed on Remote Server.
If ($Is_SMSProv)
{
	If ($Is_SiteServer -eq $false)
	{
		TraceOut "    Getting SMSProv Logs"
		If (Test-Path ($SMSProvLogPath))
		{
			New-Item -ItemType "Directory" ($Destination + "\SMSProv_Logs")
			# Copy-Item ($SMSProvLogPath + "\*.lo*") ($Destination + "\SMSProv_Logs")
			Copy-Files -Source $SMSProvLogPath -Destination ($Destination + "\SMSProv_Logs") -Filter *.lo*

			$Compress = $true
		}
		Else
		{
			TraceOut "      $SMSProvLogPath does not exist. SMS Provider Logs not collected."
		}
	}
}

# Collect AdminUI Logs
If ($Is_AdminUI -and ($RemoteStatus -ne 2))
{
	If ($AdminUILogPath -ne $null)
	{
		TraceOut "    Getting AdminUI Logs"
		If (Test-Path ($AdminUILogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AdminUI_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AdminUI_Logs")
			#$FilesToCopy = Get-ChildItem ($AdminUILogPath + "\*.log") | Where-Object -FilterScript {$_.Name -notlike "*-*"}
			#Copy-Item $FilesToCopy ($Destination + "\AdminUI_Logs")
			Copy-Files -Source $AdminUILogPath -Destination ($Destination + "\AdminUI_Logs") -Filter *.lo*
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AdminUILogPath does not exist. AdminUI Logs not collected."
		}
	}
	Else
	{
		TraceOut "      AdminUI detected but AdminUILogPath is set to null. AdminUI Logs not collected."
	}
}

# Collect Setup logs
If (Test-Path ("$Env:SystemDrive\ConfigMgr*.log"))
{
	If ($RemoteStatus -ne 2) {
		TraceOut "    Getting ConfigMgr Setup Logs"
		Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Setup_CollectConfigMgrLogs
		New-Item -ItemType "Directory" ($Destination + "\ConfigMgrSetup_Logs")
		Copy-Item ($Env:SystemDrive + "\Config*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		Copy-Item ($Env:SystemDrive + "\Comp*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		Copy-Item ($Env:SystemDrive + "\Ext*.lo*") ($Destination + "\ConfigMgrSetup_Logs") -Force -ErrorAction SilentlyContinue
		$Compress = $true
	}
}

# Collect CCM Setup Logs
If (Test-Path ($CCMSetupLogPath))
{
	TraceOut "    Getting CCMSetup Logs"
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CCMSetup_CollectConfigMgrLogs
	New-Item -ItemType "Directory" ($Destination + "\CCMSetupRTM_Logs")
	New-Item -ItemType "Directory" ($Destination + "\CCMSetup_Logs")
	Copy-Item ($CCMSetupLogPath + "\*.log") ($Destination + "\CCMSetupRTM_Logs") -Recurse -Force -ErrorAction SilentlyContinue
	Copy-Item ($CCMSetupLogPath + "\Logs\*.log") ($Destination + "\CCMSetup_Logs") -Recurse -Force -ErrorAction SilentlyContinue

	$Compress = $true
}

# Collect WSUS Logs
#If ($Is_WSUS -and ($RemoteStatus -ne 2))
#{
#	$WSUSLogPath = $WSUSInstallDir + "LogFiles"
#	TraceOut "WSUS Logs Directory: $WSUSLogPath"
#	New-Item -ItemType "Directory" ($Destination + "\WSUS_Logs")
#	Copy-Item ($WSUSLogPath + "\*.log") ($Destination + "\WSUS_Logs") -Force -ErrorAction SilentlyContinue
#	$Compress = $true
#}

# Collect App Catalog Service Logs
If ($Is_AWEBSVC -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting AppCatalogSvc Logs"
	If ($AppCatalogSvcLogPath -ne $null)
	{
		If (Test-Path ($AppCatalogSvcLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AppCat_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AppCatalogSvc_Logs")
			$FilesToCopy = Get-ChildItem ($AppCatalogSvcLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\AppCatalogSvc_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AppCatalogSvcLogPath does not exist. App Catalog Service Logs not collected."
		}
	}
	Else
	{
		TraceOut "      App Catalog Service Role detected but App Catalog Service Log Path is set to null. Logs not collected."
	}
}

# Collect App Catalog Website Logs
If ($Is_PORTALWEB -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting App Catalog Logs"
	If ($AppCatalogLogPath -ne $null)
	{
		If (Test-Path ($AppCatalogLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_AppCatSvc_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\AppCatalog_Logs")
			$FilesToCopy = Get-ChildItem ($AppCatalogLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\AppCatalog_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $AppCatalogLogPath does not exist. App Catalog Logs not collected."
		}
	}
	Else
	{
		TraceOut "      App Catalog Role detected but App Catalog Log Path is set to null. Logs not collected."
	}
}

# Collect Enrollment Point Logs
If ($Is_ENROLLSRV -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Enrollment Point Logs"
	If ($EnrollPointLogPath -ne $null)
	{
		If (Test-Path ($EnrollPointLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollPoint_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\EnrollPoint_Logs")
			$FilesToCopy = Get-ChildItem ($EnrollPointLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\EnrollPoint_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $EnrollPointLogPath does not exist. Enrollment Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Enrollment Point Role detected but Enrollment Point Log Path is set to null. Logs not collected."
	}
}

# Collect Enrollment Proxy Point Logs
If ($Is_ENROLLWEB -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Enrollment Proxy Point Logs"
	If ($EnrollProxyPointLogPath -ne $null)
	{
		If (Test-Path ($EnrollProxyPointLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollProxy_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\EnrollProxyPoint_Logs")
			$FilesToCopy = Get-ChildItem ($EnrollProxyPointLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\EnrollProxyPoint_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $EnrollProxyPointLogPath does not exist. Enrollment Proxy Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Enrollment Proxy Point Role detected but Enrollment Proxy Point Log Path is set to null. Logs not collected."
	}
}

# Collect Certificate Registration Point Logs
If ($Is_CRP -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting Certificate Registration Point Logs"
	If ($CRPLogPath -ne $null)
	{
		If (Test-Path ($CRPLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_CRP_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\CRP_Logs")
			$FilesToCopy = Get-ChildItem ($CRPLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\CRP_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $CRPLogPath does not exist. Certificate Registration Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Certificate Registration Point Role detected but Certificate Registration Point Log Path is set to null. Logs not collected."
	}
}

If ($Is_Lantern) {
	TraceOut "    Getting Policy Platform Logs"
	If ($LanternLogPath -ne $null)
	{
		If (Test-Path ($LanternLogPath))
		{
			Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Lantern_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\PolicyPlatform_Logs")
			Copy-Item $LanternLogPath ($Destination + "\PolicyPlatform_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $LanternLogPath does not exist. Microsoft Policy Platform Logs not collected."
		}
	}
	Else
	{
		TraceOut "      Microsoft Policy Platform is Installed but Log Path is set to null. Logs not collected."
	}
}

If ($Is_PXE) {
	TraceOut "    Getting WDS Logs"
	New-Item -ItemType "Directory" ($Destination + "\WDS_Logs")
	Copy-Item ("$Env:windir\tracing\wds*.log") ($Destination + "\WDS_Logs") -Recurse -Force -ErrorAction SilentlyContinue
	$Compress = $true
}

# Collect System Health Validator Point Logs
If ($Is_SMSSHV -and ($RemoteStatus -ne 2))
{
	TraceOut "    Getting System Health Validator Point Logs"
	If ($SMSSHVLogPath -ne $null)
	{
		If (Test-Path ($SMSSHVLogPath))
		{
			#Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_EnrollProxy_CollectConfigMgrLogs
			New-Item -ItemType "Directory" ($Destination + "\SMSSHV_Logs")
			$FilesToCopy = Get-ChildItem ($SMSSHVLogPath + "\*.*")
			Copy-Item $FilesToCopy ($Destination + "\SMSSHV_Logs")
			$Compress = $true
		}
		Else
		{
			TraceOut "      $SMSSHVLogPath does not exist. System Health Validator Point Logs not collected."
		}
	}
	Else
	{
		TraceOut "      System Health Validator Point Role detected but System Health Validator Point Log Path is set to null. Logs not collected."
	}
}

# Compress and Collect Logs if something was copied
If ($Compress)
{
	TraceOut "    Compressing and collecting logs"
	Write-DiagProgress -Activity $ScriptStrings.ID_SCCM_ACTIVITY_CollectConfigMgrLogs -Status $ScriptStrings.ID_SCCM_Compress_CollectConfigMgrLogs
	compressCollectFiles -DestinationFileName $ZipName -filesToCollect ($Destination + "\*.*") -sectionDescription $sectionDescription -fileDescription $fileDescription -Recursive -ForegroundProcess -noFileExtensionsOnDescription
	Remove-Item -Path $Destination -Recurse
}

Traceout "Completed"
# SIG # Begin signature block
# MIIa+QYJKoZIhvcNAQcCoIIa6jCCGuYCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUD0EJRRO9zEkbcoePFSmCCrNh
# tY2gghWDMIIEwzCCA6ugAwIBAgITMwAAAMZ4gDYBdRppcgAAAAAAxjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwOTA3MTc1ODUz
# WhcNMTgwOTA3MTc1ODUzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkY1MjgtMzc3Ny04QTc2MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEArQsjG6jKiCgU
# NuPDaF0GhCh1QYcSqJypNAJgoa1GtgoNrKXTDUZF6K+eHPNzXv9v/LaYLZX2GyOI
# 9lGz55tXVv1Ny6I1ueVhy2cUAhdE+IkVR6AtCo8Ar8uHwEpkyTi+4Ywr6sOGM7Yr
# wBqw+SeaBjBwON+8E8SAz0pgmHHj4cNvt5A6R+IQC6tyiFx+JEMO1qqnITSI2qx3
# kOXhD3yTF4YjjRnTx3HGpfawUCyfWsxasAHHlILEAfsVAmXsbr4XAC2HBZGKXo03
# jAmfvmbgbm3V4KBK296Unnp92RZmwAEqL08n+lrl+PEd6w4E9mtFHhR9wGSW29C5
# /0bOar9zHwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFNS/9jKwiDEP5hmU8T6/Mfpb
# Ag8JMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAJhbANzvo0iL5FA5Z5QkwG+PvkDfOaYsTYksqFk+MgpqzPxc
# FwSYME/S/wyihd4lwgQ6CPdO5AGz3m5DZU7gPS5FcCl10k9pTxZ4s857Pu8ZrE2x
# rnUyUiQFl5DYSNroRPuQYRZZXs2xK1WVn1JcwcAwJwfu1kwnebPD90o1DRlNozHF
# 3NMaIo0nCTRAN86eSByKdYpDndgpVLSoN2wUnsh4bLcZqod4ozdkvgGS7N1Af18R
# EFSUBVraf7MoSxKeNIKLLyhgNxDxZxrUgnPb3zL73zOj40A1Ibw3WzJob8vYK+gB
# YWORl4jm6vCwAq/591z834HDNH60Ud0bH+xS7PowggTtMIID1aADAgECAhMzAAAB
# QJap7nBW/swHAAEAAAFAMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTE2MDgxODIwMTcxN1oXDTE3MTEwMjIwMTcxN1owgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBANtLi+kDal/IG10KBTnk1Q6S0MThi+ikDQUZWMA81ynd
# ibdobkuffryavVSGOanxODUW5h2s+65r3Akw77ge32z4SppVl0jII4mzWSc0vZUx
# R5wPzkA1Mjf+6fNPpBqks3m8gJs/JJjE0W/Vf+dDjeTc8tLmrmbtBDohlKZX3APb
# LMYb/ys5qF2/Vf7dSd9UBZSrM9+kfTGmTb1WzxYxaD+Eaxxt8+7VMIruZRuetwgc
# KX6TvfJ9QnY4ItR7fPS4uXGew5T0goY1gqZ0vQIz+lSGhaMlvqqJXuI5XyZBmBre
# ueZGhXi7UTICR+zk+R+9BFF15hKbduuFlxQiCqET92ECAwEAAaOCAWEwggFdMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBSc5ehtgleuNyTe6l6pxF+QHc7Z
# ezBSBgNVHREESzBJpEcwRTENMAsGA1UECxMETU9QUjE0MDIGA1UEBRMrMjI5ODAz
# K2Y3ODViMWMwLTVkOWYtNDMxNi04ZDZhLTc0YWU2NDJkZGUxYzAfBgNVHSMEGDAW
# gBTLEejK0rQWWAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8v
# Y3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0Ff
# MDgtMzEtMjAxMC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRw
# Oi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0z
# MS0yMDEwLmNydDANBgkqhkiG9w0BAQUFAAOCAQEAa+RW49cTHSBA+W3p3k7bXR7G
# bCaj9+UJgAz/V+G01Nn5XEjhBn/CpFS4lnr1jcmDEwxxv/j8uy7MFXPzAGtOJar0
# xApylFKfd00pkygIMRbZ3250q8ToThWxmQVEThpJSSysee6/hU+EbkfvvtjSi0lp
# DimD9aW9oxshraKlPpAgnPWfEj16WXVk79qjhYQyEgICamR3AaY5mLPuoihJbKwk
# Mig+qItmLPsC2IMvI5KR91dl/6TV6VEIlPbW/cDVwCBF/UNJT3nuZBl/YE7ixMpT
# Th/7WpENW80kg3xz6MlCdxJfMSbJsM5TimFU98KNcpnxxbYdfqqQhAQ6l3mtYDCC
# BbwwggOkoAMCAQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmS
# JomT8ixkARkWA2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UE
# AxMkTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgz
# MTIyMTkzMloXDTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgT
# Cldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29m
# dCBDb3Jwb3JhdGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQ
# Q0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAg
# Qpl2U2w+G9ZvzMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn0
# 8GisTUuNpb15S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqel
# cnNW8ReU5P01lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQw
# WfjSjWL9y8lfRjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vX
# T2Pn0i1i8UU956wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJ
# XwPTAgMBAAGjggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK
# 0rQWWAHJNy4zFha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEA
# ATAjBgkrBgEEAYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ
# 5KQwUAYDVR0fBEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3Br
# aS9jcmwvcHJvZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEB
# BEgwRjBEBggrBgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNyb3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5
# Pn8mRq/rb0CxMrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9M
# uqKoVpzjcLu4tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOl
# VuC4iktX8pVCnPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7I
# G9KPcpUqcW2bGvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/Ta
# rtSCMm78pJUT5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhc
# yTUWX92THUmOLb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zK
# wexwo1eSV32UjaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K
# 3RDeZPRvzkbU0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO
# 7bN2edgKNAltHIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdib
# Ia4NXJzwoq6GaIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HO
# iMm4GPoOco3Boz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZo
# NAAAAAAAHDANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkw
# FwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9v
# dCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAz
# MTMwMzA5WjB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7R
# p9FMrXQwIBHrB9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y
# 9GccLPx754gd6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYu
# J6yGT1VSDOQDLPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdm
# EScpZqiX5NMGgUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68e
# eEExd8yb3zuDk6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAP
# BgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzAL
# BgNVHQ8EBAMCAYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyC
# YEBWJ5flJRP8KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8E
# STBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsG
# AQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFJvb3RDZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0B
# AQUFAAOCAgEAEJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxt
# YrhXAstOIBNQmd16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1P
# q5Lk541q1YDB5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxn
# LcVRDupiXD8WmIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/
# xTUrXqO/67x9C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW
# 6J1wlGysOUzU9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146So
# dDW4TsVxIxImdgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD
# 6Svpu/RIzCzU2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9
# iaF2YbRuoROmv6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpj
# tHhUBdRBLlCslLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J
# 4PcBZW+JC33Iacjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTgMIIE
# 3AIBATCBkDB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMw
# IQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAUCWqe5wVv7M
# BwABAAABQDAJBgUrDgMCGgUAoIH5MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEE
# MBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBRd
# lA/tjz8tilZ1nfwSypOcjgokmjCBmAYKKwYBBAGCNwIBDDGBiTCBhqBsgGoARABJ
# AEEARwBfAEMAVABTAF8AUwBDAEMATQBfADIAMAAxADIAXwBnAGwAbwBiAGEAbABf
# AEQAQwBfAEMAbwBsAGwAZQBjAHQAQwBvAG4AZgBpAGcATQBnAHIATABvAGcAcwAu
# AHAAcwAxoRaAFGh0dHA6Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIB
# ANrA6DQmPAq+iFzHDsiWEkIP5lCnO+Ul1c5fRZQfPUACa/t7BVHoLs0BFdV2zsLU
# OjZQPZqFa9GzUegT0VYqN/xEVQLV6w2MN5I3hOz7bVVLAiJBzxMmWjfFl0BKh+N/
# BtMorWIhg3JI/JUAvYH2b/b6RMFfpq9dNn19iwgSYsuUrhBiQReJhXkvneZYB1Hw
# 42APmjJvS2T9FULsiAzkZiUuMErd6Fa7UEz9CKaYKy/DJwsyRVYCyJUZGJXK8SFq
# H7w4UfodxkfA5oQa1lNG0WssGMMw6lojNPo+wuypDW2e7PE7jctStOuCVikvm2Br
# +RKGjmHZp9kIw6uKFgFehDShggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEw
# gY4wdzELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UE
# AxMYTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBAhMzAAAAxniANgF1GmlyAAAAAADG
# MAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3
# DQEJBTEPFw0xNzA0MjcxNDIzMzBaMCMGCSqGSIb3DQEJBDEWBBRlj9EML+OlM+eF
# xeM6wONkoG70XzANBgkqhkiG9w0BAQUFAASCAQCCl8UrSbTXSUhAzgG/g4Tg4cge
# clpsS0i2JV3aXgzKt3171uf5bgouwjupQWQfV3Wzbsj5nS3fjfIJreCrIRwXeu9R
# 7jKxEu3y4TYAZLwp+MIXVpPqUCYZ1KVxhlyDaGnqkgGfkIPBoy247M+zXCI9ToxW
# FQp2c3PrXgsPS3KiVNHyQFmJAdaGyfd16vdrBsYc3DWcSBVxSWqKzoS3Tmngjwjs
# IGySX8MQtr+iID2xAwh59P6F1Gshs4OYDKK0G1C7FCU060zGJuWqxnz5uHpUMO6z
# hWA64EsIzBbSUwi/2yBCVTl7Dddmnx5M3FLAFJyIvoYS53fL9VxK6HkCE/MN
# SIG # End signature block
