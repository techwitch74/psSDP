﻿###########################################################################
# DC_Dirs
# Version 1.0
# Date: 09-26-2012
# Author: mifannin
# Description: Collects Directory output
###########################################################################
Import-LocalizedData -BindingVariable Dirs -FileName DC_Dirs -UICulture en-us
Write-DiagProgress -Activity $Dirs.ID_Dirs  

$ProgFiles64 = $ENV:ProgramFiles 
$IEx64 = $ProgFiles64 + "\Internet Explorer" 
$ProgFiles86 = ${Env:ProgramFiles(x86)} 
$IEx86 = $ProgFiles86 + "\Internet Explorer" 
$Profile = $Env:USERPROFILE

function DirectoryOutput ([string]$dir) 
{
	##$CommandLineToExecute = "cmd.exe /c dir /s $dir > $OutputFile"
	#Invoke-Expression $CommandLineToExecute
	##RunCMD -commandToRun $CommandLineToExecute -filesToCollect $OutputFile -fileDescription $fDesc -sectionDescription $sDesc
	Write-DiagProgress -Activity $Dirs.ID_Dirs  $dir
	Get-ChildItem -Recurse $dir | Select-Object Name, directory, Length, CreationTime, LastWriteTime, Attributes | Export-Csv $OutputFile 
	CollectFiles -filesToCollect $Outputfile -fileDescription $fDesc -sectionDescription $sDesc
	
	#Invoke-Expression "cmd.exe /c dir /s $dir > $OutputFile"
	#Write-Host $CommandLineToExecute
}

#Output of Windows\System32\Drivers\*
$dir = $windir + "\System32\drivers"
$OutputFile = $ComputerName + "_Dir_Drivers.csv"
$fDesc = "Drivers directory"
$sDesc = "System Information"
logstart 
DirectoryOutput $dir $fDesc $sDesc 

#Output of Internet Explorer (x86)
if ($OSVersion.Major -gt 6)
{
	$dir = $IEx86
	$OutputFile = $ComputerName + "_Dir_InternetExplorer(x86).csv"
	$fDesc = "Internet Explorer (x86) Directory"
	$fDesc = "Internet Explorer"
	logstart
	DirectoryOutput $dir
}

#Output of Internet Explorer 
$dir = $IEx64
$OutputFile = $ComputerName + "_Dir_InternetExplorer.csv"
$fDesc = "Internet Explorer Directory"
$sDesc = "Internet Explorer"
logstart
DirectoryOutput $dir

#Output of Software Distribution
$dir = $windir + "\SoftwareDistribution"
$OutputFile = $ComputerName + "_Dir_SoftwareDistribution.csv"
$fDesc = "Software Distribution Directory"
$sDesc = "Windows Update Information"
logstart
DirectoryOutput $dir

#Output of Catroot
$dir = $windir + "\System32\Catroot"
$OutputFile = $ComputerName + "_Dir_Catroot.csv"
$fDesc = "Catroot Directory"
$sDesc = "Windows Update Information"
logstart
DirectoryOutput $dir

#Output of CBS
$dir = $windir + "\Servicing"
$OutputFile = $ComputerName + "_Dir_CBS.csv"
$OutCSV = $ComputerName + "_Dir_CBS.csv"
$fDesc = "Servicing Directory"
$sDesc = "CBS Information"
logstart
DirectoryOutput $dir
#Get-ChildItem -Recurse $dir | Export-Csv $OutCSV
#CollectFiles -filesToCollect $OutCSV -fileDescription $fDesc -sectionDescription $sDesc

#Output of Winsxs
$dir = $windir + "\Winsxs"
$OutputFile = $ComputerName + "_Dir_Winsxs.csv"
$OutCSV = $ComputerName + "_Dir_Winsxs.csv"
$fDesc = "Winsxs Directory"
$sDesc = "CBS Information"
logstart
DirectoryOutput $dir
#Get-ChildItem -recurse $dir | Export-Csv $OutCSV
#CollectFiles -filesToCollect $OutCSV -fileDescription $fDesc -sectionDescription $sDesc

#Output of Temporary Internet Files

if ($OSVersion.Major -gt 6)
	{
		$dir = $PROFILE + "\AppData\Local\Microsoft\Windows\Temporary Internet Files"
		#$OutputFile = $ComputerName + "_Dir_TempInternet.csv"
		$OutCSV = $ComputerName + "_Dir_TempInternet.csv"
		$fDesc = "Temp Internet Files Directory"
		$sDesc = "Internet Explorer"
		logstart 
		Get-ChildItem -Force -Recurse $dir -EA SilentlyContinue | Select-Object Name, directory, Length, CreationTime, LastWriteTime, Attributes | Export-Csv $OutCSV
		CollectFiles -filesToCollect $OutCSV -fileDescription $fDesc -sectionDescription $sDesc
	}
elseif ($OSVersion.Major -lt 6)
	{	
		$dir = $PROFILE + "\Local Settings\Temporary Internet Files" 
		#$OutputFile = $ComputerName + "_Dir_TempInternet.csv"
		$fDesc = "Temp Internet Files Directory"
		$sDesc = "Internet Explorer"
		$OutCSV = $ComputerName + "_Dir_TempInternet.csv"
		logstart 
		Get-ChildItem -Force -Recurse $dir -EA SilentlyContinue | Select-Object Name, directory, Length, CreationTime, LastWriteTime, Attributes | Export-Csv $OutCSV
		CollectFiles -filesToCollect $OutCSV -fileDescription $fDesc -sectionDescription $sDesc
	}


logstop 








