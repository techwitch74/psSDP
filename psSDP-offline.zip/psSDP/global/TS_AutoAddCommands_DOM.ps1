﻿	# Obtain pstat output [AutoAdded]
	Run-DiagExpression .\DC_PStat.ps1

	# Collect Machine Registry Information for Setup and Performance Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_RegistrySetupPerf.ps1

	# CheckSym [AutoAdded]
	Run-DiagExpression .\DC_ChkSym.ps1

	# List Schedule Tasks using schtasks.exe utility [AutoAdded]
	Run-DiagExpression .\DC_ScheduleTasks.ps1

	# Collects information about Driver Verifier (verifier.exe utility) [AutoAdded]
	Run-DiagExpression .\DC_Verifier.ps1

	# Collects Windows Server 2008/R2 Server Manager Information [AutoAdded]
	Run-DiagExpression .\DC_ServerManagerInfo.ps1

	# Update History [AutoAdded]
	Run-DiagExpression .\DC_UpdateHistory.ps1

	# Collects System and Application Event Logs  [AutoAdded]
	Run-DiagExpression .\DC_SystemAppEventLogs.ps1

	# GPResults.exe Output [AutoAdded]
	Run-DiagExpression .\DC_RSoP.ps1

	# User Rights (privileges) via the userrights.exe tool [AutoAdded]
	Run-DiagExpression .\DC_UserRights.ps1

	# WhoAmI [AutoAdded]
	Run-DiagExpression .\DC_Whoami.ps1

	# Applied Security Templates [AutoAdded]
	Run-DiagExpression .\DC_AppliedSecTempl.ps1

	# DCDiag information [AutoAdded]
	Run-DiagExpression .\TS_DCDiag.ps1

	# Collects functional level and local group membership information (DSMisc) [AutoAdded]
	Run-DiagExpression .\DC_DSMisc.ps1

	# Obtain Netlogon Log [AutoAdded]
	Run-DiagExpression .\DC_NetlogonLog.ps1

	# Collects NetSetup.Log from %windir%\debug [AutoAdded]
	Run-DiagExpression .\DC_NetSetupLog.ps1

	# Collects winlogon Log from %windir%\security\logs\winlogon.log  [AutoAdded]
	Run-DiagExpression .\DC_WinlogonLog.ps1

	# Run Repadmin tool with showrepl argument and obtain output [AutoAdded]
	Run-DiagExpression .\DC_Repadmin.ps1

	# Collects system security settings (INF) via secedit utility [AutoAdded]
	Run-DiagExpression .\DC_SystemSecuritySettingsINF.ps1

	# BPA DS [AutoAdded]
	Run-DiagExpression .\DC_BPA-DS.ps1

	# Collects registry entries for Directory Services support [AutoAdded]
	Run-DiagExpression .\DC_DSRegEntries.ps1

	# auditpol output [AutoAdded]
	Run-DiagExpression .\DC_AuditPol.ps1

	# Check for ephemeral port usage [AutoAdded]
	Run-DiagExpression .\TS_PortUsage.ps1

	# Kerberos tickets and TGT via klist utility [AutoAdded]
	Run-DiagExpression .\DC_KList.ps1

	# DCPromo Logs [AutoAdded]
	Run-DiagExpression .\DC_DCPromoLogs.ps1

	# Determines FSMO role owners [AutoAdded]
	Run-DiagExpression .\DC_NetdomFSMO.ps1

	# Copies Userenv Log files [AutoAdded]
	Run-DiagExpression .\DC_UserenvLogs.ps1

	# Collects W32Time information [AutoAdded]
	Run-DiagExpression .\DC_W32Time.ps1

	# Collects environment variables (output of SET command) [AutoAdded]
	Run-DiagExpression .\DC_EnvVars.ps1

	# Collecting Secure Channel Info [AutoAdded]
	Run-DiagExpression .\DC_SecureChannelInfo.ps1

	# TCPIP Component [AutoAdded]
	Run-DiagExpression .\DC_TCPIP-Component.ps1

	# DHCP Client Component [AutoAdded]
	Run-DiagExpression .\DC_DhcpClient-Component.ps1

	# DNS Client Component [AutoAdded]
	Run-DiagExpression .\DC_DNSClient-Component.ps1

	# WINSClient [AutoAdded]
	Run-DiagExpression .\DC_WINSClient-Component.ps1

	# SMB Client Component [AutoAdded]
	Run-DiagExpression .\DC_SMBClient-Component.ps1

	# SMB Server Component [AutoAdded]
	Run-DiagExpression .\DC_SMBServer-Component.ps1

	# RPC [AutoAdded]
	Run-DiagExpression .\DC_RPC-Component.ps1

	# Firewall [AutoAdded]
	Run-DiagExpression .\DC_Firewall-Component.ps1

	# IPsec [AutoAdded]
	Run-DiagExpression .\DC_IPsec-Component.ps1

	# Hyper-V Networking Settings [AutoAdded]
	Run-DiagExpression .\DC_HyperVNetworking.ps1

	# Hyper-V Network Virtualization [AutoAdded]
	Run-DiagExpression .\DC_HyperVNetworkVirtualization.ps1

	# NetworkAdapters [AutoAdded]
	Run-DiagExpression .\DC_NetworkAdapters-Component.ps1

	# NetLBFO [AutoAdded]
	Run-DiagExpression .\DC_NetLBFO-Component.ps1

	# Check AD Replication Status [AutoAdded]
	Run-DiagExpression .\TS_ADReplCheck.ps1

	# Checks if CrashOnAuditFail is either 1 or 2 [AutoAdded]
	Run-DiagExpression .\TS_CrashOnAuditFailCheck.ps1

	# SYSVOL and/or NETLOGON shares are missing on domain controller [AutoAdded]
	Run-DiagExpression .\TS_LSASSHighCPU.ps1

	# SYSVOL and/or NETLOGON shares are missing on domain controller [AutoAdded]
	Run-DiagExpression .\TS_SysvolNetLogonShareCheck.ps1

	# Missing Rid Set reference attribute detected [AutoAdded]
	Run-DiagExpression .\TS_ADRidSetReferenceCheck.ps1

	# AD Integrated DNS Server should not point only to itself if it has replica partners. [AutoAdded]
	Run-DiagExpression .\TS_DCCheckDnsExclusiveToSelf.ps1

	# [Idea ID 3768] [Windows] New rule to verify USN Roll Back [AutoAdded]
	Run-DiagExpression .\TS_USNRollBackCheck.ps1

	# [Idea ID 2882] [Windows] The stop of Intersite Messaging service on ISTG causes DFSN cannot calculate site costs [AutoAdded]
	Run-DiagExpression .\TS_IntersiteMessagingStateCheck.ps1

	# [Idea ID 2831] [Windows] DFSR Reg setting UpdateWorkerThreadCount = 64 may cause hang [AutoAdded]
	Run-DiagExpression .\TS_DfsrUpdateWorkerThreadCountCheck.ps1

	# [Idea ID 2593] [Windows] UDP 389 on DC does not respond [AutoAdded]
	Run-DiagExpression .\TS_IPv6DisabledonDCCheck.ps1

	# [Idea ID 4724] [Windows] W32Time and time skew [AutoAdded]
	Run-DiagExpression .\TS_Win32TimeTimeSkewRegCheck.ps1

	# [Idea ID 5009] [Windows] Weak Key Block Detection [AutoAdded]
	Run-DiagExpression .\TS_DetectWeakKeys.ps1

	# [Idea ID 6816] [Windows] Detect Certificate Root Store Size Problems [AutoAdded]
	Run-DiagExpression .\TS_DetectRootSize.ps1

	# Detect 4KB Drives (Disk Sector Size) [AutoAdded]
	Run-DiagExpression .\TS_DriveSectorSizeInfo.ps1

	# EMC Replistor Software installation detected but KB 975759 is not installed [AutoAdded]
	Run-DiagExpression .\TS_ReplistorCheck.ps1

	# Warning if Windows Server 2008 Service Pack 1, We end support Windows Server 2008 SP1 on July 12, advice customer to upgrade to SP2. [AutoAdded]
	Run-DiagExpression .\TS_ServicePackKB2590494Check.ps1

	# Checks 32 bit windows server 2003 / 2008 to see is DEP is disabled, if so it might not detect more than 4 GB of RAM. [AutoAdded]
	Run-DiagExpression .\TS_DEPDisabled4GBCheck.ps1

	# Check for Sophos BEFLT.SYS version 5.60.1.7 [AutoAdded]
	Run-DiagExpression .\TS_B2693877_Sophos_BEFLTCheck.ps1

	# [Idea ID 2695] [Windows] Check the Log On account for the Telnet service to verify it's not using the Local System account [AutoAdded]
	Run-DiagExpression .\TS_TelnetSystemAccount.ps1

	# [Idea ID 2842] [Windows] Alert Engineers if they are working on a Dell machine models R910, R810 and M910 [AutoAdded]
	Run-DiagExpression .\TS_DellPowerEdgeBiosCheck.ps1

	# [Idea ID 2389] [Windows] Hang caused by kernel memory depletion due 'SystemPages' reg key with wrong value [AutoAdded]
	Run-DiagExpression .\TS_MemoryManagerSystemPagesCheck.ps1

	# Detect Virtualization [AutoAdded]
	Run-DiagExpression .\TS_Virtualization.ps1

	# [Idea ID 7065] [Windows] Alert users about Windows XP EOS [AutoAdded]
	Run-DiagExpression .\TS_WindowsXPEOSCheck.ps1

	# [KSE Rule] [ Windows V3] HpCISSs2 version 62.26.0.64 causes 0xD1 or 0x9E [AutoAdded]
	Run-DiagExpression .\TS_HpCISSs2DriverIssueCheck.ps1

	# Detects and alerts evaluation media [AutoAdded]
	Run-DiagExpression .\TS_EvalMediaDetection.ps1

	# Debug/GFlags check [AutoAdded]
	Run-DiagExpression .\TS_DebugFlagsCheck.ps1

	# Check DFSR configuration [AutoAdded]
	Run-DiagExpression .\TS_DFSRRootCausesCheck.ps1

	# SMB2ClientDriverStateCheck [AutoAdded]
	Run-DiagExpression .\TS_SMB2ClientDriverStateCheck.ps1

	# SMB2ServerDriverStateCheck [AutoAdded]
	Run-DiagExpression .\TS_SMB2ServerDriverStateCheck.ps1

	# Opportunistic Locking has been disabled and may impact performance. [AutoAdded]
	Run-DiagExpression .\TS_LockingKB296264Check.ps1

	# Evaluates whether InfocacheLevel should be increased to 0x10 hex. To resolve slow logon, slow boot issues. [AutoAdded]
	Run-DiagExpression .\TS_InfoCacheLevelCheck.ps1

	# RC_HTTPRedirectionTSGateway [AutoAdded]
	Run-DiagExpression .\RC_HTTPRedirectionTSGateway.ps1

	# RSASHA512 Certificate TLS 1.2 Compat Check [AutoAdded]
	Run-DiagExpression .\TS_DetectSHA512-TLS.ps1

	# RC_KB2647170_CnameCheck [AutoAdded]
	Run-DiagExpression .\RC_KB2647170_CnameCheck.ps1

	# IPv6Check [AutoAdded]
	Run-DiagExpression .\TS_IPv6Check.ps1

	# IPv66To4Check [AutoAdded]
	Run-DiagExpression .\RC_IPv66To4Check.ps1

	# RC_32GBMemoryKB2634907 [AutoAdded]
	Run-DiagExpression .\RC_32GBMemoryKB2634907.ps1

	# PMTU Check [AutoAdded]
	Run-DiagExpression .\TS_PMTUCheck.ps1

	# Checks for modified TcpIP Reg Parameters and recommend KB [AutoAdded]
	Run-DiagExpression .\TS_TCPIPSettingsCheck.ps1

	# 'Checks if the number of 6to4 adapters is larger than the number of physical adapters [AutoAdded]
	Run-DiagExpression .\TS_AdapterKB980486Check.ps1

	# Checks if Windows Server 2008 R2 SP1, Hyper-V, and Tunnel.sys driver are installed if they are generate alert [AutoAdded]
	Run-DiagExpression .\TS_ServerCoreKB978309Check.ps1

	# [Idea ID 2749] [Windows] SBSL Windows firewall delays acquisition of DHCP address from DHCP relay on domain-joined W7 client [AutoAdded]
	Run-DiagExpression .\TS_SBSL_DHCPRelayKB2459530.ps1

	# Missing Enterprise Hotfix Rollup for Windows7/Windows2008R2 (KB2775511) [AutoAdded]
	Run-DiagExpression .\TS_HyperVEvent106Check.ps1

	# Missing Enterprise Hotfix Rollup for Windows7/Windows2008R2 (KB2775511) [AutoAdded]
	Run-DiagExpression .\TS_KB2775511Check.ps1

	# [Idea ID 7521] [Windows] McAfee HIPS 7.0 adds numerous extraneous network adapter interfaces to registry [AutoAdded]
	Run-DiagExpression .\TS_McAfeeHIPS70Check.ps1

	# Symantec Intrusion Prevenstion System Check [AutoAdded]
	Run-DiagExpression .\TS_SymantecIPSCheck.ps1

	# [Idea ID 7345] [Windows] Perfmon - Split IO Counter [AutoAdded]
	Run-DiagExpression .\TS_DetectSplitIO.ps1

	# Directory Services related Event Logs [AutoAdded]
	Run-DiagExpression .\DC_ADEventLogs.ps1

	# Active Directory environment data collection scripts. [AutoAdded]
	Run-DiagExpression .\DC_CurrentDomainInfo.ps1
      .\DC_DCSiteInfo.ps1
      .\DC_ForestInfo.ps1
      .\DC_TrustList.ps1
      .\DC_UserLogonInfo.ps1


# SIG # Begin signature block
# MIIa8AYJKoZIhvcNAQcCoIIa4TCCGt0CAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQU3VvJnS/bye95HHMRF/luj+PK
# 8CegghV6MIIEuzCCA6OgAwIBAgITMwAAAFrtL/TkIJk/OgAAAAAAWjANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTQwNTIzMTcxMzE1
# WhcNMTUwODIzMTcxMzE1WjCBqzELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAldBMRAw
# DgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24x
# DTALBgNVBAsTBE1PUFIxJzAlBgNVBAsTHm5DaXBoZXIgRFNFIEVTTjpCOEVDLTMw
# QTQtNzE0NDElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZTCC
# ASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALMhIt9q0L/7KcnVbHqJqY0T
# vJS16X0pZdp/9B+rDHlhZlRhlgfw1GBLMZsJr30obdCle4dfdqHSxinHljqjXxeM
# duC3lgcPx2JhtLaq9kYUKQMuJrAdSgjgfdNcMBKmm/a5Dj1TFmmdu2UnQsHoMjUO
# 9yn/3lsgTLsvaIQkD6uRxPPOKl5YRu2pRbRptlQmkRJi/W8O5M/53D/aKWkfSq7u
# wIJC64Jz6VFTEb/dqx1vsgpQeAuD7xsIsxtnb9MFfaEJn8J3iKCjWMFP/2fz3uzH
# 9TPcikUOlkYUKIccYLf1qlpATHC1acBGyNTo4sWQ3gtlNdRUgNLpnSBWr9TfzbkC
# AwEAAaOCAQkwggEFMB0GA1UdDgQWBBS+Z+AuAhuvCnINOh1/jJ1rImYR9zAfBgNV
# HSMEGDAWgBQjNPjZUkZwCu1A+3b7syuwwzWzDzBUBgNVHR8ETTBLMEmgR6BFhkNo
# dHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNyb3Nv
# ZnRUaW1lU3RhbXBQQ0EuY3JsMFgGCCsGAQUFBwEBBEwwSjBIBggrBgEFBQcwAoY8
# aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNyb3NvZnRUaW1l
# U3RhbXBQQ0EuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEBBQUA
# A4IBAQAgU4KQrqZNTn4zScizrcTDfhXQEvIPJ4p/W78+VOpB6VQDKym63VSIu7n3
# 2c5T7RAWPclGcLQA0fI0XaejIiyqIuFrob8PDYfQHgIb73i2iSDQLKsLdDguphD/
# 2pGrLEA8JhWqrN7Cz0qTA81r4qSymRpdR0Tx3IIf5ki0pmmZwS7phyPqCNJp5mLf
# cfHrI78hZfmkV8STLdsWeBWqPqLkhfwXvsBPFduq8Ki6ESus+is1Fm5bc/4w0Pur
# k6DezULaNj+R9+A3jNkHrTsnu/9UIHfG/RHpGuZpsjMnqwWuWI+mqX9dEhFoDCyj
# MRYNviGrnPCuGnxA1daDFhXYKPvlMIIE7DCCA9SgAwIBAgITMwAAAMps1TISNcTh
# VQABAAAAyjANBgkqhkiG9w0BAQUFADB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTAeFw0xNDA0MjIxNzM5MDBaFw0xNTA3MjIxNzM5MDBaMIGDMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQD
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCWcV3tBkb6hMudW7dGx7DhtBE5A62xFXNgnOuntm4aPD//ZeM08aal
# IV5WmWxY5JKhClzC09xSLwxlmiBhQFMxnGyPIX26+f4TUFJglTpbuVildGFBqZTg
# rSZOTKGXcEknXnxnyk8ecYRGvB1LtuIPxcYnyQfmegqlFwAZTHBFOC2BtFCqxWfR
# +nm8xcyhcpv0JTSY+FTfEjk4Ei+ka6Wafsdi0dzP7T00+LnfNTC67HkyqeGprFVN
# TH9MVsMTC3bxB/nMR6z7iNVSpR4o+j0tz8+EmIZxZRHPhckJRIbhb+ex/KxARKWp
# iyM/gkmd1ZZZUBNZGHP/QwytK9R/MEBnAgMBAAGjggFgMIIBXDATBgNVHSUEDDAK
# BggrBgEFBQcDAzAdBgNVHQ4EFgQUH17iXVCNVoa+SjzPBOinh7XLv4MwUQYDVR0R
# BEowSKRGMEQxDTALBgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNTk1K2I0MjE4ZjEz
# LTZmY2EtNDkwZi05YzQ3LTNmYzU1N2RmYzQ0MDAfBgNVHSMEGDAWgBTLEejK0rQW
# WAHJNy4zFha5TJoKHzBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jv
# c29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNDb2RTaWdQQ0FfMDgtMzEtMjAx
# MC5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY0NvZFNpZ1BDQV8wOC0zMS0yMDEwLmNy
# dDANBgkqhkiG9w0BAQUFAAOCAQEAd1zr15E9zb17g9mFqbBDnXN8F8kP7Tbbx7Us
# G177VAU6g3FAgQmit3EmXtZ9tmw7yapfXQMYKh0nfgfpxWUftc8Nt1THKDhaiOd7
# wRm2VjK64szLk9uvbg9dRPXUsO8b1U7Brw7vIJvy4f4nXejF/2H2GdIoCiKd381w
# gp4YctgjzHosQ+7/6sDg5h2qnpczAFJvB7jTiGzepAY1p8JThmURdwmPNVm52Iao
# AP74MX0s9IwFncDB1XdybOlNWSaD8cKyiFeTNQB8UCu8Wfz+HCk4gtPeUpdFKRhO
# lludul8bo/EnUOoHlehtNA04V9w3KDWVOjic1O1qhV0OIhFeezCCBbwwggOkoAMC
# AQICCmEzJhoAAAAAADEwDQYJKoZIhvcNAQEFBQAwXzETMBEGCgmSJomT8ixkARkW
# A2NvbTEZMBcGCgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9z
# b2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5MB4XDTEwMDgzMTIyMTkzMloX
# DTIwMDgzMTIyMjkzMloweTELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0
# b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3Jh
# dGlvbjEjMCEGA1UEAxMaTWljcm9zb2Z0IENvZGUgU2lnbmluZyBQQ0EwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCycllcGTBkvx2aYCAgQpl2U2w+G9Zv
# zMvx6mv+lxYQ4N86dIMaty+gMuz/3sJCTiPVcgDbNVcKicquIEn08GisTUuNpb15
# S3GbRwfa/SXfnXWIz6pzRH/XgdvzvfI2pMlcRdyvrT3gKGiXGqelcnNW8ReU5P01
# lHKg1nZfHndFg4U4FtBzWwW6Z1KNpbJpL9oZC/6SdCnidi9U3RQwWfjSjWL9y8lf
# RjFQuScT5EAwz3IpECgixzdOPaAyPZDNoTgGhVxOVoIoKgUyt0vXT2Pn0i1i8UU9
# 56wIAPZGoZ7RW4wmU+h6qkryRs83PDietHdcpReejcsRj1Y8wawJXwPTAgMBAAGj
# ggFeMIIBWjAPBgNVHRMBAf8EBTADAQH/MB0GA1UdDgQWBBTLEejK0rQWWAHJNy4z
# Fha5TJoKHzALBgNVHQ8EBAMCAYYwEgYJKwYBBAGCNxUBBAUCAwEAATAjBgkrBgEE
# AYI3FQIEFgQU/dExTtMmipXhmGA7qDFvpjy82C0wGQYJKwYBBAGCNxQCBAweCgBT
# AHUAYgBDAEEwHwYDVR0jBBgwFoAUDqyCYEBWJ5flJRP8KuEKU5VZ5KQwUAYDVR0f
# BEkwRzBFoEOgQYY/aHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvbWljcm9zb2Z0cm9vdGNlcnQuY3JsMFQGCCsGAQUFBwEBBEgwRjBEBggr
# BgEFBQcwAoY4aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNy
# b3NvZnRSb290Q2VydC5jcnQwDQYJKoZIhvcNAQEFBQADggIBAFk5Pn8mRq/rb0Cx
# MrVq6w4vbqhJ9+tfde1MOy3XQ60L/svpLTGjI8x8UJiAIV2sPS9MuqKoVpzjcLu4
# tPh5tUly9z7qQX/K4QwXaculnCAt+gtQxFbNLeNK0rxw56gNogOlVuC4iktX8pVC
# nPHz7+7jhh80PLhWmvBTI4UqpIIck+KUBx3y4k74jKHK6BOlkU7IG9KPcpUqcW2b
# Gvgc8FPWZ8wi/1wdzaKMvSeyeWNWRKJRzfnpo1hW3ZsCRUQvX/TartSCMm78pJUT
# 5Otp56miLL7IKxAOZY6Z2/Wi+hImCWU4lPF6H0q70eFW6NB4lhhcyTUWX92THUmO
# Lb6tNEQc7hAVGgBd3TVbIc6YxwnuhQ6MT20OE049fClInHLR82zKwexwo1eSV32U
# jaAbSANa98+jZwp0pTbtLS8XyOZyNxL0b7E8Z4L5UrKNMxZlHg6K3RDeZPRvzkbU
# 0xfpecQEtNP7LN8fip6sCvsTJ0Ct5PnhqX9GuwdgR2VgQE6wQuxO7bN2edgKNAlt
# HIAxH+IOVN3lofvlRxCtZJj/UBYufL8FIXrilUEnacOTj5XJjdibIa4NXJzwoq6G
# aIMMai27dmsAHZat8hZ79haDJLmIz2qoRzEvmtzjcT3XAH5iR9HOiMm4GPoOco3B
# oz2vAkBq/2mbluIQqBC0N1AI1sM9MIIGBzCCA++gAwIBAgIKYRZoNAAAAAAAHDAN
# BgkqhkiG9w0BAQUFADBfMRMwEQYKCZImiZPyLGQBGRYDY29tMRkwFwYKCZImiZPy
# LGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQDEyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZp
# Y2F0ZSBBdXRob3JpdHkwHhcNMDcwNDAzMTI1MzA5WhcNMjEwNDAzMTMwMzA5WjB3
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEwHwYDVQQDExhN
# aWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCfoWyx39tIkip8ay4Z4b3i48WZUSNQrc7dGE4kD+7Rp9FMrXQwIBHr
# B9VUlRVJlBtCkq6YXDAm2gBr6Hu97IkHD/cOBJjwicwfyzMkh53y9GccLPx754gd
# 6udOo6HBI1PKjfpFzwnQXq/QsEIEovmmbJNn1yjcRlOwhtDlKEYuJ6yGT1VSDOQD
# LPtqkJAwbofzWTCd+n7Wl7PoIZd++NIT8wi3U21StEWQn0gASkdmEScpZqiX5NMG
# gUqi+YSnEUcUCYKfhO1VeP4Bmh1QCIUAEDBG7bfeI0a7xC1Un68eeEExd8yb3zuD
# k6FhArUdDbH895uyAc4iS1T/+QXDwiALAgMBAAGjggGrMIIBpzAPBgNVHRMBAf8E
# BTADAQH/MB0GA1UdDgQWBBQjNPjZUkZwCu1A+3b7syuwwzWzDzALBgNVHQ8EBAMC
# AYYwEAYJKwYBBAGCNxUBBAMCAQAwgZgGA1UdIwSBkDCBjYAUDqyCYEBWJ5flJRP8
# KuEKU5VZ5KShY6RhMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAXBgoJkiaJk/Is
# ZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eYIQea0WoUqgpa1Mc1j0BxMuZTBQBgNVHR8ESTBHMEWgQ6BB
# hj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9taWNy
# b3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEESDBGMEQGCCsGAQUFBzAChjho
# dHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jvc29mdFJvb3RD
# ZXJ0LmNydDATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQUFAAOCAgEA
# EJeKw1wDRDbd6bStd9vOeVFNAbEudHFbbQwTq86+e4+4LtQSooxtYrhXAstOIBNQ
# md16QOJXu69YmhzhHQGGrLt48ovQ7DsB7uK+jwoFyI1I4vBTFd1Pq5Lk541q1YDB
# 5pTyBi+FA+mRKiQicPv2/OR4mS4N9wficLwYTp2OawpylbihOZxnLcVRDupiXD8W
# mIsgP+IHGjL5zDFKdjE9K3ILyOpwPf+FChPfwgphjvDXuBfrTot/xTUrXqO/67x9
# C0J71FNyIe4wyrt4ZVxbARcKFA7S2hSY9Ty5ZlizLS/n+YWGzFFW6J1wlGysOUzU
# 9nm/qhh6YinvopspNAZ3GmLJPR5tH4LwC8csu89Ds+X57H2146SodDW4TsVxIxIm
# dgs8UoxxWkZDFLyzs7BNZ8ifQv+AeSGAnhUwZuhCEl4ayJ4iIdBD6Svpu/RIzCzU
# 2DKATCYqSCRfWupW76bemZ3KOm+9gSd0BhHudiG/m4LBJ1S2sWo9iaF2YbRuoROm
# v6pH8BJv/YoybLL+31HIjCPJZr2dHYcSZAI9La9Zj7jkIeW1sMpjtHhUBdRBLlCs
# lLCleKuzoJZ1GtmShxN1Ii8yqAhuoFuMJb+g74TKIdbrHk/Jmu5J4PcBZW+JC33I
# acjmbuqnl84xKf8OxVtc2E0bodj6L54/LlUWa8kTo/0xggTgMIIE3AIBATCBkDB5
# MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVk
# bW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSMwIQYDVQQDExpN
# aWNyb3NvZnQgQ29kZSBTaWduaW5nIFBDQQITMwAAAMps1TISNcThVQABAAAAyjAJ
# BgUrDgMCGgUAoIH5MBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3AgEEMBwGCisGAQQB
# gjcCAQsxDjAMBgorBgEEAYI3AgEVMCMGCSqGSIb3DQEJBDEWBBSYb4+etdshbtbw
# I4qHSfFEd2xNTjCBmAYKKwYBBAGCNwIBDDGBiTCBhqBsgGoARABJAEEARwBfAEMA
# VABTAEEAYwB0AGkAdgBlAEQAaQByAGUAYwB0AG8AcgB5AF8AZwBsAG8AYgBhAGwA
# XwBUAFMAXwBBAHUAdABvAEEAZABkAEMAbwBtAG0AYQBuAGQAcwAuAHAAcwAxoRaA
# FGh0dHA6Ly9taWNyb3NvZnQuY29tMA0GCSqGSIb3DQEBAQUABIIBAJDVyzUvbgCh
# D+arLAJkHEB2R2Cqczy9gl73JPesYnGoMJiqW//D2m9XtGO8N3C04ZWeLcsLO3w+
# KwdIOnnzRPfI2dsDkMV7wEwZX/B1tkZTqsUJy42IYPXxN9I7csaHryaGwEeJRheI
# gMWxwXRKEn9H4ARE57AuTW5UsEckoFbH+LO/IlHrppLokWaAx3PQYysW8DsQHuAa
# YMRv5wEz+mjDaVr9KVCPBd0Dabr2neUahd8CWq/czQARueOZ+MJ7aGH5ezeL5Yny
# UPGP11rJWi/csqxBIn03T1PbTdBDRVSDbj1CZsExrOmeFeHPZK3c4u9Dx/atLLB4
# 34Dy8CVOD82hggIoMIICJAYJKoZIhvcNAQkGMYICFTCCAhECAQEwgY4wdzELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEhMB8GA1UEAxMYTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBAhMzAAAAWu0v9OQgmT86AAAAAABaMAkGBSsOAwIa
# BQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0x
# NDEwMTYxNTE1MjNaMCMGCSqGSIb3DQEJBDEWBBSqTMYPqyNj/W8+L1QM7N/IT3H/
# KTANBgkqhkiG9w0BAQUFAASCAQAJcHI8+d1xQtl/SuA7sAKVRXdtx4/4mc+oqZ2q
# lqz5xaMaxFphyf6lGOj2fpSgKosi2B2V96WaUn6KGeU8+xfeSbszsSgekvATlKXs
# LBUX4FbQvh42iKHYXCQKenZIwxh0a+6xM1IxrA42qvEWMpShBnMX59ZjDDePg4WM
# FcuSHo85M47DcBuHwXfRVzZAf8zKlK40rrvA7qLt7DtsZQf3Jd9s1XJzFNFpgF05
# keEK5VZcmDrykr2F2lTLdDSn0dcKy+N0OSVP5Dtyw8QfCUlAVOorwtEUpBYrGew+
# 0qeK3qlcqupJtklpJuA8hMG/5MzFCl4wRTp9TQY1WN5ukpmv
# SIG # End signature block
