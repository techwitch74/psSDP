﻿	# MSInfo [AutoAdded]
	Run-DiagExpression .\DC_MSInfo.ps1

	# Obtain pstat output [AutoAdded]
	Run-DiagExpression .\DC_PStat.ps1

	# Collect Machine Registry Information for Setup and Performance Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_RegistrySetupPerf.ps1

	# CheckSym [AutoAdded]
	Run-DiagExpression .\DC_ChkSym.ps1

	# List Schedule Tasks using schtasks.exe utility [AutoAdded]
	Run-DiagExpression .\DC_ScheduleTasks.ps1

	# Collects information about Driver Verifier (verifier.exe utility) [AutoAdded]
	Run-DiagExpression .\DC_Verifier.ps1

	# Collects Windows Server 2008/R2 Server Manager Information [AutoAdded]
	Run-DiagExpression .\DC_ServerManagerInfo.ps1

	# Update History [AutoAdded]
	Run-DiagExpression .\DC_UpdateHistory.ps1

	# Collects System and Application Event Logs  [AutoAdded]
	Run-DiagExpression .\DC_SystemAppEventLogs.ps1

	# Information about Processes resource usage and top Kernel memory tags [AutoAdded]
	Run-DiagExpression .\TS_ProcessInfo.ps1

	# Collects BCD information via BCDInfo tool or boot.ini [AutoAdded]
	Run-DiagExpression .\DC_BCDInfo.ps1

	# Collect WindowsUpdate.Log [AutoAdded]
	Run-DiagExpression .\DC_WindowsUpdateLog.ps1

	# Detect Virtualization [AutoAdded]
	Run-DiagExpression .\TS_Virtualization.ps1

	# AutoRuns Information [AutoAdded]
	Run-DiagExpression .\DC_Autoruns.ps1

	# Collect the VMGuestSetup.Log file [AutoAdded]
	Run-DiagExpression .\DC_VMGuestSetupLogCollector.ps1

	# GPResults.exe Output [AutoAdded]
	Run-DiagExpression .\DC_RSoP.ps1

	# User Rights (privileges) via the userrights.exe tool [AutoAdded]
	Run-DiagExpression .\DC_UserRights.ps1

	# WhoAmI [AutoAdded]
	Run-DiagExpression .\DC_Whoami.ps1

	# TCPIP Component [AutoAdded]
	Run-DiagExpression .\DC_TCPIP-Component.ps1

	# DHCP Client Component [AutoAdded]
	Run-DiagExpression .\DC_DhcpClient-Component.ps1

	# DNS Client Component [AutoAdded]
	Run-DiagExpression .\DC_DNSClient-Component.ps1

	# WINSClient [AutoAdded]
	Run-DiagExpression .\DC_WINSClient-Component.ps1

	# SMB Client Component [AutoAdded]
	Run-DiagExpression .\DC_SMBClient-Component.ps1

	# SMB Server Component [AutoAdded]
	Run-DiagExpression .\DC_SMBServer-Component.ps1

	# RPC [AutoAdded]
	Run-DiagExpression .\DC_RPC-Component.ps1

	# Firewall [AutoAdded]
	Run-DiagExpression .\DC_Firewall-Component.ps1

	# IPsec [AutoAdded]
	Run-DiagExpression .\DC_IPsec-Component.ps1

	# Capture pfirewall.log  [AutoAdded]
	Run-DiagExpression .\DC_PFirewall.ps1

	# Print Information Report [AutoAdded]
	Run-DiagExpression .\TS_PrintInfo.ps1

	# Perf/Printing Event Logs [AutoAdded]
	Run-DiagExpression .\DC_PerfPrintEventLogs.ps1

	# Collect Print Registry Keys [AutoAdded]
	Run-DiagExpression .\DC_RegPrintKeys.ps1

	# Detect 4KB Drives (Disk Sector Size) [AutoAdded]
	Run-DiagExpression .\TS_DriveSectorSizeInfo.ps1

	# Obtain information about Devices and connections using devcon.exe utility [AutoAdded]
	Run-DiagExpression .\DC_Devcon.ps1

	# Collects Fiber Channel information using fcinfo utility [AutoAdded]
	Run-DiagExpression .\DC_FCInfo.ps1

	# By adding San.exe to the SDP manifest we should be able to solve cases that have a 512e or Advanced Format (4K) disk in it faster. [AutoAdded]
	Run-DiagExpression .\DC_SanStorageInfo.ps1

	# Collect Basic Cluster System Information [AutoAdded]
	Run-DiagExpression .\TS_BasicClusterInfo.ps1

	# Collects Cluster Logs [AutoAdded]
	Run-DiagExpression .\DC_ClusterLogs.ps1

	# Export cluster resources properties to a file (2K8 R2 and newer) [AutoAdded]
	Run-DiagExpression .\DC_ClusterResourcesProperties.ps1

	# Collects Cluster Groups Resource Dependency Report (Win2K8R2) [AutoAdded]
	Run-DiagExpression .\DC_ClusterDependencyReport.ps1

	# Collects Cluster - related Event Logs for Cluster Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_ClusterEventLogs.ps1

	# Hyper-V Info [AutoAdded]
	Run-DiagExpression .\TS_HyperVInfo.ps1

	# Information about Hyper-V, including Virtual Machine Files and Hyper-V Event Logs [AutoAdded]
	Run-DiagExpression .\DC_HyperVFiles.ps1

	# SQL Server Log Collector [AutoAdded]
	Run-DiagExpression .\DC_CollectSqlLogs.ps1 -Instances $null -CollectSqlErrorlogs -CollectSqlAgentLogs

	# SQL Server XE System Health Collector [AutoAdded]
	Run-DiagExpression .\DC_GetSqlXeLogs.ps1 -Instances $null -CollectSqlDefaultDiagnosticXeLogs -CollectFailoverClusterDiagnosticXeLogs -CollectAlwaysOnDiagnosticXeLogs

	# SQL Server minidump files Collector [AutoAdded]
	Run-DiagExpression .\DC_CollectSqlMinidumps.ps1 -Instances $null

	# SQL Server Log Collector [AutoAdded]
	Run-DiagExpression .\DC_RunSqlDiagScripts.ps1 -Instances $null -CollectSqlDiag -CollectAlwaysOnInfo

	# Misc_SQL_Keys [AutoAdded]
	Run-DiagExpression .\DC_SQL_Registries.ps1

	# SQL Server Analysis Services Registry Key Collector [AutoAdded]
	Run-DiagExpression .\DC_GetOlapServerConfigFiles.ps1

	# SQL Server Analysis Services Registry Key Collector [AutoAdded]
	Run-DiagExpression .\DC_CollectSsasRegKeys.ps1

	# Check AD Replication Status [AutoAdded]
	Run-DiagExpression .\TS_ADReplCheck.ps1

	# Checks if CrashOnAuditFail is either 1 or 2 [AutoAdded]
	Run-DiagExpression .\TS_CrashOnAuditFailCheck.ps1

	# SYSVOL and/or NETLOGON shares are missing on domain controller [AutoAdded]
	Run-DiagExpression .\TS_LSASSHighCPU.ps1

	# SYSVOL and/or NETLOGON shares are missing on domain controller [AutoAdded]
	Run-DiagExpression .\TS_SysvolNetLogonShareCheck.ps1

	# Missing Rid Set reference attribute detected [AutoAdded]
	Run-DiagExpression .\TS_ADRidSetReferenceCheck.ps1

	# AD Integrated DNS Server should not point only to itself if it has replica partners. [AutoAdded]
	Run-DiagExpression .\TS_DCCheckDnsExclusiveToSelf.ps1

	# [Idea ID 3768] [Windows] New rule to verify USN Roll Back [AutoAdded]
	Run-DiagExpression .\TS_USNRollBackCheck.ps1

	# [Idea ID 2882] [Windows] The stop of Intersite Messaging service on ISTG causes DFSN cannot calculate site costs [AutoAdded]
	Run-DiagExpression .\TS_IntersiteMessagingStateCheck.ps1

	# [Idea ID 2831] [Windows] DFSR Reg setting UpdateWorkerThreadCount = 64 may cause hang [AutoAdded]
	Run-DiagExpression .\TS_DfsrUpdateWorkerThreadCountCheck.ps1

	# [Idea ID 2593] [Windows] UDP 389 on DC does not respond [AutoAdded]
	Run-DiagExpression .\TS_IPv6DisabledonDCCheck.ps1

	# [Idea ID 4724] [Windows] W32Time and time skew [AutoAdded]
	Run-DiagExpression .\TS_Win32TimeTimeSkewRegCheck.ps1

	# [Idea ID 4796] [Windows] MaxConcurrentApi Problem Detection Lite [AutoAdded]
	Run-DiagExpression .\TS_MCALite.ps1

	# [Idea ID 5009] [Windows] Weak Key Block Detection [AutoAdded]
	Run-DiagExpression .\TS_DetectWeakKeys.ps1

	# [Idea ID 6816] [Windows] Detect Certificate Root Store Size Problems [AutoAdded]
	Run-DiagExpression .\TS_DetectRootSize.ps1

	# FailoverCluster Cluster Name Object AD check [AutoAdded]
	Run-DiagExpression .\TS_ClusterCNOCheck.ps1

	# Information about Windows 2008 R2 Cluster Shared Volumes [AutoAdded]
	Run-DiagExpression .\DC_CSVInfo.ps1

	# [Idea ID 2169] [Windows] Xsigo network host driver can cause Cluster disconnects [AutoAdded]
	Run-DiagExpression .\TS_ClusterXsigoDriverNetworkCheck.ps1

	# [Idea ID 2251] [Windows] Cluster 2003 - Access denied errors during a join, heartbeat, and Cluster Admin open [AutoAdded]
	Run-DiagExpression .\TS_Cluster2K3NoLmHash.ps1

	# [Idea ID 2513] [Windows] IPv6 rules for Windows Firewall can cause loss of communications between cluster nodes [AutoAdded]
	Run-DiagExpression .\TS_ClusterIPv6FirewallCheck.ps1

	# [Idea ID 5258] [Windows] Identifying Cluster Hive orphaned resources located in the dependencies key [AutoAdded]
	Run-DiagExpression .\TS_Cluster_OrphanResource.ps1

	# [Idea ID 6519] [Windows] Invalid Class error on 2012 Clusters (SDP) [AutoAdded]
	Run-DiagExpression .\TS_ClusterCAUWMINamespaceCheck.ps1

	# [Idea ID 6500] [Windows] Invalid Namespace error on 2008 and 2012 Clusters [AutoAdded]
	Run-DiagExpression .\TS_ClusterMSClusterWMINamespaceCheck.ps1

	# RC_KB2647170_CnameCheck [AutoAdded]
	Run-DiagExpression .\RC_KB2647170_CnameCheck.ps1

	# FirewallCheck [AutoAdded]
	Run-DiagExpression .\RC_FirewallCheck.ps1

	# IPv6Check [AutoAdded]
	Run-DiagExpression .\TS_IPv6Check.ps1

	# IPv66To4Check [AutoAdded]
	Run-DiagExpression .\RC_IPv66To4Check.ps1

	# RC_32GBMemoryKB2634907 [AutoAdded]
	Run-DiagExpression .\RC_32GBMemoryKB2634907.ps1

	# PMTU Check [AutoAdded]
	Run-DiagExpression .\TS_PMTUCheck.ps1

	# Checks for modified TcpIP Reg Parameters and recommend KB [AutoAdded]
	Run-DiagExpression .\TS_TCPIPSettingsCheck.ps1

	# 'Checks if the number of 6to4 adapters is larger than the number of physical adapters [AutoAdded]
	Run-DiagExpression .\TS_AdapterKB980486Check.ps1

	# Checks if Windows Server 2008 R2 SP1, Hyper-V, and Tunnel.sys driver are installed if they are generate alert [AutoAdded]
	Run-DiagExpression .\TS_ServerCoreKB978309Check.ps1

	# [Idea ID 2749] [Windows] SBSL Windows firewall delays acquisition of DHCP address from DHCP relay on domain-joined W7 client [AutoAdded]
	Run-DiagExpression .\TS_SBSL_DHCPRelayKB2459530.ps1

	# Detect MTU of 1514 [AutoAdded]
	Run-DiagExpression .\TS_DetectMTU1514.ps1

	# DetectLowPathMTU [AutoAdded]
	Run-DiagExpression .\TS_DetectLowPathMTU.ps1

	# RC_HTTPRedirectionTSGateway [AutoAdded]
	Run-DiagExpression .\RC_HTTPRedirectionTSGateway.ps1

	# SMB2ClientDriverStateCheck [AutoAdded]
	Run-DiagExpression .\TS_SMB2ClientDriverStateCheck.ps1

	# SMB2ServerDriverStateCheck [AutoAdded]
	Run-DiagExpression .\TS_SMB2ServerDriverStateCheck.ps1

	# Opportunistic Locking has been disabled and may impact performance. [AutoAdded]
	Run-DiagExpression .\TS_LockingKB296264Check.ps1

	# Evaluates whether InfocacheLevel should be increased to 0x10 hex. To resolve slow logon, slow boot issues. [AutoAdded]
	Run-DiagExpression .\TS_InfoCacheLevelCheck.ps1

	# [Idea ID 7521] [Windows] McAfee HIPS 7.0 adds numerous extraneous network adapter interfaces to registry [AutoAdded]
	Run-DiagExpression .\TS_McAfeeHIPS70Check.ps1

	# [Idea ID 7345] [Windows] Perfmon - Split IO Counter [AutoAdded]
	Run-DiagExpression .\TS_DetectSplitIO.ps1

	# Checking the presence of Citrix AppSense 8.1 [AutoAdded]
	Run-DiagExpression .\TS_CitrixAppSenseCheck.ps1

	# Check for large number of Inactive Terminal Server ports [AutoAdded]
	Run-DiagExpression .\TS_KB2655998_InactiveTSPorts.ps1

	# Checking if Registry Size Limit setting is present on the system [AutoAdded]
	Run-DiagExpression .\TS_RegistrySizeLimitCheck.ps1

	# [Idea ID 2446] [Windows] Determining the trimming threshold set by the Memory Manager [AutoAdded]
	Run-DiagExpression .\TS_2K3PoolUsageMaximum.ps1

	# Checks files in the LamnServer, if any at .PST files a file is created with listing all of the files in the directory [AutoAdded]
	Run-DiagExpression .\TS_NetFilePSTCheck.ps1

	# [Idea ID 986] [Windows] SBSL McAfee Endpoint Encryption for PCs may cause slow boot or delay between CTRL+ALT+DEL and Cred [AutoAdded]
	Run-DiagExpression .\TS_SBSL_MCAfee_EEPC_SlowBoot.ps1

	# [Idea ID 2285] [Windows] Windows Server 2003 TS Licensing server does not renew new versions of TS Per Device CALs [AutoAdded]
	Run-DiagExpression .\TS_RemoteDesktopLServerKB2512845.ps1

	# [Idea ID 3181] [Windows] Symantec Endpoint Protection's smc.exe causing handle leak [AutoAdded]
	Run-DiagExpression .\TS_SEPProcessHandleLeak.ps1

	# [Idea ID 2387] [Windows] Verify if RPC connection a configured to accept only Authenticated sessions [AutoAdded]
	Run-DiagExpression .\TS_RPCUnauthenticatedSessions.ps1

	# [Idea ID 1911] [Windows] NTFS metafile cache consumes most of RAM in Win2k8R2 Server [AutoAdded]
	Run-DiagExpression .\TS_NTFSMetafilePerfCheck.ps1

	# [Idea ID 2346] [Windows] high cpu only on one processor [AutoAdded]
	Run-DiagExpression .\TS_2K3ProcessorAffinityMaskCheck.ps1

	# [Idea ID 3989] [Windows] STACK MATCH - Win2008R2 - Machine hangs after shutdown, caused by ClearPageFileAtShutdown setting [AutoAdded]
	Run-DiagExpression .\TS_SBSLClearPageFileAtShutdown.ps1

	# [Idea ID 2753] [Windows] HP DL385 G5p machine cannot generate dump file [AutoAdded]
	Run-DiagExpression .\TS_ProLiantDL385NMICrashDump.ps1

	# [Idea ID 3253] [Windows] Windows Search service does not start immediately after the machine is booted [AutoAdded]
	Run-DiagExpression .\TS_WindowsSearchLenovoRapidBootCheck.ps1

	# [Idea ID 2334] [Windows] W2K3 x86 SP2 server running out of paged pool due to D2d tag [AutoAdded]
	Run-DiagExpression .\TS_KnownKernelTags.ps1

	# [Idea ID 3317] [Windows] DisableEngine reg entry can cause app install or registration failure [AutoAdded]
	Run-DiagExpression .\TS_AppCompatDisabledCheck.ps1

	# [Idea ID 2357] [Windows] the usage of NPP is very large for XTE.exe [AutoAdded]
	Run-DiagExpression .\TS_XTENonPagedPoolCheck.ps1

	# [Idea ID 4368] [Windows] Windows Logon Slow and Explorer Slow [AutoAdded]
	Run-DiagExpression .\TS_2K3CLSIDUserACLCheck.ps1

	# [Idea ID 4649] [Windows] Incorrect values for HeapDecomitFreeBlockThreshold  causes high Private Bytes in multiple processes [AutoAdded]
	Run-DiagExpression .\TS_HeapDecommitFreeBlockThresholdCheck.ps1

	# [Idea ID 2056] [Windows] Consistent Explorer crash due to wsftpsi.dll [AutoAdded]
	Run-DiagExpression .\TS_WsftpsiExplorerCrashCheck.ps1

	# [Idea ID 3250] [Windows] Machine exhibits different symptoms due to Confliker attack [AutoAdded]
	Run-DiagExpression .\TS_Netapi32MS08-067Check.ps1

	# [Idea ID 5194] [Windows] Unable to install vcredist_x86.exe with message (Required file install.ini not found. Setup will now exit) [AutoAdded]
	Run-DiagExpression .\TS_RegistryEntryForAutorunsCheck.ps1

	# [Idea ID 5452] [Windows] The “Red Arrow” issue in Component Services caused by registry keys corruption [AutoAdded]
	Run-DiagExpression .\TS_RedArrowRegistryCheck.ps1

	# [Idea ID 4783] [Windows] eEye Digital Security causing physical memory depletion [AutoAdded]
	Run-DiagExpression .\TS_eEyeDigitalSecurityCheck.ps1

	# [Idea ID 5091] [Windows] Super Rule-To check if both 3GB and PAE switch is present in boot.ini for a 32bit OS (Pre - Win 2k8) [AutoAdded]
	Run-DiagExpression .\TS_SwithesInBootiniCheck.ps1

	# [Idea ID 6530] [Windows] Check for any configured RPC port range which may cause issues with DCOM or DTC components [AutoAdded]
	Run-DiagExpression .\TS_RPCPortRangeCheck.ps1

	# [Idea ID 7018] [Windows] Event Log Service won't start [AutoAdded]
	Run-DiagExpression .\TS_EventLogStoppedGPPCheck.ps1

	# Check if hotfix 2480954 installed [AutoAdded]
	Run-DiagExpression .\TS_KB2480954AndWinRMStateCheck.ps1

	# Collects Windows Remote Management Event log [AutoAdded]
	Run-DiagExpression .\DC_WinRMEventLogs.ps1

	# Collects WSMAN and WinRM binary details info [AutoAdded]
	Run-DiagExpression .\DC_WSMANWinRMInfo.ps1

	# [Idea ID 8012] [Windows] SDP-UDE check for reg key DisablePagingExecutive [AutoAdded]
	Run-DiagExpression .\TS_DisablePagingExecutiveCheck.ps1

	# [KSE Rule] [ Windows V3] Server Manager refresh issues and SDP changes reqd for MMC Snapin Issues in 2008, 2008 R2 [AutoAdded]
	Run-DiagExpression .\TS_ServerManagerRefreshKB2762229.ps1

	# [KSE Rule] [ Windows V3] Presence of lots of folders inside \spool\prtprocs\ causes failure to install print queues [AutoAdded]
	Run-DiagExpression .\TS_PrtprocsSubfolderBloat.ps1

	# [KSE Rule] [ Windows V3] Handle leak in Svchost.exe when a WMI query is triggered by using the Win32_PowerSettingCapabilities [AutoAdded]
	Run-DiagExpression .\TS_WMIHandleLeakKB2639077.ps1

	# Hyper-V KB 982210 check [AutoAdded]
	Run-DiagExpression .\TS_HyperVSCSIDiskEnum.ps1

	# Hyper-V KB 975530 check (Xeon Processor Errata) [AutoAdded]
	Run-DiagExpression .\TS_HyperVXeon5500Check.ps1

	# Checks if Windows Server 2008 R2 SP1, Hyper-V, and Hotfix 2263829 are installed if they are generate alert [AutoAdded]
	Run-DiagExpression .\TS_HyperVKB2263829Check.ps1

	# Check for event ID 21203 or 21125 [AutoAdded]
	Run-DiagExpression .\TS_CheckEvtID_KB2475761.ps1

	# [Idea ID 6134] [Windows] You cannot start Hyper-V virtual machines after you enable the IO verification option on a HyperV [AutoAdded]
	Run-DiagExpression .\TS_HyperVCheckVerificationKB2761004.ps1

	# [Idea ID 5438] [Windows] Windows 2012 Hyper-V SPN and SCP not registed if customer uses a non default dynamicportrange [AutoAdded]
	Run-DiagExpression .\TS_HyperVEvent14050Check.ps1

	# [Idea ID 5752] [Windows] BIOS update may be required for some computers before starting Hyper-V on 2012 [AutoAdded]
	Run-DiagExpression .\TS_HyperV2012-CS-BIOS-Check.ps1

	# Symantec Endpoint Protection MR1 or MR2 check [AutoAdded]
	Run-DiagExpression .\TS_SymantecEPCheck.ps1

	# EMC Replistor Software installation detected but KB 975759 is not installed [AutoAdded]
	Run-DiagExpression .\TS_ReplistorCheck.ps1

	# Warning if Windows Server 2008 Service Pack 1, We end support Windows Server 2008 SP1 on July 12, advice customer to upgrade to SP2. [AutoAdded]
	Run-DiagExpression .\TS_ServicePackKB2590494Check.ps1

	# Checks 32 bit windows server 2003 / 2008 to see is DEP is disabled, if so it might not detect more than 4 GB of RAM. [AutoAdded]
	Run-DiagExpression .\TS_DEPDisabled4GBCheck.ps1

	# Check for Sophos BEFLT.SYS version 5.60.1.7 [AutoAdded]
	Run-DiagExpression .\TS_B2693877_Sophos_BEFLTCheck.ps1

	# [Idea ID 2695] [Windows] Check the Log On account for the Telnet service to verify it's not using the Local System account [AutoAdded]
	Run-DiagExpression .\TS_TelnetSystemAccount.ps1

	# [Idea ID 2842] [Windows] Alert Engineers if they are working on a Dell machine models R910, R810 and M910 [AutoAdded]
	Run-DiagExpression .\TS_DellPowerEdgeBiosCheck.ps1

	# [Idea ID 2389] [Windows] Hang caused by kernel memory depletion due 'SystemPages' reg key with wrong value [AutoAdded]
	Run-DiagExpression .\TS_MemoryManagerSystemPagesCheck.ps1

	# [Idea ID 7065] [Windows] Alert users about Windows XP EOS [AutoAdded]
	Run-DiagExpression .\TS_WindowsXPEOSCheck.ps1

	# [KSE Rule] [ Windows V3] HpCISSs2 version 62.26.0.64 causes 0xD1 or 0x9E [AutoAdded]
	Run-DiagExpression .\TS_HpCISSs2DriverIssueCheck.ps1

	# Detects and alerts evaluation media [AutoAdded]
	Run-DiagExpression .\TS_EvalMediaDetection.ps1

	# Debug/GFlags check [AutoAdded]
	Run-DiagExpression .\TS_DebugFlagsCheck.ps1

	# Check for ephemeral port usage [AutoAdded]
	Run-DiagExpression .\TS_PortUsage.ps1

	# Collects PowerShell - related Event Logs for Exchange Server Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_ExchangeServerEventLogs.ps1

	# ExchDump [AutoAdded]
	Run-DiagExpression .\DC_Ex2003_ExchDump.ps1

	# ExBPA_2003 [AutoAdded]
	Run-DiagExpression .\DC_Ex2003_ExBPAcmd.ps1

	# ExchDump [AutoAdded]
	Run-DiagExpression .\DC_Exchange_RegKeys.ps1

	# ExBPAcmd [AutoAdded]
	#_#Run-DiagExpression .\DC_Ex_ExBPAcmd.ps1

	# Exchange Server 2007-2010 Comprehensive Data Collection [AutoAdded]
	Run-DiagExpression .\DC_GetExchange2007_2010Data.ps1

	# Exchange Server 2013 Comprehensive Data Collection [AutoAdded]
	Run-DiagExpression .\DC_GetExchange2013Data.ps1


# SIG # Begin signature block
# MIIa+gYJKoZIhvcNAQcCoIIa6zCCGucCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQUJmM/V3ZULcbXlVubIYjSI1HC
# zuigghWCMIIEwzCCA6ugAwIBAgITMwAAAEyh6E3MtHR7OwAAAAAATDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTMxMTExMjIxMTMx
# WhcNMTUwMjExMjIxMTMxWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsdj6GwYrd6jk
# lF18D+Z6ppLuilQdpPmEdYWXzMtcltDXdS3ZCPtb0u4tJcY3PvWrfhpT5Ve+a+i/
# ypYK3EbxWh4+AtKy4CaOAGR7vjyT+FgyeYfSGl0jvJxRxA8Q+gRYtRZ2buy8xuW+
# /K2swUHbqs559RyymUGneiUr/6t4DVg6sV5Q3mRM4MoVKt+m6f6kZi9bEAkJJiHU
# Pw0vbdL4d5ADbN4UEqWM5zYf9IelsEEXb+NNdGbC/aJxRjVRzGsXUWP6FZSSml9L
# KLrmFkVJ6Sy1/ouHr/ylbUPcpjD6KSjvmw0sXIPeEo1qtNtx71wUWiojKP+BcFfx
# jAeaE9gqUwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFLkNrbNN9NqfGrInJlUNIETY
# mOL0MB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAAmKTgav6O2Czx0HftcqpyQLLa+aWyR/lHEMVYgkGlIVY+KQ
# TQVKmEqc++GnbWhVgrkp6mmpstXjDNrR1nolN3hnHAz72ylaGpc4KjlWRvs1gbnk
# PUZajuT8dTdYWUmLTts8FZ1zUkvreww6wi3Bs5tSLeA1xbnBV7PoPaE8RPIjFh4K
# qlk3J9CVUl6ofz9U8IHh3Jq9ZdV49vdMObvd4NY3DpGah4xz53FkUvc+A9jGzXK4
# NDSYW4zT9Qim63jGUaANDm/0azxAGmAWLKkGUp0cE5DObwIe6nucs/b4l2DyZdHR
# H4c6wXXwQo167Yxysnv7LIq0kUdU4i5pzBZUGlkwggTsMIID1KADAgECAhMzAAAA
# sBGvCovQO5/dAAEAAACwMA0GCSqGSIb3DQEBBQUAMHkxCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xIzAhBgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBMB4XDTEzMDEyNDIyMzMzOVoXDTE0MDQyNDIyMzMzOVowgYMxCzAJ
# BgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25k
# MR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xDTALBgNVBAsTBE1PUFIx
# HjAcBgNVBAMTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAOivXKIgDfgofLwFe3+t7ut2rChTPzrbQH2zjjPmVz+l
# URU0VKXPtIupP6g34S1Q7TUWTu9NetsTdoiwLPBZXKnr4dcpdeQbhSeb8/gtnkE2
# KwtA+747urlcdZMWUkvKM8U3sPPrfqj1QRVcCGUdITfwLLoiCxCxEJ13IoWEfE+5
# G5Cw9aP+i/QMmk6g9ckKIeKq4wE2R/0vgmqBA/WpNdyUV537S9QOgts4jxL+49Z6
# dIhk4WLEJS4qrp0YHw4etsKvJLQOULzeHJNcSaZ5tbbbzvlweygBhLgqKc+/qQUF
# 4eAPcU39rVwjgynrx8VKyOgnhNN+xkMLlQAFsU9lccUCAwEAAaOCAWAwggFcMBMG
# A1UdJQQMMAoGCCsGAQUFBwMDMB0GA1UdDgQWBBRZcaZaM03amAeA/4Qevof5cjJB
# 8jBRBgNVHREESjBIpEYwRDENMAsGA1UECxMETU9QUjEzMDEGA1UEBRMqMzE1OTUr
# NGZhZjBiNzEtYWQzNy00YWEzLWE2NzEtNzZiYzA1MjM0NGFkMB8GA1UdIwQYMBaA
# FMsR6MrStBZYAck3LjMWFrlMmgofMFYGA1UdHwRPME0wS6BJoEeGRWh0dHA6Ly9j
# cmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY0NvZFNpZ1BDQV8w
# OC0zMS0yMDEwLmNybDBaBggrBgEFBQcBAQROMEwwSgYIKwYBBQUHMAKGPmh0dHA6
# Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljQ29kU2lnUENBXzA4LTMx
# LTIwMTAuY3J0MA0GCSqGSIb3DQEBBQUAA4IBAQAx124qElczgdWdxuv5OtRETQie
# 7l7falu3ec8CnLx2aJ6QoZwLw3+ijPFNupU5+w3g4Zv0XSQPG42IFTp8263Os8ls
# ujksRX0kEVQmMA0N/0fqAwfl5GZdLHudHakQ+hywdPJPaWueqSSE2u2WoN9zpO9q
# GqxLYp7xfMAUf0jNTbJE+fA8k21C2Oh85hegm2hoCSj5ApfvEQO6Z1Ktwemzc6bS
# Y81K4j7k8079/6HguwITO10g3lU/o66QQDE4dSheBKlGbeb1enlAvR/N6EXVruJd
# PvV1x+ZmY2DM1ZqEh40kMPfvNNBjHbFCZ0oOS786Du+2lTqnOOQlkgimiGaCMIIF
# vDCCA6SgAwIBAgIKYTMmGgAAAAAAMTANBgkqhkiG9w0BAQUFADBfMRMwEQYKCZIm
# iZPyLGQBGRYDY29tMRkwFwYKCZImiZPyLGQBGRYJbWljcm9zb2Z0MS0wKwYDVQQD
# EyRNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcNMTAwODMx
# MjIxOTMyWhcNMjAwODMxMjIyOTMyWjB5MQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSMwIQYDVQQDExpNaWNyb3NvZnQgQ29kZSBTaWduaW5nIFBD
# QTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJyWVwZMGS/HZpgICBC
# mXZTbD4b1m/My/Hqa/6XFhDg3zp0gxq3L6Ay7P/ewkJOI9VyANs1VwqJyq4gSfTw
# aKxNS42lvXlLcZtHB9r9Jd+ddYjPqnNEf9eB2/O98jakyVxF3K+tPeAoaJcap6Vy
# c1bxF5Tk/TWUcqDWdl8ed0WDhTgW0HNbBbpnUo2lsmkv2hkL/pJ0KeJ2L1TdFDBZ
# +NKNYv3LyV9GMVC5JxPkQDDPcikQKCLHN049oDI9kM2hOAaFXE5WgigqBTK3S9dP
# Y+fSLWLxRT3nrAgA9kahntFbjCZT6HqqSvJGzzc8OJ60d1ylF56NyxGPVjzBrAlf
# A9MCAwEAAaOCAV4wggFaMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFMsR6MrS
# tBZYAck3LjMWFrlMmgofMAsGA1UdDwQEAwIBhjASBgkrBgEEAYI3FQEEBQIDAQAB
# MCMGCSsGAQQBgjcVAgQWBBT90TFO0yaKleGYYDuoMW+mPLzYLTAZBgkrBgEEAYI3
# FAIEDB4KAFMAdQBiAEMAQTAfBgNVHSMEGDAWgBQOrIJgQFYnl+UlE/wq4QpTlVnk
# pDBQBgNVHR8ESTBHMEWgQ6BBhj9odHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtp
# L2NybC9wcm9kdWN0cy9taWNyb3NvZnRyb290Y2VydC5jcmwwVAYIKwYBBQUHAQEE
# SDBGMEQGCCsGAQUFBzAChjhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2Nl
# cnRzL01pY3Jvc29mdFJvb3RDZXJ0LmNydDANBgkqhkiG9w0BAQUFAAOCAgEAWTk+
# fyZGr+tvQLEytWrrDi9uqEn361917Uw7LddDrQv+y+ktMaMjzHxQmIAhXaw9L0y6
# oqhWnONwu7i0+Hm1SXL3PupBf8rhDBdpy6WcIC36C1DEVs0t40rSvHDnqA2iA6VW
# 4LiKS1fylUKc8fPv7uOGHzQ8uFaa8FMjhSqkghyT4pQHHfLiTviMocroE6WRTsgb
# 0o9ylSpxbZsa+BzwU9ZnzCL/XB3Nooy9J7J5Y1ZEolHN+emjWFbdmwJFRC9f9Nqu
# 1IIybvyklRPk62nnqaIsvsgrEA5ljpnb9aL6EiYJZTiU8XofSrvR4Vbo0HiWGFzJ
# NRZf3ZMdSY4tvq00RBzuEBUaAF3dNVshzpjHCe6FDoxPbQ4TTj18KUicctHzbMrB
# 7HCjV5JXfZSNoBtIA1r3z6NnCnSlNu0tLxfI5nI3EvRvsTxngvlSso0zFmUeDord
# EN5k9G/ORtTTF+l5xAS00/ss3x+KnqwK+xMnQK3k+eGpf0a7B2BHZWBATrBC7E7t
# s3Z52Ao0CW0cgDEf4g5U3eWh++VHEK1kmP9QFi58vwUheuKVQSdpw5OPlcmN2Jsh
# rg1cnPCiroZogwxqLbt2awAdlq3yFnv2FoMkuYjPaqhHMS+a3ONxPdcAfmJH0c6I
# ybgY+g5yjcGjPa8CQGr/aZuW4hCoELQ3UAjWwz0wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TGCBOIwggTe
# AgEBMIGQMHkxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xIzAh
# BgNVBAMTGk1pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBAhMzAAAAsBGvCovQO5/d
# AAEAAACwMAkGBSsOAwIaBQCggfswGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQw
# HAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwIwYJKoZIhvcNAQkEMRYEFBdr
# 0DoETS00c3UtUaeGTvcR2PT0MIGaBgorBgEEAYI3AgEMMYGLMIGIoG6AbABEAEkA
# QQBHAF8AQwBUAFMAXwBHAGUAbgBlAHIAYQBsAF8AUgBlAHAAbwByAHQAcwBfAGcA
# bABvAGIAYQBsAF8AVABTAF8AQQB1AHQAbwBBAGQAZABDAG8AbQBtAGEAbgBkAHMA
# LgBwAHMAMaEWgBRodHRwOi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASC
# AQADdvMmA7qaIwGMRmyg77CAoZvg+mjKJoKGTsjSuxYKo/dTwZTr5FKBJY3rrga6
# mf9dXKYUIz31zWySXUibhO/OVKLG0T8RUiPdQP/YDygHK51RbOEPA2cqiEkHxeUM
# Wq8/u6uOenAHqjZw4cZ9kbYNaCb2vb5zlGbi+4AfmQI7FfsHwlzAHUlTo1/HB1lF
# fw6TkKKGMOmkNbKlORHNwJJ9Avml/42IS15X2uYeSUdrgnU9iPLOCScmPHhTMepv
# 8U6zx8GTdpHljqQDPBv3UN61mWgeBB4VNa3jUKHids4Yd6Imu6VujuO7adXz1r45
# LAHQj7JzyXikOgonnW80YKBxoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEB
# MIGOMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQH
# EwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNV
# BAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQQITMwAAAEyh6E3MtHR7OwAAAAAA
# TDAJBgUrDgMCGgUAoF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG
# 9w0BCQUxDxcNMTQwMjI0MTczODAwWjAjBgkqhkiG9w0BCQQxFgQU7iSXMZO7pAKd
# 1SK39DavYBnH4FgwDQYJKoZIhvcNAQEFBQAEggEAPUhYhgeoqpehykAsGlR9Qx0c
# 7Ud98tB2Wdc2ovx2/Dk0lr3Km1Lc2Tn/0BwSZfc9Jz1+iCWYYgzLMuxdZ1GN4Tkp
# va+hUg9egubtns8elWEbvZRiIpqXe+qp7sJS6vFKw6tU6uLhDJ6vwWqmQ6M/YhUY
# qk6VaveQ2gOiCq1Nkkp/1zmKVxh70raaOMm9uGmw6IJFjy/CD1Fg/no/cqPIzmaq
# Pvg/elCmVPDo88HY7S3Aaps7o69uodvwFKhzrKzd7yiFe9NWp1d8MZMBWhQ9fnBj
# z+r/vzcLbR9CP5xekvOLWKEtkMEEYqaQMvU0B1FAM0m+xBblv+NPKkNaIs12Bg==
# SIG # End signature block
