﻿	# DBErr Data Collector [AutoAdded]
	Run-DiagExpression .\DC_DBErr.ps1

	# Running powercfg.exe to obtain power settings information [AutoAdded]
	Run-DiagExpression .\TS_PowerCFG.ps1

	# MSInfo [AutoAdded]
	Run-DiagExpression .\DC_MSInfo.ps1

	# Obtain pstat output [AutoAdded]
	Run-DiagExpression .\DC_PStat.ps1

	# Collect Machine Registry Information for Setup and Performance Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_RegistrySetupPerf.ps1

	# CheckSym [AutoAdded]
	Run-DiagExpression .\DC_ChkSym.ps1

	# List Schedule Tasks using schtasks.exe utility [AutoAdded]
	Run-DiagExpression .\DC_ScheduleTasks.ps1

	# Collects information about Driver Verifier (verifier.exe utility) [AutoAdded]
	Run-DiagExpression .\DC_Verifier.ps1

	# Collects Windows Server 2008/R2 Server Manager Information [AutoAdded]
	Run-DiagExpression .\DC_ServerManagerInfo.ps1

	# Update History [AutoAdded]
	Run-DiagExpression .\DC_UpdateHistory.ps1

	# Collects System and Application Event Logs  [AutoAdded]
	Run-DiagExpression .\DC_SystemAppEventLogs.ps1

	# Information about Processes resource usage and top Kernel memory tags [AutoAdded]
	Run-DiagExpression .\TS_ProcessInfo.ps1

	# Collects BCD information via BCDInfo tool or boot.ini [AutoAdded]
	Run-DiagExpression .\DC_BCDInfo.ps1

	# Collect WindowsUpdate.Log [AutoAdded]
	Run-DiagExpression .\DC_WindowsUpdateLog.ps1

	# Detect Virtualization [AutoAdded]
	Run-DiagExpression .\TS_Virtualization.ps1

	# AutoRuns Information [AutoAdded]
	Run-DiagExpression .\DC_Autoruns.ps1

	# Collect the VMGuestSetup.Log file [AutoAdded]
	Run-DiagExpression .\DC_VMGuestSetupLogCollector.ps1

	# Collect Deployment-related Logs (setupact.log, unattended.xml, setuperr.log) [AutoAdded]
	Run-DiagExpression .\DC_DeploymentLogs.ps1

	# Collects Windows Server 2008/R2 Server Manager Information [AutoAdded]
	Run-DiagExpression .\DC_ServerManagerLogs.ps1

	# KMS/ MAK activation information using inbox slmgr.vbs [AutoAdded]
	Run-DiagExpression .\DC_SLMGR.ps1

	# Windows Servicing Logs (CBS logs and others) [AutoAdded]
	Run-DiagExpression .\DC_ServicingLogs.ps1

	# Collect Setup Event Log for Servicing [AutoAdded]
	Run-DiagExpression .\TS_ServicingEventLogs.ps1

	# Collects Cluster - related Event Logs for Cluster Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_MBAMEventLogs.ps1

	# KB Installation Logs [AutoAdded]
	Run-DiagExpression .\DC_KBInstallLogs.ps1

	# Collects Windows Setup API Logs [AutoAdded]
	Run-DiagExpression .\DC_SetupAPILogs.ps1

	# Collect Appx event logs for tshooting application deployment, sideloading, and execution [AutoAdded]
	Run-DiagExpression .\DC_WindowsStoreAppEvtLogs.ps1

	# Startup repair Diagnostics Data Collection [AutoAdded]
	Run-DiagExpression .\DC_StartupRepairProcessLog.ps1

	# Enumerate minifilter drivers via Fltmc.exe command [AutoAdded]
	Run-DiagExpression .\DC_Fltmc.ps1

	# Obtain information about Upper and lower filters Information fltrfind.exe utility [AutoAdded]
	Run-DiagExpression .\DC_Fltrfind.ps1

	# DC_WDS [AutoAdded]
	Run-DiagExpression .\DC_WDSFiles.ps1

	# Collect Basic Cluster System Information [AutoAdded]
	Run-DiagExpression .\TS_BasicClusterInfo.ps1

	# Collects Cluster Logs [AutoAdded]
	Run-DiagExpression .\DC_ClusterLogs.ps1

	# Export cluster resources properties to a file (2K8 R2 and newer) [AutoAdded]
	Run-DiagExpression .\DC_ClusterResourcesProperties.ps1

	# Collects Cluster Groups Resource Dependency Report (Win2K8R2) [AutoAdded]
	Run-DiagExpression .\DC_ClusterDependencyReport.ps1

	# Collects Cluster - related Event Logs for Cluster Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_ClusterEventLogs.ps1

	# Collects \windows\cluster\reports contents (MHT, XML and Validate*.LOG) [AutoAdded]
	Run-DiagExpression .\DC_ClusterReportsFiles.ps1

	# Information about Windows 2008 R2 Cluster Shared Volumes [AutoAdded]
	Run-DiagExpression .\DC_CSVInfo.ps1

	# Cluster Validation Report Troubleshooter [AutoAdded]
	Run-DiagExpression .\TS_ClusterValidationTests.ps1

	# Collects Cluster - related registry keys [AutoAdded]
	Run-DiagExpression .\DC_RegistryCluster.ps1

	# Hyper-V Info [AutoAdded]
	Run-DiagExpression .\TS_HyperVInfo.ps1
      .\DC_HyperVBasicInfo.ps1

	# Information about Hyper-V, including Virtual Machine Files and Hyper-V Event Logs [AutoAdded]
	Run-DiagExpression .\DC_HyperVFiles.ps1

	# Hyper-V BPA [AutoAdded]
	Run-DiagExpression .\TS_BPAInfo.ps1 -BPAModelID "Microsoft/Windows/Hyper-V" -OutputFileName ($Computername + "_HyperV_BPAInfo.HTM") -ReportTitle "Hyper-V Best Practices Analyzer"

	# GPResults.exe Output [AutoAdded]
	Run-DiagExpression .\DC_RSoP.ps1

	# User Rights (privileges) via the userrights.exe tool [AutoAdded]
	Run-DiagExpression .\DC_UserRights.ps1

	# WhoAmI [AutoAdded]
	Run-DiagExpression .\DC_Whoami.ps1

	# TCPIP Component [AutoAdded]
	Run-DiagExpression .\DC_TCPIP-Component.ps1

	# DHCP Client Component [AutoAdded]
	Run-DiagExpression .\DC_DhcpClient-Component.ps1

	# DNS Client Component [AutoAdded]
	Run-DiagExpression .\DC_DNSClient-Component.ps1

	# WINSClient [AutoAdded]
	Run-DiagExpression .\DC_WINSClient-Component.ps1

	# SMB Client Component [AutoAdded]
	Run-DiagExpression .\DC_SMBClient-Component.ps1

	# SMB Server Component [AutoAdded]
	Run-DiagExpression .\DC_SMBServer-Component.ps1

	# RPC [AutoAdded]
	Run-DiagExpression .\DC_RPC-Component.ps1

	# Firewall [AutoAdded]
	Run-DiagExpression .\DC_Firewall-Component.ps1

	# IPsec [AutoAdded]
	Run-DiagExpression .\DC_IPsec-Component.ps1

	# Hyper-V Networking Settings [AutoAdded]
	Run-DiagExpression .\DC_HyperVNetworking.ps1

	# Hyper-V Network Virtualization [AutoAdded]
	Run-DiagExpression .\DC_HyperVNetworkVirtualization.ps1

	# NetworkAdapters [AutoAdded]
	Run-DiagExpression .\DC_NetworkAdapters-Component.ps1

	# NetLBFO [AutoAdded]
	Run-DiagExpression .\DC_NetLBFO-Component.ps1

	# Print Information Report [AutoAdded]
	Run-DiagExpression .\TS_PrintInfo.ps1

	# Perf/Printing Event Logs [AutoAdded]
	Run-DiagExpression .\DC_PerfPrintEventLogs.ps1

	# Collect Print Registry Keys [AutoAdded]
	Run-DiagExpression .\DC_RegPrintKeys.ps1

	# Detect 4KB Drives (Disk Sector Size) [AutoAdded]
	Run-DiagExpression .\TS_DriveSectorSizeInfo.ps1

	# Obtain information about Devices and connections using devcon.exe utility [AutoAdded]
	Run-DiagExpression .\DC_Devcon.ps1

	# Collects Fiber Channel information using fcinfo utility [AutoAdded]
	Run-DiagExpression .\DC_FCInfo.ps1

	# By adding San.exe to the SDP manifest we should be able to solve cases that have a 512e or Advanced Format (4K) disk in it faster. [AutoAdded]
	Run-DiagExpression .\DC_SanStorageInfo.ps1

	# Obtain information about MS-DOS device names (symbolic links) via DOSDev utility [AutoAdded]
	Run-DiagExpression .\DC_DOSDev.ps1

	# Collects Information about iSCSI though the iscsicli utility [AutoAdded]
	Run-DiagExpression .\DC_ISCSIInfo.ps1

	# Parse Storage related event logs on System log using evParse.exe and dump to a HTML file [AutoAdded]
	Run-DiagExpression .\DC_EvParser.ps1

	# Collects VSS information via VSSAdmin tool [AutoAdded]
	Run-DiagExpression .\DC_VSSAdmin.ps1

	# Collect Machine Registry Information for Storage Related Diagnostics [AutoAdded]
	Run-DiagExpression .\DC_RegistryStorage.ps1

	# Detects and alerts evaluation media [AutoAdded]
	Run-DiagExpression .\TS_EvalMediaDetection.ps1

	# Debug/GFlags check [AutoAdded]
	Run-DiagExpression .\TS_DebugFlagsCheck.ps1

	# Check for ephemeral port usage [AutoAdded]
	Run-DiagExpression .\TS_PortUsage.ps1

	# FailoverCluster Cluster Name Object AD check [AutoAdded]
	Run-DiagExpression .\TS_ClusterCNOCheck.ps1

	# [Idea ID 2169] [Windows] Xsigo network host driver can cause Cluster disconnects [AutoAdded]
	Run-DiagExpression .\TS_ClusterXsigoDriverNetworkCheck.ps1

	# [Idea ID 2251] [Windows] Cluster 2003 - Access denied errors during a join, heartbeat, and Cluster Admin open [AutoAdded]
	Run-DiagExpression .\TS_Cluster2K3NoLmHash.ps1

	# [Idea ID 2513] [Windows] IPv6 rules for Windows Firewall can cause loss of communications between cluster nodes [AutoAdded]
	Run-DiagExpression .\TS_ClusterIPv6FirewallCheck.ps1

	# [Idea ID 5258] [Windows] Identifying Cluster Hive orphaned resources located in the dependencies key [AutoAdded]
	Run-DiagExpression .\TS_Cluster_OrphanResource.ps1

	# [Idea ID 6519] [Windows] Invalid Class error on 2012 Clusters (SDP) [AutoAdded]
	Run-DiagExpression .\TS_ClusterCAUWMINamespaceCheck.ps1

	# [Idea ID 6500] [Windows] Invalid Namespace error on 2008 and 2012 Clusters [AutoAdded]
	Run-DiagExpression .\TS_ClusterMSClusterWMINamespaceCheck.ps1

	# Checking the presence of Citrix AppSense 8.1 [AutoAdded]
	Run-DiagExpression .\TS_CitrixAppSenseCheck.ps1

	# Check for large number of Inactive Terminal Server ports [AutoAdded]
	Run-DiagExpression .\TS_KB2655998_InactiveTSPorts.ps1

	# Checking if Registry Size Limit setting is present on the system [AutoAdded]
	Run-DiagExpression .\TS_RegistrySizeLimitCheck.ps1

	# [Idea ID 2446] [Windows] Determining the trimming threshold set by the Memory Manager [AutoAdded]
	Run-DiagExpression .\TS_2K3PoolUsageMaximum.ps1

	# Checks files in the LamnServer, if any at .PST files a file is created with listing all of the files in the directory [AutoAdded]
	Run-DiagExpression .\TS_NetFilePSTCheck.ps1

	# [Idea ID 986] [Windows] SBSL McAfee Endpoint Encryption for PCs may cause slow boot or delay between CTRL+ALT+DEL and Cred [AutoAdded]
	Run-DiagExpression .\TS_SBSL_MCAfee_EEPC_SlowBoot.ps1

	# [Idea ID 2285] [Windows] Windows Server 2003 TS Licensing server does not renew new versions of TS Per Device CALs [AutoAdded]
	Run-DiagExpression .\TS_RemoteDesktopLServerKB2512845.ps1

	# [Idea ID 3181] [Windows] Symantec Endpoint Protection's smc.exe causing handle leak [AutoAdded]
	Run-DiagExpression .\TS_SEPProcessHandleLeak.ps1

	# [Idea ID 2387] [Windows] Verify if RPC connection a configured to accept only Authenticated sessions [AutoAdded]
	Run-DiagExpression .\TS_RPCUnauthenticatedSessions.ps1

	# [Idea ID 1911] [Windows] NTFS metafile cache consumes most of RAM in Win2k8R2 Server [AutoAdded]
	Run-DiagExpression .\TS_NTFSMetafilePerfCheck.ps1

	# [Idea ID 2346] [Windows] high cpu only on one processor [AutoAdded]
	Run-DiagExpression .\TS_2K3ProcessorAffinityMaskCheck.ps1

	# [Idea ID 3989] [Windows] STACK MATCH - Win2008R2 - Machine hangs after shutdown, caused by ClearPageFileAtShutdown setting [AutoAdded]
	Run-DiagExpression .\TS_SBSLClearPageFileAtShutdown.ps1

	# [Idea ID 2753] [Windows] HP DL385 G5p machine cannot generate dump file [AutoAdded]
	Run-DiagExpression .\TS_ProLiantDL385NMICrashDump.ps1

	# [Idea ID 3253] [Windows] Windows Search service does not start immediately after the machine is booted [AutoAdded]
	Run-DiagExpression .\TS_WindowsSearchLenovoRapidBootCheck.ps1

	# [Idea ID 2334] [Windows] W2K3 x86 SP2 server running out of paged pool due to D2d tag [AutoAdded]
	Run-DiagExpression .\TS_KnownKernelTags.ps1

	# [Idea ID 3317] [Windows] DisableEngine reg entry can cause app install or registration failure [AutoAdded]
	Run-DiagExpression .\TS_AppCompatDisabledCheck.ps1

	# [Idea ID 2357] [Windows] the usage of NPP is very large for XTE.exe [AutoAdded]
	Run-DiagExpression .\TS_XTENonPagedPoolCheck.ps1

	# [Idea ID 4368] [Windows] Windows Logon Slow and Explorer Slow [AutoAdded]
	Run-DiagExpression .\TS_2K3CLSIDUserACLCheck.ps1

	# [Idea ID 4649] [Windows] Incorrect values for HeapDecomitFreeBlockThreshold  causes high Private Bytes in multiple processes [AutoAdded]
	Run-DiagExpression .\TS_HeapDecommitFreeBlockThresholdCheck.ps1

	# [Idea ID 2056] [Windows] Consistent Explorer crash due to wsftpsi.dll [AutoAdded]
	Run-DiagExpression .\TS_WsftpsiExplorerCrashCheck.ps1

	# [Idea ID 3250] [Windows] Machine exhibits different symptoms due to Confliker attack [AutoAdded]
	Run-DiagExpression .\TS_Netapi32MS08-067Check.ps1

	# [Idea ID 5194] [Windows] Unable to install vcredist_x86.exe with message (Required file install.ini not found. Setup will now exit) [AutoAdded]
	Run-DiagExpression .\TS_RegistryEntryForAutorunsCheck.ps1

	# [Idea ID 5452] [Windows] The “Red Arrow” issue in Component Services caused by registry keys corruption [AutoAdded]
	Run-DiagExpression .\TS_RedArrowRegistryCheck.ps1

	# [Idea ID 4783] [Windows] eEye Digital Security causing physical memory depletion [AutoAdded]
	Run-DiagExpression .\TS_eEyeDigitalSecurityCheck.ps1

	# [Idea ID 5091] [Windows] Super Rule-To check if both 3GB and PAE switch is present in boot.ini for a 32bit OS (Pre - Win 2k8) [AutoAdded]
	Run-DiagExpression .\TS_SwithesInBootiniCheck.ps1

	# [Idea ID 6530] [Windows] Check for any configured RPC port range which may cause issues with DCOM or DTC components [AutoAdded]
	Run-DiagExpression .\TS_RPCPortRangeCheck.ps1

	# [Idea ID 7018] [Windows] Event Log Service won't start [AutoAdded]
	Run-DiagExpression .\TS_EventLogStoppedGPPCheck.ps1

	# Check if hotfix 2480954 installed [AutoAdded]
	Run-DiagExpression .\TS_KB2480954AndWinRMStateCheck.ps1

	# Collects Windows Remote Management Event log [AutoAdded]
	Run-DiagExpression .\DC_WinRMEventLogs.ps1

	# Collects WSMAN and WinRM binary details info [AutoAdded]
	Run-DiagExpression .\DC_WSMANWinRMInfo.ps1

	# [Idea ID 8012] [Windows] SDP-UDE check for reg key DisablePagingExecutive [AutoAdded]
	Run-DiagExpression .\TS_DisablePagingExecutiveCheck.ps1

	# [KSE Rule] [ Windows V3] Server Manager refresh issues and SDP changes reqd for MMC Snapin Issues in 2008, 2008 R2 [AutoAdded]
	Run-DiagExpression .\TS_ServerManagerRefreshKB2762229.ps1

	# [KSE Rule] [ Windows V3] Presence of lots of folders inside \spool\prtprocs\ causes failure to install print queues [AutoAdded]
	Run-DiagExpression .\TS_PrtprocsSubfolderBloat.ps1

	# [KSE Rule] [ Windows V3] Handle leak in Svchost.exe when a WMI query is triggered by using the Win32_PowerSettingCapabilities [AutoAdded]
	Run-DiagExpression .\TS_WMIHandleLeakKB2639077.ps1

	# EMC Replistor Software installation detected but KB 975759 is not installed [AutoAdded]
	Run-DiagExpression .\TS_ReplistorCheck.ps1

	# Warning if Windows Server 2008 Service Pack 1, We end support Windows Server 2008 SP1 on July 12, advice customer to upgrade to SP2. [AutoAdded]
	Run-DiagExpression .\TS_ServicePackKB2590494Check.ps1

	# Checks 32 bit windows server 2003 / 2008 to see is DEP is disabled, if so it might not detect more than 4 GB of RAM. [AutoAdded]
	Run-DiagExpression .\TS_DEPDisabled4GBCheck.ps1

	# Check for Sophos BEFLT.SYS version 5.60.1.7 [AutoAdded]
	Run-DiagExpression .\TS_B2693877_Sophos_BEFLTCheck.ps1

	# [Idea ID 2695] [Windows] Check the Log On account for the Telnet service to verify it's not using the Local System account [AutoAdded]
	Run-DiagExpression .\TS_TelnetSystemAccount.ps1

	# [Idea ID 2842] [Windows] Alert Engineers if they are working on a Dell machine models R910, R810 and M910 [AutoAdded]
	Run-DiagExpression .\TS_DellPowerEdgeBiosCheck.ps1

	# [Idea ID 2389] [Windows] Hang caused by kernel memory depletion due 'SystemPages' reg key with wrong value [AutoAdded]
	Run-DiagExpression .\TS_MemoryManagerSystemPagesCheck.ps1

	# [Idea ID 7065] [Windows] Alert users about Windows XP EOS [AutoAdded]
	Run-DiagExpression .\TS_WindowsXPEOSCheck.ps1

	# [KSE Rule] [ Windows V3] HpCISSs2 version 62.26.0.64 causes 0xD1 or 0x9E [AutoAdded]
	Run-DiagExpression .\TS_HpCISSs2DriverIssueCheck.ps1

	# check for WMI corruption on HP systems [AutoAdded]
	Run-DiagExpression .\TS_HPWMICheck.ps1

	# Hyper-V KB 982210 check [AutoAdded]
	Run-DiagExpression .\TS_HyperVSCSIDiskEnum.ps1

	# Hyper-V KB 975530 check (Xeon Processor Errata) [AutoAdded]
	Run-DiagExpression .\TS_HyperVXeon5500Check.ps1

	# Checks if Windows Server 2008 R2 SP1, Hyper-V, and Hotfix 2263829 are installed if they are generate alert [AutoAdded]
	Run-DiagExpression .\TS_HyperVKB2263829Check.ps1

	# Checks if Windows Server 2008 R2 SP1, Hyper-V, and Tunnel.sys driver are installed if they are generate alert [AutoAdded]
	Run-DiagExpression .\TS_ServerCoreKB978309Check.ps1

	# Check for event ID 21203 or 21125 [AutoAdded]
	Run-DiagExpression .\TS_CheckEvtID_KB2475761.ps1

	# [Idea ID 6134] [Windows] You cannot start Hyper-V virtual machines after you enable the IO verification option on a HyperV [AutoAdded]
	Run-DiagExpression .\TS_HyperVCheckVerificationKB2761004.ps1

	# [Idea ID 5438] [Windows] Windows 2012 Hyper-V SPN and SCP not registed if customer uses a non default dynamicportrange [AutoAdded]
	Run-DiagExpression .\TS_HyperVEvent14050Check.ps1

	# [Idea ID 5752] [Windows] BIOS update may be required for some computers before starting Hyper-V on 2012 [AutoAdded]
	Run-DiagExpression .\TS_HyperV2012-CS-BIOS-Check.ps1

	# [Idea ID 3474] [Windows] Pending Trans Rule - PendingXmlIdentifier, NextQueueEntryIndex, AdvancedInstallersNeedResolving [AutoAdded]
	Run-DiagExpression .\TS_ServicingComponentsReg.ps1

	# [Idea ID 3472] [Windows] Pending Transactions Rule Idea - Pending.xml [AutoAdded]
	Run-DiagExpression .\TS_ServicingPendingXml.ps1

	# [Idea ID 3002] [Windows] SP1 installation on Windows 7 and Windows Server 2008 R2 fails with the error 0x800F0826 [AutoAdded]
	Run-DiagExpression .\TS_UsbstorSystemPermissionsSPCheck.ps1

	# [Idea ID 5712] [Windows] Run Dism checkhealth on Win8 or 2012 to detect possible servicing corruption [AutoAdded]
	Run-DiagExpression .\TS_ServicingCorruptionCheck.ps1

	# [Idea ID 1922] [Windows] On Windows 2008 R2 and Windows 7 System state backup fails with event id 5 and error 2155347997 [AutoAdded]
	Run-DiagExpression .\TS_BackupSystemStateKB2182466.ps1

	# [Idea ID 3919] [Windows] Create Shadow Copy fail only on VERTIAS storage foundation volume [AutoAdded]
	Run-DiagExpression .\TS_VeritasVXIOBadConfigFlags.ps1

	# [Idea ID 3059] [Windows] Ntbackup high CPU and hang [AutoAdded]
	Run-DiagExpression .\TS_FilesNotToBackup2K3Check.ps1

	# [Idea ID 2004] [Windows] Bitlocker Drive Preparation fails with Error 'The new active drive cannot be formatted.' [AutoAdded]
	Run-DiagExpression .\TS_BitlockerDenyWriteFixedPolicy.ps1

	# [Idea ID 5327] [Windows] Machine imaged using vlite 1.2 will fail to install SP1 [AutoAdded]
	Run-DiagExpression .\TS_MachineImageVliteCheck.ps1

	# [Idea ID 6711] [Windows] MSI package fails to install with error code HRESULT -2147319780 [AutoAdded]
	Run-DiagExpression .\TS_MSIPackageInstallationCheck.ps1

	# SurfaceDetectWifiDriverVersion [AutoAdded]
	Run-DiagExpression .\TS_SurfaceDetectWifiDriverVersion.ps1

	# SurfaceDetectFirmwareVersions [AutoAdded]
	Run-DiagExpression .\TS_SurfaceDetectFirmwareVersions.ps1

	# SurfaceDetectConnectedStandbyStatus [AutoAdded]
	Run-DiagExpression .\TS_SurfaceDetectConnectedStandbyStatus.ps1

	# Surface  [AutoAdded]
	Run-DiagExpression .\DC_Surface.ps1

	# Collect summary report [AutoAdded]
	Run-DiagExpression .\DC_SummaryReliability.ps1


# SIG # Begin signature block
# MIIdvgYJKoZIhvcNAQcCoIIdrzCCHasCAQExCzAJBgUrDgMCGgUAMGkGCisGAQQB
# gjcCAQSgWzBZMDQGCisGAQQBgjcCAR4wJgIDAQAABBAfzDtgWUsITrck0sYpfvNR
# AgEAAgEAAgEAAgEAAgEAMCEwCQYFKw4DAhoFAAQULbo4nnt+RMy03MXWa2lq9eVF
# s2ugghhkMIIEwzCCA6ugAwIBAgITMwAAAKxjFufjRlWzHAAAAAAArDANBgkqhkiG
# 9w0BAQUFADB3MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSEw
# HwYDVQQDExhNaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EwHhcNMTYwNTAzMTcxMzIz
# WhcNMTcwODAzMTcxMzIzWjCBszELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjENMAsGA1UECxMETU9QUjEnMCUGA1UECxMebkNpcGhlciBEU0UgRVNO
# OkMwRjQtMzA4Ni1ERUY4MSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBT
# ZXJ2aWNlMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAnyHdhNxySctX
# +G+LSGICEA1/VhPVm19x14FGBQCUqQ1ATOa8zP1ZGmU6JOUj8QLHm4SAwlKvosGL
# 8o03VcpCNsN+015jMXbhhP7wMTZpADTl5Ew876dSqgKRxEtuaHj4sJu3W1fhJ9Yq
# mwep+Vz5+jcUQV2IZLBw41mmWMaGLahpaLbul+XOZ7wi2+qfTrPVYpB3vhVMwapL
# EkM32hsOUfl+oZvuAfRwPBFxY/Gm0nZcTbB12jSr8QrBF7yf1e/3KSiqleci3GbS
# ZT896LOcr7bfm5nNX8fEWow6WZWBrI6LKPx9t3cey4tz0pAddX2N6LASt3Q0Hg7N
# /zsgOYvrlwIDAQABo4IBCTCCAQUwHQYDVR0OBBYEFCFXLAHtg1Boad3BTWmrjatP
# lDdiMB8GA1UdIwQYMBaAFCM0+NlSRnAK7UD7dvuzK7DDNbMPMFQGA1UdHwRNMEsw
# SaBHoEWGQ2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1Y3Rz
# L01pY3Jvc29mdFRpbWVTdGFtcFBDQS5jcmwwWAYIKwYBBQUHAQEETDBKMEgGCCsG
# AQUFBzAChjxodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY3Jv
# c29mdFRpbWVTdGFtcFBDQS5jcnQwEwYDVR0lBAwwCgYIKwYBBQUHAwgwDQYJKoZI
# hvcNAQEFBQADggEBAEY2iloCmeBNdm4IPV1pQi7f4EsNmotUMen5D8Dg4rOLE9Jk
# d0lNOL5chmWK+d9BLG5SqsP0R/gqph4hHFZM4LVHUrSxQcQLWBEifrM2BeN0G6Yp
# RiGB7nnQqq86+NwX91pLhJ5LBzJo+EucWFKFmEBXLMBL85fyCusCk0RowdHpqh5s
# 3zhkMgjFX+cXWzJXULfGfEPvCXDKIgxsc5kUalYie/mkCKbpWXEW6gN+FNPKTbvj
# HcCxtcf9mVeqlA5joTFe+JbMygtOTeX0Mlf4rTvCrf3kA0zsRJL/y5JdihdxSP8n
# KX5H0Q2CWmDDY+xvbx9tLeqs/bETpaMz7K//Af4wggYHMIID76ADAgECAgphFmg0
# AAAAAAAcMA0GCSqGSIb3DQEBBQUAMF8xEzARBgoJkiaJk/IsZAEZFgNjb20xGTAX
# BgoJkiaJk/IsZAEZFgltaWNyb3NvZnQxLTArBgNVBAMTJE1pY3Jvc29mdCBSb290
# IENlcnRpZmljYXRlIEF1dGhvcml0eTAeFw0wNzA0MDMxMjUzMDlaFw0yMTA0MDMx
# MzAzMDlaMHcxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYD
# VQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAf
# BgNVBAMTGE1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQTCCASIwDQYJKoZIhvcNAQEB
# BQADggEPADCCAQoCggEBAJ+hbLHf20iSKnxrLhnhveLjxZlRI1Ctzt0YTiQP7tGn
# 0UytdDAgEesH1VSVFUmUG0KSrphcMCbaAGvoe73siQcP9w4EmPCJzB/LMySHnfL0
# Zxws/HvniB3q506jocEjU8qN+kXPCdBer9CwQgSi+aZsk2fXKNxGU7CG0OUoRi4n
# rIZPVVIM5AMs+2qQkDBuh/NZMJ36ftaXs+ghl3740hPzCLdTbVK0RZCfSABKR2YR
# JylmqJfk0waBSqL5hKcRRxQJgp+E7VV4/gGaHVAIhQAQMEbtt94jRrvELVSfrx54
# QTF3zJvfO4OToWECtR0Nsfz3m7IBziJLVP/5BcPCIAsCAwEAAaOCAaswggGnMA8G
# A1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFCM0+NlSRnAK7UD7dvuzK7DDNbMPMAsG
# A1UdDwQEAwIBhjAQBgkrBgEEAYI3FQEEAwIBADCBmAYDVR0jBIGQMIGNgBQOrIJg
# QFYnl+UlE/wq4QpTlVnkpKFjpGEwXzETMBEGCgmSJomT8ixkARkWA2NvbTEZMBcG
# CgmSJomT8ixkARkWCW1pY3Jvc29mdDEtMCsGA1UEAxMkTWljcm9zb2Z0IFJvb3Qg
# Q2VydGlmaWNhdGUgQXV0aG9yaXR5ghB5rRahSqClrUxzWPQHEy5lMFAGA1UdHwRJ
# MEcwRaBDoEGGP2h0dHA6Ly9jcmwubWljcm9zb2Z0LmNvbS9wa2kvY3JsL3Byb2R1
# Y3RzL21pY3Jvc29mdHJvb3RjZXJ0LmNybDBUBggrBgEFBQcBAQRIMEYwRAYIKwYB
# BQUHMAKGOGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbS9wa2kvY2VydHMvTWljcm9z
# b2Z0Um9vdENlcnQuY3J0MBMGA1UdJQQMMAoGCCsGAQUFBwMIMA0GCSqGSIb3DQEB
# BQUAA4ICAQAQl4rDXANENt3ptK132855UU0BsS50cVttDBOrzr57j7gu1BKijG1i
# uFcCy04gE1CZ3XpA4le7r1iaHOEdAYasu3jyi9DsOwHu4r6PCgXIjUji8FMV3U+r
# kuTnjWrVgMHmlPIGL4UD6ZEqJCJw+/b85HiZLg33B+JwvBhOnY5rCnKVuKE5nGct
# xVEO6mJcPxaYiyA/4gcaMvnMMUp2MT0rcgvI6nA9/4UKE9/CCmGO8Ne4F+tOi3/F
# NSteo7/rvH0LQnvUU3Ih7jDKu3hlXFsBFwoUDtLaFJj1PLlmWLMtL+f5hYbMUVbo
# nXCUbKw5TNT2eb+qGHpiKe+imyk0BncaYsk9Hm0fgvALxyy7z0Oz5fnsfbXjpKh0
# NbhOxXEjEiZ2CzxSjHFaRkMUvLOzsE1nyJ9C/4B5IYCeFTBm6EISXhrIniIh0EPp
# K+m79EjMLNTYMoBMJipIJF9a6lbvpt6Znco6b72BJ3QGEe52Ib+bgsEnVLaxaj2J
# oXZhtG6hE6a/qkfwEm/9ijJssv7fUciMI8lmvZ0dhxJkAj0tr1mPuOQh5bWwymO0
# eFQF1EEuUKyUsKV4q7OglnUa2ZKHE3UiLzKoCG6gW4wlv6DvhMoh1useT8ma7kng
# 9wFlb4kLfchpyOZu6qeXzjEp/w7FW1zYTRuh2Povnj8uVRZryROj/TCCBhAwggP4
# oAMCAQICEzMAAABkR4SUhttBGTgAAAAAAGQwDQYJKoZIhvcNAQELBQAwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMTAeFw0xNTEwMjgyMDMxNDZaFw0xNzAx
# MjgyMDMxNDZaMIGDMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQ
# MA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9u
# MQ0wCwYDVQQLEwRNT1BSMR4wHAYDVQQDExVNaWNyb3NvZnQgQ29ycG9yYXRpb24w
# ggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCTLtrY5j6Y2RsPZF9NqFhN
# FDv3eoT8PBExOu+JwkotQaVIXd0Snu+rZig01X0qVXtMTYrywPGy01IVi7azCLiL
# UAvdf/tqCaDcZwTE8d+8dRggQL54LJlW3e71Lt0+QvlaHzCuARSKsIK1UaDibWX+
# 9xgKjTBtTTqnxfM2Le5fLKCSALEcTOLL9/8kJX/Xj8Ddl27Oshe2xxxEpyTKfoHm
# 5jG5FtldPtFo7r7NSNCGLK7cDiHBwIrD7huTWRP2xjuAchiIU/urvzA+oHe9Uoi/
# etjosJOtoRuM1H6mEFAQvuHIHGT6hy77xEdmFsCEezavX7qFRGwCDy3gsA4boj4l
# AgMBAAGjggF/MIIBezAfBgNVHSUEGDAWBggrBgEFBQcDAwYKKwYBBAGCN0wIATAd
# BgNVHQ4EFgQUWFZxBPC9uzP1g2jM54BG91ev0iIwUQYDVR0RBEowSKRGMEQxDTAL
# BgNVBAsTBE1PUFIxMzAxBgNVBAUTKjMxNjQyKzQ5ZThjM2YzLTIzNTktNDdmNi1h
# M2JlLTZjOGM0NzUxYzRiNjAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzcitW2oynUC
# lTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtp
# b3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEGCCsGAQUF
# BwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3Br
# aW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0MAwGA1Ud
# EwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAIjiDGRDHd1crow7hSS1nUDWvWas
# W1c12fToOsBFmRBN27SQ5Mt2UYEJ8LOTTfT1EuS9SCcUqm8t12uD1ManefzTJRtG
# ynYCiDKuUFT6A/mCAcWLs2MYSmPlsf4UOwzD0/KAuDwl6WCy8FW53DVKBS3rbmdj
# vDW+vCT5wN3nxO8DIlAUBbXMn7TJKAH2W7a/CDQ0p607Ivt3F7cqhEtrO1Rypehh
# bkKQj4y/ebwc56qWHJ8VNjE8HlhfJAk8pAliHzML1v3QlctPutozuZD3jKAO4WaV
# qJn5BJRHddW6l0SeCuZmBQHmNfXcz4+XZW/s88VTfGWjdSGPXC26k0LzV6mjEaEn
# S1G4t0RqMP90JnTEieJ6xFcIpILgcIvcEydLBVe0iiP9AXKYVjAPn6wBm69FKCQr
# IPWsMDsw9wQjaL8GHk4wCj0CmnixHQanTj2hKRc2G9GL9q7tAbo0kFNIFs0EYkbx
# Cn7lBOEqhBSTyaPS6CvjJZGwD0lNuapXDu72y4Hk4pgExQ3iEv/Ij5oVWwT8okie
# +fFLNcnVgeRrjkANgwoAyX58t0iqbefHqsg3RGSgMBu9MABcZ6FQKwih3Tj0DVPc
# gnJQle3c6xN3dZpuEgFcgJh/EyDXSdppZzJR4+Bbf5XA/Rcsq7g7X7xl4bJoNKLf
# cafOabJhpxfcFOowMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkqhkiG9w0B
# AQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNV
# BAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAG
# A1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTEw
# HhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQGEwJVUzET
# MBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMV
# TWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQgQ29kZSBT
# aWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA
# q/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03a8YS2Avw
# OMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akrrnoJr9eW
# WcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0RrrgOGSsbmQ1
# eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy4BI6t0le
# 2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9sbKvkjh+
# 0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAhdCVfGCi2
# zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8kA/DRelsv
# 1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTBw3J64HLn
# JN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmnEyimp31n
# gOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90lfdu+Hgg
# WCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0wggHpMBAG
# CSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2oynUClTAZ
# BgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/
# BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBaBgNVHR8E
# UzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9k
# dWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsGAQUFBwEB
# BFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9j
# ZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNVHSAEgZcw
# gZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsGAQUFBwIC
# MDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABlAG0AZQBu
# AHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKbC5YR4WOS
# mUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11lhJB9i0ZQ
# VdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6I/MTfaaQ
# dION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0wI/zRive
# /DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560STkKxgrC
# xq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQamASooPoI/
# E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGaJ+HNpZfQ
# 7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ahXJbYANah
# Rr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA9Z74v2u3
# S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33VtY5E90Z1W
# Tk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr/Xmfwb1t
# bWrJUnMTDXpQzTGCBMQwggTAAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25pbmcg
# UENBIDIwMTECEzMAAABkR4SUhttBGTgAAAAAAGQwCQYFKw4DAhoFAKCB2DAZBgkq
# hkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgorBgEEAYI3AgELMQ4wDAYKKwYBBAGC
# NwIBFTAjBgkqhkiG9w0BCQQxFgQU4LXp1GSrcZRtPG/Ug/N9KfNAF8AweAYKKwYB
# BAGCNwIBDDFqMGigToBMAEMAVABTAHcAaQBuAGQAbwB3AHMAcwBlAHQAdQBwAF8A
# VABTAF8AQQB1AHQAbwBBAGQAZABDAG8AbQBtAGEAbgBkAHMALgBwAHMAMaEWgBRo
# dHRwOi8vbWljcm9zb2Z0LmNvbTANBgkqhkiG9w0BAQEFAASCAQBmsUmXyeM/bTs4
# 4Owct/YnacnLs7IvxmGwT1rRPOeWcc0snc0Z+SRU47dKT8OriiH2JR4HhyFGvJ8d
# MiHKvVNxeGGrSsEEC2sTceI89VXJ3hXh1nh6uwKeqXkkDlcqZjnyX3C98zS56IDZ
# +YbeHp6bAwogZENLXuACJTdM3AvHg4AURntFqypLDDRH97iGz5TcyVDfBrv9gb0F
# +WnCg7iFcRiAD2S0feh3XGapJ6WGIten/eT4QKUwrFKNIO2vbkgJpEL4JonwkXsW
# 1sxM0kjaALu8qtUoZSBN/LejBKW+uZY9bLu7ZlGXtGQ/52+z5K6ZU1riHHeC28eE
# Qf8NKscWoYICKDCCAiQGCSqGSIb3DQEJBjGCAhUwggIRAgEBMIGOMHcxCzAJBgNV
# BAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4w
# HAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xITAfBgNVBAMTGE1pY3Jvc29m
# dCBUaW1lLVN0YW1wIFBDQQITMwAAAKxjFufjRlWzHAAAAAAArDAJBgUrDgMCGgUA
# oF0wGAYJKoZIhvcNAQkDMQsGCSqGSIb3DQEHATAcBgkqhkiG9w0BCQUxDxcNMTYw
# NzI4MjAwODI5WjAjBgkqhkiG9w0BCQQxFgQU40m8DNc9Xoe3xV/sv/fot3S7b+gw
# DQYJKoZIhvcNAQEFBQAEggEAX5UBGWVx8Vdt+xO+Gmbfs6bnytscfkhib3o2O0kh
# ZJ/dcongvIaZowDBnkKlIg4awj9qhx5KC61YubBrZnNStH5OG7XDRqRx/iZnaNff
# wf9fXTi01cjMTjZnT2MSr8lWaaXPQDjylu8OvkeDG93bxxpsvDGNdhslfi2FyUYK
# 33h583Txa8QxBvkD/AJmDKgQ/3ralJ4xvvwTbV3mW+5fcT3UPtusGW3eY+Sukqu7
# H77EtsRtgbYFD2EDfaAxhAd5OAs11CtqUE+Ni2gupwel8e/yaRqito+gQNjyB/bk
# /40vwovnElZiiS/mFEI/469l2gBJPN9EXepSqpwcyXnUnQ==
# SIG # End signature block
