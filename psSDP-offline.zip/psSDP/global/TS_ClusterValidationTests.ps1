﻿#************************************************
# TS_ClusterValidationTests.ps1
# Version 1.0.1
# Date: 07-24-2009
# Author: Andre Teixeira - andret@microsoft.com
# Hacked by Jacques Boulet - jaboulet@microsoft.com - 2019-02-21
# Description: This script is used to obtain cluster validation report.
#              Before validation, script also confirms it is able to connect to remote systems via SCM
#************************************************

if ($OSVersion.Build -ge 7600)
{

    # Okay, so Validation tests have changed over different versions of Windows. Some test were added and 
    # some got removed via previous versions. So what we are going to do is just seperate this into two 
    # differnt if statements so the correct tests get set. 

    # TODO: Test if the changes I have made will work in Server 2008 through 2012 R2

    # Let's first set an empty array that we will use in our definfing of the tests. 
    $ValidationTests = @()

    # If we are greater than or equal to Server 2008 R2 and LE Server 2012 R2 then we set the test to the old way of doing things. 
    # if (($OSVersion.Build -ge 7600) -and ($OSVersion.Build -le 9600)){
    	    $ValidationTests = "List BIOS Information", 
		    "List Fibre Channel Host Bus Adapters", 
		    "List iSCSI Host Bus Adapters", 
		    "List Memory Information", 
		    "List Operating System Information", 
		    "List Plug and Play Devices", 
		    "List SAS Host Bus Adapters", 
		    "List Services Information", 
		    "List Software Updates", 
		    "List System Drivers", 
		    "List System Information", 
		    "List All Disks", 
		    "Validate Network Communication",
		    "Validate Windows Firewall Configuration",
		    "Validate Cluster Network Configuration",
		    "Validate IP Configuration",
		    "Validate Active Directory Configuration", 
		    "Validate Cluster Service and Driver Settings", 
		    "Validate Service Pack Levels", 
		    "Validate Same Processor Architecture", 
		    "Validate Software Update Levels", 
		    "Validate System Drive Variable", 
		    "Validate Required Services", 
		    "Validate Operating System Installation Option"
	#_#}
	if (($OSVersion.Build -ge 7600) -and ($OSVersion.Build -le 9600))	{ $ValidationTests +="List Network Binding Order"}
	if ($OSVersion.Build -gt 9600 )	{ $ValidationTests +="List Network Metric Order"} #_# likely not needed
					
    # If we are newer to Server 2012 R2 then we do things the new way. 
    if ($OSVersion.Build -gt 9600 ){
        #
        # Default Tests we will test these no matter the circumstances:
        # System Configuration, Network, Inventory, Cluster Configuration
        # There might be some fails in these because it's a blanket test. We are testing EVERYTHING in these categories 

        # We make our Array of test we will start off with. 
        $ValidationTests = "System Configuration", "Network", "Inventory", "Cluster Configuration"
        #_# $ignore = "Storage" # I don't think I need this. 

        # Now for some simple tests to determine if we are running Hyper-V and or S2D then add those tests to the $validation array
        Try 
			{ $HV = Get-VM }
		Catch [System.Management.Automation.CommandNotFoundException] 
			{ Write-Host " [Info] No Hyper-V Detected" }

        # Test for Hyper-V. So I realize that someone, somewhere out in the world might have Hyper-V and Failover Cluster installed side by side but do not actually have a Hyper-V cluster. We need to detect if that is the case. 
        if ($hv -ne $null){ 
            Write-DiagProgress -activity $ClusterValidationStrings.ID_ClusterValidationDetectHyperV
            # Write-Host "Detected Hyper-V, Checking for clustered VMs"
            # We're going to do a loop and if IsClustered returns true then we will add Hyper-V tests to the list and break the loop. 
            foreach ($cvm in $hv.IsClustered){
                if ($cvm -eq $true){
                    Write-DiagProgress -activity $ClusterValidationStrings.ID_ClusterValidationAddHyperV
                    # Write-Host "Found a clustered VM, adding Hyper-V to the cluster tests"
                    $ValidationTests += "Hyper-V"
                    Break
                }
            }
        } else {
            Write-Verbose "Hyper-V not detected"
        }

        # Now we Test for S2D
		$SSD = Get-StorageEnclosure
        if ($SSD -ne $null){
            Write-DiagProgress -activity $ClusterValidationStrings.ID_ClusterValidationDetectS2D
            #Write-Host "S2D detected, adding the S2D tests to the list"
            $ValidationTests += "Storage Spaces Direct"
        } else {
            # IF Get-VM is null then there are no VMs, Hyper-V could still be instaled though. 
            Write-Verbose "S2D not detected"
        }
    }

    # Back to business as usual before my hack

    # TODO: I don't think pinging a server is the best way to go about determining if the server is alive or not. 
    # Cluster has some required ports that must be open if we are going to work correclty, I think testing a 
    # connection to one or more of those ports is better. 

	Import-LocalizedData -BindingVariable ClusterValidationStrings

	Write-DiagProgress -activity $ClusterValidationStrings.ID_ClusterValidationReport -status $ClusterValidationStrings.ID_ClusterValidationReportObtaining

	$ClusterServiceKey="HKLM:\Cluster"

	if (Test-Path $ClusterServiceKey) 
	{

		Import-Module FailoverClusters
		
		$ClusterNodes = Get-ClusterNode

		$ServersWithValidCommunication = $null
		$OnlineServersWithSCMIssues = ""
		foreach ($ClusterNode in $ClusterNodes) {
			#Try to connect to Cluster node using SCM.
			#Validation tests fail if remote server is not accessible via SCM
			$Status = $ClusterValidationStrings.ID_ClusterValidationReportStatus -replace("%Node%", $ClusterNode.Name)
			Write-DiagProgress -activity $ClusterValidationStrings.ID_ClusterValidationReport -status $Status 
			
			##First - Ping remote server to check if it is alive:

			$ping = new-object System.Net.NetworkInformation.Ping
			$pingResults = $ping.Send($ClusterNode.Name)

			if ($pingResults.Status.value__ -eq 0) { #Success
				$Error.Clear()
				$ServerName = ($ClusterNode.Name)
				
				##Try to query serive status of each node
				
				$CluServiceForNode = Get-Service -ComputerName $ServerName | Where-Object {$_.Name -eq "ClusSvc"}

				if ($CluServiceForNode -eq $null) 
				{
					if ($ClusterNode.State.Value__ -ne 1) 
					{ #Down
						if ($OnlineServersWithSCMIssues -ne "") {$OnlineServersWithSCMIssues += " and "}
						$OnlineServersWithSCMIssues += $ClusterNode.Name
					}
				} else {
					$ServersWithValidCommunication += [array] $ClusterNode.Name
				}
				
				if ($Error.Count -ne 0) 
				{
					"[TS_ClusterValidationTests.ps1] Error Obtaining status from ClusSvc service: " + $Error[0].Exception.Message | WriteTo-StdOut
				}
			}
		}

		if ($OnlineServersWithSCMIssues -ne "") 
		{
			#Disabling this for now
			#Update-DiagRootCause -id "RC_ClusterSCMError" -Detected $true -Parameter @{"NodeName"=$OnlineServersWithSCMIssues;}
		}

		if ($ServersWithValidCommunication.Count -gt 0)
		{
			Write-DiagProgress -activity $ClusterValidationStrings.ID_ClusterValidationReport -status $ClusterValidationStrings.ID_ClusterValidationReportTestNet
			
			$OutputfileName = $PWD.Path + "\" + $Computername + "_ValidationReport.mht.htm"

			$Error.Clear()

			$TestMHTFile = Test-Cluster -include $ValidationTests -node $ServersWithValidCommunication

			if ($Error.Count -gt 0) 
			{
			
				$ValidationError_Summary = new-object PSObject
				$ID = 0
				ForEach ($Err in $Error) 
				{
					$Name = "Error [" + $ID.ToString() + "]"
					$ID += 1
					$ErrorString = $Err.Exception.Message
					add-member -inputobject $ValidationError_Summary -membertype noteproperty -name $Name -value $ErrorString
				}
				$XMLFileName = "..\ValidationErrors.XML"
				$XMLObj = $ValidationError_Summary | ConvertTo-Xml2 
				
				#Disabling below as root cause for now
				
				#$XMLObj.Save($XMLFileName)		
				#Update-DiagRootCause -id "RC_ClusterValidationError" -Detected $true -Parameter @{"XMLFileName"=$XMLFileName}			
				
			}
			
			If ($TestMHTFile) {
                   If (Test-Path $TestMHTFile.FullName) 
			    {
				$ValidationXMLFileName = $TestMHTFile.DirectoryName + "\" + $TestMHTFile.BaseName + ".xml"
				
				$TestMHTFile | Move-Item -Destination $outputfileName
				
				CollectFiles -filesToCollect $outputfileName -fileDescription "Validation Report" -sectionDescription "Cluster Validation Test Report"

				#Open the XML version to look for Warnings and Errors. If any found, create alerts.

				if (Test-Path $ValidationXMLFileName) 
				{
					[xml] $ValidationXMLDoc = Get-Content -Path $ValidationXMLFileName
					if ($ValidationXMLDoc -ne $null) {
						$WarningNode = $ValidationXMLDoc.SelectNodes("//Channel/Message[@Level=`'Warn`']").Item(0)
						$ErrNode = $ValidationXMLDoc.SelectNodes("//Channel/Message[@Level=`'Fail`']").Item(0)
						if (($WarningNode -ne $null) -or ($ErrNode -ne $null)) 
						{
							Update-DiagRootCause -id "RC_ClusterValidationTests" -Detected $true -Parameter @{"XMLFileName"=$ValidationXMLFileName}
						}
					}
				}
			} else {
				    "[TS_ClusterValidationTests.ps1] Error: " + $TestMHTFile.FullName + " does not exist." | WriteTo-StdOut
			    } 
            }
		}
	} else {
		"[TS_ClusterValidationTests.ps1] Info: Machine $Computername is not a cluster" | WriteTo-StdOut
	}
}
else
{
	"[TS_ClusterValidationTests.ps1] OS Build " + $OSVersion.Build + " does not support validation tests" | WriteTo-StdOut
}
