<# Script name: Get-psSDP.ps1
::
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
::
Purpose: Powershell Script to collect SDP (Support Diagnostic Platform) report
Help: get-help .\Get-psSDP.ps1 -detailed
last edit by: waltere 2018-12-10
File Name: Get-psSDP.ps1
#> 

<#
.SYNOPSIS
The script generates Support Diagnostic Platform files (*_msinfo.*, hotfixes.*, _sym.*, *_pstat.txt) to run in PowerShell window on your system.
One package to collect SDPs for different speciality reports (SDPtech), also able to collect Mini (*_msinfo.*, hotfixes.*, _sym.*, *_pstat.txt) or Nano (network) report.

.DESCRIPTION
The script generates Support Diagnostic files when running in an elevated PowerShell window on your system.
It will collect the same file set as done in classic CSS SDP troubleshooters.
To start data collection, open an elevated PowerShell CMD
Usage:
 .\Get-psSDP.ps1 [Net|Dom|CTS|Print|HyperV|Setup|Cluster|Perf|Mini|Nano|Repro]

If you get an error that running scripts is disabled, run "Set-ExecutionPolicy Bypass -force -Scope Process" and then run ".\Get-psSDP.ps1" again.

.EXAMPLE
 Example for collecting SDP Networking Diagnostic data, saving data to folder C:\temp:
  .\Get-psSDP.ps1 Net -savePath C:\temp

 Example for SDP Basic minimal data collection, saving data to current folder:
  .\Get-psSDP.ps1 Mini
  
 Example for SDP Net without zipping results:
  .\Get-psSDP.ps1 Net NoCab
  
.LINK
email: waltere@microsoft.com
#>

Param(
	[ValidateSet("Net","Dom","CTS","Print","HyperV","Setup","Perf","Cluster","Remote","vss","mini","nano","Repro")]
	[Parameter(Mandatory=$True,Position=0,HelpMessage='Choose one technology from: Net|Dom|CTS|Print|HyperV|Setup|Perf|Cluster|Remote|VSS|mini|nano')]
	[string]$SDPtech
	,
	[string]$savePath = (Split-Path $MyInvocation.MyCommand.Path -Parent),
	[switch]$NoCab,
	[switch]$ZipIt
	,
	[ValidateSet("on","off")]
	[Parameter(Mandatory=$False,HelpMessage='Debug facility: on|off')]
	[string]$Debug_script = "off"
	)

#region ::::: Helper Functions ::::
function Get-TimeStamp {
# PURPOSE: Returns a timestamp string
 return "$(Get-Date -format "yyyyMMdd_HHmmss_ffff")"
} # end Get-TimeStamp

Function Zip-Files(
        [Parameter(Position=0, Mandatory=$true, ValueFromPipeline=$false)]
        [string] $zipfilename,
        [Parameter(Position=1, Mandatory=$true, ValueFromPipeline=$false)]
        [string] $sourcedir,
        [Parameter(Position=2, Mandatory=$false, ValueFromPipeline=$false)]
        [bool] $overwrite)
	{
		if ($Script:PSver -le 2) 
			{ Write-Output "Compression not supported for this PS version: $Script:PSver"
			return $false
			}
		else {
			Add-Type -Assembly System.IO.Compression.FileSystem
			$compressionLevel = [System.IO.Compression.CompressionLevel]::Optimal
			if ($overwrite -eq $true ) { if (Test-Path $zipfilename) { Remove-Item $zipfilename } }
			[System.IO.Compression.ZipFile]::CreateFromDirectory($sourcedir, $zipfilename, $compressionLevel, $false)
			return $true
		}
	}

function Create-ZipFromDirectory
{
    <#

    .DESCRIPTION
    Creates a ZIP file from a given the directory.

    .PARAMETER SourceDirectory
    The folder with the files you intend to zip.
    
    .PARAMETER ZipFileName
    The zip file that you intend to create
    
    .PARAMETER IncludeParentDirectory
    Setting this option will include the parent directory.
    
    .PARAMETER Overwrite
    Setting this option will overwrite the zip file if already exits.
    
    .EXAMPLE
    Create-ZipFromDirectory -Source $ResultRootDirectory -ZipFileName $CompressedResultFileName -IncludeParentDirectory -Overwrite

    .EXAMPLE
    Create-ZipFromDirectory -S $ResultRootDirectory -O $CompressedResultFileName -Rooted -Force

    #>

    PARAM
    (
        [Alias('S')]
        [Parameter(Position = 1, Mandatory = $true)]
        [ValidateScript({Test-Path -Path $_})]
        [string]$SourceDirectory,
     
        [Alias('O')]
        [parameter(Position = 2, Mandatory = $false)]
        [string]$ZipFileName,

        [Alias('Rooted')]
        [Parameter(Mandatory = $false)]
        [switch]$IncludeParentDirectory,

        [Alias('Force')]
        [Parameter(Mandatory = $false)]
        [switch]$Overwrite
    )
    PROCESS
    {
        $ZipFileName = (("{0}.zip" -f $ZipFileName), $ZipFileName)[$ZipFileName.EndsWith('.zip', [System.StringComparison]::OrdinalIgnoreCase)]

        if(![System.IO.Path]::IsPathRooted($ZipFileName))
        {
            $ZipFileName = ("{0}\{1}" -f (Get-Location), $ZipFileName)
        }
                    
        if($Overwrite)
        {
           if(Test-Path($ZipFileName)){ Remove-Item $ZipFileName -Force -ErrorAction SilentlyContinue }
        }
        
        $source = Get-Item $SourceDirectory

        if ($source.PSIsContainer)
        {
            if($newZipperAvailable -eq $null)
            {
                try
                {
                    $ErrorActionPreference = 'Stop'
                    Add-Type -AssemblyName System.IO.Compression.FileSystem
                    $newZipperAvailable = $true
                }
                catch
                {
                    $newZipperAvailable = $false
                }
            }

            if($newZipperAvailable -eq $true) # More efficent and works silently.
            {
                [System.IO.Compression.ZipFile]::CreateFromDirectory($source.FullName, $ZipFileName, [System.IO.Compression.CompressionLevel]::Optimal, $IncludeParentDirectory)
            }
            else # Will show progress dialog.
            {

                # Preparing zip if not available.
                if(-not(Test-Path($ZipFileName)))
                {
                    Set-Content $ZipFileName (“PK” + [char]5 + [char]6 + (“$([char]0)” * 18))
                    (dir $ZipFileName).IsReadOnly = $false
                }

                if(-not $IncludeParentDirectory)
                {
                    $source = Get-ChildItem $SourceDirectory
                }
            
                $zipPackage = (New-Object -ComObject Shell.Application).NameSpace($ZipFileName)
        
                [System.Int32]$NoProgressDialog = 16 #Tried but not effective.
                foreach($file in $source)
                { 
                    $zipPackage.CopyHere($file.FullName, $NoProgressDialog)
                    do
                    {
                        Start-Sleep -Milliseconds 256
                    }
                    while ($zipPackage.Items().count -eq 0) # Waiting for an operation to complete.
                }
            }
        }
        else
        {
            Write-Error 'The directory name is invalid.'
        }
    }
}

#endregion ::::: Helper Functions ::::


## customization section of script #########################
$ScriptParentPath 	= Split-Path $MyInvocation.MyCommand.Path -Parent
$global:ToolsPath 	= "$ScriptParentPath\psSDP\global"
$savePathTmp 		= "$savePath`\Results`_$(Get-Timestamp)"
$TranscriptLog	= "$savePathTmp`\_psSDP_$SDPtech`_Transcript_$ComputerName`_$CheckDate`.Log"
############################################################

### MAIN ===================
$computername = $env:computername
$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R").Replace(":","-")
$Script:PSver = $PSVersionTable.PSVersion.Major

$ExecPolicyOrig = get-executionpolicy
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy Bypass -Force
Start-Transcript -Path $TranscriptLog
Write-Host "$(Get-Date -Format 'HH:mm:ss') starting psSDP Data Collection Report for Windows Technology: '$SDPtech'" -ForegroundColor White -BackgroundColor DarkGreen
if (($SDPtech -match "Dom") -or ($SDPtech -match "Cluster")) {Write-Host "Note: You will be asked for additional input for '$SDPtech' report... " -ForegroundColor Yellow}

$ToolsPath = $global:ToolsPath
write-verbose "ScriptParentPath $ScriptParentPath"
write-verbose "ToolsPath        $ToolsPath"
write-verbose "savePathTmp      $savePathTmp"
write-verbose "savePath         $savePath"

$VerMa="1"
$VerMi="02"
$start = Get-Date


### Debug output is stored in $env:TEMP\longGUID.txt i.e. d61ae9b514e84e5984cd8992acd1dd4b.txt
	switch($Debug_script)
		{
		"off"			{$Debug=$false}
		"on"			{$Debug=$true}
		} 

$CurrentPath= get-location	# will jump bak at end of script
if (-NOT (Test-Path $savePathTmp)) {[void](new-item -path $savePathTmp -type directory)}
if (-NOT (Test-Path $savePathTmp\output)) {[void](new-item -path $savePathTmp\output -type directory)}	# for Filter UpdateDiagReport
if (-NOT (Test-Path $savePathTmp\result)) {[void](new-item -path $savePathTmp\result -type directory)}	# in utils_CTS.ps1
#if (-NOT (Test-Path $savePathTmp\results)) {[void](new-item -path $savePathTmp\results -type directory)} # in utils_CTS.ps1

set-location -path $savePathTmp

if (Test-Path $savePathTmp) {
	Write-host "$(Get-Date -UFormat "%R:%S") _Copy utils..."
	Write-Verbose "_Copy-Item *.exe *.dll *.vbs *.sql *.cs *.ps* *.xml *.xsl Files to $($savePathTmp)\* -Force"
	[string[]]$Files = @("exe", "dll", "ico", "js", "mui", "vbs", "sql", "cs", "ps*", "xml", "xsl")
	foreach ($File in $Files)
		{ 
		if ( Get-ChildItem -path "$ToolsPath`\*.$File" -ErrorAction SilentlyContinue ) {[void](Copy-Item "$ToolsPath`\*.$File" $savePathTmp -Force) }
		}
#	\Run_Discovery.ps1 and \ConfigXPLSchema.xml are needed in Discovery
	#_#Copy-Item ($ToolsPath + "\GetDiagInputResponse.xml") $savePathTmp\output -Force #was needed in DOM report - Answerfile Sec-Event
	# Create and copy Images
	if (-NOT (($SDPtech -match "mini") -or ($SDPtech -match "nano"))) {
		if (-NOT (Test-Path $savePathTmp\Images)) {new-item -path $savePathTmp\Images -type directory |out-null}
		$imageFiles =$ToolsPath + "\images\*.png"
		Copy-Item $imageFiles ($savePathTmp + "\Images\")  -Force}
	Write-host "$(Get-Date -UFormat "%R:%S") _Copy utils... done"
	
	### Load Common Library
	Write-Verbose "_Load Common Library"
	. "$ToolsPath\utils_Cts.ps1"
	. "$ToolsPath\Utils_Discovery.ps1"
	. "$ToolsPath\utils_Remote.ps1"	# Filter Update-Diagreport, Function Write-DiagProgress
	if ($SDPtech -match "CTS") {. "$ToolsPath\utils_DSD.ps1"
								. "$ToolsPath\utils_Exchange_all_exchange_versions_using_powershell_should_not_be_called_while_loading_powershell.ps1"
								. "$ToolsPath\utils_Exchange_all_exchange_versions_withoutpowershellaccess.ps1"
								. "$ToolsPath\utils_load20072010powershell.ps1"
								. "$ToolsPath\utils_loadex2013powershell.ps1" }

	$start_info32 = Get-Date
	### collect Mini (*_msinfo.*, hotfixes.*, _sym.*, *_pstat.txt) or Nano (network) report:
	if (($SDPtech -match "mini") -or ($SDPtech -match "nano")) {
		$PSscript_Names = Get-Content "$ToolsPath\_Script_names_$($SDPtech).txt"
		foreach ($line in $PSscript_Names){
			if (-not $line.StartsWith('#')) {
				"$(Get-Date -UFormat "%R:%S") _running_ $line"
				& "$($ToolsPath)\$($line)"
				}
		}
	}
	##### collect various speciality reports (SDPtech):
	else {
		#Write-Verbose "_Copy-Item $ToolsPath`\TS_AutoAddCommands_$SDPtech`.ps1 $savePathTmp`\TS_AutoAddCommands.ps1 -Force"
		if (Test-Path $ToolsPath`\TS_AutoAddCommands_$SDPtech`.ps1) {Copy-Item $ToolsPath`\TS_AutoAddCommands_$SDPtech`.ps1 $savePathTmp`\TS_AutoAddCommands.ps1 -Force}
		#if (Test-Path $ToolsPath`\DiagPackage_$SDPtech`.diagpkg) 	{Copy-Item $ToolsPath`\DiagPackage_$SDPtech`.diagpkg $savePathTmp`\DiagPackage.diagpkg -Force}
		#if (Test-Path $ToolsPath`\DiagPackage_$SDPtech`.dll) 		{Copy-Item $ToolsPath`\DiagPackage_$SDPtech`.dll $savePathTmp`\DiagPackage.dll -Force}
		#if (Test-Path $ToolsPath`\TS_Main_$SDPtech`.ps1) 			{Copy-Item $ToolsPath`\TS_Main_$SDPtech`.ps1 $savePathTmp`\TS_Main.ps1 -Force}
		Write-Host "... starting script: TS_Main_$SDPtech`.ps1 (... please be patient until all modules finished ...)"
		& ".\TS_Main_$SDPtech.ps1"
		Write-Host "$(Get-Date -Format 'HH:mm:ss') *** end psSDP Report for Windows Technology: '$SDPtech'" -ForegroundColor White -BackgroundColor DarkGreen
	}

	## remove Util files
	Write-Verbose "$(Get-Date -UFormat "%R:%S") _Remove utils..." #   
	[string[]]$Files = @("*.exe", "*.dll", "*.ico", "*.js", "*.mui", "*.vbs", "*.sql", "*.cs", "*.ps*", "*.diagpkg", "*.xsl", "results_*.xml", "WUErrors.xml", "SystemPerformance.xml", "PSSDiag.XML", "GetDiagInputResponse.xml", "EventLogAdvisorAlerts.XML", "ConfigXPLSchema.xml")
	foreach ($File in $Files)
	{ 
		if ( Get-ChildItem -path "$savePathTmp\$File" -ErrorAction SilentlyContinue ) {[void](Remove-Item "$savePathTmp\$File" -Force) }
	}
	# Remove empty Folders
	if (Test-Path .\EventLogs) {Remove-Item .\EventLogs -Recurse -Force}
	if (Test-Path .\Perfmon) {Remove-Item .\Perfmon -Recurse -Force}
	if (Test-Path .\RasTracingDir) {Remove-Item .\RasTracingDir -Recurse -Force}

	Copy-Item $ToolsPath`\results_$SDPtech`.xml $savePathTmp`\results_$SDPtech`.xml -Force

	# moved to end before compress: wait for msinfo32 to complete
	if (Get-Process msinfo32 -EA SilentlyContinue) {Write-Host "$(Get-Date -UFormat "%R:%S") ...waiting on MsInfo32 to complete"}
	do
	{
		$isDone = Get-Process msinfo32 -EA SilentlyContinue
		Start-Sleep -Seconds 2
	} until ($isDone -eq $null -or (Get-Date) -gt $start_info32.AddMinutes(3))

	if (Test-Path $ScriptParentPath\stdout*.log) {Move-Item $ScriptParentPath\stdout*.log $savePathTmp -Force}

	$CheckDate = (Get-Date -UFormat "%Y-%m-%d_%R-%S").Replace(":","-")
	
	### begin compress -inner-
	if ($ZipIt.IsPresent) {
		$OutputFileZip = "psSDP_i_$SDPtech`_$ComputerName`_$CheckDate`.zip"
		Write-Host "$(Get-Date -UFormat "%R:%S") ... zipping $OutputFileZip"
		$zipComp = CompressCollectFiles -Recursive -NumberofDays 1 -filesToCollect $savePathTmp -DestinationFileName $OutputFileZip -renameOutput $false -fileDescription "psSDP Logs" -sectionDescription "psSDP data collection" 
		if ($zipComp) {	Write-Verbose "_zipped $OutputFileZip" }
	}

	Stop-Transcript
	
	### begin compress files (zip cab)
	if ($NoCab.IsPresent -ne $true) {
		### Zip file if PowerShell v3 or higher is installed
		if ($Script:PSver -gt 2) { Write-Host "$(Get-Date -UFormat "%R:%S") ... now zipping '$SDPtech' data folder $savePathTmp" }

		$OutputFileZip = "$savePath`\psSDP_$SDPtech`_$ComputerName`_$CheckDate`.zip"
		#if ($Script:PSver -gt 2) { $zipped = Zip-Files -zipfilename $OutputFileZip -sourcedir $savePathTmp -Verbose -overwrite $true }
		if ($Script:PSver -gt 2) { $zipped = Create-ZipFromDirectory -SourceDirectory $savePathTmp -ZipFileName $OutputFileZip -overwrite }
	} ### end zip
	else {Write-Host "`n*** Please zip all results files in $savePathTmp" -ForegroundColor cyan}

	set-location -path $CurrentPath
	if ($zipped) {
	Write-Verbose "_Remove-Item $savePathTmp -Force -Recurse"
	Remove-Item $savePathTmp -Force -Recurse
	Write-Host " [psSDP-Info] done. Resulting cabinet: $OutputFileZip" -ForegroundColor green
	}
}


 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
 if ($Script:PSver -gt 2) { Unblock-File -Path $ScriptParentPath\Get-psSDP.ps1 -ErrorAction SilentlyContinue }
 Write-Host "`n [psSDP-Info] in case you see any red error messages regarding signing, open an Admin Powershell CMD and run this command first:
 	 Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force `n" -ForegroundColor gray

# Reset original ExecutionPolicy
Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy $ExecPolicyOrig -Force

$end = Get-Date
$Duration = $end - $start
Write-Host -BackgroundColor Gray -ForegroundColor Black -Object "$(Get-Date -UFormat "%R:%S") Done on this PC $env:COMPUTERNAME; script Get-psSDP '$SDPtech' version v$VerMa.$VerMi took $($Duration)"

<#
Files collected within SDP report:
- "Net","Dom","CTS","Print","HyperV","Perf","Setup","Cluster","Mini","Nano"

 2027424	[SDP 3][d92078bc-87a3-492b-978e-1f91d4eaaed9] Windows Printing
  http://support.microsoft.com/kb/2027424/EN-US
 2224427	[SDP 2][9B947211-ED5B-4BAE-85A5-823B8718DB59] Setup - Windows XP, Server 2003, Windows Vista, and Windows Server 2008 MSDT manifest
  http://support.microsoft.com/kb/2224427/EN-US
 2415016	[SDP 3][62ec9a58-1f9e-4550-b65c-87827221dd05] FailoverCluster Multinode troubleshooter for Windows Server
  http://support.microsoft.com/kb/2415016/EN-US


VERSION and AUTHORs:
        Ver 1.00 - 12.03.2017
	Walter Eder	- waltere@microsoft.com

HISTORY
	2016-09-23  v1.00
	2017-03-11  v1.02 commented original SDP *.ps1 files with: #_#Write-DiagProgress -activity, + #_#Run-DiagExpression,+ #_#Run-DiagExpression --> undo, Filter/functions are in utils_Remote.ps1
	 ??some older DC_* files have incorrect REG parts, missing "," at end of line:
	  DC_DirectAccessClient-Component.ps1: 	corrected error in REG part of $CurrentVersionKeys = "HKLM\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient",	< missing ","
	  DC_RegistrySetupPerf.ps1: 			corrected error in REG part of $StartupKeys = "HKCU\Software\Microsoft\Windows NT\CurrentVersion"" < missing ","
	  DC_RegistrySetupPerf.ps1 				corrected error in REG part of $PoliciesKeys
	2017-03-14  v1.03 created standalone offline package psSDP-offline.zip
	2017-03-18  v1.04 DC_W32Time.ps1 corrected error "Copy-Item : Cannot overwrite the item .\Results\computername_W32Time_Reg_Key.txt with itself." \utils_Remote.ps1:297
				Win10 Fixes in networking *.ps1: replace : $bn = $wmiOSVersion.BuildNumber - with: [int]$bn = [int]$wmiOSVersion.BuildNumber
				corrected in TS_AutoAddCommands_CTS.ps1: Run-DiagExpression .\DC_ExchangeServerEventLogs.ps1
	2017-03-20	v1.05 DC_IPsec-Component, DC_DirectAccessServer-Component.ps1 : not running "Get-NetIPsecDospSetting" on Win8+,Win10 client;
				DC_HyperVNetworking.ps1: not running "Get-NetNat*" not running "Get-NetIPsecDospSetting" on Win8+ client;
				DC_NetdomFSMO.ps1: Netdom.exe -- -or ($bn -ge 9200)) #_# netdom.exe not running on W8+
				TS_DFSRRootCausesCheck.ps1: -- $SysvolRG = get-itemproperty -path Registry::"HKLM\SYSTEM\CurrentControlSet\Services\Netlogon\Parameters" -name SysVol -ErrorAction SilentlyContinue #_#
				DC_IPsec-Component.ps1, DC_HyperVNetworking.ps1 #_#
	2018-06-15	v1.06 DC_DirectAccessClient-Component.ps1 DirectAccessConnectivityAssistant < missing ","
				DC_ProxyConfiguration.ps1 - suppress output of HKU; DC_RAS-Component.ps1 suppress output of Compress RasTracingFiles
				removed HTM in DC_UpdateHistory.ps1 $OutputFormats= @("TXT", "CSV", "HTM")
	
	ToDo: handle utils_Remote.ps1:Function Get-DiagInput :: in DC_CollectSecurityEventLog.ps1 (done), DC_DfsrInfo.ps1, DC_HyperVReplica.ps1, DC_ServerCoreR2Setup.ps1, TS_RemoteSetup.ps1
		- only run once CTS report, else errors: New-Variable : Cannot overwrite variable SQL:PSSDIAGXML because it is read-only or constant.
		- Cluster report

#>
